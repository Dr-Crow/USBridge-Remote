// SPDX-License-Identifier: GPL-3.0-only
// Package streamer joins the independent session and media implementations.
// Authentication/pairing belongs to the agent that owns the private stdin pipe.
package streamer

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"net"
	"path/filepath"
	"regexp"

	"github.com/Dr-Crow/rustshine-research/source/gamestreamvideo"
	"github.com/Dr-Crow/rustshine-research/source/media"
)

const MaxConfigBytes = 64 << 10
const Profile = "source-streamer-v1"

// Config must arrive through a private, authenticated supervisor channel. The
// launch key is secret, fresh per launch, and never placed in argv or output.
// V1 is intentionally loopback-only: an agent must separately authorize any
// remote forwarding. Silence is explicit and is not native audio capture.
type Config struct {
	SchemaVersion  int    `json:"schema_version"`
	Owner          string `json:"owner"`
	SessionID      string `json:"session_id"`
	KeyB64         string `json:"key_b64"`
	KeyID          uint32 `json:"key_id"`
	PeerIP         string `json:"peer_ip"`
	VideoPort      int    `json:"video_port"`
	AudioPort      int    `json:"audio_port"`
	Display        string `json:"display"`
	CaptureConsent bool   `json:"capture_consent"`
	InputConsent   bool   `json:"input_consent,omitempty"`
	FFmpeg         string `json:"ffmpeg"`
	Width          int    `json:"width"`
	Height         int    `json:"height"`
	FPS            int    `json:"fps"`
	PixelFormat    string `json:"pixel_format"`
	PacketSize     int    `json:"packet_size"`
	AudioMode      string `json:"audio_mode"`
	MaxSeconds     int    `json:"max_seconds"`
}

var sessionID = regexp.MustCompile(`^[A-Za-z0-9_-]{1,128}$`)

func (c Config) Pattern() media.Pattern {
	return media.Pattern{Width: c.Width, Height: c.Height, FPS: c.FPS, Frames: 1, PixelFormat: c.PixelFormat}
}

// Validate does not open a socket, capture a display or execute an encoder.
func (c Config) Validate() error {
	if c.SchemaVersion != 1 || len(c.Owner) == 0 || len(c.Owner) > 256 || !sessionID.MatchString(c.SessionID) {
		return errors.New("invalid launch schema, owner or session identifier")
	}
	if c.PeerIP != "127.0.0.1" || !net.ParseIP(c.PeerIP).IsLoopback() {
		return errors.New("v1 requires explicit IPv4 loopback peer")
	}
	if c.VideoPort < 0 || c.VideoPort > 65535 || c.AudioPort < 0 || c.AudioPort > 65535 || (c.VideoPort != 0 && c.VideoPort == c.AudioPort) {
		return errors.New("distinct media ports or zero for token-bound rendezvous required")
	}
	if !c.CaptureConsent || media.ValidateX11Display(c.Display) != nil {
		return errors.New("explicit local X11 display and capture consent required")
	}
	if !filepath.IsAbs(c.FFmpeg) {
		return errors.New("absolute trusted FFmpeg path required")
	}
	if c.AudioMode != "silence" {
		return errors.New("only explicit synthesized silence is currently supported")
	}
	if c.MaxSeconds < 1 || c.MaxSeconds > 300 {
		return errors.New("launch duration must be 1..300 seconds")
	}
	if err := c.Pattern().Validate(); err != nil {
		return err
	}
	if _, err := gamestreamvideo.NewPlainPacketizer(c.PacketSize); err != nil {
		return err
	}
	key, err := base64.StdEncoding.Strict().DecodeString(c.KeyB64)
	if err != nil || len(key) != 16 {
		return errors.New("fresh 16-byte base64 launch key required")
	}
	return nil
}

// DecodeConfig accepts exactly one JSON object. Duplicate fields are rejected
// as well as unknown fields, to avoid different supervisor/child interpretations.
func DecodeConfig(data []byte) (Config, error) {
	var c Config
	if len(data) == 0 || len(data) > MaxConfigBytes {
		return c, errors.New("launch config exceeds size limit")
	}
	scan := json.NewDecoder(bytes.NewReader(data))
	tok, err := scan.Token()
	if err != nil || tok != json.Delim('{') {
		return c, errors.New("launch config must be an object")
	}
	seen := map[string]bool{}
	for scan.More() {
		tok, err = scan.Token()
		if err != nil {
			return c, errors.New("invalid launch config")
		}
		key, ok := tok.(string)
		if !ok || seen[key] {
			return c, errors.New("duplicate launch config field")
		}
		seen[key] = true
		var value json.RawMessage
		if err = scan.Decode(&value); err != nil {
			return c, errors.New("invalid launch config")
		}
	}
	if _, err = scan.Token(); err != nil {
		return c, errors.New("invalid launch config")
	}
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err = decoder.Decode(&c); err != nil {
		return Config{}, errors.New("invalid or unsupported launch config field")
	}
	var extra any
	if err = decoder.Decode(&extra); err != io.EOF {
		return Config{}, errors.New("one launch object required")
	}
	if err = c.Validate(); err != nil {
		return Config{}, err
	}
	return c, nil
}
