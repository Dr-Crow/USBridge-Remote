//go:build linux && cgo

// SPDX-License-Identifier: GPL-3.0-only
package input

import (
	"bufio"
	"context"
	_ "embed"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"
)

//go:embed testdata/x11_probe.py
var nativeProbe string

type snapshot struct {
	X, Y     int
	Mask     uint
	AHeld    bool `json:"a_held"`
	CtrlHeld bool `json:"ctrl_held"`
	ACode    int  `json:"a_code"`
	Events   [][3]int
}

// TestNativeX11 is deliberately opt-in and always starts a new isolated Xvfb.
// It neither reads DISPLAY nor attaches to an existing desktop. Missing native
// prerequisites and Xvfb startup errors fail (rather than silently skip) once
// SOURCE_INPUT_X11_TEST=1 has requested native acceptance.
func TestNativeX11(t *testing.T) {
	if os.Getenv("SOURCE_INPUT_X11_TEST") != "1" {
		t.Skip("set SOURCE_INPUT_X11_TEST=1 for isolated Xvfb/XTest acceptance")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	xvfb := os.Getenv("SOURCE_INPUT_XVFB")
	if xvfb == "" {
		xvfb = "Xvfb"
	}
	read, write, err := os.Pipe()
	if err != nil {
		t.Fatal(err)
	}
	defer read.Close()
	defer write.Close()
	log, err := os.Create(filepath.Join(t.TempDir(), "xvfb.log"))
	if err != nil {
		t.Fatal(err)
	}
	defer log.Close()
	server := exec.CommandContext(ctx, xvfb, "-displayfd", "3", "-screen", "0", "320x240x24", "-nolisten", "tcp", "-noreset")
	server.ExtraFiles = []*os.File{write}
	server.Stdout = log
	server.Stderr = log
	server.WaitDelay = time.Second
	if err = server.Start(); err != nil {
		t.Fatal(err)
	}
	stopped := false
	stop := func() {
		if !stopped {
			_ = server.Process.Kill()
			_ = server.Wait()
			stopped = true
		}
	}
	defer stop()
	_ = write.Close()
	ready := make(chan string, 1)
	go func() { line, _ := bufio.NewReader(read).ReadString('\n'); ready <- strings.TrimSpace(line) }()
	var display string
	select {
	case number := <-ready:
		n, err := strconv.Atoi(number)
		if err != nil || n < 0 || n > 65535 {
			stop()
			data := make([]byte, 4096)
			n, _ := log.ReadAt(data, 0)
			t.Fatalf("isolated Xvfb failed to start: %.4096s", data[:n])
		}
		display = ":" + number
	case <-ctx.Done():
		stop()
		data := make([]byte, 4096)
		n, _ := log.ReadAt(data, 0)
		t.Fatalf("isolated Xvfb readiness: %v: %.4096s", ctx.Err(), data[:n])
	}
	probe := exec.CommandContext(ctx, "python3", "-c", nativeProbe, display)
	probe.Stderr = log
	probe.WaitDelay = time.Second
	in, err := probe.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	out, err := probe.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	if err = probe.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = in.Close(); _ = probe.Process.Kill(); _ = probe.Wait() }()
	lines := bufio.NewReader(out)
	line, err := lines.ReadString('\n')
	if err != nil || !strings.Contains(line, `"ready": true`) {
		t.Fatalf("observer start: %q %v", line, err)
	}
	take := func() snapshot {
		t.Helper()
		if _, err := io.WriteString(in, "snapshot\n"); err != nil {
			t.Fatal(err)
		}
		line, err := lines.ReadString('\n')
		if err != nil {
			t.Fatal(err)
		}
		var s snapshot
		if err = json.Unmarshal([]byte(line), &s); err != nil {
			t.Fatal(err)
		}
		return s
	}
	b, err := New(display, true)
	if err != nil {
		t.Fatal(err)
	}
	defer b.Close()
	if _, err := New(display, true); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("simultaneous native backend accepted: %v", err)
	}
	// Reference maxima 639x479 scale precisely onto Xvfb maxima 319x239.
	handle(t, b, record(5, 0x02, 0x7f, 0x01, 0xdf, 0, 0, 0x02, 0x7f, 0x01, 0xdf))
	if s := take(); s.X != 319 || s.Y != 239 {
		t.Fatalf("absolute edge scaling: %+v", s)
	}
	handle(t, b, record(5, 0, 0, 0, 0, 0, 0, 0x02, 0x7f, 0x01, 0xdf))
	handle(t, b, record(7, 0, 5, 0, 3))
	if s := take(); s.X != 5 || s.Y != 3 {
		t.Fatalf("relative mouse: %+v", s)
	}
	handle(t, b, keyboard(0xa3, true, 2))
	handle(t, b, keyboard(0x41, true, 2))
	handle(t, b, record(8, 1))
	s := take()
	if !s.AHeld || !s.CtrlHeld || s.Mask&(1<<8) == 0 {
		t.Fatalf("native held state: %+v", s)
	}
	keyDown, buttonDown := false, false
	for _, e := range s.Events {
		if e[0] == 2 && e[1] == s.ACode && e[2]&4 != 0 {
			keyDown = true
		}
		if e[0] == 4 && e[1] == 1 {
			buttonDown = true
		}
	}
	if !keyDown || !buttonDown {
		t.Fatalf("actual key/button events missing: %+v", s)
	}
	handle(t, b, keyboard(0x41, false, 2))
	handle(t, b, keyboard(0xa3, false, 0))
	handle(t, b, record(9, 1))
	s = take()
	if s.AHeld || s.CtrlHeld || s.Mask&(1<<8) != 0 {
		t.Fatalf("explicit native releases: %+v", s)
	}
	handle(t, b, scroll(60, false))
	handle(t, b, scroll(60, false))
	handle(t, b, scroll(-120, false))
	handle(t, b, scroll(120, true))
	handle(t, b, scroll(-120, true))
	s = take()
	var buttonEvents []string
	for _, e := range s.Events {
		if e[0] == 4 || e[0] == 5 {
			buttonEvents = append(buttonEvents, fmt.Sprintf("%d:%d", e[0], e[1]))
		}
	}
	if got := strings.Join(buttonEvents, ","); got != "4:4,5:4,4:5,5:5,4:7,5:7,4:6,5:6" {
		t.Fatalf("native scroll order/sign: %s", got)
	}
	for _, button := range []byte{2, 3, 4, 5} {
		handle(t, b, record(8, button))
		handle(t, b, record(9, button))
	}
	s = take()
	buttonEvents = nil
	for _, e := range s.Events {
		if e[0] == 4 || e[0] == 5 {
			buttonEvents = append(buttonEvents, fmt.Sprintf("%d:%d", e[0], e[1]))
		}
	}
	if got := strings.Join(buttonEvents, ","); got != "4:2,5:2,4:3,5:3,4:8,5:8,4:9,5:9" {
		t.Fatalf("native button mapping: %s", got)
	}
	// Close without receiving ups must visibly release every owned key/button.
	handle(t, b, keyboard(0x41, true, 0))
	handle(t, b, record(8, 1))
	_ = take()
	if err = b.Close(); err != nil {
		t.Fatal(err)
	}
	s = take()
	if s.AHeld || s.Mask&(1<<8) != 0 {
		t.Fatalf("close left held input: %+v", s)
	}
	keyUp, buttonUp := false, false
	for _, e := range s.Events {
		keyUp = keyUp || (e[0] == 3 && e[1] == s.ACode)
		buttonUp = buttonUp || (e[0] == 5 && e[1] == 1)
	}
	if !keyUp || !buttonUp {
		t.Fatalf("close release events missing: %+v", s)
	}
	// Parser error also performs real release and makes the backend terminal.
	b, err = New(display, true)
	if err != nil {
		t.Fatal(err)
	}
	defer b.Close()
	handle(t, b, keyboard(0x41, true, 0))
	handle(t, b, record(8, 1))
	_ = take()
	if err = b.Handle(ctx, record(8, 0)); !errors.Is(err, ErrMalformed) {
		t.Fatal(err)
	}
	s = take()
	if s.AHeld || s.Mask&(1<<8) != 0 {
		t.Fatalf("malformed input left held state: %+v", s)
	}
	// A disappearing display is an error, never Xlib's default process exit.
	b, err = New(display, true)
	if err != nil {
		t.Fatal(err)
	}
	defer b.Close()
	stop()
	if err = b.Handle(ctx, record(7, 0, 1, 0, 1)); err == nil {
		t.Fatal("server loss was not reported")
	}
	if err = b.Handle(ctx, record(7, 0, 1, 0, 1)); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
}

func TestNativeBuildAvailable(t *testing.T) {
	if !Available() {
		t.Fatal("Linux/cgo backend not advertised")
	}
}
