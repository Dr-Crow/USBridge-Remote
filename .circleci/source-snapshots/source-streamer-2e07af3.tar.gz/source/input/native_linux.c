//go:build linux && cgo

// SPDX-License-Identifier: GPL-3.0-only
// Header-free adapter to the stable public Xlib/XTest ABI. These declarations
// contain no private Display layout and require only the runtime shared objects.
#include "native_linux.h"
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct _XDisplay Display;
typedef unsigned long Window;
typedef struct {
    int type;
    Display *display;
    unsigned long resourceid;
    unsigned long serial;
    unsigned char error_code;
    unsigned char request_code;
    unsigned char minor_code;
} XErrorEvent;
typedef int (*ErrorHandler)(Display *, XErrorEvent *);
typedef int (*IOHandler)(Display *);
struct source_x11 { Display *display; int screen; int error; int dead; };
static struct {
    void *x11, *xtst;
    int initialized;
    int (*init_threads)(void);
    Display *(*open)(const char *);
    int (*close)(Display *);
    int (*sync)(Display *, int);
    int (*screen)(Display *);
    Window (*root)(Display *, int);
    int (*geometry)(Display *, Window, Window *, int *, int *, unsigned *, unsigned *, unsigned *, unsigned *);
    unsigned char (*keycode)(Display *, unsigned long);
    ErrorHandler (*set_error)(ErrorHandler);
    IOHandler (*set_io_error)(IOHandler);
    void (*set_io_exit)(Display *, void (*)(Display *,void *), void *);
    int (*query)(Display *, int *, int *, int *, int *);
    int (*key)(Display *, unsigned int, int, unsigned long);
    int (*button)(Display *, unsigned int, int, unsigned long);
    int (*relative)(Display *, int, int, unsigned long);
    int (*absolute)(Display *, int, int, int, unsigned long);
    ErrorHandler previous_error;
    IOHandler previous_io;
} api;
// All entry points are protected by nativeMu in Go. TLS associates synchronous
// callbacks with this call without consuming errors from unrelated Xlib users.
static _Thread_local source_x11 *active;
static int on_error(Display *d, XErrorEvent *e) {
    if (active && active->display == d) { active->error = e->error_code; return 0; }
    return api.previous_error ? api.previous_error(d,e) : 0;
}
static int on_io_error(Display *d) {
    if (active && active->display == d) { active->dead = 1; return 0; }
    return api.previous_io ? api.previous_io(d) : 0;
}
static void on_io_exit(Display *d, void *data) {
    (void)d;
    ((source_x11 *)data)->dead = 1;
}
static int load(char *error, unsigned long size) {
    if (api.initialized) return 1;
    api.x11 = dlopen("libX11.so.6", RTLD_NOW | RTLD_LOCAL);
    api.xtst = dlopen("libXtst.so.6", RTLD_NOW | RTLD_LOCAL);
    if (!api.x11 || !api.xtst) { snprintf(error,size,"libX11.so.6 and libXtst.so.6 are required"); goto fail; }
#define LOAD(lib, field, symbol) do { \
    *(void **)(&api.field) = dlsym(api.lib,symbol); \
    if (!api.field) { snprintf(error,size,"missing runtime X11 symbol %s",symbol); goto fail; } \
} while (0)
    LOAD(x11,init_threads,"XInitThreads");
    LOAD(x11,open,"XOpenDisplay"); LOAD(x11,close,"XCloseDisplay");
    LOAD(x11,sync,"XSync"); LOAD(x11,screen,"XDefaultScreen");
    LOAD(x11,root,"XRootWindow"); LOAD(x11,geometry,"XGetGeometry");
    LOAD(x11,keycode,"XKeysymToKeycode");
    LOAD(x11,set_error,"XSetErrorHandler"); LOAD(x11,set_io_error,"XSetIOErrorHandler");
    // Require a runtime whose I/O handler need not exit the entire Go server.
    LOAD(x11,set_io_exit,"XSetIOErrorExitHandler");
    LOAD(xtst,query,"XTestQueryExtension"); LOAD(xtst,key,"XTestFakeKeyEvent");
    LOAD(xtst,button,"XTestFakeButtonEvent");
    LOAD(xtst,relative,"XTestFakeRelativeMotionEvent");
    LOAD(xtst,absolute,"XTestFakeMotionEvent");
#undef LOAD
    if (!api.init_threads()) { snprintf(error,size,"XInitThreads failed"); goto fail; }
    api.previous_error = api.set_error(on_error);
    api.previous_io = api.set_io_error(on_io_error);
    api.initialized = 1;
    // Keep libraries loaded while installed process-wide callbacks exist.
    return 1;
fail:
    if (api.xtst) dlclose(api.xtst);
    if (api.x11) dlclose(api.x11);
    api.xtst = api.x11 = NULL;
    return 0;
}
source_x11 *source_x11_open(const char *display, char *error, unsigned long size) {
    if (!load(error,size)) return NULL;
    source_x11 *x = calloc(1,sizeof(*x));
    if (!x) { snprintf(error,size,"X11 allocation failed"); return NULL; }
    x->display = api.open(display);
    if (!x->display) { snprintf(error,size,"cannot open the selected X11 display"); free(x); return NULL; }
    active = x;
    api.set_io_exit(x->display,on_io_exit,x);
    x->screen = api.screen(x->display);
    int event,error_base,major,minor;
    int ok = api.query(x->display,&event,&error_base,&major,&minor);
    api.sync(x->display,0);
    if (!ok || x->error || x->dead || major < 2 || (major == 2 && minor < 2)) {
        snprintf(error,size,"selected display requires XTEST 2.2 or later");
        api.close(x->display); active = NULL; free(x); return NULL;
    }
    active = NULL;
    return x;
}
static int begin(source_x11 *x) {
    if (!x || !x->display || x->dead) return 0;
    active = x; x->error = 0; return 1;
}
static int end(source_x11 *x, int ok) {
    if (!x->dead) api.sync(x->display,0);
    int result = ok && !x->error && !x->dead;
    active = NULL;
    return result ? 0 : -1;
}
int source_x11_dimensions(source_x11 *x, int *width, int *height) {
    if (!begin(x)) return -1;
    Window root; int left,top; unsigned w,h,border,depth;
    int ok = api.geometry(x->display,api.root(x->display,x->screen),&root,&left,&top,&w,&h,&border,&depth);
    if (ok) { *width=(int)w; *height=(int)h; }
    return end(x,ok);
}
int source_x11_keycode(source_x11 *x, uint32_t sym, unsigned char *code) {
    if (!begin(x)) return -1;
    *code = api.keycode(x->display,(unsigned long)sym);
    return end(x,1);
}
int source_x11_key(source_x11 *x, unsigned char code, int down) {
    if (!begin(x)) return -1;
    return end(x,api.key(x->display,code,down,0));
}
int source_x11_button(source_x11 *x, unsigned char button, int down) {
    if (!begin(x)) return -1;
    return end(x,api.button(x->display,button,down,0));
}
int source_x11_relative(source_x11 *x, int dx, int dy) {
    if (!begin(x)) return -1;
    return end(x,api.relative(x->display,dx,dy,0));
}
int source_x11_absolute(source_x11 *x, int left, int top) {
    if (!begin(x)) return -1;
    return end(x,api.absolute(x->display,x->screen,left,top,0));
}
int source_x11_close(source_x11 *x) {
    if (!x) return 0;
    active = x;
    // Modern Xlib allows the per-display exit callback to return; close frees
    // connection storage even when the display's I/O-error flag has been set.
    api.close(x->display);
    int result = (x->error || x->dead) ? -1 : 0;
    active = NULL; free(x);
    return result;
}
