//go:build linux && cgo

// SPDX-License-Identifier: GPL-3.0-only
package input

/*
#cgo LDFLAGS: -ldl
#include <stdlib.h>
#include "native_linux.h"
*/
import "C"

import (
	"fmt"
	"sync"
	"unsafe"
)

// Xlib initialization and package-owned display operations have one owner at a
// time, independently of the per-Backend application-state mutex.
var nativeMu sync.Mutex
var nativeOpen bool

type native struct{ ptr *C.source_x11 }

func newNative(display string) (injector, error) {
	nativeMu.Lock()
	defer nativeMu.Unlock()
	if nativeOpen {
		return nil, fmt.Errorf("%w: one active X11 input backend is permitted per process", ErrUnavailable)
	}
	name := C.CString(display)
	defer C.free(unsafe.Pointer(name))
	var message [256]C.char
	ptr := C.source_x11_open(name, &message[0], C.ulong(len(message)))
	if ptr == nil {
		return nil, fmt.Errorf("%w: %s", ErrUnavailable, C.GoString(&message[0]))
	}
	nativeOpen = true
	return &native{ptr: ptr}, nil
}
func nativeResult(code C.int) error {
	if code != 0 {
		return fmt.Errorf("%w: X11 input operation failed", ErrUnavailable)
	}
	return nil
}
func (n *native) dimensions() (int, int, error) {
	nativeMu.Lock()
	defer nativeMu.Unlock()
	var w, h C.int
	err := nativeResult(C.source_x11_dimensions(n.ptr, &w, &h))
	return int(w), int(h), err
}
func (n *native) keycode(sym uint32) (uint8, error) {
	nativeMu.Lock()
	defer nativeMu.Unlock()
	var code C.uchar
	err := nativeResult(C.source_x11_keycode(n.ptr, C.uint32_t(sym), &code))
	return uint8(code), err
}
func truth(v bool) C.int {
	if v {
		return 1
	}
	return 0
}
func (n *native) key(code uint8, down bool) error {
	nativeMu.Lock()
	defer nativeMu.Unlock()
	return nativeResult(C.source_x11_key(n.ptr, C.uchar(code), truth(down)))
}
func (n *native) button(button uint8, down bool) error {
	nativeMu.Lock()
	defer nativeMu.Unlock()
	return nativeResult(C.source_x11_button(n.ptr, C.uchar(button), truth(down)))
}
func (n *native) relative(x, y int) error {
	nativeMu.Lock()
	defer nativeMu.Unlock()
	return nativeResult(C.source_x11_relative(n.ptr, C.int(x), C.int(y)))
}
func (n *native) absolute(x, y int) error {
	nativeMu.Lock()
	defer nativeMu.Unlock()
	return nativeResult(C.source_x11_absolute(n.ptr, C.int(x), C.int(y)))
}
func (n *native) close() error {
	nativeMu.Lock()
	defer nativeMu.Unlock()
	ptr := n.ptr
	n.ptr = nil
	err := nativeResult(C.source_x11_close(ptr))
	if ptr != nil {
		nativeOpen = false
	}
	return err
}

// Available reports compile-time support, not installed libraries or display
// access. New must still validate separate consent and runtime availability.
func Available() bool { return true }
