//go:build !linux || !cgo

// SPDX-License-Identifier: GPL-3.0-only
package input

func newNative(string) (injector, error) { return nil, ErrUnavailable }

// Available reports whether this build includes the Linux/cgo backend.
func Available() bool { return false }
