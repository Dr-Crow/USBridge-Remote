// SPDX-License-Identifier: GPL-3.0-only
// Package input injects a bounded modern Moonlight keyboard/mouse profile into
// an explicitly selected, separately consented local X11 display. It does not
// authenticate packets: callers must authenticate and reject replays first.
package input

import (
	"context"
	"errors"
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"sync"
)

var (
	ErrConsent     = errors.New("explicit input-injection consent required")
	ErrDisplay     = errors.New("explicit local X11 display required, such as :99")
	ErrUnavailable = errors.New("X11 input backend unavailable")
	ErrMalformed   = errors.New("malformed Moonlight input")
	ErrUnsupported = errors.New("unsupported Moonlight input")
	ErrClosed      = errors.New("input backend closed")
)

var localDisplay = regexp.MustCompile(`^:[0-9]{1,5}(\.[0-9]{1,2})?$`)

func validateDisplay(display string) error {
	if !localDisplay.MatchString(display) {
		return ErrDisplay
	}
	parts := strings.Split(display[1:], ".")
	n, _ := strconv.Atoi(parts[0])
	if n > 65535 {
		return ErrDisplay
	}
	if len(parts) == 2 {
		n, _ = strconv.Atoi(parts[1])
		if n > 15 {
			return ErrDisplay
		}
	}
	return nil
}

type injector interface {
	dimensions() (int, int, error)
	keycode(uint32) (uint8, error)
	key(uint8, bool) error
	button(uint8, bool) error
	relative(int, int) error
	absolute(int, int) error
	close() error
}

// Backend owns only the keys/buttons it injects. Calls are serialized. It must
// not be copied. The zero value is closed. Close must be called at every session
// exit, including authentication/replay rejection, disconnect and revocation.
// A canceled Handle context or any parsing/device error closes the backend and
// attempts every owned release before returning. A context passed to Handle
// does not replace the caller's session-lifetime cleanup obligation.
type Backend struct {
	mu                            sync.Mutex
	sink                          injector
	keys                          map[uint32]uint8
	buttons                       map[uint8]bool
	scroll                        [2]int
	closed                        bool
	closeErr                      error
	requiredWidth, requiredHeight int
}

// New opens a consented local display. It never reads DISPLAY or chooses an
// active desktop. Capture permission does not imply input-injection consent.
// Linux/cgo and runtime libX11 (with XSetIOErrorExitHandler) plus libXtst are
// required; other builds return ErrUnavailable after validating consent/display.
func New(display string, consent bool) (*Backend, error) {
	if !consent {
		return nil, ErrConsent
	}
	if err := validateDisplay(display); err != nil {
		return nil, err
	}
	sink, err := newNative(display)
	if err != nil {
		return nil, err
	}
	return newBackend(sink), nil
}

func newBackend(sink injector) *Backend {
	return &Backend{sink: sink, keys: make(map[uint32]uint8), buttons: make(map[uint8]bool)}
}

// RequireDisplaySize rejects cropped capture/input mismatches before a launch
// can inject anything, then retains and rechecks the dimensions on every event.
// The initial runtime maps absolute input to the entire
// selected X11 screen; its authorized capture must show that same pixel region.
func (b *Backend) RequireDisplaySize(width, height int) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed || b.sink == nil {
		return ErrClosed
	}
	w, h, err := b.sink.dimensions()
	if err != nil {
		return errors.Join(err, b.closeLocked())
	}
	if width <= 0 || height <= 0 || width > 32768 || height > 32768 || w != width || h != height {
		return errors.Join(errors.New("input requires capture of the whole selected X11 screen"), b.closeLocked())
	}
	b.requiredWidth, b.requiredHeight = width, height
	return nil
}

// Handle accepts exactly one already-authenticated modern Moonlight input
// record, including its BE32 size and LE32 magic. Control framing, haptics,
// controllers, raw HID and text injection are not accepted here.
func (b *Backend) Handle(ctx context.Context, payload []byte) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed || b.sink == nil {
		return ErrClosed
	}
	fail := func(err error) error { return errors.Join(err, b.closeLocked()) }
	if ctx == nil {
		return fail(errors.New("input context required"))
	}
	if err := ctx.Err(); err != nil {
		return fail(err)
	}
	e, err := parse(payload)
	if err != nil {
		return fail(err)
	}
	// Capture dimensions are fixed for the authorized launch. A later screen
	// resize must not redirect any event into an uncaptured desktop region.
	if b.requiredWidth != 0 {
		w, h, sizeErr := b.sink.dimensions()
		if sizeErr != nil {
			return fail(sizeErr)
		}
		if w != b.requiredWidth || h != b.requiredHeight {
			return fail(errors.New("X11 screen size changed from the authorized capture region"))
		}
	}
	if err = b.apply(ctx, e); err != nil {
		return fail(err)
	}
	// Cancellation racing with an injection must not leave held state behind.
	if err = ctx.Err(); err != nil {
		return fail(err)
	}
	return nil
}

func (b *Backend) apply(ctx context.Context, e event) error {
	switch e.kind {
	case keyEvent:
		code, held := b.keys[e.keysym]
		if !e.down {
			if !held {
				return nil
			}
			for sym, other := range b.keys {
				if sym != e.keysym && other == code {
					delete(b.keys, e.keysym)
					return nil
				}
			}
			if err := b.sink.key(code, false); err != nil {
				return err
			}
			delete(b.keys, e.keysym)
			return nil
		}
		if !held {
			var err error
			code, err = b.sink.keycode(e.keysym)
			if err != nil {
				return err
			}
			if code < 8 {
				return fmt.Errorf("%w: unmapped X11 keysym %#x", ErrUnsupported, e.keysym)
			}
			for _, other := range b.keys {
				if other == code {
					b.keys[e.keysym] = code
					return nil
				}
			}
			// Record before calling: a failed synchronization may follow delivery.
			b.keys[e.keysym] = code
		}
		return b.sink.key(code, true)
	case buttonEvent:
		if !e.down && !b.buttons[e.button] {
			return nil
		}
		if e.down {
			b.buttons[e.button] = true
		}
		if err := b.sink.button(e.button, e.down); err != nil {
			return err
		}
		if !e.down {
			delete(b.buttons, e.button)
		}
		return nil
	case relativeEvent:
		return b.sink.relative(e.x, e.y)
	case absoluteEvent:
		// Required dimensions were checked immediately before dispatch. Use
		// that same authorized region rather than re-querying a new scale.
		width, height := b.requiredWidth, b.requiredHeight
		if width == 0 {
			var err error
			width, height, err = b.sink.dimensions()
			if err != nil {
				return err
			}
		}
		if width < 1 || width > 32768 || height < 1 || height > 32768 {
			return errors.New("invalid X11 display dimensions")
		}
		// Wire width/height are inclusive maxima (reference dimensions minus one).
		scale := func(v, maximum, size int) int {
			if maximum == 0 {
				return 0
			}
			return int((int64(v)*int64(size-1) + int64(maximum)/2) / int64(maximum))
		}
		return b.sink.absolute(scale(e.x, e.width, width), scale(e.y, e.height, height))
	case scrollEvent:
		axis := 0
		if e.horizontal {
			axis = 1
		}
		b.scroll[axis] += e.amount
		for b.scroll[axis] >= 120 || b.scroll[axis] <= -120 {
			if err := ctx.Err(); err != nil {
				return err
			}
			button, step := uint8(4), 120
			if b.scroll[axis] < 0 {
				button, step = 5, -120
			}
			// X11: 6=left, 7=right; positive Moonlight horizontal means right.
			if e.horizontal {
				if step > 0 {
					button = 7
				} else {
					button = 6
				}
			}
			b.buttons[button] = true
			if err := b.sink.button(button, true); err != nil {
				return err
			}
			if err := b.sink.button(button, false); err != nil {
				return err
			}
			delete(b.buttons, button)
			b.scroll[axis] -= step
		}
		return nil
	default:
		return ErrUnsupported
	}
}

// Close attempts to release every owned key and button even if one release
// fails, then closes the display. It is idempotent and preserves cleanup errors.
func (b *Backend) Close() error {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.closeLocked()
}

func (b *Backend) closeLocked() error {
	if b.closed {
		return b.closeErr
	}
	b.closed = true
	if b.sink == nil {
		return nil
	}
	var errs []error
	// Deterministic native-code order also collapses aliases of one X11 keycode.
	var codes [256]bool
	for _, code := range b.keys {
		codes[code] = true
	}
	for code, held := range codes {
		if held {
			if err := b.sink.key(uint8(code), false); err != nil {
				errs = append(errs, err)
			}
		}
	}
	for button := uint8(1); button <= 9; button++ {
		if b.buttons[button] {
			if err := b.sink.button(button, false); err != nil {
				errs = append(errs, err)
			}
		}
	}
	if err := b.sink.close(); err != nil {
		errs = append(errs, err)
	}
	clear(b.keys)
	clear(b.buttons)
	b.scroll = [2]int{}
	b.sink = nil
	b.closeErr = errors.Join(errs...)
	return b.closeErr
}
