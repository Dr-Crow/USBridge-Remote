// SPDX-License-Identifier: GPL-3.0-only
#ifndef SOURCE_INPUT_NATIVE_H
#define SOURCE_INPUT_NATIVE_H
#include <stdint.h>
typedef struct source_x11 source_x11;
source_x11 *source_x11_open(const char *display, char *error, unsigned long size);
int source_x11_dimensions(source_x11 *, int *, int *);
int source_x11_keycode(source_x11 *, uint32_t, unsigned char *);
int source_x11_key(source_x11 *, unsigned char, int);
int source_x11_button(source_x11 *, unsigned char, int);
int source_x11_relative(source_x11 *, int, int);
int source_x11_absolute(source_x11 *, int, int);
int source_x11_close(source_x11 *);
#endif
