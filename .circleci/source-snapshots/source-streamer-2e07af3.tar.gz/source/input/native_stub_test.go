//go:build !linux || !cgo

// SPDX-License-Identifier: GPL-3.0-only
package input

import (
	"errors"
	"testing"
)

func TestUnavailablePlatform(t *testing.T) {
	if Available() {
		t.Fatal("stub backend advertised as available")
	}
	if _, err := New(":99", true); !errors.Is(err, ErrUnavailable) {
		t.Fatal(err)
	}
}
