// SPDX-License-Identifier: GPL-3.0-only
package input

import (
	"encoding/binary"
	"fmt"
)

type eventKind uint8

const (
	keyEvent eventKind = iota + 1
	buttonEvent
	relativeEvent
	absoluteEvent
	scrollEvent
)

type event struct {
	kind                eventKind
	down                bool
	keysym              uint32
	button              uint8
	x, y, width, height int
	amount              int
	horizontal          bool
}

// Validate checks the supported bounded input profile without opening or
// affecting an operating-system device. View-only sessions use it to safely
// ignore authenticated client input, including the automatic cursor wake pair.
func Validate(p []byte) error { _, err := parse(p); return err }

func parse(p []byte) (event, error) {
	bad := func(s string) (event, error) { return event{}, fmt.Errorf("%w: %s", ErrMalformed, s) }
	if len(p) < 8 || len(p) > 18 {
		return bad("record length")
	}
	if binary.BigEndian.Uint32(p[:4]) != uint32(len(p)-4) {
		return bad("size field")
	}
	magic := binary.LittleEndian.Uint32(p[4:8])
	be := func(offset int) int { return int(binary.BigEndian.Uint16(p[offset : offset+2])) }
	signed := func(offset int) int { return int(int16(binary.BigEndian.Uint16(p[offset : offset+2]))) }
	switch magic {
	case 3, 4:
		if len(p) != 14 {
			return bad("keyboard length")
		}
		if p[12] != 0 || p[13] != 0 || p[11]&^byte(0x1f) != 0 {
			return bad("keyboard reserved fields")
		}
		if p[8] != 0 {
			return event{}, fmt.Errorf("%w: keyboard flags %#x", ErrUnsupported, p[8])
		}
		vk := binary.LittleEndian.Uint16(p[9:11])
		// Moonlight Qt marks VK records with 0x8000. Other high bits are
		// not a valid VK encoding and must not alias an accepted key.
		if vk&0x7f00 != 0 {
			return event{}, fmt.Errorf("%w: virtual key %#x", ErrUnsupported, vk)
		}
		vk &^= 0x8000
		sym, ok := virtualKeysym(vk, p[11]&0x10 != 0)
		if !ok {
			return event{}, fmt.Errorf("%w: virtual key %#x", ErrUnsupported, vk)
		}
		// SHIFT/CTRL/ALT/META are advisory snapshots. Modifier keys must arrive as
		// explicit key events; synthesizing from snapshots can stick right modifiers.
		return event{kind: keyEvent, down: magic == 3, keysym: sym}, nil
	case 7:
		if len(p) != 12 {
			return bad("relative mouse length")
		}
		return event{kind: relativeEvent, x: signed(8), y: signed(10)}, nil
	case 5:
		if len(p) != 18 {
			return bad("absolute mouse length")
		}
		if be(12) != 0 {
			return bad("absolute reserved field")
		}
		x, y, w, h := be(8), be(10), be(14), be(16)
		// Client API uses positive signed-short dimensions, then subtracts one.
		if w > 32766 || h > 32766 || x > w+1 || y > h+1 {
			return bad("absolute coordinates")
		}
		// LiSendMouseMoveAsMousePositionEvent can produce exactly one
		// beyond the wire maxima; its reference dimensions are not minus one.
		x = min(x, w)
		y = min(y, h)
		return event{kind: absoluteEvent, x: x, y: y, width: w, height: h}, nil
	case 8, 9:
		if len(p) != 9 {
			return bad("mouse button length")
		}
		if p[8] < 1 || p[8] > 5 {
			return bad("mouse button index")
		}
		button := p[8]
		if button >= 4 {
			button += 4
		} // Moonlight X1/X2 -> X11 8/9, not wheel 4/5.
		return event{kind: buttonEvent, down: magic == 8, button: button}, nil
	case 10:
		if len(p) != 14 {
			return bad("vertical scroll length")
		}
		if be(8) != be(10) || be(12) != 0 {
			return bad("vertical scroll duplicated/reserved fields")
		}
		return event{kind: scrollEvent, amount: signed(8)}, nil
	case 0x55000001:
		if len(p) != 10 {
			return bad("horizontal scroll length")
		}
		return event{kind: scrollEvent, amount: signed(8), horizontal: true}, nil
	default:
		return event{}, fmt.Errorf("%w: magic %#x", ErrUnsupported, magic)
	}
}

// Windows VK values are mapped explicitly to X keysyms, never used as X keycodes.
// The supported profile uses the server's X keyboard mapping (US-layout fixture).
func virtualKeysym(vk uint16, extended bool) (uint32, bool) {
	if vk >= 0x41 && vk <= 0x5a {
		return uint32(vk + 0x20), true
	}
	if vk >= 0x30 && vk <= 0x39 {
		return uint32(vk), true
	}
	if vk >= 0x60 && vk <= 0x69 {
		return uint32(0xffb0 + vk - 0x60), true
	}
	if vk >= 0x70 && vk <= 0x87 {
		return uint32(0xffbe + vk - 0x70), true
	}
	if vk == 0x0d && extended {
		return 0xff8d, true
	} // KP_Enter
	sym, ok := map[uint16]uint32{
		0x08: 0xff08, 0x09: 0xff09, 0x0c: 0xff0b, 0x0d: 0xff0d,
		0x10: 0xffe1, 0x11: 0xffe3, 0x12: 0xffe9, 0x13: 0xff13,
		0x14: 0xffe5, 0x1b: 0xff1b, 0x20: 0x20, 0x21: 0xff55,
		0x22: 0xff56, 0x23: 0xff57, 0x24: 0xff50, 0x25: 0xff51,
		0x26: 0xff52, 0x27: 0xff53, 0x28: 0xff54, 0x2c: 0xff61,
		0x2d: 0xff63, 0x2e: 0xffff, 0x5b: 0xffeb, 0x5c: 0xffec,
		0x5d: 0xff67, 0x6a: 0xffaa, 0x6b: 0xffab, 0x6c: 0xffac,
		0x6d: 0xffad, 0x6e: 0xffae, 0x6f: 0xffaf, 0x90: 0xff7f,
		0x91: 0xff14, 0xa0: 0xffe1, 0xa1: 0xffe2, 0xa2: 0xffe3,
		0xa3: 0xffe4, 0xa4: 0xffe9, 0xa5: 0xffea,
		0xba: 0x3b, 0xbb: 0x3d, 0xbc: 0x2c, 0xbd: 0x2d, 0xbe: 0x2e,
		0xbf: 0x2f, 0xc0: 0x60, 0xdb: 0x5b, 0xdc: 0x5c, 0xdd: 0x5d,
		0xde: 0x27, 0xe2: 0x3c,
	}[vk]
	return sym, ok
}
