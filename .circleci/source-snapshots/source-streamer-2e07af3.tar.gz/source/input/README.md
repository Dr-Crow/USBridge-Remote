# Consented local X11 input

Analyst-authored experimental Linux input backend, not recovered vendor code.
This package accepts the public modern Moonlight keyboard/mouse record format
only after the integrating session has authenticated its control envelope and
checked authorization and replay state.

```go
backend, err := input.New(":99", inputConsent)
if err != nil { /* fail startup */ }
defer backend.Close() // join cleanup on every session exit
err = backend.Handle(sessionContext, authenticatedInputRecord)
```

`New` takes an explicit local `:display[.screen]` and a separate input-injection
consent boolean. It never selects `DISPLAY`; permission to capture a display
is not permission to control it. Network displays, absent consent, invalid
screens, missing libraries and missing XTEST are errors. `Available()` reports
compile-time Linux/cgo support only; `New` checks runtime support. The session must bind
this object to the same authorized launch as the input packets. This package
has no network listener, pairing implementation, shell execution or vendor
credential handling.

## Supported records

One payload contains one BE32 size (`total bytes - 4`), LE32 magic, and an
exact-length body. Unsupported magic, keyboard flags and virtual keys fail
explicitly. No prefix/trailing data or unused nonzero fields are accepted.

- Modern relative pointer motion: signed BE16 dx/dy
- Absolute pointer motion: BE16 x/y and inclusive reference maxima, scaled to
  the selected X11 screen; a one-pixel reference dimension maps to zero, and
  the public relative-as-absolute sender’s known one-pixel edge overflow is clamped
- Mouse buttons 1–5: left/middle/right/X1/X2 map to X11 1/2/3/8/9
- Keyboard down/up: bare and Moonlight Qt 0x8000-prefixed VK values, with
  explicit Windows-VK-to-X-keysym mapping, then the selected
  server's keysym-to-keycode map; left/right modifiers and extended Enter
- Vertical/horizontal scroll: signed BE16 120-unit notches, with fractional
  deltas accumulated independently per axis; positive vertical goes up and
  positive horizontal goes right

This is an X keysym profile tested with a US keyboard layout. It does not
reconfigure the host layout or implement full physical-scancode normalization.
SHIFT/CTRL/ALT/META snapshot bits are validated but do not synthesize implicit
modifier presses; actual modifier key events are required. Unsupported
non-normalized-key flags, UTF-8 text, controllers, raw HID, touch and pen are
rejected. Haptics-enable startup records belong to the upstream control handler,
not this device sink. Native X11 cannot emit smooth fractional wheel events, so
sub-notch scroll is accumulated until a complete 120-unit notch is available.

## Lifetime and failures

Only one native backend may be open per process, preventing launches from
releasing each other’s owned input. `Handle` and `Close` are serialized, as are
all package-owned Xlib calls. Presses are recorded before native submission because a failed synchronization can
follow successful delivery. Releases for unowned keys/buttons do nothing.
`Close` attempts every owned release, even after individual failures, then
closes the display; repeated closes retain the cleanup result. Any malformed,
unsupported, canceled or failed `Handle` is terminal and performs the same
cleanup. Wheel presses are included in ownership until their release succeeds.

The caller must close on disconnect, authorization revocation, failed packet
authentication, replay rejection and session-context cancellation, including
when no further `Handle` call occurs. In particular, a reliable key-up delayed
beyond the control replay window must cause close/release, not be silently
ignored. This package neither widens nor resets replay state.

Native libraries are loaded at runtime (`libX11.so.6`, `libXtst.so.6`), without
X11 development headers or a link-time X11 dependency. The runtime must expose
`XSetIOErrorExitHandler`; errors from a disappeared X server become terminal
errors rather than Xlib's default process exit after a display is opened. XTEST
2.2 or newer is required. A server disappearing during `XOpenDisplay` can still
trigger Xlib's fatal startup handler before per-display handling is installed.
This happens before this package owns any injected input; the integrating
supervisor must report missing readiness/nonzero exit as a startup failure.
No unsafe `longjmp` recovery is used.
Unavailable/disappeared servers cannot confirm release; cleanup reports failure
rather than claiming success. Xlib operations are synchronous and assume a
responsive local X server. Other platforms and no-cgo builds explicitly return
`ErrUnavailable` and retain parser/unit-test coverage.

## Verification

From `source/`:

```sh
go test -race ./input
go vet ./input
CGO_ENABLED=0 go test ./input
go test ./input -run '^$' -fuzz '^FuzzInputRecord$' -fuzztime=100000x -parallel=2
SOURCE_INPUT_X11_TEST=1 go test -race ./input -run '^TestNativeX11$' -count=1
```

The opt-in native test requires Xvfb, Python 3 and the runtime libraries. It
starts its own virtual display with TCP disabled and uses an independent ctypes
Xlib window to observe actual events and held-state queries. It covers relative
motion, inclusive-max absolute scaling, left/right modifier/key/button mapping,
wheel order/sign, explicit releases, close/error releases and display loss.
The independent observer is embedded into the test binary, so `go test -c`
output can be run from any directory. `SOURCE_INPUT_XVFB` may specify the
trusted Xvfb executable; otherwise Xvfb is resolved from PATH. It never connects to
an existing display. Once opted in, missing prerequisites/startup failures fail
the test rather than silently skip. The current local sandbox disallows Xvfb's
Unix listeners, so native execution must be verified on the CI runner; passing
pure unit/race tests is not evidence of OS injection.

## Public references

Wire layout and sender behavior were independently implemented against pinned
[Input.h](https://github.com/itsme228/moonlight-common-c/blob/e913d516fab11d8fc84a35c7818cea1e455436fa/src/Input.h),
[InputStream.c](https://github.com/itsme228/moonlight-common-c/blob/e913d516fab11d8fc84a35c7818cea1e455436fa/src/InputStream.c)
[Moonlight Qt keyboard sender](https://github.com/moonlight-stream/moonlight-qt/blob/master/app/streaming/input/keyboard.cpp),
and [Limelight.h](https://github.com/itsme228/moonlight-common-c/blob/e913d516fab11d8fc84a35c7818cea1e455436fa/src/Limelight.h).
The native shim uses the documented public Xlib/XTest ABI, with
[Xlib error/exit handling](https://raw.githubusercontent.com/mirror/libX11/master/src/XlibInt.c)
and [display cleanup](https://raw.githubusercontent.com/mirror/libX11/master/src/ClDisplay.c)
checked against upstream source. No upstream implementation is copied here.
