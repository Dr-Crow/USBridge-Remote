// SPDX-License-Identifier: GPL-3.0-only
package input

import (
	"context"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"reflect"
	"strings"
	"sync"
	"testing"
)

func fixture(s string) []byte {
	b, err := hex.DecodeString(strings.ReplaceAll(s, " ", ""))
	if err != nil {
		panic(err)
	}
	return b
}
func record(magic uint32, body ...byte) []byte {
	p := make([]byte, 8+len(body))
	binary.BigEndian.PutUint32(p, uint32(len(p)-4))
	binary.LittleEndian.PutUint32(p[4:], magic)
	copy(p[8:], body)
	return p
}
func keyboard(vk uint16, down bool, modifiers byte) []byte {
	magic := uint32(4)
	if down {
		magic = 3
	}
	return record(magic, 0, byte(vk), byte(vk>>8), modifiers, 0, 0)
}
func scroll(amount int, horizontal bool) []byte {
	n := uint16(int16(amount))
	hi, lo := byte(n>>8), byte(n)
	if horizontal {
		return record(0x55000001, hi, lo)
	}
	return record(10, hi, lo, hi, lo, 0, 0)
}

func TestPublicWireFixtures(t *testing.T) {
	for _, tc := range []struct {
		name, wire string
		want       event
	}{
		{"A down", "0000000a 03000000 00 4100 00 0000", event{kind: keyEvent, down: true, keysym: 'a'}},
		{"A up", "0000000a 04000000 00 4100 00 0000", event{kind: keyEvent, keysym: 'a'}},
		{"Qt A down", "0000000a 03000000 00 4180 00 0000", event{kind: keyEvent, down: true, keysym: 'a'}},
		{"Qt A up", "0000000a 04000000 00 4180 00 0000", event{kind: keyEvent, keysym: 'a'}},
		{"relative", "00000008 07000000 0005 fffd", event{kind: relativeEvent, x: 5, y: -3}},
		{"absolute", "0000000e 05000000 0064 00c8 0000 077f 0437", event{kind: absoluteEvent, x: 100, y: 200, width: 1919, height: 1079}},
		{"relative-as-absolute edge", "0000000e 05000000 0280 01e0 0000 027f 01df", event{kind: absoluteEvent, x: 639, y: 479, width: 639, height: 479}},
		{"left down", "00000005 08000000 01", event{kind: buttonEvent, down: true, button: 1}},
		{"left up", "00000005 09000000 01", event{kind: buttonEvent, button: 1}},
		{"vertical", "0000000a 0a000000 0078 0078 0000", event{kind: scrollEvent, amount: 120}},
		{"horizontal", "00000006 01000055 ff88", event{kind: scrollEvent, amount: -120, horizontal: true}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			p := fixture(tc.wire)
			got, err := parse(p)
			if err != nil || got != tc.want {
				t.Fatalf("got %+v, %v; want %+v", got, err, tc.want)
			}
			for n := 0; n < len(p); n++ {
				if _, err := parse(p[:n]); err == nil {
					t.Fatalf("accepted prefix %d", n)
				}
			}
			extended := append(append([]byte(nil), p...), 0)
			if _, err := parse(extended); err == nil {
				t.Fatal("accepted trailing byte")
			}
			binary.BigEndian.PutUint32(extended, uint32(len(extended)-4))
			if _, err := parse(extended); err == nil {
				t.Fatal("accepted extended body")
			}
		})
	}
}

func TestRejectMalformedAndUnsupported(t *testing.T) {
	valid := keyboard(0x41, true, 0)
	cases := [][]byte{
		nil, {}, make([]byte, 7), make([]byte, 19),
		record(6, 0, 0, 0, 0), record(0x17, 'x'), record(0x0d, 1, 0), record(0x55420001),
		record(8, 0), record(8, 6), record(9, 255),
		record(10, 0, 120, 0, 121, 0, 0), record(10, 0, 120, 0, 120, 0, 1),
		record(5, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0), record(5, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1),
		record(5, 0, 0, 0, 0, 0, 0, 0xff, 0xff, 0, 1),
		keyboard(0xffff, true, 0), keyboard(0x8141, true, 0), keyboard(0x0141, true, 0), keyboard(0x41, true, 0x80), keyboard(0, true, 0),
	}
	for _, index := range []int{0, 4, 8, 12, 13} {
		p := append([]byte(nil), valid...)
		p[index] ^= 0x80
		cases = append(cases, p)
	}
	for _, p := range cases {
		if _, err := parse(p); err == nil {
			t.Errorf("accepted %x", p)
		}
	}
}

func TestSignedAndButtonBounds(t *testing.T) {
	e, err := parse(record(7, 0x80, 0, 0x7f, 0xff))
	if err != nil || e.x != -32768 || e.y != 32767 {
		t.Fatal(e, err)
	}
	for button := byte(1); button <= 5; button++ {
		e, err := parse(record(8, button))
		want := button
		if want >= 4 {
			want += 4
		}
		if err != nil || e.button != want {
			t.Fatal(e, err)
		}
	}
	for _, n := range []int{-32768, -1, 0, 1, 32767} {
		for _, h := range []bool{false, true} {
			e, err := parse(scroll(n, h))
			if err != nil || e.amount != n || e.horizontal != h {
				t.Fatal(e, err)
			}
		}
	}
}

func TestVirtualKeysAndModifiers(t *testing.T) {
	for _, tc := range []struct {
		vk       uint16
		extended bool
		sym      uint32
	}{
		{0x41, false, 'a'}, {0x5a, false, 'z'}, {0x30, false, '0'}, {0x39, false, '9'},
		{0x10, false, 0xffe1}, {0xa0, false, 0xffe1}, {0xa1, false, 0xffe2},
		{0xa2, false, 0xffe3}, {0xa3, false, 0xffe4}, {0xa4, false, 0xffe9}, {0xa5, false, 0xffea},
		{0x5b, false, 0xffeb}, {0x5c, false, 0xffec}, {0x0d, false, 0xff0d}, {0x0d, true, 0xff8d},
		{0x60, false, 0xffb0}, {0x69, false, 0xffb9}, {0x70, false, 0xffbe}, {0x87, false, 0xffd5},
	} {
		sym, ok := virtualKeysym(tc.vk, tc.extended)
		if !ok || sym != tc.sym {
			t.Fatalf("%#x -> %#x, %v", tc.vk, sym, ok)
		}
	}
	for modifiers := byte(0); modifiers < 32; modifiers++ {
		if _, err := parse(keyboard(0x41, true, modifiers)); err != nil {
			t.Fatal(err)
		}
	}
}

type operation struct {
	kind string
	a, b int
	down bool
}
type fakeInjector struct {
	ops           []operation
	width, height int
	failAt        int
	calls         int
	resolveErr    error
	sameCode      uint8
	closeErr      error
	onKey         func()
}

func newFake() *fakeInjector { return &fakeInjector{width: 1920, height: 1080} }
func (f *fakeInjector) add(o operation) error {
	f.ops = append(f.ops, o)
	f.calls++
	if f.failAt == f.calls {
		return errors.New("injected failure")
	}
	return nil
}
func (f *fakeInjector) dimensions() (int, int, error) {
	return f.width, f.height, f.add(operation{kind: "dimensions"})
}
func (f *fakeInjector) keycode(sym uint32) (uint8, error) {
	if f.resolveErr != nil {
		return 0, f.resolveErr
	}
	if f.sameCode != 0 {
		return f.sameCode, nil
	}
	return uint8(sym%200 + 8), nil
}
func (f *fakeInjector) key(code uint8, down bool) error {
	if f.onKey != nil {
		f.onKey()
	}
	return f.add(operation{kind: "key", a: int(code), down: down})
}
func (f *fakeInjector) button(code uint8, down bool) error {
	return f.add(operation{kind: "button", a: int(code), down: down})
}
func (f *fakeInjector) relative(x, y int) error {
	return f.add(operation{kind: "relative", a: x, b: y})
}
func (f *fakeInjector) absolute(x, y int) error {
	return f.add(operation{kind: "absolute", a: x, b: y})
}
func (f *fakeInjector) close() error { _ = f.add(operation{kind: "close"}); return f.closeErr }
func handle(t *testing.T, b *Backend, p []byte) {
	t.Helper()
	if err := b.Handle(context.Background(), p); err != nil {
		t.Fatal(err)
	}
}

func TestHeldStateAndClose(t *testing.T) {
	f := newFake()
	b := newBackend(f)
	handle(t, b, keyboard(0x41, true, 0))
	handle(t, b, keyboard(0x41, true, 0))
	handle(t, b, record(8, 1))
	handle(t, b, record(8, 4))
	handle(t, b, record(9, 1))
	// Stray releases must not modify keys/buttons we do not own.
	before := len(f.ops)
	handle(t, b, keyboard(0x42, false, 0))
	handle(t, b, record(9, 5))
	if len(f.ops) != before {
		t.Fatal("stray release injected")
	}
	if err := b.Close(); err != nil {
		t.Fatal(err)
	}
	got := append([]operation(nil), f.ops...)
	if err := b.Close(); err != nil || !reflect.DeepEqual(got, f.ops) {
		t.Fatal("Close not idempotent", err)
	}
	if !reflect.DeepEqual(f.ops[len(f.ops)-3:], []operation{{kind: "key", a: int('a'%200 + 8)}, {kind: "button", a: 8}, {kind: "close"}}) {
		t.Fatal(f.ops)
	}
	if err := b.Handle(context.Background(), keyboard(0x41, true, 0)); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
	if len(b.keys) != 0 || len(b.buttons) != 0 {
		t.Fatal("stale ownership")
	}
}

func TestMalformedClosesAndReleases(t *testing.T) {
	for _, p := range [][]byte{nil, record(0x17, 'x'), record(8, 255)} {
		f := newFake()
		b := newBackend(f)
		handle(t, b, keyboard(0xa3, true, 2))
		handle(t, b, record(8, 3))
		before := len(f.ops)
		if err := b.Handle(context.Background(), p); err == nil {
			t.Fatal("accepted malformed")
		}
		if len(f.ops) != before+3 || f.ops[before].down || f.ops[before+1].down || f.ops[before+2].kind != "close" {
			t.Fatal(f.ops)
		}
	}
}

func TestFailureAttemptsAllReleases(t *testing.T) {
	f := newFake()
	b := newBackend(f)
	handle(t, b, keyboard(0x41, true, 0))
	handle(t, b, keyboard(0x42, true, 0))
	handle(t, b, record(8, 5))
	f.failAt = f.calls + 1 // first release fails; subsequent releases must still run.
	if err := b.Close(); err == nil {
		t.Fatal("lost release error")
	}
	tail := f.ops[3:]
	if len(tail) != 4 || tail[0].kind != "key" || tail[1].kind != "key" || tail[2].kind != "button" || tail[3].kind != "close" {
		t.Fatal(tail)
	}
	if err := b.Close(); err == nil {
		t.Fatal("lost saved close error")
	}
}

func TestFailedPressStillReleased(t *testing.T) {
	f := newFake()
	f.failAt = 1
	b := newBackend(f)
	if err := b.Handle(context.Background(), keyboard(0x41, true, 0)); err == nil {
		t.Fatal("lost failure")
	}
	if len(f.ops) != 3 || !f.ops[0].down || f.ops[1].down || f.ops[2].kind != "close" {
		t.Fatal(f.ops)
	}
}

func TestScrollAccumulatesAndReleases(t *testing.T) {
	f := newFake()
	b := newBackend(f)
	for _, n := range []int{30, 30, 59} {
		handle(t, b, scroll(n, false))
	}
	if len(f.ops) != 0 {
		t.Fatal(f.ops)
	}
	handle(t, b, scroll(1, false))
	handle(t, b, scroll(-240, false))
	handle(t, b, scroll(120, true))
	handle(t, b, scroll(-120, true))
	var buttons []int
	for i, o := range f.ops {
		if o.kind != "button" || o.down != (i%2 == 0) {
			t.Fatal(f.ops)
		}
		if o.down {
			buttons = append(buttons, o.a)
		}
	}
	if !reflect.DeepEqual(buttons, []int{4, 5, 5, 7, 6}) {
		t.Fatal(buttons)
	}
	if len(b.buttons) != 0 || b.scroll != [2]int{} {
		t.Fatal("scroll left held state")
	}
	if err := b.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestFailedWheelReleaseIsRetriedOnClose(t *testing.T) {
	f := newFake()
	f.failAt = 2
	b := newBackend(f)
	if err := b.Handle(context.Background(), scroll(120, false)); err == nil {
		t.Fatal("lost failure")
	}
	if len(f.ops) != 4 || f.ops[2].kind != "button" || f.ops[2].a != 4 || f.ops[2].down {
		t.Fatal(f.ops)
	}
}

func TestAbsoluteScaling(t *testing.T) {
	for _, tc := range []struct {
		wire                string
		width, height, x, y int
	}{
		{"0000000e 05000000 077f 0437 0000 077f 0437", 1280, 720, 1279, 719},
		{"0000000e 05000000 0000 0000 0000 0000 0000", 1280, 720, 0, 0},
		{"0000000e 05000000 0001 0001 0000 0002 0002", 1280, 720, 640, 360},
		{"0000000e 05000000 0001 0001 0000 0002 0002", 1, 1, 0, 0},
	} {
		f := newFake()
		f.width = tc.width
		f.height = tc.height
		b := newBackend(f)
		handle(t, b, fixture(tc.wire))
		if got := f.ops[1]; got != (operation{kind: "absolute", a: tc.x, b: tc.y}) {
			t.Fatal(got)
		}
		_ = b.Close()
	}
}

func TestCancellationAndNilContextClose(t *testing.T) {
	for _, mode := range []string{"before", "during", "nil"} {
		t.Run(mode, func(t *testing.T) {
			f := newFake()
			b := newBackend(f)
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			handle(t, b, record(8, 1))
			switch mode {
			case "before":
				cancel()
			case "during":
				f.onKey = cancel
			case "nil":
				ctx = nil
			}
			if err := b.Handle(ctx, keyboard(0x41, true, 0)); err == nil {
				t.Fatal("lost cancellation")
			}
			if !b.closed || f.ops[len(f.ops)-1].kind != "close" {
				t.Fatal(f.ops)
			}
		})
	}
}

func TestConsentAndDisplayBoundary(t *testing.T) {
	if _, err := New(":99", false); !errors.Is(err, ErrConsent) {
		t.Fatal(err)
	}
	for _, d := range []string{"", ":", ":65536", ":1.16", "localhost:0", "unix:0", "127.0.0.1:0", ":0\x00", ":0 ", " :0", ":000001", "$DISPLAY"} {
		if _, err := New(d, true); !errors.Is(err, ErrDisplay) {
			t.Fatalf("%q: %v", d, err)
		}
	}
	for _, d := range []string{":0", ":65535", ":1.15", ":00001.00"} {
		if err := validateDisplay(d); err != nil {
			t.Fatal(d, err)
		}
	}
	var b Backend
	if err := b.Close(); err != nil {
		t.Fatal(err)
	}
	if err := b.Handle(context.Background(), nil); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
}

func TestConcurrentHandleClose(t *testing.T) {
	f := newFake()
	b := newBackend(f)
	var wg sync.WaitGroup
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			err := b.Handle(context.Background(), keyboard(0x41, true, 0))
			if err != nil && !errors.Is(err, ErrClosed) {
				t.Error(err)
			}
		}()
	}
	wg.Add(1)
	go func() {
		defer wg.Done()
		if err := b.Close(); err != nil {
			t.Error(err)
		}
	}()
	wg.Wait()
	if len(f.ops) == 0 || f.ops[len(f.ops)-1].kind != "close" {
		t.Fatal(f.ops)
	}
}

func FuzzInputRecord(f *testing.F) {
	for _, p := range [][]byte{keyboard(0x41, true, 0), record(7, 0, 5, 0xff, 0xfd), record(8, 1), scroll(120, false), record(5, 0, 1, 0, 1, 0, 0, 0, 2, 0, 2)} {
		f.Add(p)
	}
	f.Fuzz(func(t *testing.T, p []byte) {
		e, err := parse(p)
		if err != nil {
			return
		}
		sink := newFake()
		b := newBackend(sink)
		if err := b.apply(context.Background(), e); err != nil {
			t.Fatal(err)
		}
		if err := b.Close(); err != nil {
			t.Fatal(err)
		}
		if len(sink.ops) > 550 {
			t.Fatalf("unbounded injection: %d", len(sink.ops))
		}
	})
}

func TestAliasesDoNotReleaseEachOther(t *testing.T) {
	f := newFake()
	f.sameCode = 38
	b := newBackend(f)
	handle(t, b, keyboard(0x41, true, 0))
	handle(t, b, keyboard(0x42, true, 0))
	if len(f.ops) != 1 {
		t.Fatal(f.ops)
	}
	handle(t, b, keyboard(0x41, false, 0))
	if len(f.ops) != 1 {
		t.Fatal("released alias early", f.ops)
	}
	handle(t, b, keyboard(0x42, false, 0))
	if len(f.ops) != 2 || f.ops[1].down {
		t.Fatal(f.ops)
	}
	if err := b.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestUnmappedAndOversizeDisplayFailClosed(t *testing.T) {
	f := newFake()
	f.resolveErr = ErrUnsupported
	b := newBackend(f)
	if err := b.Handle(context.Background(), keyboard(0x41, true, 0)); !errors.Is(err, ErrUnsupported) {
		t.Fatal(err)
	}
	if len(f.ops) != 1 || f.ops[0].kind != "close" {
		t.Fatal(f.ops)
	}
	f = newFake()
	f.width = 32769
	b = newBackend(f)
	if err := b.Handle(context.Background(), record(5, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1)); err == nil {
		t.Fatal("unrepresentable XTEST coordinate range")
	}
	if !b.closed {
		t.Fatal("backend not closed")
	}
}

func TestInputRequiresVisibleCaptureRegion(t *testing.T) {
	f := newFake()
	b := newBackend(f)
	if err := b.RequireDisplaySize(1920, 1080); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(f.ops, []operation{{kind: "dimensions"}}) {
		t.Fatal("size check injected input", f.ops)
	}
	if err := b.RequireDisplaySize(1280, 720); err == nil {
		t.Fatal("cropped capture accepted")
	}
	if !b.closed {
		t.Fatal("mismatch retained device")
	}
}

func TestResizeBlocksEveryInputKindAndReleasesHeldState(t *testing.T) {
	for _, tc := range []struct {
		name string
		p    []byte
	}{
		{"key", keyboard(0x42, true, 0)},
		{"button", record(8, 3)},
		{"relative", record(7, 0, 1, 0, 1)},
		{"absolute", record(5, 0, 1, 0, 1, 0, 0, 0, 2, 0, 2)},
		{"vertical scroll", scroll(120, false)},
		{"horizontal scroll", scroll(120, true)},
	} {
		t.Run(tc.name, func(t *testing.T) {
			f := newFake()
			b := newBackend(f)
			if err := b.RequireDisplaySize(1920, 1080); err != nil {
				t.Fatal(err)
			}
			handle(t, b, keyboard(0x41, true, 0))
			handle(t, b, record(8, 1))
			before := len(f.ops)
			f.width = 3840
			if err := b.Handle(context.Background(), tc.p); err == nil {
				t.Fatal("resize accepted")
			}
			want := []operation{{kind: "dimensions"}, {kind: "key", a: int('a'%200 + 8)}, {kind: "button", a: 1}, {kind: "close"}}
			if !reflect.DeepEqual(f.ops[before:], want) {
				t.Fatalf("new event injected or held state not released: %+v", f.ops[before:])
			}
			if err := b.Handle(context.Background(), tc.p); !errors.Is(err, ErrClosed) {
				t.Fatal(err)
			}
		})
	}
}

func TestRequiredSizeIsRecheckedAndAbsoluteKeepsAuthorizedScale(t *testing.T) {
	f := newFake()
	b := newBackend(f)
	if err := b.RequireDisplaySize(1920, 1080); err != nil {
		t.Fatal(err)
	}
	f.ops = nil
	handle(t, b, record(5, 0, 1, 0, 1, 0, 0, 0, 2, 0, 2))
	want := []operation{{kind: "dimensions"}, {kind: "absolute", a: 960, b: 540}}
	if !reflect.DeepEqual(f.ops, want) {
		t.Fatal(f.ops)
	}
	f.failAt = f.calls + 1
	if err := b.Handle(context.Background(), record(8, 1)); err == nil {
		t.Fatal("dimension query failure ignored")
	}
	if !b.closed || f.ops[len(f.ops)-1].kind != "close" {
		t.Fatal(f.ops)
	}
}
