// SPDX-License-Identifier: GPL-3.0-only
package gamestreamvideo

import (
	"bytes"
	"encoding/binary"
	"math"
	"testing"
)

func testFrame(n int) []byte {
	return append([]byte{0, 0, 0, 1, 9, 0xf0, 0, 0, 1, 0x65}, bytes.Repeat([]byte{0x55}, n)...)
}
func TestPacketRoundtrip(t *testing.T) {
	for _, size := range []int{64, 1024, 1408} {
		p, err := NewPlainPacketizer(size)
		if err != nil {
			t.Fatal(err)
		}
		for _, length := range []int{0, 1, 38, 100, 10000} {
			want := testFrame(length)
			packets, err := p.Packetize(want, 90000)
			if err != nil {
				t.Fatal(err)
			}
			got, err := ReassemblePlain(packets, size)
			if err != nil || !bytes.Equal(want, got) {
				t.Fatal(size, length, err)
			}
			for i, b := range packets {
				fec := binary.LittleEndian.Uint32(b[28:32])
				if fec>>22 != uint32(len(packets)) || (fec>>12)&1023 != uint32(i) || (fec>>4)&255 != 0 {
					t.Fatal("FEC bitfield")
				}
			}
		}
	}
}
func TestCounterWrapAndExhaustion(t *testing.T) {
	p, _ := NewPlainPacketizer(64)
	p.sequence = math.MaxUint16
	p.streamIndex = 0xffffff
	p.frameIndex = math.MaxUint32
	frame := testFrame(200)
	packets, err := p.Packetize(frame, math.MaxUint32)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = ReassemblePlain(packets, 64); err != nil {
		t.Fatal(err)
	}
	if _, err = p.Packetize(frame, 0); err == nil {
		t.Fatal("frame counter reset")
	}
}
func TestRejectDamagedPackets(t *testing.T) {
	for _, position := range []int{0, 1, 2, 4, 16, 20, 24, 25, 26, 27, 28, 32} {
		p, _ := NewPlainPacketizer(64)
		packets, _ := p.Packetize(testFrame(100), 0)
		packets[0][position] ^= 1
		if _, err := ReassemblePlain(packets, 64); err == nil {
			t.Fatal("accepted mutation", position)
		}
	}
	p, _ := NewPlainPacketizer(64)
	packets, _ := p.Packetize(testFrame(100), 0)
	if _, err := ReassemblePlain(packets[1:], 64); err == nil {
		t.Fatal("accepted packet loss")
	}
}
func TestInputLimits(t *testing.T) {
	for _, size := range []int{0, 63, 65, 1424} {
		if _, err := NewPlainPacketizer(size); err == nil {
			t.Fatal(size)
		}
	}
	p, _ := NewPlainPacketizer(64)
	for _, b := range [][]byte{nil, []byte("no annexb"), testFrame(MaxDataPackets * 48)} {
		if _, err := p.Packetize(b, 0); err == nil {
			t.Fatal("accepted invalid frame")
		}
	}
	if p.frameIndex != 1 || p.sequence != 0 {
		t.Fatal("failed frame consumed counters")
	}
}
func FuzzRoundtrip(f *testing.F) {
	f.Add([]byte{1, 2, 3}, uint32(100))
	f.Fuzz(func(t *testing.T, b []byte, ts uint32) {
		if len(b) > 65536 {
			return
		}
		p, _ := NewPlainPacketizer(1024)
		frame := append([]byte{0, 0, 0, 1, 0x65}, b...)
		packets, err := p.Packetize(frame, ts)
		if err != nil {
			t.Fatal(err)
		}
		got, err := ReassemblePlain(packets, 1024)
		if err != nil || !bytes.Equal(got, frame) {
			t.Fatal(err)
		}
	})
}
