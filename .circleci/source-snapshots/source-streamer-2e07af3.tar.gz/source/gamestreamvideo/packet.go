// SPDX-License-Identifier: GPL-3.0-only
// Experimental public-client-derived, single-block, zero-FEC H264 framing.
package gamestreamvideo

import (
	"bytes"
	"encoding/binary"
	"errors"
)

const RTPSize = 16
const NVSize = 16
const MaxDataPackets = 1023

var frameHeader = []byte{1, 0, 0, 104, 0, 0, 0, 0}

// PlainPacketizer produces in-memory UNENCRYPTED video packet fixtures. It is
// not a network sender and must not bypass negotiated video encryption. A real
// backend needs authenticated pairing/control and the encrypted media envelope.
// This type is confined to one caller/session; it is not concurrency-safe.
type PlainPacketizer struct {
	packetSize              int
	sequence                uint16
	streamIndex, frameIndex uint32
}

func NewPlainPacketizer(packetSize int) (*PlainPacketizer, error) {
	if packetSize < 64 || packetSize > 1408 || packetSize%16 != 0 {
		return nil, errors.New("packet size must be a multiple of 16 in 64..1408")
	}
	return &PlainPacketizer{packetSize: packetSize, frameIndex: 1}, nil
}
func annexB(b []byte) bool {
	prefix := 0
	if bytes.HasPrefix(b, []byte{0, 0, 0, 1}) {
		prefix = 4
	} else if bytes.HasPrefix(b, []byte{0, 0, 1}) {
		prefix = 3
	}
	return prefix != 0 && len(b) > prefix && b[prefix]&128 == 0 && b[prefix]&31 >= 1 && b[prefix]&31 <= 23
}

// Packetize accepts one complete H264 access unit and a 90kHz RTP timestamp.
// It emits a fixed eight-byte frame header, single FEC block and no parity.
// Packet-count overflow is an error; frames are never silently truncated.
func (p *PlainPacketizer) Packetize(frame []byte, timestamp uint32) ([][]byte, error) {
	if p.frameIndex == 0 {
		return nil, errors.New("frame counter exhausted")
	}
	if !annexB(frame) {
		return nil, errors.New("Annex-B access unit required")
	}
	capacity := p.packetSize - NVSize
	if len(frame) > MaxDataPackets*capacity-len(frameHeader) {
		return nil, errors.New("frame exceeds single-block packet limit")
	}
	data := make([]byte, len(frameHeader)+len(frame))
	copy(data, frameHeader)
	copy(data[len(frameHeader):], frame)
	count := (len(data) + capacity - 1) / capacity
	packets := make([][]byte, count)
	for i := 0; i < count; i++ {
		lo, hi := i*capacity, (i+1)*capacity
		if hi > len(data) {
			hi = len(data)
		}
		packet := make([]byte, RTPSize+NVSize+hi-lo)
		packet[0] = 0x90
		packet[1] = 96
		binary.BigEndian.PutUint16(packet[2:4], p.sequence)
		binary.BigEndian.PutUint32(packet[4:8], timestamp)
		nv := packet[RTPSize:]
		binary.LittleEndian.PutUint32(nv[:4], p.streamIndex<<8)
		binary.LittleEndian.PutUint32(nv[4:8], p.frameIndex)
		nv[8] = 1
		if i == 0 {
			nv[8] |= 4
		}
		if i == count-1 {
			nv[8] |= 2
		}
		nv[10] = 0x10
		binary.LittleEndian.PutUint32(nv[12:16], uint32(count)<<22|uint32(i)<<12)
		copy(nv[NVSize:], data[lo:hi])
		packets[i] = packet
		p.sequence++
		p.streamIndex = (p.streamIndex + 1) & 0xffffff
	}
	p.frameIndex++
	return packets, nil
}

// ReassemblePlain is an offline fixture oracle for this strict generated profile.
// It does not handle packet loss, out-of-order delivery, FEC, or stock captures.
func ReassemblePlain(packets [][]byte, packetSize int) ([]byte, error) {
	if _, err := NewPlainPacketizer(packetSize); err != nil {
		return nil, err
	}
	if len(packets) == 0 || len(packets) > MaxDataPackets {
		return nil, errors.New("invalid packet count")
	}
	var data []byte
	var firstSeq uint16
	var firstStream, frame, timestamp uint32
	for i, packet := range packets {
		if len(packet) <= RTPSize+NVSize || len(packet) > RTPSize+packetSize || packet[0] != 0x90 || packet[1] != 96 {
			return nil, errors.New("invalid video packet header/size")
		}
		if i < len(packets)-1 && len(packet) != RTPSize+packetSize {
			return nil, errors.New("short non-final packet")
		}
		nv := packet[RTPSize:]
		seq := binary.BigEndian.Uint16(packet[2:4])
		spi := binary.LittleEndian.Uint32(nv[:4])
		fi := binary.LittleEndian.Uint32(nv[4:8])
		ts := binary.BigEndian.Uint32(packet[4:8])
		if i == 0 {
			firstSeq, firstStream, frame, timestamp = seq, spi>>8, fi, ts
		}
		flags := byte(1)
		if i == 0 {
			flags |= 4
		}
		if i == len(packets)-1 {
			flags |= 2
		}
		fec := binary.LittleEndian.Uint32(nv[12:16])
		expected := uint32(len(packets))<<22 | uint32(i)<<12
		if frame == 0 || fi != frame || ts != timestamp || seq != firstSeq+uint16(i) || spi&255 != 0 || spi>>8 != (firstStream+uint32(i))&0xffffff || nv[8] != flags || nv[9] != 0 || nv[10] != 0x10 || nv[11] != 0 || fec != expected {
			return nil, errors.New("inconsistent video packet metadata")
		}
		data = append(data, nv[NVSize:]...)
	}
	if len(data) <= len(frameHeader) || !bytes.Equal(data[:len(frameHeader)], frameHeader) || !annexB(data[len(frameHeader):]) {
		return nil, errors.New("invalid H264 frame envelope")
	}
	return data[len(frameHeader):], nil
}
