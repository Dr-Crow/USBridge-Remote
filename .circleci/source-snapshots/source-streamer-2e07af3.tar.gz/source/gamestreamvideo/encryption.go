// SPDX-License-Identifier: GPL-3.0-only
package gamestreamvideo

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"math"
	"sync"
)

const EncryptionHeaderSize = 32

// VideoCipher seals video packets with the public client's AES-GCM envelope.
// Use exactly one instance for one authenticated launch with a fresh unique key.
// Retain it across connections; restarting with the same key would reuse nonces.
// Nonces use our monotonic counter and HV suffix, separate from RTSP HR/CR and
// modern control HC/CC. There is no key generation or plaintext fallback.
type VideoCipher struct {
	mu       sync.Mutex
	aead     cipher.AEAD
	sequence uint32
}

func NewVideoCipher(key []byte) (*VideoCipher, error) {
	if len(key) != 16 {
		return nil, errors.New("video requires a 16-byte launch key")
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return &VideoCipher{aead: aead}, nil
}
func (c *VideoCipher) Seal(packet []byte) ([]byte, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if len(packet) <= RTPSize+NVSize || len(packet) > RTPSize+1408 || packet[0] != 0x90 || packet[1] != 96 {
		return nil, errors.New("invalid plaintext video packet")
	}
	frame := binary.LittleEndian.Uint32(packet[RTPSize+4 : RTPSize+8])
	if frame == 0 {
		return nil, errors.New("invalid frame index")
	}
	if c.sequence == math.MaxUint32 {
		return nil, errors.New("video nonce exhausted; fresh launch required")
	}
	c.sequence++
	var iv [12]byte
	binary.LittleEndian.PutUint32(iv[:4], c.sequence)
	iv[10] = 'H'
	iv[11] = 'V'
	encrypted := c.aead.Seal(nil, iv[:], packet, nil)
	out := make([]byte, EncryptionHeaderSize+len(packet))
	copy(out[:12], iv[:])
	binary.LittleEndian.PutUint32(out[12:16], frame)
	copy(out[16:32], encrypted[len(packet):])
	copy(out[32:], encrypted[:len(packet)])
	return out, nil
}
