// SPDX-License-Identifier: GPL-3.0-only
package gamestreamvideo

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"math"
	"os"
	"sync"
	"testing"
)

func TestVideoEncryptionVectors(t *testing.T) {
	var v struct {
		Key    string `json:"key_hex"`
		Plain  string `json:"plaintext_hex"`
		Sealed string `json:"sealed_hex"`
	}
	b, err := os.ReadFile("testdata/video-vector.json")
	if err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(b, &v); err != nil {
		t.Fatal(err)
	}
	key, _ := hex.DecodeString(v.Key)
	plain, _ := hex.DecodeString(v.Plain)
	want, _ := hex.DecodeString(v.Sealed)
	c, err := NewVideoCipher(key)
	if err != nil {
		t.Fatal(err)
	}
	got, err := c.Seal(plain)
	if err != nil || !bytes.Equal(got, want) {
		t.Fatal("independent vector mismatch", err)
	}
}
func TestVideoCipherRoundtripAndNonce(t *testing.T) {
	key := bytes.Repeat([]byte{7}, 16)
	c, _ := NewVideoCipher(key)
	p, _ := NewPlainPacketizer(64)
	packets, _ := p.Packetize(testFrame(150), 3000)
	block, _ := aes.NewCipher(key)
	g, _ := cipher.NewGCM(block)
	seen := map[string]bool{}
	for _, packet := range packets {
		sealed, err := c.Seal(packet)
		if err != nil {
			t.Fatal(err)
		}
		iv := sealed[:12]
		if seen[string(iv)] || iv[10] != 'H' || iv[11] != 'V' {
			t.Fatal("nonce separation/reuse")
		}
		seen[string(iv)] = true
		payload := append(append([]byte(nil), sealed[32:]...), sealed[16:32]...)
		got, err := g.Open(nil, iv, payload, nil)
		if err != nil || !bytes.Equal(got, packet) {
			t.Fatal(err)
		}
		if binary.LittleEndian.Uint32(sealed[12:16]) != binary.LittleEndian.Uint32(got[20:24]) {
			t.Fatal("frame hint mismatch")
		}
		payload[0] ^= 1
		if _, err = g.Open(nil, iv, payload, nil); err == nil {
			t.Fatal("modified ciphertext authenticated")
		}
	}
}
func TestVideoCipherBounds(t *testing.T) {
	if _, err := NewVideoCipher(nil); err == nil {
		t.Fatal("bad key accepted")
	}
	c, _ := NewVideoCipher(make([]byte, 16))
	if _, err := c.Seal(nil); err == nil {
		t.Fatal("bad packet accepted")
	}
	if c.sequence != 0 {
		t.Fatal("invalid packet consumed nonce")
	}
	p, _ := NewPlainPacketizer(64)
	packets, _ := p.Packetize(testFrame(1), 0)
	c.sequence = math.MaxUint32
	if _, err := c.Seal(packets[0]); err == nil {
		t.Fatal("nonce wrapped")
	}
}
func TestConcurrentVideoSeals(t *testing.T) {
	c, _ := NewVideoCipher(make([]byte, 16))
	p, _ := NewPlainPacketizer(64)
	packets, _ := p.Packetize(testFrame(1), 0)
	var wg sync.WaitGroup
	out := make(chan []byte, 20)
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			b, err := c.Seal(packets[0])
			if err != nil {
				t.Error(err)
				return
			}
			out <- b
		}()
	}
	wg.Wait()
	close(out)
	seen := map[string]bool{}
	for b := range out {
		n := string(b[:12])
		if seen[n] {
			t.Fatal("concurrent nonce reuse")
		}
		seen[n] = true
	}
	if len(seen) != 20 {
		t.Fatal(len(seen))
	}
}
