// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"bytes"
	"context"
	"errors"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/annexb"
)

// These opt-ins are a harness assertion, not OS isolation or user consent UI.
// Set them only in a dedicated disposable Windows CI desktop showing a
// purpose-built non-sensitive pattern. Never point this test at a user's
// desktop, and never enable the variables globally on a shared CI runner.
// No captured pixels or encoded frames are persisted or sent to a network.
func windowsCaptureTestEncoder(t *testing.T) string {
	t.Helper()
	if runtime.GOOS != "windows" {
		t.Skip("native Windows capture test; cross-compilation is not capture evidence")
	}
	if os.Getenv("CI") != "true" || os.Getenv("STREAMER_WINDOWS_CAPTURE_ISOLATED_CI") != "1" ||
		os.Getenv("STREAMER_WINDOWS_CAPTURE_CONSENT") != "1" ||
		os.Getenv("STREAMER_WINDOWS_CAPTURE_DISPLAY") != "desktop" {
		t.Skip("explicit isolated Windows CI desktop and capture consent required")
	}
	ffmpeg := os.Getenv("STREAMER_FFMPEG")
	if !filepath.IsAbs(ffmpeg) || !strings.EqualFold(filepath.Ext(ffmpeg), ".exe") {
		t.Fatal("STREAMER_FFMPEG must select a trusted absolute native FFmpeg .exe")
	}
	return ffmpeg
}

// Fail on oversized output rather than retaining an unbounded captured stream.
type windowsCaptureTestBuffer struct {
	bytes.Buffer
	limit int
}

func (b *windowsCaptureTestBuffer) Write(p []byte) (int, error) {
	if len(p) > b.limit-b.Len() {
		return 0, errors.New("capture test output exceeds bound")
	}
	return b.Buffer.Write(p)
}

func assertWindowsCaptureIntra(t *testing.T, unit []byte) {
	t.Helper()
	var kinds [32]bool
	for i := 0; i+3 < len(unit); {
		prefix := 0
		if i+4 < len(unit) && bytes.Equal(unit[i:i+4], []byte{0, 0, 0, 1}) {
			prefix = 4
		} else if bytes.Equal(unit[i:i+3], []byte{0, 0, 1}) {
			prefix = 3
		}
		if prefix != 0 {
			kinds[unit[i+prefix]&31] = true
			i += prefix + 1
		} else {
			i++
		}
	}
	if !kinds[9] || !kinds[7] || !kinds[8] || !kinds[5] {
		t.Fatal("captured access unit lacks AUD, SPS, PPS or IDR")
	}
	if kinds[1] || kinds[2] || kinds[3] || kinds[4] {
		t.Fatal("all-intra capture emitted non-IDR VCL")
	}
}

func TestWindowsGDIBoundedCaptureIntegration(t *testing.T) {
	ffmpeg := windowsCaptureTestEncoder(t)
	for _, pix := range []string{"yuv420p", "yuv444p"} {
		t.Run(pix, func(t *testing.T) {
			ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
			defer cancel()
			p := Pattern{Width: 128, Height: 72, Frames: 3, FPS: 30, PixelFormat: pix}
			encoded := &windowsCaptureTestBuffer{limit: 4 << 20}
			if err := CaptureWindowsGDI(ctx, ffmpeg, "desktop", encoded, p); err != nil {
				t.Fatal(err)
			}
			reader := annexb.NewReader(bytes.NewReader(encoded.Bytes()))
			frames := 0
			for {
				unit, err := reader.Next()
				if err == io.EOF {
					break
				}
				if err != nil {
					t.Fatal(err)
				}
				assertWindowsCaptureIntra(t, unit)
				frames++
			}
			if frames != p.Frames {
				t.Fatalf("got %d access units, want %d", frames, p.Frames)
			}
			// Decode independently with FFmpeg and retain only bounded checksums.
			// Dimensions, decoded frame count and raw sample size are verified;
			// visual fidelity to the CI pattern requires a separate image oracle.
			cmd := exec.CommandContext(ctx, ffmpeg, "-hide_banner", "-nostdin", "-v", "error",
				"-f", "h264", "-i", "pipe:0", "-map", "0:v:0", "-an", "-pix_fmt", pix,
				"-f", "framehash", "-hash", "sha256", "pipe:1")
			cmd.Stdin = bytes.NewReader(encoded.Bytes())
			hashes := &windowsCaptureTestBuffer{limit: 64 << 10}
			cmd.Stdout = hashes
			log := &cappedLog{}
			cmd.Stderr = log
			if err := cmd.Run(); err != nil {
				t.Fatalf("independent decode failed: %v: %s", err, log.b)
			}
			if !strings.Contains(hashes.String(), "#dimensions 0: 128x72") {
				t.Fatal("decoded dimensions do not match requested region")
			}
			frameBytes := p.Width * p.Height * 3
			if pix == "yuv420p" {
				frameBytes /= 2
			}
			decoded := 0
			for _, line := range strings.Split(hashes.String(), "\n") {
				line = strings.TrimSpace(line)
				if line == "" || strings.HasPrefix(line, "#") {
					continue
				}
				parts := strings.Split(line, ",")
				if len(parts) != 6 || strings.TrimSpace(parts[0]) != "0" ||
					strings.TrimSpace(parts[4]) != strconv.Itoa(frameBytes) || len(strings.TrimSpace(parts[5])) != 64 {
					t.Fatal("invalid decoded frame checksum record")
				}
				decoded++
			}
			if decoded != p.Frames {
				t.Fatalf("decoded %d frames, want %d", decoded, p.Frames)
			}
			t.Logf("captured and independently decoded %d %dx%d %s frames; no pixels saved", decoded, p.Width, p.Height, pix)
		})
	}
}

func TestWindowsGDILiveCaptureCancellationIntegration(t *testing.T) {
	ffmpeg := windowsCaptureTestEncoder(t)
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	reader, writer := io.Pipe()
	joined := make(chan error, 1)
	stop := context.AfterFunc(ctx, func() {
		_ = reader.CloseWithError(ctx.Err())
		_ = writer.CloseWithError(ctx.Err())
	})
	go func() {
		err := CaptureWindowsGDILiveIntra(ctx, ffmpeg, "desktop", writer,
			Pattern{Width: 128, Height: 72, FPS: 30, PixelFormat: "yuv444p"})
		_ = writer.CloseWithError(err)
		joined <- err
	}()
	defer func() {
		cancel()
		_ = reader.CloseWithError(context.Canceled)
		_ = writer.CloseWithError(context.Canceled)
		stop()
		select {
		case err := <-joined:
			if !errors.Is(err, context.Canceled) {
				t.Errorf("live capture did not return cancellation: %v", err)
			}
		case <-time.After(5 * time.Second):
			t.Error("live FFmpeg process did not join after cancellation")
		}
	}()
	units := annexb.NewReader(reader)
	for i := 0; i < 3; i++ {
		unit, err := units.Next()
		if err != nil {
			t.Fatal(err)
		}
		assertWindowsCaptureIntra(t, unit)
	}
	cancel()
	t.Log("received three live all-IDR frames; checking subprocess cancellation and join")
}
