// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"errors"
	"io"
	"reflect"
	"runtime"
	"strings"
	"testing"
)

func TestWindowsGDIExplicitDisplay(t *testing.T) {
	if err := ValidateWindowsGDIDisplay("desktop"); err != nil {
		t.Fatal(err)
	}
	for _, display := range []string{
		"", "Desktop", "DESKTOP", " desktop", "desktop ", "desktop\n", "desktop\x00",
		"default", ":0", "$DISPLAY", "title=Test", "hwnd=123", "http://localhost/",
		"\\\\host\\desktop", "desktop -f lavfi", "desktop;exit", "desktop+0,0",
	} {
		if err := ValidateWindowsGDIDisplay(display); err == nil {
			t.Fatalf("accepted invalid display %q", display)
		}
	}
}

func TestWindowsGDIArgsBoundedAndLive(t *testing.T) {
	for _, pix := range []string{"yuv420p", "yuv444p"} {
		for _, live := range []bool{false, true} {
			p := Pattern{Width: 128, Height: 72, Frames: 3, FPS: 30, PixelFormat: pix}
			want := []string{
				"-hide_banner", "-nostdin", "-v", "error",
				"-f", "gdigrab", "-draw_mouse", "0", "-offset_x", "0", "-offset_y", "0",
				"-video_size", "128x72", "-framerate", "30", "-i", "desktop",
			}
			if !live {
				want = append(want, "-frames:v", "3")
			}
			want = append(want,
				"-an", "-pix_fmt", pix, "-c:v", "libx264", "-qp", "0",
				"-preset", "ultrafast", "-tune", "zerolatency",
				"-x264-params", "aud=1:repeat-headers=1:keyint=1:min-keyint=1:scenecut=0",
				"-threads", "1", "-f", "h264", "pipe:1",
			)
			got, err := windowsGDIArgs("desktop", p, live)
			if err != nil || !reflect.DeepEqual(got, want) {
				t.Fatalf("live=%v format=%s args=%q err=%v", live, pix, got, err)
			}
		}
	}
}

func TestWindowsGDIArgsRejectInvalidFormats(t *testing.T) {
	base := Pattern{Width: 128, Height: 72, Frames: 3, FPS: 30, PixelFormat: "yuv444p"}
	for _, mutate := range []func(*Pattern){
		func(p *Pattern) { p.Width = 0 }, func(p *Pattern) { p.Width = 129 },
		func(p *Pattern) { p.Width = 1922 }, func(p *Pattern) { p.Height = 0 },
		func(p *Pattern) { p.Height = 73 }, func(p *Pattern) { p.Height = 1082 },
		func(p *Pattern) { p.FPS = 0 }, func(p *Pattern) { p.FPS = 121 },
		func(p *Pattern) { p.PixelFormat = "" }, func(p *Pattern) { p.PixelFormat = "rgb24" },
	} {
		p := base
		mutate(&p)
		for _, live := range []bool{false, true} {
			if args, err := windowsGDIArgs("desktop", p, live); err == nil || args != nil {
				t.Fatalf("accepted invalid pattern %+v live=%v", p, live)
			}
		}
	}
	for _, frames := range []int{-1, 0, 301} {
		p := base
		p.Frames = frames
		if _, err := windowsGDIArgs("desktop", p, false); err == nil {
			t.Fatalf("bounded capture accepted %d frames", frames)
		}
		if _, err := windowsGDIArgs("desktop", p, true); err != nil {
			t.Fatalf("live capture should ignore Frames: %v", err)
		}
	}
	if args, err := windowsGDIArgs("title=Test", base, false); err == nil || args != nil {
		t.Fatal("argument builder accepted a window selection")
	}
}

func TestWindowsGDIPreconditionsDoNotLaunch(t *testing.T) {
	p := Pattern{Width: 2, Height: 2, Frames: 1, FPS: 30, PixelFormat: "yuv444p"}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	for _, capture := range []func(context.Context, string, string, io.Writer, Pattern) error{
		CaptureWindowsGDI, CaptureWindowsGDILiveIntra,
	} {
		if err := capture(ctx, "missing", "desktop", io.Discard, p); !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
		if err := capture(nil, "missing", "desktop", io.Discard, p); err == nil {
			t.Fatal("nil context accepted")
		}
		if err := capture(context.Background(), "", "desktop", io.Discard, p); err == nil {
			t.Fatal("empty encoder accepted")
		}
		if err := capture(context.Background(), "missing", "desktop", nil, p); err == nil {
			t.Fatal("nil output accepted")
		}
		if err := capture(context.Background(), "missing", "title=Test", io.Discard, p); err == nil {
			t.Fatal("window selection accepted")
		}
		if err := capture(context.Background(), "missing", "desktop", io.Discard, Pattern{}); err == nil {
			t.Fatal("invalid pattern accepted")
		}
		if runtime.GOOS != "windows" {
			err := capture(context.Background(), "missing", "desktop", io.Discard, p)
			if err == nil || !strings.Contains(err.Error(), "requires Windows") {
				t.Fatalf("missing unsupported-platform error: %v", err)
			}
		} else {
			for _, path := range []string{
				"ffmpeg.exe", `C:ffmpeg.exe`, `\ffmpeg.exe`, `C:\ffmpeg.cmd`,
				`\\server\share\ffmpeg.exe`, `\\?\C:\ffmpeg.exe`,
			} {
				err := capture(context.Background(), path, "desktop", io.Discard, p)
				if err == nil || !strings.Contains(err.Error(), "absolute local") {
					t.Fatalf("missing path validation error: %v", err)
				}
			}
		}
	}
}
