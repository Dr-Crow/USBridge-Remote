// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"errors"
	"io"
	"sync"

	"github.com/Dr-Crow/rustshine-research/source/annexb"
	"github.com/Dr-Crow/rustshine-research/source/gamestreamvideo"
)

// Encoder must emit AUD-delimited Annex-B, honor cancellation, and return after
// output fails. Sink must honor context and return; it must not block forever.
// These callbacks do not establish pairing or authorize a network destination.
type Encoder func(context.Context, io.Writer, Pattern) error

// LiveEncoder emits bounded AUD-delimited access units until cancellation or
// normal shutdown. It must honor context and stop when its writer fails.
type LiveEncoder func(context.Context, io.Writer) error
type PacketSink func(context.Context, []byte) error

type PipelineStats struct {
	Frames, Packets int
	Bytes           int64
}

// EncryptedPipeline is single-use and consumes bounded encoder output with
// backpressure. It never emits plaintext packets. The caller owns the unique
// authenticated launch key lifetime represented by cipher.
type EncryptedPipeline struct {
	mu         sync.Mutex
	used       bool
	packetizer *gamestreamvideo.PlainPacketizer
	cipher     *gamestreamvideo.VideoCipher
}

func NewEncryptedPipeline(packetSize int, cipher *gamestreamvideo.VideoCipher) (*EncryptedPipeline, error) {
	if cipher == nil {
		return nil, errors.New("authenticated launch video cipher required")
	}
	p, err := gamestreamvideo.NewPlainPacketizer(packetSize)
	if err != nil {
		return nil, err
	}
	return &EncryptedPipeline{packetizer: p, cipher: cipher}, nil
}

// Run connects encoder -> access units -> packetizer -> GCM -> sink. It retains
// one bounded access unit at a time, never a whole movie. Timestamps use the 90kHz
// clock without accumulated integer truncation. No wall-clock pacing is implied.
func (p *EncryptedPipeline) Run(ctx context.Context, encoder Encoder, sink PacketSink, pattern Pattern) (PipelineStats, error) {
	return p.run(ctx, encoder, sink, pattern, nil)
}

// RunPaced schedules each frame against a monotonic clock starting when its
// first encoded frame is ready. It neither drops late frames nor promises
// real-time performance. Authentication and destination selection remain the
// caller's responsibility. The same bounded pipeline and single-use rule apply.
func (p *EncryptedPipeline) RunPaced(ctx context.Context, encoder Encoder, sink PacketSink, pattern Pattern) (PipelineStats, error) {
	pacer := newFramePacer()
	return p.run(ctx, encoder, sink, pattern, pacer.wait)
}

func (p *EncryptedPipeline) run(ctx context.Context, encoder Encoder, sink PacketSink, pattern Pattern, wait func(context.Context, int, int) error) (stats PipelineStats, result error) {
	return p.runMode(ctx, encoder, sink, pattern, wait, false)
}

// RunLive removes the synthetic fixture's total frame budget while preserving
// bounded access units, backpressure, encryption and single-use key ownership.
// The encoder supplies pacing (for example a live capture device). This method
// adds no wall-clock pacing; FPS determines the nominal RTP timestamp clock.
func (p *EncryptedPipeline) RunLive(ctx context.Context, encoder LiveEncoder, sink PacketSink, fps int) (PipelineStats, error) {
	return p.live(ctx, encoder, sink, fps, nil)
}

// RunLivePaced additionally applies the same monotonic nominal-rate schedule as
// RunPaced. Late frames are neither dropped nor falsely reported as on time.
func (p *EncryptedPipeline) RunLivePaced(ctx context.Context, encoder LiveEncoder, sink PacketSink, fps int) (PipelineStats, error) {
	return p.live(ctx, encoder, sink, fps, newFramePacer().wait)
}
func (p *EncryptedPipeline) live(ctx context.Context, encoder LiveEncoder, sink PacketSink, fps int, wait func(context.Context, int, int) error) (PipelineStats, error) {
	if encoder == nil {
		return PipelineStats{}, errors.New("live encoder required")
	}
	// Only FPS applies to framing here; the encoder owns capture dimensions and
	// must validate its own format. Placeholder dimensions are never captured.
	format := Pattern{Width: 2, Height: 2, Frames: 1, FPS: fps, PixelFormat: "yuv420p"}
	return p.runMode(ctx, func(ctx context.Context, w io.Writer, _ Pattern) error { return encoder(ctx, w) }, sink, format, wait, true)
}

func (p *EncryptedPipeline) runMode(ctx context.Context, encoder Encoder, sink PacketSink, pattern Pattern, wait func(context.Context, int, int) error, live bool) (stats PipelineStats, result error) {
	if ctx == nil || encoder == nil || sink == nil {
		return stats, errors.New("context, encoder and sink required")
	}
	if err := pattern.Validate(); err != nil {
		return stats, err
	}
	if err := ctx.Err(); err != nil {
		return stats, err
	}
	p.mu.Lock()
	if p.used {
		p.mu.Unlock()
		return stats, errors.New("pipeline already used")
	}
	p.used = true
	p.mu.Unlock()

	runCtx, cancel := context.WithCancel(ctx)
	reader, writer := io.Pipe()
	finished := make(chan error, 1)
	stop := context.AfterFunc(runCtx, func() {
		_ = reader.CloseWithError(runCtx.Err())
		_ = writer.CloseWithError(runCtx.Err())
	})
	defer func() {
		cancel()
		_ = reader.CloseWithError(context.Canceled)
		_ = writer.CloseWithError(context.Canceled)
		stop()
		encoderErr := <-finished
		if result == nil {
			result = encoderErr
		}
		if ctx.Err() != nil {
			result = ctx.Err()
		}
	}()
	go func() {
		err := encoder(runCtx, writer, pattern)
		_ = writer.CloseWithError(err)
		finished <- err
	}()
	frames := annexb.NewReader(reader)
	for {
		frame, err := frames.Next()
		if err == io.EOF {
			if (!live && stats.Frames != pattern.Frames) || (live && stats.Frames == 0) {
				return stats, errors.New("encoder frame count mismatch")
			}
			return stats, nil
		}
		if err != nil {
			return stats, err
		}
		if err = runCtx.Err(); err != nil {
			return stats, err
		}
		if !live && stats.Frames >= pattern.Frames {
			return stats, errors.New("encoder produced excess frames")
		}
		if wait != nil {
			if err = wait(runCtx, stats.Frames, pattern.FPS); err != nil {
				return stats, err
			}
		}
		timestamp := uint32(uint64(stats.Frames) * 90000 / uint64(pattern.FPS))
		packets, err := p.packetizer.Packetize(frame, timestamp)
		if err != nil {
			return stats, err
		}
		for _, packet := range packets {
			if err = runCtx.Err(); err != nil {
				return stats, err
			}
			sealed, err := p.cipher.Seal(packet)
			if err != nil {
				return stats, err
			}
			if err = sink(runCtx, sealed); err != nil {
				return stats, err
			}
			stats.Packets++
			stats.Bytes += int64(len(sealed))
		}
		stats.Frames++
	}
}
