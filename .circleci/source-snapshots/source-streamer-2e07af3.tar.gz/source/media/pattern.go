// SPDX-License-Identifier: GPL-3.0-only
// Synthetic media backend for reconstruction acceptance; no display capture.
package media

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os/exec"
	"strconv"
)

type Pattern struct {
	Width, Height, Frames, FPS int
	PixelFormat                string
}

func (p Pattern) Validate() error {
	if p.Width < 2 || p.Height < 2 || p.Width > 1920 || p.Height > 1080 || p.Width%2 != 0 || p.Height%2 != 0 {
		return errors.New("even dimensions within 2..1920 by 2..1080 required")
	}
	if p.Frames < 1 || p.Frames > 300 || p.FPS < 1 || p.FPS > 120 {
		return errors.New("frame count or rate out of bounds")
	}
	if p.PixelFormat != "yuv420p" && p.PixelFormat != "yuv444p" {
		return errors.New("unsupported synthetic pixel format")
	}
	return nil
}

type patternReader struct {
	p                  Pattern
	position           int64
	frameBytes, cw, ch int
}

func NewPatternReader(p Pattern) (io.Reader, error) {
	if err := p.Validate(); err != nil {
		return nil, err
	}
	cw, ch := p.Width, p.Height
	if p.PixelFormat == "yuv420p" {
		cw /= 2
		ch /= 2
	}
	return &patternReader{p: p, cw: cw, ch: ch, frameBytes: p.Width*p.Height + 2*cw*ch}, nil
}
func (r *patternReader) Read(out []byte) (int, error) {
	if len(out) == 0 {
		return 0, nil
	}
	total := int64(r.frameBytes) * int64(r.p.Frames)
	if r.position == total {
		return 0, io.EOF
	}
	n := len(out)
	if int64(n) > total-r.position {
		n = int(total - r.position)
	}
	for i := 0; i < n; i++ {
		pos := r.position + int64(i)
		frame := int(pos / int64(r.frameBytes))
		inFrame := int(pos % int64(r.frameBytes))
		ySize := r.p.Width * r.p.Height
		switch {
		case inFrame < ySize:
			out[i] = byte(16 + (inFrame%r.p.Width+frame)%220)
		case inFrame < ySize+r.cw*r.ch:
			v := inFrame - ySize
			out[i] = byte(16 + ((v%r.cw+v/r.cw+frame)%2)*224)
		default:
			v := inFrame - ySize - r.cw*r.ch
			out[i] = byte(16 + ((v%r.cw+frame)%2)*224)
		}
	}
	r.position += int64(n)
	return n, nil
}

// cappedLog drains all stderr but retains at most 64 KiB. It contains only
// synthetic encoder diagnostics; no source desktop/audio data is acquired.
type cappedLog struct{ b []byte }

func (w *cappedLog) Write(p []byte) (int, error) {
	n := len(p)
	remaining := (64 << 10) - len(w.b)
	if len(p) > remaining {
		p = p[:remaining]
	}
	w.b = append(w.b, p...)
	return n, nil
}

// EncodePattern runs a caller-selected trusted FFmpeg installation without a
// shell. It writes lossless Annex-B H264 with AUD delimiters to out. This is a
// synthetic encoder backend, not a desktop capture or GameStream transport.
// The context controls process lifetime. The output writer must not block forever.
func EncodePattern(ctx context.Context, ffmpeg string, out io.Writer, p Pattern) error {
	if ctx == nil || ffmpeg == "" || out == nil {
		return errors.New("context, encoder path and output required")
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	input, err := NewPatternReader(p)
	if err != nil {
		return err
	}
	args := []string{"-hide_banner", "-nostdin", "-v", "error", "-f", "rawvideo", "-pixel_format", p.PixelFormat, "-video_size", fmt.Sprintf("%dx%d", p.Width, p.Height), "-framerate", strconv.Itoa(p.FPS), "-i", "pipe:0", "-frames:v", strconv.Itoa(p.Frames), "-an", "-c:v", "libx264", "-qp", "0", "-preset", "ultrafast", "-x264-params", "aud=1:repeat-headers=1", "-threads", "1", "-f", "h264", "pipe:1"}
	cmd := exec.CommandContext(ctx, ffmpeg, args...)
	cmd.Stdin = input
	cmd.Stdout = out
	log := &cappedLog{}
	cmd.Stderr = log
	if err = cmd.Run(); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return fmt.Errorf("synthetic encoder failed: %w: %s", err, string(log.b))
	}
	return nil
}
