// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"errors"
	"io"
	"testing"
	"time"
)

func TestLiveBeyondFixtureBudget(t *testing.T) {
	p := testPipeline(t)
	encoder := func(ctx context.Context, w io.Writer) error { return fixtureEncoder(ctx, w, Pattern{Frames: 600}) }
	stats, e := p.RunLive(context.Background(), encoder, func(context.Context, []byte) error { return nil }, 60)
	if e != nil || stats.Frames != 600 || stats.Packets != 600 {
		t.Fatal(stats, e)
	}
	if _, e = p.RunLive(context.Background(), encoder, func(context.Context, []byte) error { return nil }, 60); e == nil {
		t.Fatal("reused live key lifetime")
	}
}
func TestLiveCancellationJoinsEncoder(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan struct{})
	frames := 0
	encoder := func(ctx context.Context, w io.Writer) error {
		defer close(done)
		for {
			if e := fixtureEncoder(ctx, w, Pattern{Frames: 1}); e != nil {
				return e
			}
		}
	}
	stats, e := testPipeline(t).RunLive(ctx, encoder, func(context.Context, []byte) error {
		frames++
		if frames == 17 {
			cancel()
		}
		return nil
	}, 60)
	if !errors.Is(e, context.Canceled) || stats.Frames != 17 {
		t.Fatal(stats, e)
	}
	select {
	case <-done:
	default:
		t.Fatal("encoder was not joined")
	}
}
func TestLiveInvalidFormatAndEmptyStream(t *testing.T) {
	encoder := func(context.Context, io.Writer) error { return nil }
	sink := func(context.Context, []byte) error { return nil }
	for _, fps := range []int{0, 121} {
		if _, e := testPipeline(t).RunLive(context.Background(), encoder, sink, fps); e == nil {
			t.Fatal(fps)
		}
	}
	if _, e := testPipeline(t).RunLive(context.Background(), encoder, sink, 60); e == nil {
		t.Fatal("empty capture accepted")
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if _, e := testPipeline(t).RunLivePaced(ctx, func(ctx context.Context, w io.Writer) error { return fixtureEncoder(ctx, w, Pattern{Frames: 3}) }, sink, 120); e != nil {
		t.Fatal(e)
	}
}
