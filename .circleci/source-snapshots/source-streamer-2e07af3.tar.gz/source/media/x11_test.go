// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"errors"
	"io"
	"testing"
)

func TestX11ExplicitLocalDisplay(t *testing.T) {
	for _, s := range []string{":0", ":99", ":99.0", ":65535.15"} {
		if err := validateX11Display(s); err != nil {
			t.Fatal(s, err)
		}
	}
	for _, s := range []string{"", "localhost:0", "remote:99", ":1+0,0", ":1;sh", ":65536", ":1.16", "$DISPLAY", " :0", ":0\n"} {
		if err := validateX11Display(s); err == nil {
			t.Fatal("accepted", s)
		}
	}
}
func TestX11CanceledAndInvalidDoNotLaunch(t *testing.T) {
	p := Pattern{2, 2, 1, 30, "yuv444p"}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := CaptureX11(ctx, "missing", ":99", io.Discard, p); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	if err := CaptureX11(context.Background(), "missing", "remote:0", io.Discard, p); err == nil {
		t.Fatal("remote display accepted")
	}
}
