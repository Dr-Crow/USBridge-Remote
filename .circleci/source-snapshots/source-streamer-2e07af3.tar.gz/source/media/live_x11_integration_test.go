// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"errors"
	"io"
	"os"
	"testing"
	"time"
)

// The harness must create an isolated Xvfb display. Never point this fixture at
// a user's desktop. No packet is sent or saved; only counts and cleanup tested.
func TestLiveX11Integration(t *testing.T) {
	display := os.Getenv("STREAMER_X11_TEST_DISPLAY")
	if display == "" {
		t.Skip("isolated Xvfb harness required")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	joined := make(chan struct{})
	enc := func(ctx context.Context, w io.Writer) error {
		defer close(joined)
		return CaptureX11Live(ctx, "ffmpeg", display, w, Pattern{Width: 128, Height: 72, FPS: 30, PixelFormat: "yuv444p"})
	}
	packets := 0
	stats, err := testPipeline(t).RunLive(ctx, enc, func(context.Context, []byte) error {
		packets++
		if packets == 90 {
			cancel()
		}
		return nil
	}, 30)
	if !errors.Is(err, context.Canceled) || stats.Frames < 2 || packets != 90 {
		t.Fatal(stats, packets, err)
	}
	select {
	case <-joined:
	default:
		t.Fatal("live capture process did not join")
	}
}
