// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"errors"
	"io"
	"testing"
	"time"
)

func TestPacingNoCumulativeDrift(t *testing.T) {
	now := time.Unix(1000, 0)
	p := newFramePacer()
	p.now = func() time.Time { return now }
	var slept time.Duration
	p.sleep = func(_ context.Context, d time.Duration) error {
		if d <= 0 {
			t.Fatal(d)
		}
		slept += d
		now = now.Add(d)
		return nil
	}
	for i := 0; i < 300; i++ {
		if err := p.wait(context.Background(), i, 29); err != nil {
			t.Fatal(err)
		}
	}
	if slept != time.Duration(int64(299)*int64(time.Second)/29) {
		t.Fatal(slept)
	}
	now = now.Add(time.Second)
	before := slept
	if err := p.wait(context.Background(), 299, 29); err != nil || slept != before {
		t.Fatal("late frame slept")
	}
}
func TestPacingCancellationWhileWaiting(t *testing.T) {
	p := newFramePacer()
	if err := p.wait(context.Background(), 0, 1); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- p.wait(ctx, 299, 1) }()
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("pacing ignored cancel")
	}
}
func TestPacedPipelineWaitFailureJoinsEncoder(t *testing.T) {
	stopped := make(chan struct{})
	sentinel := errors.New("clock stopped")
	encoder := func(ctx context.Context, w io.Writer, p Pattern) error {
		defer close(stopped)
		for {
			if err := fixtureEncoder(ctx, w, p); err != nil {
				return err
			}
		}
	}
	count := 0
	wait := func(_ context.Context, frame, fps int) error {
		if frame == 1 {
			return sentinel
		}
		return nil
	}
	stats, err := testPipeline(t).run(context.Background(), encoder, func(context.Context, []byte) error { count++; return nil }, Pattern{2, 2, 3, 30, "yuv444p"}, wait)
	if !errors.Is(err, sentinel) || stats.Frames != 1 || count != 1 {
		t.Fatal(stats, count, err)
	}
	select {
	case <-stopped:
	default:
		t.Fatal("encoder not joined")
	}
}
func TestRunPacedAndUnpacedShareSingleUse(t *testing.T) {
	p := testPipeline(t)
	pattern := Pattern{2, 2, 2, 120, "yuv444p"}
	sink := func(context.Context, []byte) error { return nil }
	stats, err := p.RunPaced(context.Background(), fixtureEncoder, sink, pattern)
	if err != nil || stats.Frames != 2 {
		t.Fatal(stats, err)
	}
	if _, err = p.Run(context.Background(), fixtureEncoder, sink, pattern); err == nil {
		t.Fatal("pipeline reused across modes")
	}
}
