// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"bytes"
	"context"
	"errors"
	"io"
	"testing"
)

func TestPatternExactPlanes(t *testing.T) {
	for _, pix := range []string{"yuv420p", "yuv444p"} {
		p := Pattern{Width: 4, Height: 2, Frames: 2, FPS: 30, PixelFormat: pix}
		r, err := NewPatternReader(p)
		if err != nil {
			t.Fatal(err)
		}
		got, err := io.ReadAll(r)
		if err != nil {
			t.Fatal(err)
		}
		cw, ch := p.Width, p.Height
		if pix == "yuv420p" {
			cw /= 2
			ch /= 2
		}
		var want []byte
		for f := 0; f < 2; f++ {
			for y := 0; y < p.Height; y++ {
				for x := 0; x < p.Width; x++ {
					want = append(want, byte(16+(x+f)%220))
				}
			}
			for y := 0; y < ch; y++ {
				for x := 0; x < cw; x++ {
					want = append(want, byte(16+((x+y+f)%2)*224))
				}
			}
			for y := 0; y < ch; y++ {
				for x := 0; x < cw; x++ {
					want = append(want, byte(16+((x+f)%2)*224))
				}
			}
		}
		if !bytes.Equal(got, want) {
			t.Fatal(pix, got, want)
		}
		if n, err := r.Read(make([]byte, 1)); n != 0 || err != io.EOF {
			t.Fatal(n, err)
		}
	}
}
func TestPatternBounds(t *testing.T) {
	base := Pattern{Width: 128, Height: 72, Frames: 30, FPS: 30, PixelFormat: "yuv444p"}
	for _, mutate := range []func(*Pattern){func(p *Pattern) { p.Width = 3 }, func(p *Pattern) { p.Height = 1082 }, func(p *Pattern) { p.Frames = 301 }, func(p *Pattern) { p.FPS = 0 }, func(p *Pattern) { p.PixelFormat = "x" }} {
		p := base
		mutate(&p)
		if _, err := NewPatternReader(p); err == nil {
			t.Fatal(p)
		}
	}
}
func TestCanceledDoesNotLaunch(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	err := EncodePattern(ctx, "nonexistent-encoder", io.Discard, Pattern{})
	if !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}
func TestEncoderFailure(t *testing.T) {
	p := Pattern{Width: 2, Height: 2, Frames: 1, FPS: 1, PixelFormat: "yuv420p"}
	if err := EncodePattern(context.Background(), "/definitely/missing/ffmpeg", io.Discard, p); err == nil {
		t.Fatal("missing encoder succeeded")
	}
}
func TestCappedLog(t *testing.T) {
	w := &cappedLog{}
	p := make([]byte, 100000)
	n, err := w.Write(p)
	if err != nil || n != len(p) || len(w.b) != 64<<10 {
		t.Fatal(n, err, len(w.b))
	}
	w.Write(p)
	if len(w.b) != 64<<10 {
		t.Fatal("unbounded log")
	}
}
