// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"time"
)

// Private to the bounded, sequential pipeline. No goroutine or growing queue.
type framePacer struct {
	start   time.Time
	started bool
	now     func() time.Time
	sleep   func(context.Context, time.Duration) error
}

func newFramePacer() *framePacer {
	return &framePacer{now: time.Now, sleep: func(ctx context.Context, d time.Duration) error {
		timer := time.NewTimer(d)
		defer timer.Stop()
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-timer.C:
			return ctx.Err()
		}
	}}
}
func (p *framePacer) wait(ctx context.Context, frame, fps int) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if !p.started {
		p.start = p.now()
		p.started = true
	}
	// FPS is 1..120; the packetizer limits a live stream to uint32 frame count.
	// That count times one second fits int64. Derive each deadline from the
	// origin, avoiding cumulative integer interval truncation.
	deadline := p.start.Add(time.Duration(int64(frame) * int64(time.Second) / int64(fps)))
	if d := deadline.Sub(p.now()); d > 0 {
		return p.sleep(ctx, d)
	}
	return ctx.Err()
}
