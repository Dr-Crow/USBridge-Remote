// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
)

// ValidateWindowsGDIDisplay validates an explicit capture selection without
// opening a display. No default, window title, HWND or network source is accepted.
func ValidateWindowsGDIDisplay(display string) error {
	if display != "desktop" {
		return errors.New("explicit Windows GDI display desktop required")
	}
	return nil
}

// CaptureWindowsGDI captures exactly the requested width-by-height rectangle at
// (0,0) relative to the primary monitor, without a cursor or audio. It does not
// scale the whole desktop or choose another display if capture fails.
//
// The trusted caller MUST obtain separate operator capture consent for this
// region before calling, and supply an explicitly selected trusted absolute
// local FFmpeg .exe path. A display string alone is not consent. The output is
// AUD-delimited lossless H264 with repeated headers and an IDR for every frame.
// The context bounds process lifetime; out must not block forever.
func CaptureWindowsGDI(ctx context.Context, ffmpeg, display string, out io.Writer, p Pattern) error {
	return captureWindowsGDI(ctx, ffmpeg, display, out, p, false)
}

// CaptureWindowsGDILiveIntra applies the same region and consent requirements
// as CaptureWindowsGDI, and captures until canceled. Frames is ignored; all
// other format bounds remain enforced. All-IDR encoding satisfies keyframe
// requests without claiming dynamic control of the FFmpeg encoder. The caller
// must cancel the context and join the enclosing pipeline before returning.
func CaptureWindowsGDILiveIntra(ctx context.Context, ffmpeg, display string, out io.Writer, p Pattern) error {
	return captureWindowsGDI(ctx, ffmpeg, display, out, p, true)
}

// windowsGDIArgs is deliberately pure: validation and argument tests must never
// access a desktop, start a subprocess, or depend on the host operating system.
func windowsGDIArgs(display string, p Pattern, live bool) ([]string, error) {
	if err := ValidateWindowsGDIDisplay(display); err != nil {
		return nil, err
	}
	if live {
		p.Frames = 1
	}
	if err := p.Validate(); err != nil {
		return nil, err
	}
	args := []string{
		"-hide_banner", "-nostdin", "-v", "error",
		"-f", "gdigrab", "-draw_mouse", "0", "-offset_x", "0", "-offset_y", "0",
		"-video_size", fmt.Sprintf("%dx%d", p.Width, p.Height),
		"-framerate", strconv.Itoa(p.FPS), "-i", display,
	}
	if !live {
		args = append(args, "-frames:v", strconv.Itoa(p.Frames))
	}
	return append(args,
		"-an", "-pix_fmt", p.PixelFormat, "-c:v", "libx264", "-qp", "0",
		"-preset", "ultrafast", "-tune", "zerolatency",
		"-x264-params", "aud=1:repeat-headers=1:keyint=1:min-keyint=1:scenecut=0",
		"-threads", "1", "-f", "h264", "pipe:1",
	), nil
}

func captureWindowsGDI(ctx context.Context, ffmpeg, display string, out io.Writer, p Pattern, live bool) error {
	if ctx == nil || ffmpeg == "" || out == nil {
		return errors.New("context, encoder and output required")
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	args, err := windowsGDIArgs(display, p, live)
	if err != nil {
		return err
	}
	if runtime.GOOS != "windows" {
		return errors.New("Windows GDI capture adapter requires Windows")
	}
	// A trusted binary is selected by the caller, never through PATH or a shell.
	// Reject UNC/device paths and scripts as well as drive-relative paths.
	volume := filepath.VolumeName(ffmpeg)
	if !filepath.IsAbs(ffmpeg) || len(volume) != 2 || volume[1] != ':' ||
		!strings.EqualFold(filepath.Ext(ffmpeg), ".exe") {
		return errors.New("trusted absolute local Windows FFmpeg .exe path required")
	}
	cmd := exec.CommandContext(ctx, ffmpeg, args...)
	cmd.Stdout = out
	log := &cappedLog{}
	cmd.Stderr = log
	if err := cmd.Run(); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return fmt.Errorf("Windows GDI capture failed: %w: %s", err, string(log.b))
	}
	return nil
}
