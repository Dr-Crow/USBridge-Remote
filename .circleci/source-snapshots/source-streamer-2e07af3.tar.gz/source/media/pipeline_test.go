// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"bytes"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"io"
	"testing"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/gamestreamvideo"
)

func testPipeline(t *testing.T) *EncryptedPipeline {
	t.Helper()
	c, err := gamestreamvideo.NewVideoCipher(make([]byte, 16))
	if err != nil {
		t.Fatal(err)
	}
	p, err := NewEncryptedPipeline(64, c)
	if err != nil {
		t.Fatal(err)
	}
	return p
}
func fixtureEncoder(_ context.Context, w io.Writer, p Pattern) error {
	for i := 0; i < p.Frames; i++ {
		if _, err := w.Write([]byte{0, 0, 0, 1, 9, 0xf0, 0, 0, 0, 1, 0x65, byte(i + 1)}); err != nil {
			return err
		}
	}
	return nil
}
func TestEncryptedPipelineFrames(t *testing.T) {
	p := testPipeline(t)
	block, _ := aes.NewCipher(make([]byte, 16))
	g, _ := cipher.NewGCM(block)
	var timestamps []uint32
	sink := func(_ context.Context, b []byte) error {
		encrypted := append(append([]byte(nil), b[32:]...), b[16:32]...)
		plain, err := g.Open(nil, b[:12], encrypted, nil)
		if err != nil {
			return err
		}
		timestamps = append(timestamps, binary.BigEndian.Uint32(plain[4:8]))
		return nil
	}
	pattern := Pattern{Width: 2, Height: 2, Frames: 3, FPS: 29, PixelFormat: "yuv444p"}
	stats, err := p.Run(context.Background(), fixtureEncoder, sink, pattern)
	if err != nil || stats.Frames != 3 || stats.Packets != 3 || stats.Bytes == 0 {
		t.Fatal(stats, err)
	}
	for i, ts := range timestamps {
		if ts != uint32(i*90000/29) {
			t.Fatal(timestamps)
		}
	}
	if _, err = p.Run(context.Background(), fixtureEncoder, sink, pattern); err == nil {
		t.Fatal("pipeline reused")
	}
}
func TestPipelineFailureCleanup(t *testing.T) {
	sentinel := errors.New("sink failed")
	done := make(chan struct{})
	encoder := func(ctx context.Context, w io.Writer, p Pattern) error {
		defer close(done)
		// Keep producing until a failed sink closes the pipe.
		for {
			if err := fixtureEncoder(ctx, w, p); err != nil {
				return err
			}
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	_, err := testPipeline(t).Run(ctx, encoder, func(context.Context, []byte) error { return sentinel }, Pattern{2, 2, 3, 30, "yuv420p"})
	if !errors.Is(err, sentinel) {
		t.Fatal(err)
	}
	select {
	case <-done:
	default:
		t.Fatal("encoder not joined")
	}
}
func TestPipelineCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	started := make(chan struct{})
	encoder := func(ctx context.Context, _ io.Writer, _ Pattern) error {
		close(started)
		<-ctx.Done()
		return ctx.Err()
	}
	done := make(chan error, 1)
	go func() {
		_, err := testPipeline(t).Run(ctx, encoder, func(context.Context, []byte) error { return nil }, Pattern{2, 2, 1, 30, "yuv420p"})
		done <- err
	}()
	<-started
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("cancellation stalled")
	}
}
func TestPipelineRejectsMalformedOrMissingFrames(t *testing.T) {
	for _, data := range [][]byte{nil, []byte("garbage"), {0, 0, 0, 1, 9, 0xf0}} {
		_, err := testPipeline(t).Run(context.Background(), func(_ context.Context, w io.Writer, _ Pattern) error {
			_, e := io.Copy(w, bytes.NewReader(data))
			return e
		}, func(context.Context, []byte) error { return nil }, Pattern{2, 2, 1, 30, "yuv444p"})
		if err == nil {
			t.Fatal("invalid encoder output accepted")
		}
	}
	if _, err := NewEncryptedPipeline(64, nil); err == nil {
		t.Fatal("missing cipher accepted")
	}
}

func TestPipelineEncoderErrorAndExcessFrames(t *testing.T) {
	marker := errors.New("encoder stopped")
	for _, tc := range []struct {
		name    string
		encoder Encoder
		want    error
	}{
		{"failure", func(context.Context, io.Writer, Pattern) error { return marker }, marker},
		{"excess", func(ctx context.Context, w io.Writer, p Pattern) error { p.Frames++; return fixtureEncoder(ctx, w, p) }, nil},
	} {
		t.Run(tc.name, func(t *testing.T) {
			_, err := testPipeline(t).Run(context.Background(), tc.encoder, func(context.Context, []byte) error { return nil }, Pattern{2, 2, 1, 30, "yuv444p"})
			if err == nil || (tc.want != nil && !errors.Is(err, tc.want)) {
				t.Fatal(err)
			}
		})
	}
}
