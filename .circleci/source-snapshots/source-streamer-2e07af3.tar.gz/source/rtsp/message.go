// SPDX-License-Identifier: GPL-3.0-only
// Analyst-authored bounded RTSP/1.0 framing; not recovered Rust source.
package rtsp

import (
	"bufio"
	"bytes"
	"errors"
	"io"
	"net/textproto"
	"sort"
	"strconv"
	"strings"
)

const MaxHeader = 64 << 10
const MaxBody = 1 << 20

var ErrHeaderLimit = errors.New("header exceeds limit")

// Message preserves the start line and lower-case field names. Method/session
// semantics, authentication, RTP and interleaved binary data are separate layers.
type Message struct {
	StartLine string
	Headers   map[string]string
	Body      []byte
}

func token(s string) bool {
	if s == "" {
		return false
	}
	for _, c := range []byte(s) {
		if c <= 32 || c >= 127 || strings.ContainsRune("()<>@,;:\\\"/[]?={}", rune(c)) {
			return false
		}
	}
	return true
}
func text(s string) bool {
	for _, c := range []byte(s) {
		if c < 32 || c == 127 {
			return false
		}
	}
	return true
}
func validStart(s string) bool {
	if !text(s) {
		return false
	}
	fields := strings.SplitN(s, " ", 3)
	if len(fields) != 3 {
		return false
	}
	if fields[0] == "RTSP/1.0" {
		if len(fields[1]) != 3 || fields[1][0] < '1' || fields[1][0] > '5' {
			return false
		}
		_, err := decimal(fields[1], 999)
		return err == nil
	}
	return token(fields[0]) && fields[1] != "" && fields[2] == "RTSP/1.0"
}
func decimal(s string, max uint64) (uint64, error) {
	if s == "" {
		return 0, errors.New("empty decimal field")
	}
	for _, c := range []byte(s) {
		if c < '0' || c > '9' {
			return 0, errors.New("invalid decimal field")
		}
	}
	n, err := strconv.ParseUint(s, 10, 64)
	if err != nil || n > max {
		return 0, errors.New("decimal field exceeds limit")
	}
	return n, nil
}
func line(r *bufio.Reader, budget *int) (string, error) {
	var out []byte
	for {
		b, err := r.ReadSlice('\n')
		*budget -= len(b)
		if *budget < 0 {
			return "", ErrHeaderLimit
		}
		out = append(out, b...)
		if err == bufio.ErrBufferFull {
			continue
		}
		if err != nil {
			if err == io.EOF && len(out) > 0 {
				err = io.ErrUnexpectedEOF
			}
			return "", err
		}
		if len(out) < 2 || out[len(out)-2] != '\r' {
			return "", errors.New("expected CRLF")
		}
		return string(out[:len(out)-2]), nil
	}
}

// Read consumes one message from a caller-owned buffered stream. The same reader
// must be retained for successive messages. Deadlines/cancellation belong to the
// caller. Lengths and duplicate headers are rejected before body allocation.
func Read(r *bufio.Reader) (Message, error) {
	fail := func(err error) (Message, error) { return Message{}, err }
	budget := MaxHeader
	start, err := line(r, &budget)
	if err != nil {
		return fail(err)
	}
	if !validStart(start) {
		return fail(errors.New("invalid RTSP/1.0 start line"))
	}
	m := Message{StartLine: start, Headers: map[string]string{}}
	for {
		s, err := line(r, &budget)
		if err != nil {
			return fail(err)
		}
		if s == "" {
			break
		}
		name, value, ok := strings.Cut(s, ":")
		if !ok || !token(name) {
			return fail(errors.New("invalid header name"))
		}
		name = strings.ToLower(name)
		if strings.ContainsAny(value, "\r\n") {
			return fail(errors.New("header injection"))
		}
		value = strings.Trim(value, " \t")
		if !text(value) {
			return fail(errors.New("invalid header value"))
		}
		if _, exists := m.Headers[name]; exists {
			return fail(errors.New("duplicate header"))
		}
		m.Headers[name] = value
	}
	if _, err := decimal(m.Headers["cseq"], ^uint64(0)); err != nil {
		return fail(errors.New("invalid or missing CSeq"))
	}
	if _, ok := m.Headers["transfer-encoding"]; ok {
		return fail(errors.New("transfer encoding unsupported"))
	}
	var size uint64
	if s, ok := m.Headers["content-length"]; ok {
		size, err = decimal(s, MaxBody)
		if err != nil {
			return fail(err)
		}
	}
	m.Body = make([]byte, int(size))
	if _, err := io.ReadFull(r, m.Body); err != nil {
		return fail(err)
	}
	return m, nil
}

// Encode emits conventional wire header names and recalculates Content-Length.
// Internal map keys remain lower-case. The public Moonlight codec has case-sensitive
// lookups for CSeq and several extension headers, despite protocol case rules.
// It rejects duplicate names after case normalization and header injection.
func Encode(m Message) ([]byte, error) {
	if len(m.Body) > MaxBody || !validStart(m.StartLine) {
		return nil, errors.New("invalid message or body limit")
	}
	fields := make(map[string]string, len(m.Headers)+1)
	for k, v := range m.Headers {
		if !token(k) || !text(v) {
			return nil, errors.New("invalid header")
		}
		k = strings.ToLower(k)
		if _, ok := fields[k]; ok {
			return nil, errors.New("duplicate header")
		}
		fields[k] = v
	}
	if _, err := decimal(fields["cseq"], ^uint64(0)); err != nil {
		return nil, err
	}
	if _, ok := fields["transfer-encoding"]; ok {
		return nil, errors.New("transfer encoding unsupported")
	}
	fields["content-length"] = strconv.Itoa(len(m.Body))
	names := make([]string, 0, len(fields))
	for k := range fields {
		names = append(names, k)
	}
	sort.Strings(names)
	var out bytes.Buffer
	out.WriteString(m.StartLine + "\r\n")
	for _, k := range names {
		out.WriteString(wireHeaderName(k) + ": " + fields[k] + "\r\n")
	}
	out.WriteString("\r\n")
	if out.Len() > MaxHeader {
		return nil, ErrHeaderLimit
	}
	out.Write(m.Body)
	return out.Bytes(), nil
}

func wireHeaderName(k string) string {
	switch k {
	case "cseq":
		return "CSeq"
	case "x-ss-ping-payload":
		return "X-SS-Ping-Payload"
	case "x-ss-connect-data":
		return "X-SS-Connect-Data"
	case "www-authenticate":
		return "WWW-Authenticate"
	default:
		return textproto.CanonicalMIMEHeaderKey(k)
	}
}
