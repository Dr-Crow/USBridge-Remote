// SPDX-License-Identifier: GPL-3.0-only
package rtsp

import (
	"bufio"
	"bytes"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

func TestPublicClientInterop(t *testing.T) {
	binary := os.Getenv("RTSP_INTEROP_BINARY")
	if binary == "" {
		t.Skip("pinned public C codec fixture not configured")
	}
	request, err := exec.Command(binary, "emit").Output()
	if err != nil {
		t.Fatal(err)
	}
	got, err := Read(bufio.NewReader(bytes.NewReader(request)))
	if err != nil || got.StartLine != "ANNOUNCE rtsp://127.0.0.1/test RTSP/1.0" || got.Headers["cseq"] != "7" || string(got.Body) != "v=0\r\n" {
		t.Fatalf("public request mismatch: %v", err)
	}
	wire, err := Encode(Message{StartLine: "RTSP/1.0 200 OK", Headers: map[string]string{
		"cseq": "7", "session": "test-session", "transport": "RTP/AVP/UDP;unicast;server_port=48000",
		"x-ss-ping-payload": "test-ping", "x-ss-connect-data": "test-connect",
	}, Body: []byte("v=0\r\n")})
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "response.rtsp")
	if err = os.WriteFile(path, wire, 0600); err != nil {
		t.Fatal(err)
	}
	if out, err := exec.Command(binary, "check", path).CombinedOutput(); err != nil {
		t.Fatalf("public client response decoder: %v: %s", err, out)
	}
}
