// SPDX-License-Identifier: GPL-3.0-only
package rtsp

import (
	"bufio"
	"bytes"
	"errors"
	"io"
	"strings"
	"testing"
)

type fragmented struct{ io.Reader }

func (r fragmented) Read(p []byte) (int, error) {
	if len(p) > 1 {
		p = p[:1]
	}
	return r.Reader.Read(p)
}
func parse(s string) (Message, error) { return Read(bufio.NewReader(strings.NewReader(s))) }
func TestMessages(t *testing.T) {
	for _, s := range []string{"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\n\r\n", "RTSP/1.0 200 OK\r\nCSeq: 2\r\nContent-Length: 3\r\n\r\nabc"} {
		m, e := parse(s)
		if e != nil {
			t.Fatal(e)
		}
		wire, e := Encode(m)
		if e != nil {
			t.Fatal(e)
		}
		got, e := Read(bufio.NewReader(fragmented{bytes.NewReader(wire)}))
		if e != nil || got.StartLine != m.StartLine || !bytes.Equal(got.Body, m.Body) {
			t.Fatalf("%+v %v", got, e)
		}
	}
}
func TestConcatenated(t *testing.T) {
	s := "OPTIONS * RTSP/1.0\r\nCSeq: 1\r\n\r\n"
	r := bufio.NewReader(strings.NewReader(s + s))
	for i := 0; i < 2; i++ {
		if _, e := Read(r); e != nil {
			t.Fatal(e)
		}
	}
	if _, e := Read(r); e != io.EOF {
		t.Fatalf("expected EOF got %v", e)
	}
}
func TestInvalid(t *testing.T) {
	for _, s := range []string{
		"OPTIONS * RTSP/2.0\r\nCSeq: 1\r\n\r\n",
		"OPTIONS * RTSP/1.0\nCSeq: 1\n\n",
		"OPTIONS * RTSP/1.0\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: -1\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\ncseq: 1\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nBad Header: x\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nX: \rx\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nX: x\r\n continued\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nTransfer-Encoding: chunked\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nContent-Length: 1048577\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nContent-Length: 18446744073709551616\r\n\r\n",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nContent-Length: 3\r\n\r\nab",
		"OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nX: " + strings.Repeat("x", MaxHeader) + "\r\n\r\n",
	} {
		if _, e := parse(s); e == nil {
			t.Fatalf("accepted invalid input of %d bytes", len(s))
		}
	}
}
func TestEncodeDefenses(t *testing.T) {
	for _, h := range []map[string]string{{"CSeq": "1", "cseq": "1"}, {"cseq": "1", "x": "a\r\nInjected: yes"}, {"cseq": "1", "transfer-encoding": "chunked"}} {
		if _, e := Encode(Message{StartLine: "OPTIONS * RTSP/1.0", Headers: h}); e == nil {
			t.Fatal("accepted unsafe header")
		}
	}
	m := Message{StartLine: "ANNOUNCE rtsp://127.0.0.1/ RTSP/1.0", Headers: map[string]string{"cseq": "5", "content-length": "999"}, Body: []byte("sdp")}
	b, e := Encode(m)
	if e != nil {
		t.Fatal(e)
	}
	got, e := Read(bufio.NewReader(bytes.NewReader(b)))
	if e != nil || got.Headers["content-length"] != "3" {
		t.Fatal("did not recalculate content length")
	}
}
func FuzzMessage(f *testing.F) {
	f.Add([]byte("OPTIONS * RTSP/1.0\r\nCSeq: 1\r\n\r\n"))
	f.Add([]byte("RTSP/1.0 200 OK\r\nCSeq: 2\r\nContent-Length: 3\r\n\r\nabc"))
	f.Fuzz(func(t *testing.T, raw []byte) {
		if len(raw) > MaxHeader+MaxBody {
			return
		}
		m, e := Read(bufio.NewReader(bytes.NewReader(raw)))
		if e != nil {
			return
		}
		wire, e := Encode(m)
		if errors.Is(e, ErrHeaderLimit) {
			return
		}
		if e != nil {
			t.Fatalf("accepted message cannot encode: %v", e)
		}
		got, e := Read(bufio.NewReader(bytes.NewReader(wire)))
		if e != nil || got.StartLine != m.StartLine || !bytes.Equal(got.Body, m.Body) {
			t.Fatal("roundtrip mismatch")
		}
	})
}

func TestWireHeaderNames(t *testing.T) {
	m := Message{StartLine: "RTSP/1.0 200 OK", Headers: map[string]string{"cseq": "7", "session": "test", "transport": "test", "x-ss-ping-payload": "test", "x-ss-connect-data": "test"}}
	raw, err := Encode(m)
	if err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"CSeq", "Session", "Transport", "X-SS-Ping-Payload", "X-SS-Connect-Data", "Content-Length"} {
		if !bytes.Contains(raw, []byte("\r\n"+name+": ")) {
			t.Fatalf("missing conventional wire name %s", name)
		}
	}
}
