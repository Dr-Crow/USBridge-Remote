module github.com/Dr-Crow/rustshine-research/source

go 1.26.6
