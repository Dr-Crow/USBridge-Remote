// SPDX-License-Identifier: GPL-3.0-only
// Analyst-authored parsing of a bounded public-client ANNOUNCE subset.
package sdp

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
)

const MaxBody = 64 << 10
const MaxLine = 4096
const MaxLines = 512

// VideoRequest is requested configuration, not a claim of backend support or
// authorization. An absent encryption field is distinguishable from explicit
// zero. Callers must negotiate security separately; never silently downgrade.
type VideoRequest struct {
	Width, Height, FPS, PacketSize                                uint32
	EncryptionFlags                                               uint32
	HasEncryptionFlags                                            bool
	ChromaSampling                                                uint32
	HasChromaSampling                                             bool
	AudioChannels, AudioChannelMask, AudioPacketDuration          uint32
	AudioSurround, AudioQuality                                   uint32
	HasAudioChannels, HasAudioChannelMask, HasAudioPacketDuration bool
	HasAudioSurround, HasAudioQuality                             bool
}

// ParseVideoRequest accepts a modern textual ANNOUNCE subset. It is not a
// general SDP parser or a complete validator for a GameStream session. Unknown
// fields are ignored; malformed framing and duplicate known fields are errors.
// No socket, session, encoder, credential or cryptographic operation is opened.
func ParseVideoRequest(body []byte) (VideoRequest, error) {
	var out VideoRequest
	if len(body) == 0 || len(body) > MaxBody {
		return out, errors.New("SDP body size out of bounds")
	}
	s := string(body)
	if !strings.HasSuffix(s, "\r\n") {
		return out, errors.New("SDP requires CRLF termination")
	}
	lines := strings.Split(s[:len(s)-2], "\r\n")
	if len(lines) > MaxLines {
		return out, errors.New("too many SDP lines")
	}
	if lines[0] != "v=0" {
		return out, errors.New("unsupported SDP version")
	}
	seen := make(map[string]bool)
	for i, line := range lines {
		if len(line) < 2 || len(line) > MaxLine || line[1] != '=' || line[0] < 'a' || line[0] > 'z' {
			return VideoRequest{}, errors.New("invalid SDP line")
		}
		for _, c := range []byte(line) {
			if c < 32 || c > 126 {
				return VideoRequest{}, errors.New("non-text SDP field")
			}
		}
		if i != 0 && line[0] == 'v' {
			return VideoRequest{}, errors.New("duplicate SDP version")
		}
		if !strings.HasPrefix(line, "a=") {
			continue
		}
		key, value, found := strings.Cut(line[2:], ":")
		var dst *uint32
		positive := false
		switch key {
		case "x-nv-video[0].clientViewportWd":
			dst, positive = &out.Width, true
		case "x-nv-video[0].clientViewportHt":
			dst, positive = &out.Height, true
		case "x-nv-video[0].maxFPS":
			dst, positive = &out.FPS, true
		case "x-nv-video[0].packetSize":
			dst, positive = &out.PacketSize, true
		case "x-ss-general.encryptionEnabled":
			dst = &out.EncryptionFlags
			out.HasEncryptionFlags = true
		case "x-ss-video[0].chromaSamplingType":
			dst = &out.ChromaSampling
			out.HasChromaSampling = true
		case "x-nv-audio.surround.numChannels":
			dst = &out.AudioChannels
			out.HasAudioChannels = true
		case "x-nv-audio.surround.channelMask":
			dst = &out.AudioChannelMask
			out.HasAudioChannelMask = true
		case "x-nv-aqos.packetDuration":
			dst = &out.AudioPacketDuration
			out.HasAudioPacketDuration = true
		case "x-nv-audio.surround.enable":
			dst = &out.AudioSurround
			out.HasAudioSurround = true
		case "x-nv-audio.surround.AudioQuality":
			dst = &out.AudioQuality
			out.HasAudioQuality = true
		default:
			continue
		}
		if !found {
			return VideoRequest{}, fmt.Errorf("missing SDP attribute value %s", key)
		}
		if seen[key] {
			return VideoRequest{}, fmt.Errorf("duplicate SDP attribute %s", key)
		}
		seen[key] = true
		// The pinned public generator emits a trailing ASCII space before CRLF.
		value = strings.Trim(value, " ")
		if value == "" {
			return VideoRequest{}, fmt.Errorf("empty SDP attribute %s", key)
		}
		for _, c := range []byte(value) {
			if c < '0' || c > '9' {
				return VideoRequest{}, fmt.Errorf("nondecimal SDP attribute %s", key)
			}
		}
		n, err := strconv.ParseUint(value, 10, 32)
		if err != nil || (positive && n == 0) {
			return VideoRequest{}, fmt.Errorf("out of range SDP attribute %s", key)
		}
		*dst = uint32(n)
	}
	if out.Width == 0 || out.Height == 0 || out.FPS == 0 || out.PacketSize == 0 {
		return VideoRequest{}, errors.New("missing required video attribute")
	}
	if out.HasChromaSampling && out.ChromaSampling > 1 {
		return VideoRequest{}, errors.New("unsupported chroma sampling value")
	}
	return out, nil
}
