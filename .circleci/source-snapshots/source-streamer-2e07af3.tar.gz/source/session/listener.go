// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"context"
	"errors"
	"net"
	"sync"
	"sync/atomic"
)

// ListenerStats count accepted sockets and transaction outcomes, not paired
// clients or successful streaming sessions. Rejected sockets receive no data.
type ListenerStats struct{ Accepted, Rejected, Completed, Failed uint64 }

// ServeLaunch owns a caller-bound listener and one already authenticated launch
// endpoint. It never selects an owner or issues keys from untrusted requests.
// The caller must bind only an intended interface and supply a fresh launch key.
// Across reconnects the endpoint retains its encryption/replay state. Capacity
// bounds active transaction goroutines; each transaction has a five-second
// deadline. Saturation closes excess sockets without a plaintext response.
// Shutdown cancels transactions, joins them, and closes the endpoint once.
// Backend/authorizer callbacks must honor context, as required by their APIs.
func ServeLaunch(ctx context.Context, listener net.Listener, endpoint *EncryptedEndpoint, capacity int) (stats ListenerStats, result error) {
	if ctx == nil || listener == nil || endpoint == nil || capacity < 1 || capacity > 64 {
		return stats, errors.New("context, listener, launch endpoint and capacity 1..64 required")
	}
	runCtx, cancel := context.WithCancel(ctx)
	stop := context.AfterFunc(runCtx, func() { _ = listener.Close() })
	var wg sync.WaitGroup
	var completed, failed atomic.Uint64
	slots := make(chan struct{}, capacity)
	defer func() {
		cancel()
		_ = listener.Close()
		wg.Wait()
		stop()
		result = errors.Join(result, endpoint.Close())
		stats.Completed, stats.Failed = completed.Load(), failed.Load()
		if ctx.Err() != nil {
			result = errors.Join(ctx.Err(), result)
		}
	}()
	for {
		conn, err := listener.Accept()
		if err != nil {
			if runCtx.Err() != nil {
				return stats, nil
			}
			return stats, err
		}
		stats.Accepted++
		if runCtx.Err() != nil {
			_ = conn.Close()
			return stats, nil
		}
		select {
		case slots <- struct{}{}:
			wg.Add(1)
			go func() {
				defer wg.Done()
				defer func() { <-slots }()
				if err := ServeTransaction(runCtx, conn, endpoint); err != nil {
					failed.Add(1)
				} else {
					completed.Add(1)
				}
				// TEARDOWN, revocation and backend failure terminate this launch. A bad
				// packet alone does not close the launch or reset its replay counters.
				if endpoint.session.State() == Closed {
					cancel()
				}
			}()
		default:
			stats.Rejected++
			_ = conn.Close()
		}
	}
}
