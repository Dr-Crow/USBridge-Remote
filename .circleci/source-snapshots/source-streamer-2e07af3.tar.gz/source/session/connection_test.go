// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"context"
	"errors"
	"github.com/Dr-Crow/rustshine-research/source/rtsp"
	"io"
	"net"
	"testing"
	"time"
)

func transactFixture(t *testing.T, e *EncryptedEndpoint, packet []byte) ([]byte, error) {
	t.Helper()
	server, client := net.Pipe()
	defer client.Close()
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() { done <- ServeTransaction(ctx, server, e) }()
	_ = client.SetDeadline(time.Now().Add(time.Second))
	if _, err := client.Write(packet); err != nil {
		t.Fatal(err)
	}
	reply, err := io.ReadAll(client)
	if err != nil {
		t.Fatal(err)
	}
	return reply, <-done
}
func TestEncryptedFlowAcrossFreshConnections(t *testing.T) {
	key := []byte("0123456789abcdef")
	b := &fakeBackend{}
	e, err := NewEncryptedEndpoint("paired-user", "fixture-session", key, b, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	var first []byte
	for i, req := range flow() {
		wire, err := rtsp.Encode(req)
		if err != nil {
			t.Fatal(err)
		}
		packet := clientPacket(t, key, wire, uint32(i+1))
		if i == 0 {
			first = packet
		}
		reply, err := transactFixture(t, e, packet)
		if err != nil {
			t.Fatal(err)
		}
		if m := hostReply(t, key, reply); m.StartLine != "RTSP/1.0 200 OK" {
			t.Fatal(m)
		}
	}
	if e.session.State() != Playing {
		t.Fatal(e.session.State())
	}
	reply, err := transactFixture(t, e, first)
	if err == nil || len(reply) != 0 {
		t.Fatal("replay accepted across connections")
	}
	if e.session.State() != Playing {
		t.Fatal("connection failure incorrectly ended launch")
	}
}
func TestTransactionCancellationUnblocksRead(t *testing.T) {
	b := &fakeBackend{}
	e, err := NewEncryptedEndpoint("owner", "session", []byte("0123456789abcdef"), b, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	server, client := net.Pipe()
	defer client.Close()
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- ServeTransaction(ctx, server, e) }()
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("read did not stop")
	}
}
func TestTransactionTamperHasNoResponse(t *testing.T) {
	b := &fakeBackend{}
	key := []byte("0123456789abcdef")
	e, err := NewEncryptedEndpoint("owner", "session", key, b, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	wire, _ := rtsp.Encode(flow()[0])
	packet := clientPacket(t, key, wire, 1)
	packet[8] ^= 1
	reply, err := transactFixture(t, e, packet)
	if err == nil || len(reply) != 0 || len(b.calls) != 0 {
		t.Fatal("tamper had effects", err, b.calls)
	}
}

func TestTransactionCancellationUnblocksResponseWrite(t *testing.T) {
	key := []byte("0123456789abcdef")
	b := &fakeBackend{}
	e, err := NewEncryptedEndpoint("owner", "session", key, b, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	server, client := net.Pipe()
	defer client.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan error, 1)
	go func() { done <- ServeTransaction(ctx, server, e) }()
	wire, _ := rtsp.Encode(flow()[0])
	packet := clientPacket(t, key, wire, 1)
	_ = client.SetDeadline(time.Now().Add(time.Second))
	if _, err := client.Write(packet); err != nil {
		t.Fatal(err)
	}
	// Do not read the response; cancellation must unblock the pending write.
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("write did not stop")
	}
}
