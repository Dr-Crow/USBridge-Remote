// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"sync"

	"github.com/Dr-Crow/rustshine-research/source/rtsp"
	"github.com/Dr-Crow/rustshine-research/source/rtspsecure"
)

// EncryptedEndpoint binds one authenticated launch key and owner to a session.
// It handles complete encrypted packets in memory, not network connections.
// Pairing/launch code must establish the owner and provide a fresh unique key.
// Retain this instance throughout the launch; never recreate it with the same key.
type EncryptedEndpoint struct {
	mu      sync.Mutex
	session *Session
	channel *rtspsecure.Host
}

func NewEncryptedEndpoint(owner, id string, key []byte, b Backend, auth Authorize) (*EncryptedEndpoint, error) {
	c, err := rtspsecure.NewHost(key)
	if err != nil {
		return nil, err
	}
	s, err := NewSession(owner, id, b, auth)
	if err != nil {
		return nil, err
	}
	return &EncryptedEndpoint{session: s, channel: c}, nil
}

// Exchange verifies the packet tag/replay state, parses exactly one RTSP message,
// authorizes/dispatches it and encrypts the response. Application errors can return
// both an encrypted error response and a diagnostic error. Framing/authentication
// errors return no response. Callers must not put diagnostic errors on the wire.
func (e *EncryptedEndpoint) Exchange(ctx context.Context, packet []byte) ([]byte, error) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if ctx == nil {
		return nil, errors.New("missing context")
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	plain, err := e.channel.Open(packet)
	if err != nil {
		return nil, err
	}
	r := bufio.NewReader(bytes.NewReader(plain))
	req, err := rtsp.Read(r)
	if err != nil {
		return nil, err
	}
	if _, err = r.Peek(1); err == nil {
		return nil, errors.New("multiple messages in encrypted packet")
	}
	reply, dispatchErr := e.session.Handle(ctx, e.session.owner, req)
	wire, err := rtsp.Encode(reply)
	if err != nil {
		return nil, errors.Join(dispatchErr, err)
	}
	sealed, err := e.channel.Seal(wire)
	return sealed, errors.Join(dispatchErr, err)
}
func (e *EncryptedEndpoint) Close() error { e.mu.Lock(); defer e.mu.Unlock(); return e.session.Close() }
