// SPDX-License-Identifier: GPL-3.0-only
// Analyst-authored modern RTSP session orchestration, not recovered Rust source.
package session

import (
	"context"
	"crypto/sha256"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"sync"

	"github.com/Dr-Crow/rustshine-research/source/rtsp"
	"github.com/Dr-Crow/rustshine-research/source/sdp"
)

type Stream string

const (
	Audio   Stream = "audio"
	Video   Stream = "video"
	Control Stream = "control"
)

// Backend must implement real capabilities: Describe cannot advertise codecs or
// security it cannot support; Setup must return an owned port; Configure must
// reject unsupported configuration/security. Each operation must honor context.
// Close must release all resources, including partly completed operations.
// Session serializes calls. A backend must not call back into its Session.
type Backend interface {
	Describe(context.Context) ([]byte, error)
	Setup(context.Context, Stream) (uint16, error)
	Configure(context.Context, sdp.VideoRequest) error
	Start(context.Context) error
	Close() error
}

// SetupMetadata optionally supplies the bounded public-client rendezvous token
// for this stream. These headers are sent only in the already encrypted RTSP
// exchange. A token is launch scoped, not a substitute for authenticated pairing.
type SetupMetadata interface {
	SetupHeaders(Stream) map[string]string
}

// Authorize validates the already authenticated principal's permission to use
// this session. It is checked for every request, including retries. It does not
// replace pairing or transport encryption, which must precede this API.
// It must honor context and must not re-enter the same Session.
type Authorize func(context.Context, string) error

type State string

const (
	New          State = "new"
	Described    State = "described"
	AudioReady   State = "audio-ready"
	VideoReady   State = "video-ready"
	ControlReady State = "control-ready"
	Configured   State = "configured"
	Playing      State = "playing"
	Closed       State = "closed"
)

type Session struct {
	mu           sync.Mutex
	owner, id    string
	backend      Backend
	authorize    Authorize
	state        State
	lastSeq      uint64
	haveSeq      bool
	lastDigest   [32]byte
	lastResponse rtsp.Message
	lastErr      error
}

func NewSession(owner, id string, b Backend, auth Authorize) (*Session, error) {
	if owner == "" || id == "" || len(id) > 128 || b == nil || auth == nil {
		return nil, errors.New("session requires owner, identifier, backend and authorizer")
	}
	for _, c := range []byte(id) {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-' || c == '_') {
			return nil, errors.New("invalid session identifier")
		}
	}
	return &Session{owner: owner, id: id, backend: b, authorize: auth, state: New}, nil
}
func (s *Session) State() State { s.mu.Lock(); defer s.mu.Unlock(); return s.state }
func (s *Session) Close() error { s.mu.Lock(); defer s.mu.Unlock(); return s.close() }
func (s *Session) close() error {
	if s.state == Closed {
		return nil
	}
	s.state = Closed
	return s.backend.Close()
}
func copyMessage(m rtsp.Message) rtsp.Message {
	n := rtsp.Message{StartLine: m.StartLine, Headers: make(map[string]string, len(m.Headers)), Body: append([]byte(nil), m.Body...)}
	for k, v := range m.Headers {
		n.Headers[k] = v
	}
	return n
}
func response(seq string, code int) rtsp.Message {
	names := map[int]string{200: "OK", 400: "Bad Request", 403: "Forbidden", 454: "Session Not Found", 455: "Method Not Valid in This State", 500: "Internal Server Error", 501: "Not Implemented"}
	return rtsp.Message{StartLine: fmt.Sprintf("RTSP/1.0 %d %s", code, names[code]), Headers: map[string]string{"cseq": seq}}
}

// Handle orchestrates the modern public-client flow. There is no network
// listener. Requests must already have passed rtsp.Read and authenticated
// transport processing. Errors are diagnostic only and are not put on the wire.
func (s *Session) Handle(ctx context.Context, principal string, req rtsp.Message) (rtsp.Message, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	seqText := req.Headers["cseq"]
	if ctx == nil {
		return response(seqText, 400), errors.New("missing context")
	}
	if err := ctx.Err(); err != nil {
		return response(seqText, 400), err
	}
	if principal != s.owner {
		return response(seqText, 403), errors.New("principal mismatch")
	}
	if err := s.authorize(ctx, principal); err != nil {
		return response(seqText, 403), errors.Join(err, s.close())
	}
	if s.state == Closed {
		return response(seqText, 454), errors.New("session closed")
	}
	// Re-encoding validates the envelope for direct API callers as well.
	wire, err := rtsp.Encode(req)
	if err != nil {
		return response(seqText, 400), err
	}
	fields := strings.SplitN(req.StartLine, " ", 3)
	if len(fields) != 3 || fields[0] == "RTSP/1.0" {
		return response(seqText, 400), errors.New("request required")
	}
	seq, err := strconv.ParseUint(seqText, 10, 64)
	if err != nil {
		return response(seqText, 400), errors.New("invalid sequence")
	}
	digest := sha256.Sum256(wire)
	if s.haveSeq && seq <= s.lastSeq {
		if seq == s.lastSeq && digest == s.lastDigest {
			return copyMessage(s.lastResponse), s.lastErr
		}
		return response(seqText, 400), errors.New("stale or changed sequence")
	}
	reply, handleErr := s.handle(ctx, req, fields[0], fields[1])
	s.haveSeq = true
	s.lastSeq = seq
	s.lastDigest = digest
	s.lastResponse = copyMessage(reply)
	s.lastErr = handleErr
	return reply, handleErr
}
func (s *Session) handle(ctx context.Context, req rtsp.Message, method, target string) (rtsp.Message, error) {
	reply := response(req.Headers["cseq"], 200)
	fail := func(code int, err error) (rtsp.Message, error) { return response(req.Headers["cseq"], code), err }
	backendFail := func(err error) (rtsp.Message, error) { return fail(500, errors.Join(err, s.close())) }
	if method != "OPTIONS" && method != "DESCRIBE" && !(method == "SETUP" && s.state == Described && target == "streamid=audio/0/0") {
		if req.Headers["session"] != s.id {
			return fail(454, errors.New("session identifier mismatch"))
		}
	}
	if id := req.Headers["session"]; id != "" && id != s.id {
		return fail(454, errors.New("session identifier mismatch"))
	}
	switch method {
	case "OPTIONS":
		reply.Headers["public"] = "OPTIONS, DESCRIBE, SETUP, ANNOUNCE, PLAY, TEARDOWN"
	case "DESCRIBE":
		if s.state != New && s.state != Described {
			return fail(455, errors.New("description after setup"))
		}
		body, err := s.backend.Describe(ctx)
		if err != nil {
			return backendFail(err)
		}
		if len(body) == 0 || len(body) > rtsp.MaxBody {
			return backendFail(errors.New("backend description size invalid"))
		}
		reply.Body = append([]byte(nil), body...)
		reply.Headers["content-type"] = "application/sdp"
		s.state = Described
	case "SETUP":
		var stream Stream
		var next State
		switch {
		case s.state == Described && target == "streamid=audio/0/0":
			stream, next = Audio, AudioReady
		case s.state == AudioReady && target == "streamid=video/0/0":
			stream, next = Video, VideoReady
		case s.state == VideoReady && target == "streamid=control/13/0":
			stream, next = Control, ControlReady
		default:
			return fail(455, errors.New("unsupported setup order or target"))
		}
		port, err := s.backend.Setup(ctx, stream)
		if err != nil {
			return backendFail(err)
		}
		if port == 0 {
			return backendFail(errors.New("backend supplied zero port"))
		}
		reply.Headers["session"] = s.id
		reply.Headers["transport"] = fmt.Sprintf("server_port=%d", port)
		if metadata, ok := s.backend.(SetupMetadata); ok {
			for key, value := range metadata.SetupHeaders(stream) {
				if key != "x-ss-ping-payload" || len(value) != 16 {
					return backendFail(errors.New("unsupported setup metadata"))
				}
				for _, c := range []byte(value) {
					if c < 33 || c > 126 {
						return backendFail(errors.New("invalid setup ping token"))
					}
				}
				reply.Headers[key] = value
			}
		}
		s.state = next
	case "ANNOUNCE":
		if s.state != ControlReady || target != "streamid=control/13/0" {
			return fail(455, errors.New("announce before setup or wrong target"))
		}
		if req.Headers["content-type"] != "application/sdp" {
			return fail(400, errors.New("SDP content type required"))
		}
		config, err := sdp.ParseVideoRequest(req.Body)
		if err != nil {
			return fail(400, err)
		}
		if err = s.backend.Configure(ctx, config); err != nil {
			return backendFail(err)
		}
		reply.Headers["session"] = s.id
		s.state = Configured
	case "PLAY":
		if s.state != Configured || target != "/" {
			return fail(455, errors.New("play before configuration or wrong target"))
		}
		if err := s.backend.Start(ctx); err != nil {
			return backendFail(err)
		}
		reply.Headers["session"] = s.id
		s.state = Playing
	case "TEARDOWN":
		if err := s.close(); err != nil {
			return fail(500, err)
		}
	default:
		return fail(501, errors.New("unsupported method"))
	}
	return reply, nil
}
