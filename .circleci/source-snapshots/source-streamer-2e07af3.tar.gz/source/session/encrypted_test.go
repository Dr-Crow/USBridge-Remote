// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"bufio"
	"bytes"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"testing"

	"github.com/Dr-Crow/rustshine-research/source/rtsp"
)

// Synthetic client-side fixture follows the pinned public client's packet layout.
// It is not execution of the complete public client or a stock server capture.
func fixtureAEAD(t *testing.T, key []byte) cipher.AEAD {
	t.Helper()
	b, err := aes.NewCipher(key)
	if err != nil {
		t.Fatal(err)
	}
	g, err := cipher.NewGCM(b)
	if err != nil {
		t.Fatal(err)
	}
	return g
}
func clientPacket(t *testing.T, key, plain []byte, seq uint32) []byte {
	t.Helper()
	var iv [12]byte
	binary.LittleEndian.PutUint32(iv[:4], seq)
	iv[10] = 'C'
	iv[11] = 'R'
	sealed := fixtureAEAD(t, key).Seal(nil, iv[:], plain, nil)
	p := make([]byte, 24+len(plain))
	binary.BigEndian.PutUint32(p, 0x80000000|uint32(len(plain)))
	binary.BigEndian.PutUint32(p[4:], seq)
	copy(p[8:24], sealed[len(plain):])
	copy(p[24:], sealed[:len(plain)])
	return p
}
func hostReply(t *testing.T, key, packet []byte) rtsp.Message {
	t.Helper()
	if len(packet) <= 24 {
		t.Fatal("short reply")
	}
	n := binary.BigEndian.Uint32(packet) & 0x7fffffff
	if int(n) != len(packet)-24 {
		t.Fatal("length")
	}
	seq := binary.BigEndian.Uint32(packet[4:8])
	var iv [12]byte
	binary.LittleEndian.PutUint32(iv[:4], seq)
	iv[10] = 'H'
	iv[11] = 'R'
	sealed := append(append([]byte(nil), packet[24:]...), packet[8:24]...)
	p, err := fixtureAEAD(t, key).Open(nil, iv[:], sealed, nil)
	if err != nil {
		t.Fatal(err)
	}
	r, err := rtsp.Read(bufio.NewReader(bytes.NewReader(p)))
	if err != nil {
		t.Fatal(err)
	}
	return r
}
func TestEncryptedModernExchange(t *testing.T) {
	key := []byte("0123456789abcdef")
	b := &fakeBackend{}
	e, err := NewEncryptedEndpoint("paired-user", "fixture-session", key, b, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	for i, req := range flow() {
		wire, err := rtsp.Encode(req)
		if err != nil {
			t.Fatal(err)
		}
		packet := clientPacket(t, key, wire, uint32(i+1))
		reply, err := e.Exchange(context.Background(), packet)
		if err != nil {
			t.Fatal(err)
		}
		m := hostReply(t, key, reply)
		if m.StartLine != "RTSP/1.0 200 OK" || m.Headers["cseq"] != req.Headers["cseq"] {
			t.Fatal(m)
		}
		if _, err = e.Exchange(context.Background(), packet); err == nil {
			t.Fatal("encrypted replay accepted")
		}
	}
	if e.session.State() != Playing || len(b.calls) != 6 {
		t.Fatal(e.session.State(), b.calls)
	}
}
func TestBadEncryptedInputHasNoBackendSideEffects(t *testing.T) {
	key := []byte("0123456789abcdef")
	for _, plain := range [][]byte{[]byte("junk"), []byte("OPTIONS * RTSP/1.0\r\nCSeq: 1\r\n\r\nOPTIONS * RTSP/1.0\r\nCSeq: 2\r\n\r\n")} {
		b := &fakeBackend{}
		e, err := NewEncryptedEndpoint("paired-user", "fixture-session", key, b, func(context.Context, string) error { return nil })
		if err != nil {
			t.Fatal(err)
		}
		reply, err := e.Exchange(context.Background(), clientPacket(t, key, plain, 1))
		if err == nil || reply != nil || len(b.calls) != 0 {
			t.Fatal(err, b.calls)
		}
		e.Close()
	}
}
