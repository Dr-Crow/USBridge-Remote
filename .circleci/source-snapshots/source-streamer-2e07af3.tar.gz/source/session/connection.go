// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"context"
	"errors"
	"github.com/Dr-Crow/rustshine-research/source/rtspsecure"
	"io"
	"net"
	"time"
)

// ServeTransaction owns and closes conn, serving one encrypted RTSP request.
// The public TCP client reconnects per transaction and reads its reply to EOF.
// The launch owner MUST retain endpoint and its counters across those connections
// and close it at launch teardown. A connection closing is not launch teardown.
// There is no listener, key issuance, pairing or plaintext fallback here.
// The caller must select the endpoint from an authenticated launch, rather than
// allowing a remote client to choose arbitrary owners. All diagnostic errors
// stay local; only Exchange's encrypted protocol response is written.
func ServeTransaction(ctx context.Context, conn net.Conn, endpoint *EncryptedEndpoint) error {
	if ctx == nil || conn == nil || endpoint == nil {
		return errors.New("context, connection and authenticated launch endpoint required")
	}
	defer conn.Close()
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	if err := ctx.Err(); err != nil {
		return err
	}
	stop := context.AfterFunc(ctx, func() { _ = conn.Close() })
	defer stop()
	deadline := time.Now().Add(5 * time.Second)
	if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
		deadline = d
	}
	if err := conn.SetDeadline(deadline); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return err
	}
	packet, err := rtspsecure.ReadPacket(conn)
	if err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return err
	}
	reply, exchangeErr := endpoint.Exchange(ctx, packet)
	if len(reply) == 0 {
		return exchangeErr
	}
	for len(reply) > 0 {
		n, err := conn.Write(reply)
		if err != nil {
			if ctx.Err() != nil {
				return errors.Join(ctx.Err(), exchangeErr)
			}
			return errors.Join(err, exchangeErr)
		}
		if n <= 0 {
			return errors.Join(io.ErrShortWrite, exchangeErr)
		}
		reply = reply[n:]
	}
	return exchangeErr
}
