// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"testing"
)

type controlFixture struct {
	start, ping, idr, closed int
	fail                     bool
}

func (b *controlFixture) StartControl(context.Context) error { b.start++; return nil }
func (b *controlFixture) Keepalive(context.Context) error    { b.ping++; return nil }
func (b *controlFixture) RequestIDR(context.Context) error {
	b.idr++
	if b.fail {
		return errors.New("encoder unavailable")
	}
	return nil
}
func (b *controlFixture) CloseControl() error { b.closed++; return nil }
func controlPacket(seq uint32, typ uint16, payload []byte) []byte {
	b, _ := aes.NewCipher(make([]byte, 16))
	a, _ := cipher.NewGCM(b)
	iv := make([]byte, 12)
	binary.LittleEndian.PutUint32(iv, seq)
	iv[10] = 'C'
	iv[11] = 'C'
	p := make([]byte, 4+len(payload))
	binary.LittleEndian.PutUint16(p, typ)
	binary.LittleEndian.PutUint16(p[2:], uint16(len(payload)))
	copy(p[4:], payload)
	s := a.Seal(nil, iv, p, nil)
	out := make([]byte, 28+len(payload))
	binary.LittleEndian.PutUint16(out, 1)
	binary.LittleEndian.PutUint16(out[2:], uint16(len(out)-4))
	binary.LittleEndian.PutUint32(out[4:], seq)
	copy(out[8:24], s[len(p):])
	copy(out[24:], s[:len(p)])
	return out
}
func TestControlDispatchAndAuthorization(t *testing.T) {
	b := &controlFixture{}
	allowed := true
	e, err := NewControlEndpoint("owner", make([]byte, 16), b, func(context.Context, string) error {
		if !allowed {
			return errors.New("revoked")
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	cases := []struct {
		typ uint16
		p   []byte
	}{{0x302, []byte{0, 0}}, {0x307, []byte{0}}, {0x200, []byte{4, 0, 0, 0, 0, 0, 123, 255}}}
	for i, c := range cases {
		if err = e.Handle(ctx, "owner", controlPacket(uint32(i), c.typ, c.p)); err != nil {
			t.Fatal(err)
		}
	}
	if b.start != 1 || b.ping != 1 || b.idr != 1 {
		t.Fatal(b)
	}
	if err = e.Handle(ctx, "other", controlPacket(3, 0x302, []byte{0, 0})); err == nil {
		t.Fatal("wrong owner")
	}
	if err = e.Handle(ctx, "owner", controlPacket(0, 0x302, []byte{0, 0})); err == nil {
		t.Fatal("replayed action")
	}
	if b.idr != 1 {
		t.Fatal("replayed backend")
	}
	allowed = false
	if err = e.Handle(ctx, "owner", controlPacket(3, 0x302, []byte{0, 0})); err == nil {
		t.Fatal("revoked owner")
	}
	if b.closed != 1 || b.idr != 1 {
		t.Fatal(b)
	}
	allowed = true
	e.Close()
	if b.closed != 1 {
		t.Fatal("double close")
	}
	if err = e.Handle(ctx, "owner", controlPacket(4, 0x302, []byte{0, 0})); err == nil {
		t.Fatal("reopened")
	}
}
func TestControlRejectsMalformedUnsupportedAndFailure(t *testing.T) {
	b := &controlFixture{}
	e, _ := NewControlEndpoint("owner", make([]byte, 16), b, func(context.Context, string) error { return nil })
	defer e.Close()
	for i, c := range []struct {
		typ uint16
		p   []byte
	}{{0x302, nil}, {0x302, []byte{1, 0}}, {0x307, []byte{1}}, {0x200, make([]byte, 8)}, {0x206, []byte{1, 2, 3}}} {
		if err := e.Handle(context.Background(), "owner", controlPacket(uint32(i), c.typ, c.p)); err == nil {
			t.Fatal(i)
		}
	}
	if b.start+b.ping+b.idr != 0 {
		t.Fatal("invalid action dispatched")
	}
	tamper := controlPacket(5, 0x302, []byte{0, 0})
	tamper[8] ^= 1
	if err := e.Handle(context.Background(), "owner", tamper); err == nil {
		t.Fatal("tampered action")
	}
	b.fail = true
	if err := e.Handle(context.Background(), "owner", controlPacket(5, 0x302, []byte{0, 0})); err == nil {
		t.Fatal("backend failure hidden")
	}
	if b.idr != 1 || b.closed != 1 {
		t.Fatal(b)
	}
}

func TestAutomaticClientNoticesAreAuthenticatedAndBounded(t *testing.T) {
	b := &controlFixture{}
	e, _ := NewControlEndpoint("owner", make([]byte, 16), b, func(context.Context, string) error { return nil })
	defer e.Close()
	notices := [][]byte{{0, 0, 0, 6, 0x0d, 0, 0, 0, 1, 0}, make([]byte, 21)}
	notices[1][20] = 1
	for i, p := range notices {
		typ := uint16(0x0206)
		if i == 1 {
			typ = 0x5502
		}
		if err := e.Handle(context.Background(), "owner", controlPacket(uint32(i), typ, p)); err != nil {
			t.Fatal(err)
		}
	}
	if b.start+b.ping+b.idr != 0 {
		t.Fatal("notice invoked device or encoder action")
	}
	notices[0][8] = 0
	if err := e.Handle(context.Background(), "owner", controlPacket(2, 0x0206, notices[0])); err == nil {
		t.Fatal("unsupported input accepted")
	}
	notices[1][19] = 1
	if err := e.Handle(context.Background(), "owner", controlPacket(3, 0x5502, notices[1])); err == nil {
		t.Fatal("invalid FEC block index accepted")
	}
}

type inputControlFixture struct {
	controlFixture
	inputs int
	last   []byte
}

func (b *inputControlFixture) HandleInput(_ context.Context, p []byte) error {
	b.inputs++
	b.last = append([]byte(nil), p...)
	return nil
}
func TestOptionalInputDispatchRemainsAuthenticated(t *testing.T) {
	b := &inputControlFixture{}
	e, _ := NewControlEndpoint("owner", make([]byte, 16), b, func(context.Context, string) error { return nil })
	defer e.Close()
	record := []byte{0, 0, 0, 10, 3, 0, 0, 0, 0, 0x41, 0, 0, 0, 0}
	p := controlPacket(0, 0x206, record)
	bad := append([]byte(nil), p...)
	bad[8] ^= 1
	if err := e.Handle(context.Background(), "owner", bad); err == nil || b.inputs != 0 {
		t.Fatal("unauthenticated input reached backend")
	}
	if err := e.Handle(context.Background(), "owner", p); err != nil || b.inputs != 1 {
		t.Fatal(err, b.inputs)
	}
	if err := e.Handle(context.Background(), "owner", p); err == nil || b.inputs != 1 {
		t.Fatal("replayed input reached backend")
	}
}
