// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"context"
	"errors"
	"strconv"
	"strings"
	"sync"
	"testing"

	"github.com/Dr-Crow/rustshine-research/source/rtsp"
	"github.com/Dr-Crow/rustshine-research/source/sdp"
)

const configBody = "v=0\r\na=x-nv-video[0].clientViewportWd:1920 \r\na=x-nv-video[0].clientViewportHt:1080 \r\na=x-nv-video[0].maxFPS:60 \r\na=x-nv-video[0].packetSize:1024 \r\na=x-ss-general.encryptionEnabled:7 \r\n"

type fakeBackend struct {
	calls  []string
	fail   string
	config sdp.VideoRequest
	closes int
}

func (b *fakeBackend) call(name string) error {
	b.calls = append(b.calls, name)
	if b.fail == name {
		return errors.New("fixture failure")
	}
	return nil
}
func (b *fakeBackend) Describe(context.Context) ([]byte, error) {
	return []byte("v=0\r\n"), b.call("describe")
}
func (b *fakeBackend) Setup(_ context.Context, s Stream) (uint16, error) {
	return 48000, b.call(string(s))
}
func (b *fakeBackend) Configure(_ context.Context, c sdp.VideoRequest) error {
	b.config = c
	return b.call("configure")
}
func (b *fakeBackend) Start(context.Context) error { return b.call("start") }
func (b *fakeBackend) Close() error                { b.closes++; return b.call("close") }
func makeSession(t *testing.T) (*Session, *fakeBackend) {
	t.Helper()
	b := &fakeBackend{}
	s, err := NewSession("paired-user", "fixture-session", b, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	return s, b
}
func request(n int, method, target string) rtsp.Message {
	return rtsp.Message{StartLine: method + " " + target + " RTSP/1.0", Headers: map[string]string{"cseq": strconv.Itoa(n), "session": "fixture-session"}}
}
func flow() []rtsp.Message {
	messages := []rtsp.Message{request(1, "OPTIONS", "rtsp://192.0.2.1"), request(2, "DESCRIBE", "rtsp://192.0.2.1"), request(3, "SETUP", "streamid=audio/0/0"), request(4, "SETUP", "streamid=video/0/0"), request(5, "SETUP", "streamid=control/13/0"), request(6, "ANNOUNCE", "streamid=control/13/0"), request(7, "PLAY", "/")}
	delete(messages[2].Headers, "session")
	messages[5].Headers["content-type"] = "application/sdp"
	messages[5].Body = []byte(configBody)
	return messages
}
func runThrough(t *testing.T, s *Session, n int) {
	t.Helper()
	for _, r := range flow()[:n] {
		reply, err := s.Handle(context.Background(), "paired-user", r)
		if err != nil || reply.StartLine != "RTSP/1.0 200 OK" {
			t.Fatalf("%s: %+v %v", r.StartLine, reply, err)
		}
	}
}
func TestModernFlow(t *testing.T) {
	s, b := makeSession(t)
	runThrough(t, s, 7)
	if s.State() != Playing {
		t.Fatal(s.State())
	}
	if strings.Join(b.calls, ",") != "describe,audio,video,control,configure,start" {
		t.Fatal(b.calls)
	}
	if b.config.Width != 1920 || !b.config.HasEncryptionFlags || b.config.EncryptionFlags != 7 {
		t.Fatal(b.config)
	}
	if err := s.Close(); err != nil {
		t.Fatal(err)
	}
	s.Close()
	if b.closes != 1 || s.State() != Closed {
		t.Fatal("cleanup not idempotent")
	}
}
func TestRetriesDoNotRepeatBackend(t *testing.T) {
	s, b := makeSession(t)
	for _, r := range flow() {
		first, err := s.Handle(context.Background(), "paired-user", r)
		if err != nil {
			t.Fatal(err)
		}
		first.Headers["session"] = "changed"
		first.Body = append(first.Body, 'X')
		second, err := s.Handle(context.Background(), "paired-user", r)
		if err != nil || second.Headers["session"] == "changed" {
			t.Fatalf("reply alias/retry: %+v %v", second, err)
		}
	}
	if len(b.calls) != 6 {
		t.Fatal(b.calls)
	}
}
func TestAuthorizationAlwaysChecked(t *testing.T) {
	s, b := makeSession(t)
	deny := false
	calls := 0
	s.authorize = func(context.Context, string) error {
		calls++
		if deny {
			return errors.New("revoked")
		}
		return nil
	}
	r := flow()[1]
	if _, err := s.Handle(context.Background(), "intruder", r); err == nil {
		t.Fatal("principal accepted")
	}
	if len(b.calls) != 0 {
		t.Fatal(b.calls)
	}
	if _, err := s.Handle(context.Background(), "paired-user", r); err != nil {
		t.Fatal(err)
	}
	deny = true
	reply, err := s.Handle(context.Background(), "paired-user", r)
	if err == nil || !strings.Contains(reply.StartLine, "403") || calls != 2 || len(b.calls) != 2 || b.closes != 1 || s.State() != Closed {
		t.Fatal(reply, err, calls, b.calls)
	}
}
func TestWrongSessionDoesNotAdvance(t *testing.T) {
	s, b := makeSession(t)
	runThrough(t, s, 3)
	r := flow()[3]
	r.Headers["session"] = "wrong"
	reply, err := s.Handle(context.Background(), "paired-user", r)
	if err == nil || !strings.Contains(reply.StartLine, "454") || s.State() != AudioReady || len(b.calls) != 2 {
		t.Fatal(reply, err, s.State(), b.calls)
	}
}
func TestOrderingAndSequence(t *testing.T) {
	s, b := makeSession(t)
	r := request(1, "PLAY", "/")
	reply, err := s.Handle(context.Background(), "paired-user", r)
	if err == nil || !strings.Contains(reply.StartLine, "455") || len(b.calls) != 0 {
		t.Fatal(reply, err)
	}
	r = request(1, "DESCRIBE", "rtsp://192.0.2.1")
	if _, err = s.Handle(context.Background(), "paired-user", r); err == nil {
		t.Fatal("changed CSeq accepted")
	}
	r.Headers["cseq"] = "2"
	if _, err = s.Handle(context.Background(), "paired-user", r); err != nil {
		t.Fatal(err)
	}
	r.Headers["cseq"] = "1"
	if _, err = s.Handle(context.Background(), "paired-user", r); err == nil {
		t.Fatal("stale CSeq accepted")
	}
}
func TestBackendFailuresCloseResources(t *testing.T) {
	for _, stage := range []string{"describe", "audio", "video", "control", "configure", "start"} {
		t.Run(stage, func(t *testing.T) {
			s, b := makeSession(t)
			b.fail = stage
			failed := false
			for _, r := range flow() {
				reply, err := s.Handle(context.Background(), "paired-user", r)
				if err != nil {
					if !strings.Contains(reply.StartLine, "500") {
						t.Fatal(reply, err)
					}
					failed = true
					break
				}
			}
			if !failed || s.State() != Closed || b.closes != 1 {
				t.Fatal(failed, s.State(), b.closes)
			}
			s.Close()
			if b.closes != 1 {
				t.Fatal("double cleanup")
			}
		})
	}
}
func TestMalformedAnnounceCanBeCorrected(t *testing.T) {
	s, b := makeSession(t)
	runThrough(t, s, 5)
	r := flow()[5]
	r.Body = []byte("v=0\r\n")
	if _, err := s.Handle(context.Background(), "paired-user", r); err == nil {
		t.Fatal("bad config accepted")
	}
	if s.State() != ControlReady || len(b.calls) != 4 {
		t.Fatal(s.State(), b.calls)
	}
	r = flow()[5]
	r.Headers["cseq"] = "7"
	if _, err := s.Handle(context.Background(), "paired-user", r); err != nil {
		t.Fatal(err)
	}
}
func TestCanceledContextAndClosedSession(t *testing.T) {
	s, b := makeSession(t)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := s.Handle(ctx, "paired-user", flow()[0]); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	if len(b.calls) != 0 {
		t.Fatal(b.calls)
	}
	s.Close()
	if _, err := s.Handle(context.Background(), "paired-user", flow()[0]); err == nil {
		t.Fatal("closed session accepted")
	}
}
func TestConcurrentDuplicateSetup(t *testing.T) {
	s, b := makeSession(t)
	runThrough(t, s, 2)
	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if _, err := s.Handle(context.Background(), "paired-user", flow()[2]); err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if len(b.calls) != 2 || s.State() != AudioReady {
		t.Fatal(b.calls, s.State())
	}
}
func TestConstructorRequiresBoundaries(t *testing.T) {
	if _, err := NewSession("u", "id", &fakeBackend{}, nil); err == nil {
		t.Fatal("nil authorizer")
	}
	if _, err := NewSession("u", "bad\r\nid", &fakeBackend{}, func(context.Context, string) error { return nil }); err == nil {
		t.Fatal("bad ID")
	}
}

func TestFirstSetupRejectsWrongProvidedSession(t *testing.T) {
	s, b := makeSession(t)
	runThrough(t, s, 2)
	r := flow()[2]
	r.Headers["session"] = "other-session"
	if _, err := s.Handle(context.Background(), "paired-user", r); err == nil {
		t.Fatal("wrong explicit first session accepted")
	}
	if len(b.calls) != 1 || s.State() != Described {
		t.Fatal(b.calls, s.State())
	}
}
func TestTeardownClosesOnce(t *testing.T) {
	s, b := makeSession(t)
	runThrough(t, s, 3)
	if reply, err := s.Handle(context.Background(), "paired-user", request(4, "TEARDOWN", "/")); err != nil || reply.StartLine != "RTSP/1.0 200 OK" {
		t.Fatal(reply, err)
	}
	s.Close()
	if b.closes != 1 || s.State() != Closed {
		t.Fatal(b.closes, s.State())
	}
}

func FuzzLifecycle(f *testing.F) {
	f.Add([]byte{0, 1, 2, 3, 4, 5, 6, 7})
	f.Add([]byte{2, 2, 5, 6, 1, 3, 7})
	f.Fuzz(func(t *testing.T, steps []byte) {
		if len(steps) > 64 {
			return
		}
		s, b := makeSession(t)
		for i, step := range steps {
			var r rtsp.Message
			if step%8 == 7 {
				r = request(i+1, "TEARDOWN", "/")
			} else {
				r = flow()[int(step%8)]
				r.Headers["cseq"] = strconv.Itoa(i + 1)
			}
			if step&16 != 0 {
				r.Headers["session"] = "wrong"
			}
			if step&32 != 0 {
				r.Body = []byte("invalid")
			}
			_, _ = s.Handle(context.Background(), "paired-user", r)
		}
		s.Close()
		s.Close()
		starts, configured := 0, false
		for _, call := range b.calls {
			if call == "configure" {
				configured = true
			}
			if call == "start" {
				starts++
				if !configured {
					t.Fatal("start without config")
				}
			}
		}
		if starts > 1 || b.closes != 1 || s.State() != Closed {
			t.Fatal(starts, b.closes, s.State())
		}
	})
}
