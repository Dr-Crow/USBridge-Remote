// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"context"
	"errors"
	"io"
	"net"
	"testing"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/rtsp"
)

func TestLaunchListenerTCPFlowAndCancellation(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	key := []byte("0123456789abcdef")
	b := &fakeBackend{}
	endpoint, err := NewEncryptedEndpoint("paired-user", "fixture-session", key, b, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	type outcome struct {
		stats ListenerStats
		err   error
	}
	done := make(chan outcome, 1)
	go func() { s, e := ServeLaunch(ctx, listener, endpoint, 2); done <- outcome{s, e} }()
	transact := func(packet []byte) []byte {
		t.Helper()
		conn, err := net.DialTimeout("tcp", listener.Addr().String(), time.Second)
		if err != nil {
			t.Fatal(err)
		}
		defer conn.Close()
		_ = conn.SetDeadline(time.Now().Add(time.Second))
		if _, err = conn.Write(packet); err != nil {
			t.Fatal(err)
		}
		reply, err := io.ReadAll(conn)
		if err != nil {
			t.Fatal(err)
		}
		return reply
	}
	var first []byte
	for i, req := range flow() {
		wire, err := rtsp.Encode(req)
		if err != nil {
			t.Fatal(err)
		}
		p := clientPacket(t, key, wire, uint32(i+1))
		if i == 0 {
			first = p
		}
		reply := hostReply(t, key, transact(p))
		if reply.StartLine != "RTSP/1.0 200 OK" {
			t.Fatal(reply)
		}
	}
	if reply := transact(first); len(reply) != 0 {
		t.Fatal("replay returned response")
	}
	if endpoint.session.State() != Playing {
		t.Fatal("replay stopped launch")
	}
	// A socket that never supplies framing must not prevent launch shutdown.
	idle, err := net.DialTimeout("tcp", listener.Addr().String(), time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer idle.Close()
	cancel()
	select {
	case out := <-done:
		if !errors.Is(out.err, context.Canceled) || out.stats.Completed != uint64(len(flow())) || out.stats.Failed < 1 {
			t.Fatal(out)
		}
		if endpoint.session.State() != Closed {
			t.Fatal("endpoint not closed")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("listener failed to join on cancellation")
	}
}

func TestLaunchListenerClosedSocketStopsEndpoint(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	_ = listener.Close()
	endpoint, err := NewEncryptedEndpoint("owner", "session", []byte("0123456789abcdef"), &fakeBackend{}, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	if _, err = ServeLaunch(context.Background(), listener, endpoint, 1); err == nil {
		t.Fatal("closed listener succeeded")
	}
	if endpoint.session.State() != Closed {
		t.Fatal("endpoint leaked")
	}
}

func TestLaunchListenerCapacityRejectsWithoutResponse(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	endpoint, err := NewEncryptedEndpoint("owner", "session", []byte("0123456789abcdef"), &fakeBackend{}, func(context.Context, string) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	type outcome struct {
		stats ListenerStats
		err   error
	}
	done := make(chan outcome, 1)
	go func() { s, e := ServeLaunch(ctx, listener, endpoint, 1); done <- outcome{s, e} }()
	first, err := net.DialTimeout("tcp", listener.Addr().String(), time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer first.Close()
	second, err := net.DialTimeout("tcp", listener.Addr().String(), time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer second.Close()
	_ = second.SetReadDeadline(time.Now().Add(time.Second))
	var b [1]byte
	if n, err := second.Read(b[:]); n != 0 || err != io.EOF {
		t.Fatal("excess socket not silently closed", n, err)
	}
	cancel()
	select {
	case out := <-done:
		if out.stats.Accepted != 2 || out.stats.Rejected != 1 || out.stats.Failed != 1 || !errors.Is(out.err, context.Canceled) {
			t.Fatal(out)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("shutdown blocked")
	}
}

func TestLaunchListenerRevocationEndsLaunch(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	key := []byte("0123456789abcdef")
	endpoint, err := NewEncryptedEndpoint("owner", "session", key, &fakeBackend{}, func(context.Context, string) error { return errors.New("revoked") })
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() { _, err := ServeLaunch(ctx, listener, endpoint, 1); done <- err }()
	conn, err := net.DialTimeout("tcp", listener.Addr().String(), time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(time.Second))
	wire, err := rtsp.Encode(flow()[0])
	if err != nil {
		t.Fatal(err)
	}
	if _, err = conn.Write(clientPacket(t, key, wire, 1)); err != nil {
		t.Fatal(err)
	}
	reply, err := io.ReadAll(conn)
	if err != nil {
		t.Fatal(err)
	}
	if hostReply(t, key, reply).StartLine != "RTSP/1.0 403 Forbidden" {
		t.Fatal("revocation response")
	}
	select {
	case err := <-done:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("revoked launch did not stop")
	}
	if endpoint.session.State() != Closed {
		t.Fatal("revoked endpoint leaked")
	}
}
