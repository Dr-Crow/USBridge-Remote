// SPDX-License-Identifier: GPL-3.0-only
// Offline framing diagnostic; not a streaming server.
package main

import (
	"bufio"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/Dr-Crow/rustshine-research/source/rtsp"
	"io"
	"os"
)

var version = "dev"

func main() {
	file := flag.String("file", "", "one RTSP/1.0 message file (never a URL)")
	ver := flag.Bool("version", false, "print source build version")
	flag.Parse()
	if *ver {
		fmt.Println(version)
		return
	}
	if *file == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "usage: rtsp-message-inspect --file MESSAGE; not a streaming server")
		os.Exit(2)
	}
	f, e := os.Open(*file)
	if e != nil {
		fmt.Fprintln(os.Stderr, "cannot open input file")
		os.Exit(1)
	}
	defer f.Close()
	r := bufio.NewReader(f)
	m, e := rtsp.Read(r)
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	if _, e = r.Peek(1); e != io.EOF {
		fmt.Fprintln(os.Stderr, "expected exactly one message")
		os.Exit(1)
	}
	// Never print request paths, headers or body, which may contain credentials.
	e = json.NewEncoder(os.Stdout).Encode(struct {
		Headers int `json:"header_count"`
		Body    int `json:"body_bytes"`
	}{len(m.Headers), len(m.Body)})
	if e != nil {
		fmt.Fprintln(os.Stderr, "cannot write report")
		os.Exit(1)
	}
}
