// SPDX-License-Identifier: GPL-3.0-only
package main

import "testing"

func TestRejectInvalidLoopbackPortBeforeEncoder(t *testing.T) {
	for _, port := range []int{-1, 65536} {
		if err := run("must-not-execute", "yuv444p", false, port); err == nil {
			t.Fatal(port)
		}
	}
}
