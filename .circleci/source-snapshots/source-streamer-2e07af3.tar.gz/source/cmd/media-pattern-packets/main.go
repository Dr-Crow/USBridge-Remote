// SPDX-License-Identifier: GPL-3.0-only
// Offline end-to-end synthetic media fixture. PUBLIC key, never deployment.
package main

import (
	"context"
	"encoding/binary"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"strconv"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/gamestreamvideo"
	"github.com/Dr-Crow/rustshine-research/source/media"
)

var version = "development"

func main() {
	pix := flag.String("pixel-format", "yuv444p", "synthetic yuv420p or yuv444p")
	ffmpeg := flag.String("ffmpeg", "ffmpeg", "trusted installed FFmpeg")
	port := flag.Int("test-loopback-udp-port", 0, "PUBLIC-key test packets to IPv4 loopback only; forces pacing")
	paced := flag.Bool("paced", false, "pace frame emission using a monotonic clock")
	show := flag.Bool("version", false, "print source version")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "unexpected arguments")
		os.Exit(2)
	}
	if err := run(*ffmpeg, *pix, *paced, *port); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(ffmpeg, pix string, paced bool, port int) error {
	if port < 0 || port > 65535 {
		return fmt.Errorf("test UDP port must be 1..65535, or 0 for file output")
	}
	var conn *net.UDPConn
	if port != 0 {
		remote := &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: port}
		var err error
		conn, err = net.DialUDP("udp4", nil, remote)
		if err != nil {
			return err
		}
		defer conn.Close()
		paced = true
		fmt.Fprintln(os.Stderr, "PUBLIC TEST KEY ONLY; IPv4 loopback destination port "+strconv.Itoa(port))
	}
	key := make([]byte, 16)
	for i := range key {
		key[i] = byte(i)
	}
	cipher, err := gamestreamvideo.NewVideoCipher(key)
	if err != nil {
		return err
	}
	pipeline, err := media.NewEncryptedPipeline(1024, cipher)
	if err != nil {
		return err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	encoder := func(ctx context.Context, w io.Writer, p media.Pattern) error {
		return media.EncodePattern(ctx, ffmpeg, w, p)
	}
	sink := func(ctx context.Context, packet []byte) error {
		if err := ctx.Err(); err != nil {
			return err
		}
		if conn != nil {
			deadline := time.Now().Add(time.Second)
			if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
				deadline = d
			}
			if err := conn.SetWriteDeadline(deadline); err != nil {
				return err
			}
			n, err := conn.Write(packet)
			if err != nil {
				return err
			}
			if n != len(packet) {
				return io.ErrShortWrite
			}
			return nil
		}
		if err := binary.Write(os.Stdout, binary.BigEndian, uint32(len(packet))); err != nil {
			return err
		}
		_, err := os.Stdout.Write(packet)
		return err
	}
	runner := pipeline.Run
	if paced {
		runner = pipeline.RunPaced
	}
	_, err = runner(ctx, encoder, sink, media.Pattern{Width: 128, Height: 72, Frames: 30, FPS: 30, PixelFormat: pix})
	return err
}
