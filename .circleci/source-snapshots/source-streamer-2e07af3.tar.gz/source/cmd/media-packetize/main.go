// SPDX-License-Identifier: GPL-3.0-only
// Offline packet fixture exporter. Output is length-prefixed records, not UDP.
package main

import (
	"encoding/binary"
	"flag"
	"fmt"
	"github.com/Dr-Crow/rustshine-research/source/annexb"
	"github.com/Dr-Crow/rustshine-research/source/gamestreamvideo"
	"io"
	"os"
)

var version = "development"

func main() {
	file := flag.String("file", "", "synthetic Annex-B file with AUDs")
	size := flag.Int("packet-size", 1024, "negotiated video packet size")
	encrypted := flag.Bool("test-encrypted", false, "encrypt offline fixture with PUBLIC deterministic test key; never for deployment")
	show := flag.Bool("version", false, "source version")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if *file == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "--file required")
		os.Exit(2)
	}
	if err := run(*file, *size, *encrypted); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(path string, size int, encrypted bool) error {
	var protector *gamestreamvideo.VideoCipher
	if encrypted {
		key := make([]byte, 16)
		for i := range key {
			key[i] = byte(i)
		}
		var err error
		protector, err = gamestreamvideo.NewVideoCipher(key)
		if err != nil {
			return err
		}
	}
	p, err := gamestreamvideo.NewPlainPacketizer(size)
	if err != nil {
		return err
	}
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	r := annexb.NewReader(f)
	var ts uint32
	for {
		frame, err := r.Next()
		if err == io.EOF {
			return nil
		}
		if err != nil {
			return err
		}
		packets, err := p.Packetize(frame, ts)
		if err != nil {
			return err
		}
		ts += 3000
		for _, packet := range packets {
			if protector != nil {
				packet, err = protector.Seal(packet)
				if err != nil {
					return err
				}
			}
			if err = binary.Write(os.Stdout, binary.BigEndian, uint32(len(packet))); err != nil {
				return err
			}
			if _, err = os.Stdout.Write(packet); err != nil {
				return err
			}
		}
	}
}
