// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"context"
	"flag"
	"fmt"
	"github.com/Dr-Crow/rustshine-research/source/media"
	"os"
	"time"
)

var version = "development"

func main() {
	width := flag.Int("width", 128, "synthetic width")
	height := flag.Int("height", 72, "synthetic height")
	frames := flag.Int("frames", 30, "bounded synthetic frame count")
	fps := flag.Int("fps", 30, "synthetic frame rate")
	pix := flag.String("pixel-format", "yuv444p", "yuv420p or yuv444p")
	encoder := flag.String("ffmpeg", "ffmpeg", "trusted installed FFmpeg path")
	showVersion := flag.Bool("version", false, "print source version")
	flag.Parse()
	if *showVersion {
		fmt.Println(version)
		return
	}
	if flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "unexpected arguments")
		os.Exit(2)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	if err := media.EncodePattern(ctx, *encoder, os.Stdout, media.Pattern{Width: *width, Height: *height, Frames: *frames, FPS: *fps, PixelFormat: *pix}); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
