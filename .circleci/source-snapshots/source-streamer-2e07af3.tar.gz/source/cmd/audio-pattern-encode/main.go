// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"context"
	"flag"
	"fmt"
	"github.com/Dr-Crow/rustshine-research/source/audio"
	"io"
	"os"
	"time"
)

var version = "development"

func main() {
	duration := flag.Int("duration-ms", 1000, "synthetic duration,5..5000 ms in steps of5")
	ffmpeg := flag.String("ffmpeg", "ffmpeg", "trusted installed encoder")
	pcm := flag.Bool("pcm", false, "write reference signed16 little-endian stereo PCM instead of Ogg Opus")
	show := flag.Bool("version", false, "print source commit")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "unexpected arguments")
		os.Exit(2)
	}
	pattern := audio.Pattern{DurationMillis: *duration}
	var err error
	if *pcm {
		var r io.Reader
		r, err = audio.NewPCMReader(pattern)
		if err == nil {
			_, err = io.Copy(os.Stdout, r)
		}
	} else {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		err = audio.EncodePattern(ctx, *ffmpeg, os.Stdout, pattern)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
