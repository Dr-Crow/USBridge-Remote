// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"strings"
	"testing"
)

func TestInvalidSettingsBeforeEncoder(t *testing.T) {
	for _, tc := range []struct{ duration, port int }{{1000, -1}, {1000, 65536}, {0, 1}, {5001, 1}} {
		err := run("missing-test-encoder", tc.duration, false, false, tc.port)
		if err == nil || strings.Contains(err.Error(), "missing-test-encoder") {
			t.Fatal("invalid settings reached encoder", err)
		}
	}
}
