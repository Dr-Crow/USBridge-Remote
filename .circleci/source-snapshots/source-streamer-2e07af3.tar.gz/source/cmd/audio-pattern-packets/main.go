// SPDX-License-Identifier: GPL-3.0-only
// Synthetic public-test-key diagnostic. File or IPv4 loopback only, never deployment.
package main

import (
	"context"
	"encoding/binary"
	"flag"
	"fmt"
	"github.com/Dr-Crow/rustshine-research/source/audio"
	"io"
	"net"
	"os"
	"time"
)

var version = "development"

func main() {
	test := flag.Bool("test-keys", false, "required acknowledgment: public zero key, synthetic data only")
	ffmpeg := flag.String("ffmpeg", "ffmpeg", "trusted FFmpeg executable")
	duration := flag.Int("duration-ms", 1000, "synthetic duration 5..5000 ms")
	port := flag.Int("test-loopback-udp-port", 0, "PUBLIC-key packets to IPv4 loopback only; forces pacing")
	fec := flag.Bool("fec", false, "add experimental 4+2 parity to complete encrypted audio blocks")
	paced := flag.Bool("paced", false, "space offline packet writes by 5 ms; no catch-up bursts")
	show := flag.Bool("version", false, "print source commit")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if !*test || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "--test-keys required; no positional arguments")
		os.Exit(2)
	}
	if err := run(*ffmpeg, *duration, *paced, *fec, *port); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(ffmpeg string, duration int, paced, fec bool, port int) error {
	if port < 0 || port > 65535 {
		return fmt.Errorf("test UDP port must be 1..65535, or 0 for file output")
	}
	if err := (audio.Pattern{DurationMillis: duration}).Validate(); err != nil {
		return err
	}
	var conn *net.UDPConn
	if port != 0 {
		var err error
		conn, err = net.DialUDP("udp4", nil, &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: port})
		if err != nil {
			return err
		}
		defer conn.Close()
		paced = true
		fmt.Fprintln(os.Stderr, "PUBLIC TEST KEY ONLY; IPv4 loopback destination")
	}
	p, err := audio.NewPacketizer(make([]byte, 16), 0x01020304, 0x11223344)
	if err != nil {
		panic(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	sink := audio.PacketSink(func(ctx context.Context, b []byte) error {
		if err := ctx.Err(); err != nil {
			return err
		}
		if conn != nil {
			deadline := time.Now().Add(time.Second)
			if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
				deadline = d
			}
			if err := conn.SetWriteDeadline(deadline); err != nil {
				return err
			}
			n, err := conn.Write(b)
			if err != nil {
				return err
			}
			if n != len(b) {
				return io.ErrShortWrite
			}
			return nil
		}
		var length [4]byte
		binary.BigEndian.PutUint32(length[:], uint32(len(b)))
		if _, err := os.Stdout.Write(length[:]); err != nil {
			return err
		}
		_, err := os.Stdout.Write(b)
		return err
	})
	if fec {
		output := sink
		var block [4][]byte
		index := 0
		sink = func(ctx context.Context, b []byte) error {
			if err := output(ctx, b); err != nil {
				return err
			}
			block[index] = append([]byte(nil), b...)
			index++
			if index < 4 {
				return nil
			}
			parity, err := audio.AudioParity(block)
			if err != nil {
				return err
			}
			for _, p := range parity {
				if err := output(ctx, p); err != nil {
					return err
				}
			}
			index = 0
			block = [4][]byte{}
			return nil
		}
	}
	if paced {
		sink, err = audio.PaceFiveMillis(sink)
		if err != nil {
			panic(err)
		}
	}
	_, err = audio.StreamPattern(ctx, func(ctx context.Context, w io.Writer, pattern audio.Pattern) error {
		return audio.EncodePattern(ctx, ffmpeg, w, pattern)
	}, sink, p, audio.Pattern{DurationMillis: duration})
	return err
}
