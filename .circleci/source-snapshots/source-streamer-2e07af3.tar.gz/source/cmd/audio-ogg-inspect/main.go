// SPDX-License-Identifier: GPL-3.0-only
// Bounded offline packet hashes, not an audio decoder or transport.
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"github.com/Dr-Crow/rustshine-research/source/audio"
	"io"
	"os"
)

var version = "development"

type packetInfo struct {
	Size   int    `json:"size"`
	SHA256 string `json:"sha256"`
}

func inspect(path string) error {
	before, err := os.Lstat(path)
	if err != nil {
		return err
	}
	if !before.Mode().IsRegular() || before.Size() > 8<<20 {
		return errors.New("regular Ogg file up to 8 MiB required")
	}
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	st, err := f.Stat()
	if err != nil {
		return err
	}
	if !st.Mode().IsRegular() || st.Size() > 8<<20 {
		return errors.New("regular Ogg file up to8 MiB required")
	}
	r := audio.NewOggReader(f)
	head, err := r.Next()
	if err != nil {
		return err
	}
	if len(head) < 8 || !bytes.Equal(head[:8], []byte("OpusHead")) {
		return errors.New("Opus identification packet required")
	}
	tags, err := r.Next()
	if err != nil {
		return err
	}
	if len(tags) < 8 || !bytes.Equal(tags[:8], []byte("OpusTags")) {
		return errors.New("Opus comment packet required")
	}
	packets := make([]packetInfo, 0)
	for {
		p, err := r.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
		if len(p) == 0 || len(p) > audio.MaxOggPacket || len(packets) >= 10000 {
			return errors.New("packet count or size exceeds diagnostic profile")
		}
		sum := sha256.Sum256(p)
		packets = append(packets, packetInfo{len(p), hex.EncodeToString(sum[:])})
	}
	var extra [1]byte
	if n, err := f.Read(extra[:]); n != 0 || err != io.EOF {
		return errors.New("chained or trailing data unsupported")
	}
	return json.NewEncoder(os.Stdout).Encode(struct {
		HeaderPackets int          `json:"header_packets"`
		AudioPackets  []packetInfo `json:"audio_packets"`
	}{2, packets})
}
func main() {
	file := flag.String("file", "", "regular Ogg Opus file up to8 MiB")
	show := flag.Bool("version", false, "print source commit")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if flag.NArg() != 0 || *file == "" {
		fmt.Fprintln(os.Stderr, "--file required, no positional arguments")
		os.Exit(2)
	}
	if err := inspect(*file); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
