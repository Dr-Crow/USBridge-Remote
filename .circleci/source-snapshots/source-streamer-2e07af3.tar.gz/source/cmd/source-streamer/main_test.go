// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"github.com/Dr-Crow/rustshine-research/source/controltransport"
	"github.com/Dr-Crow/rustshine-research/source/streamer"
	"os"
	"runtime"
	"testing"
)

func TestEOFCancelsAndEmitsBoundedLifecycle(t *testing.T) {
	if (runtime.GOOS != "linux" && runtime.GOOS != "windows") || !controltransport.Available() {
		t.Skip("native launch unavailable; unsupported-platform rejection tested separately")
	}
	binary, _ := os.Executable()
	display := ":99"
	if runtime.GOOS == "windows" {
		display = "desktop"
	}
	key := base64.StdEncoding.EncodeToString([]byte("0123456789abcdef"))
	cfg := streamer.Config{SchemaVersion: 1, Owner: "owner", SessionID: "unit", KeyB64: key, PeerIP: "127.0.0.1", Display: display, CaptureConsent: true, FFmpeg: binary, Width: 128, Height: 72, FPS: 30, PixelFormat: "yuv420p", PacketSize: 1024, AudioMode: "silence", MaxSeconds: 5}
	data, _ := json.Marshal(cfg)
	data = append(data, '\n')
	var out bytes.Buffer
	if err := run(context.Background(), bytes.NewReader(data), &out); err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(out.Bytes(), []byte(key)) {
		t.Fatal("secret echoed")
	}
	lines := bytes.Split(bytes.TrimSpace(out.Bytes()), []byte{'\n'})
	if len(lines) != 2 {
		t.Fatal(out.String())
	}
	var stop map[string]any
	if err := json.Unmarshal(lines[1], &stop); err != nil || stop["reason"] != "completed" {
		t.Fatal(out.String(), err)
	}
	out.Reset()
	if err := run(context.Background(), bytes.NewReader(append(data, 'x')), &out); err == nil {
		t.Fatal("unexpected control-pipe data accepted")
	}
}
