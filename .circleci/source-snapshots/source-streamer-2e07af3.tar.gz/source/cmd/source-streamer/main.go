// SPDX-License-Identifier: GPL-3.0-only
// Explicit experimental agent-owned launch. This is not a stock rustshine CLI.
package main

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"syscall"

	"github.com/Dr-Crow/rustshine-research/source/streamer"
)

var version = "development"

func main() {
	caps := flag.Bool("capabilities", false, "print source-streamer-v1 capabilities")
	launch := flag.Bool("launch-stdin", false, "read one private launch JSON line; EOF cancels")
	flag.Parse()
	if flag.NArg() != 0 || *caps == *launch {
		fmt.Fprintln(os.Stderr, "choose exactly one of --capabilities or --launch-stdin")
		os.Exit(2)
	}
	if *caps {
		if err := json.NewEncoder(os.Stdout).Encode(streamer.Manifest(version)); err != nil {
			os.Exit(1)
		}
		return
	}
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	if err := run(ctx, os.Stdin, os.Stdout); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(ctx context.Context, input io.Reader, output io.Writer) error {
	reader := bufio.NewReaderSize(input, streamer.MaxConfigBytes+1)
	line, err := reader.ReadSlice('\n')
	if err != nil {
		return errors.New("one bounded newline-terminated launch JSON object required")
	}
	cfg, err := streamer.DecodeConfig(line)
	if err != nil {
		return err
	}
	launch, err := streamer.NewLaunch(ctx, cfg)
	if err != nil {
		return err
	}
	// No secret or owner value is echoed in lifecycle events.
	encoder := json.NewEncoder(output)
	if err = encoder.Encode(launch.Ready()); err != nil {
		launch.Cancel()
		_ = launch.Run()
		return err
	}
	inputDone := make(chan error, 1)
	go func() {
		_, readErr := reader.ReadByte()
		if readErr == io.EOF {
			inputDone <- nil
		} else {
			inputDone <- errors.New("unexpected data or failure on launch control pipe")
		}
		launch.Cancel()
	}()
	err = launch.Run()
	select {
	case inputErr := <-inputDone:
		err = errors.Join(err, inputErr)
	default:
	}
	reason := "completed"
	if err != nil {
		reason = "failed"
	}
	event := struct {
		SchemaVersion int            `json:"schema_version"`
		Event         string         `json:"event"`
		SessionID     string         `json:"session_id"`
		Reason        string         `json:"reason"`
		Stats         streamer.Stats `json:"stats"`
	}{1, "stopped", cfg.SessionID, reason, launch.Stats()}
	return errors.Join(err, encoder.Encode(event))
}
