// SPDX-License-Identifier: GPL-3.0-only
// Explicit-display X11 capture fixture. PUBLIC key, never deployment.
package main

import (
	"context"
	"encoding/binary"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/gamestreamvideo"
	"github.com/Dr-Crow/rustshine-research/source/media"
)

var version = "development"

func main() {
	pix := flag.String("pixel-format", "yuv444p", "captured yuv420p or yuv444p")
	ffmpeg := flag.String("ffmpeg", "ffmpeg", "trusted installed FFmpeg")
	display := flag.String("display", "", "REQUIRED explicit local X11 display; operator-authorized capture only")
	port := flag.Int("test-loopback-udp-port", 0, "PUBLIC-key test packets to IPv4 loopback only; forces pacing")
	show := flag.Bool("version", false, "print source version")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if flag.NArg() != 0 || *display == "" {
		fmt.Fprintln(os.Stderr, "explicit --display required; no positional arguments")
		os.Exit(2)
	}
	if err := run(*ffmpeg, *pix, *display, *port); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(ffmpeg, pix, display string, port int) error {
	if port < 0 || port > 65535 {
		return fmt.Errorf("test UDP port must be 1..65535, or 0 for file output")
	}
	var conn *net.UDPConn
	if port != 0 {
		var err error
		conn, err = net.DialUDP("udp4", nil, &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: port})
		if err != nil {
			return err
		}
		defer conn.Close()
		fmt.Fprintln(os.Stderr, "PUBLIC TEST KEY ONLY; IPv4 loopback destination")
	}

	key := make([]byte, 16)
	for i := range key {
		key[i] = byte(i)
	}
	cipher, err := gamestreamvideo.NewVideoCipher(key)
	if err != nil {
		return err
	}
	pipeline, err := media.NewEncryptedPipeline(1024, cipher)
	if err != nil {
		return err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	encoder := func(ctx context.Context, w io.Writer, p media.Pattern) error {
		return media.CaptureX11(ctx, ffmpeg, display, w, p)
	}
	sink := func(ctx context.Context, packet []byte) error {
		if err := ctx.Err(); err != nil {
			return err
		}
		if conn != nil {
			deadline := time.Now().Add(time.Second)
			if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
				deadline = d
			}
			if err := conn.SetWriteDeadline(deadline); err != nil {
				return err
			}
			n, err := conn.Write(packet)
			if err != nil {
				return err
			}
			if n != len(packet) {
				return io.ErrShortWrite
			}
			return nil
		}
		if err := binary.Write(os.Stdout, binary.BigEndian, uint32(len(packet))); err != nil {
			return err
		}
		_, err := os.Stdout.Write(packet)
		return err
	}
	runner := pipeline.Run
	if conn != nil {
		runner = pipeline.RunPaced
	}
	_, err = runner(ctx, encoder, sink, media.Pattern{Width: 128, Height: 72, Frames: 30, FPS: 30, PixelFormat: pix})
	return err
}
