// SPDX-License-Identifier: GPL-3.0-only
package main

import "testing"

func TestRejectInvalidLoopbackPortBeforeCapture(t *testing.T) {
	for _, port := range []int{-1, 65536} {
		if err := run("must-not-execute", "yuv444p", ":0", port); err == nil {
			t.Fatal(port)
		}
	}
}
