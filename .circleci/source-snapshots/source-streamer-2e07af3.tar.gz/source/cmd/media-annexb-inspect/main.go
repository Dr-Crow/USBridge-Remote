// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/Dr-Crow/rustshine-research/source/annexb"
	"io"
	"os"
)

var version = "development"

func main() {
	path := flag.String("file", "", "local Annex-B H264 file with AUD delimiters")
	showVersion := flag.Bool("version", false, "show source version")
	flag.Parse()
	if *showVersion {
		fmt.Println(version)
		return
	}
	if *path == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "--file required")
		os.Exit(2)
	}
	if err := inspect(*path); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func inspect(path string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	input, output := sha256.New(), sha256.New()
	r := annexb.NewReader(io.TeeReader(f, input))
	count, total := 0, 0
	for {
		u, err := r.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
		output.Write(u)
		count++
		total += len(u)
	}
	a, b := hex.EncodeToString(input.Sum(nil)), hex.EncodeToString(output.Sum(nil))
	if a != b {
		return fmt.Errorf("access unit reconstruction changed bytes")
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"access_units": count, "bytes": total, "sha256": a, "reconstructed_sha256": b, "source_version": version})
}
