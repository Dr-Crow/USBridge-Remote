//go:build (linux || windows) && cgo

// SPDX-License-Identifier: GPL-3.0-only
package controltransport

/*
#cgo CFLAGS: -std=c99 -I${SRCDIR}/third_party/enet/include
#cgo linux CFLAGS: -DHAS_FCNTL=1 -DHAS_IOCTL=1 -DHAS_POLL=1 -DHAS_GETADDRINFO=1 -DHAS_GETNAMEINFO=1 -DHAS_INET_PTON=1 -DHAS_INET_NTOP=1 -DHAS_MSGHDR_FLAGS=1 -DHAS_SOCKLEN_T=1
#cgo windows CFLAGS: -D_WIN32_WINNT=0x0601 -DHAS_QOS_FLOWID=1 -DHAS_PQOS_FLOWID=1
#cgo windows LDFLAGS: -lws2_32 -lwinmm
#include <stdlib.h>
#include "bridge.h"
*/
import "C"

import (
	"errors"
	"fmt"
	"net"
	"syscall"
	"time"
	"unsafe"
)

type enetNative struct{ host *C.ControlENetHost }

func listenNative(bind *net.UDPAddr, allowed net.IP) (nativeTransport, *net.UDPAddr, error) {
	lockNative()
	defer unlockNative()
	if err := initializeNative(); err != nil {
		return nil, nil, err
	}
	b := C.CString(bind.IP.String())
	defer C.free(unsafe.Pointer(b))
	a := C.CString(allowed.String())
	defer C.free(unsafe.Pointer(a))
	var port C.uint16_t
	// The bridge reports POSIX errno only on Linux. Windows host creation
	// can clean up sockets before returning, so use its honest generic error
	// instead of treating cgo errno (or a stale WSA last error) as a socket code.
	var nativeErr C.int
	n := C.control_enet_create(b, C.uint16_t(bind.Port), a, &port, &nativeErr)
	if n == nil {
		if nativeErr != 0 {
			return nil, nil, fmt.Errorf("bind ENet control socket: %w", syscall.Errno(nativeErr))
		}
		return nil, nil, errors.New("could not allocate or bind ENet control host")
	}
	return &enetNative{host: n}, &net.UDPAddr{IP: append(net.IP(nil), bind.IP...), Port: int(port)}, nil
}

func (n *enetNative) service(wait time.Duration) (nativeEvent, error) {
	lockNative()
	defer unlockNative()
	var event C.ControlENetEvent
	// Round up to a millisecond to avoid spinning near a deadline.
	ms := (wait + time.Millisecond - 1) / time.Millisecond
	if C.control_enet_service(n.host, C.uint32_t(ms), &event) < 0 {
		return nativeEvent{}, errors.New("ENet control service failed")
	}
	out := nativeEvent{kind: int(event.kind)}
	if event.packet != nil {
		defer C.enet_packet_destroy(event.packet)
		if event.packet.dataLength > C.size_t(maxPacketSize) {
			return nativeEvent{}, errors.New("ENet control packet exceeded bound")
		}
		out.packet = C.GoBytes(unsafe.Pointer(event.packet.data), C.int(event.packet.dataLength))
	}
	return out, nil
}
func (n *enetNative) disconnect() {
	lockNative()
	defer unlockNative()
	C.control_enet_disconnect(n.host)
}
func (n *enetNative) close() {
	lockNative()
	defer unlockNative()
	C.control_enet_destroy(n.host)
	n.host = nil
}

// Available reports whether this build includes the native ENet adapter.
func Available() bool { return true }
