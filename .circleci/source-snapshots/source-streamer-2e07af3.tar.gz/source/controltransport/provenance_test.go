// SPDX-License-Identifier: GPL-3.0-only
package controltransport

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestUnmodifiedPublicENetProvenance(t *testing.T) {
	const base = "third_party/enet"
	b, err := os.ReadFile(filepath.Join(base, "PROVENANCE.json"))
	if err != nil {
		t.Fatal(err)
	}
	var m struct {
		Repository string            `json:"repository"`
		Commit     string            `json:"commit"`
		SHA256     map[string]string `json:"sha256"`
	}
	if err := json.Unmarshal(b, &m); err != nil {
		t.Fatal(err)
	}
	if m.Repository != "https://github.com/cgutman/enet" || m.Commit != "aca87840b57f045a1f7f9299e4b1b9b8e2a5e2f1" || len(m.SHA256) != 20 {
		t.Fatal("incorrect public-source pin")
	}
	for name, want := range m.SHA256 {
		b, err := os.ReadFile(filepath.Join(base, name))
		if err != nil {
			t.Fatal(err)
		}
		hash := sha256.Sum256(b)
		if got := hex.EncodeToString(hash[:]); got != want {
			t.Errorf("public ENet %s modified: got %s want %s", name, got, want)
		}
	}
}
