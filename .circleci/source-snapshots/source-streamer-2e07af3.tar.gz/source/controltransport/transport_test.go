// SPDX-License-Identifier: GPL-3.0-only
package controltransport

import (
	"context"
	"encoding/binary"
	"errors"
	"net"
	"sync/atomic"
	"testing"
	"time"
)

func TestAddressValidation(t *testing.T) {
	for _, c := range []struct{ bind, allowed string }{
		{"127.0.0.1:0", "127.0.0.1"}, {"0.0.0.0:47999", "192.0.2.1"},
		{"[::1]:0", "::1"}, {"[::]:47999", "2001:db8::1"},
	} {
		if _, _, err := parseAddresses(c.bind, net.ParseIP(c.allowed)); err != nil {
			t.Errorf("%+v: %v", c, err)
		}
	}
	for _, c := range []struct{ bind, allowed string }{
		{"localhost:47999", "127.0.0.1"}, {":47999", "127.0.0.1"},
		{"127.0.0.1:0", ""}, {"127.0.0.1:0", "0.0.0.0"},
		{"127.0.0.1:0", "224.0.0.1"}, {"127.0.0.1:0", "255.255.255.255"},
		{"127.0.0.1:0", "::1"}, {"[::]:0", "127.0.0.1"},
		{"127.0.0.1:-1", "127.0.0.1"}, {"127.0.0.1:65536", "127.0.0.1"},
		{"127.0.0.1:enet", "127.0.0.1"}, {"127.0.0.1", "127.0.0.1"},
		{"224.0.0.1:0", "127.0.0.1"}, {"[fe80::1%lo]:0", "fe80::1"},
	} {
		if _, _, err := parseAddresses(c.bind, net.ParseIP(c.allowed)); err == nil {
			t.Errorf("accepted %+v", c)
		}
	}
}

func framed(n int) []byte {
	p := make([]byte, n)
	binary.LittleEndian.PutUint16(p, 1)
	binary.LittleEndian.PutUint16(p[2:], uint16(n-4))
	return p
}

func TestEncryptedEnvelopeOnly(t *testing.T) {
	for _, n := range []int{28, 29, maxPacketSize} {
		if !encryptedEnvelope(framed(n)) {
			t.Fatal(n)
		}
	}
	for _, p := range [][]byte{nil, {2, 3}, make([]byte, 28), framed(27), framed(maxPacketSize + 1)} {
		if encryptedEnvelope(p) {
			t.Fatalf("accepted invalid envelope %d", len(p))
		}
	}
	p := framed(28)
	p[2]++
	if encryptedEnvelope(p) {
		t.Fatal("accepted mismatched length")
	}
}

type fakeNative struct {
	events               chan nativeEvent
	closed, disconnected atomic.Int32
	fail                 error
}

func (f *fakeNative) service(wait time.Duration) (nativeEvent, error) {
	if f.fail != nil {
		return nativeEvent{}, f.fail
	}
	select {
	case ev := <-f.events:
		return ev, nil
	case <-time.After(wait):
		return nativeEvent{}, nil
	}
}
func (f *fakeNative) disconnect() { f.disconnected.Add(1) }
func (f *fakeNative) close()      { f.closed.Add(1) }
func fakeHost() (*Host, *fakeNative) {
	f := &fakeNative{events: make(chan nativeEvent, 16)}
	return &Host{native: f, addr: &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 1234}, connectLimit: time.Second, idleLimit: time.Second}, f
}

func TestServeHandlerErrorsAndFraming(t *testing.T) {
	h, f := fakeHost()
	f.events <- nativeEvent{kind: eventReceive, packet: []byte{2, 3, 0, 0}}
	for range 3 {
		f.events <- nativeEvent{kind: eventReceive, packet: framed(28)}
	}
	calls := 0
	failure := errors.New("backend stopped")
	err := h.Serve(context.Background(), func(context.Context, []byte) error {
		calls++
		if calls == 1 {
			return errors.New("authentication failed")
		}
		if calls == 3 {
			return errors.Join(ErrStop, failure)
		}
		return nil
	})
	if !errors.Is(err, ErrStop) || !errors.Is(err, failure) || calls != 3 || f.disconnected.Load() != 3 || f.closed.Load() != 1 {
		t.Fatalf("%v calls=%d disconnect=%d close=%d", err, calls, f.disconnected.Load(), f.closed.Load())
	}
	if err := h.Close(); err != nil || f.closed.Load() != 1 {
		t.Fatal("double free")
	}
}

func TestCloseBeforeServeAndAddressCopy(t *testing.T) {
	h, f := fakeHost()
	a := h.Addr().(*net.UDPAddr)
	a.IP[0] = 42
	a.Port = 1
	if h.Port() != 1234 || !h.Addr().(*net.UDPAddr).IP.Equal(net.IPv4(127, 0, 0, 1)) {
		t.Fatal("address mutated")
	}
	if h.Close() != nil || h.Close() != nil || f.closed.Load() != 1 {
		t.Fatal("close")
	}
	if err := h.Serve(context.Background(), func(context.Context, []byte) error { return nil }); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
}

func TestCloseInsideHandler(t *testing.T) {
	h, f := fakeHost()
	f.events <- nativeEvent{kind: eventReceive, packet: framed(28)}
	err := h.Serve(context.Background(), func(ctx context.Context, _ []byte) error {
		if err := h.Close(); err != nil {
			t.Fatal(err)
		}
		if !errors.Is(ctx.Err(), context.Canceled) {
			t.Fatal("handler context not canceled")
		}
		return nil
	})
	if !errors.Is(err, ErrClosed) || f.closed.Load() != 1 {
		t.Fatal(err)
	}
}

func TestServeCancellationAndSingleUse(t *testing.T) {
	h, f := fakeHost()
	f.events <- nativeEvent{kind: eventReceive, packet: framed(28)}
	entered := make(chan struct{})
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan error, 1)
	go func() {
		done <- h.Serve(ctx, func(ctx context.Context, _ []byte) error { close(entered); <-ctx.Done(); return ctx.Err() })
	}()
	<-entered
	if err := h.Serve(ctx, func(context.Context, []byte) error { return nil }); !errors.Is(err, ErrAlreadyServed) {
		t.Fatal(err)
	}
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("cancellation hung")
	}
	if f.closed.Load() != 1 {
		t.Fatal("socket not released")
	}
}

func TestServeBounds(t *testing.T) {
	for _, authenticated := range []bool{false, true} {
		h, f := fakeHost()
		h.connectLimit, h.idleLimit = 30*time.Millisecond, 30*time.Millisecond
		if authenticated {
			f.events <- nativeEvent{kind: eventReceive, packet: framed(28)}
		}
		started := time.Now()
		err := h.Serve(context.Background(), func(context.Context, []byte) error { return nil })
		want := ErrConnectTimeout
		if authenticated {
			want = ErrIdleTimeout
		}
		if !errors.Is(err, want) || time.Since(started) > time.Second {
			t.Fatal(err, time.Since(started))
		}
	}
}

func TestServeRejectsNilAndPropagatesNativeFailure(t *testing.T) {
	h, f := fakeHost()
	if h.Serve(nil, func(context.Context, []byte) error { return nil }) == nil || h.Serve(context.Background(), nil) == nil {
		t.Fatal("nil accepted")
	}
	failure := errors.New("native service failure")
	f.fail = failure
	if err := h.Serve(context.Background(), func(context.Context, []byte) error { return nil }); !errors.Is(err, failure) || f.closed.Load() != 1 {
		t.Fatal(err)
	}
}

func TestDisconnectCleanupCoversPeerLossAndForcedReset(t *testing.T) {
	for _, test := range []struct {
		name       string
		event      nativeEvent
		handlerErr error
	}{
		{"peer disconnect", nativeEvent{kind: eventDisconnect}, nil},
		{"malformed envelope", nativeEvent{kind: eventReceive, packet: []byte{1, 2}}, nil},
		{"replay or authentication rejection", nativeEvent{kind: eventReceive, packet: framed(28)}, errors.New("rejected")},
	} {
		t.Run(test.name, func(t *testing.T) {
			h, f := fakeHost()
			f.events <- test.event
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			n := 0
			err := h.ServeWithDisconnect(ctx, func(context.Context, []byte) error { return test.handlerErr }, func() { n++; cancel() })
			if !errors.Is(err, context.Canceled) || n != 1 || f.closed.Load() != 1 {
				t.Fatal(err, n, f.closed.Load())
			}
		})
	}
}
