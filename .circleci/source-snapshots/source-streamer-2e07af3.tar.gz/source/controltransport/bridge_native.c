//go:build (linux || windows) && cgo

/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef _WIN32
#include <errno.h>
#endif
#include <stdlib.h>
#include <string.h>
#include "bridge.h"

#define CONTROL_CHANNELS 48
#define CONTROL_MAX_PACKET 65539
#define CONTROL_MAX_WAITING (256 * 1024)

struct ControlENetHost {
    ENetHost *host;
    ENetAddress allowed;
    ENetAddress selected;
    int connected;
};

static int numeric_address(const char *ip, uint16_t port, ENetAddress *out) {
    struct sockaddr_in v4;
    struct sockaddr_in6 v6;
    memset(&v4, 0, sizeof(v4));
    memset(&v6, 0, sizeof(v6));
    if (inet_pton(AF_INET, ip, &v4.sin_addr) == 1) {
        v4.sin_family = AF_INET;
        v4.sin_port = htons(port);
        return enet_address_set_address(out, (struct sockaddr *)&v4, sizeof(v4));
    }
    if (inet_pton(AF_INET6, ip, &v6.sin6_addr) == 1) {
        v6.sin6_family = AF_INET6;
        v6.sin6_port = htons(port);
        return enet_address_set_address(out, (struct sockaddr *)&v6, sizeof(v6));
    }
#ifndef _WIN32
    errno = EINVAL;
#endif
    return -1;
}

static int same_ip(const ENetAddress *a, const ENetAddress *b) {
    if (a->address.ss_family != b->address.ss_family) return 0;
    if (a->address.ss_family == AF_INET) {
        return ((const struct sockaddr_in *)&a->address)->sin_addr.s_addr ==
               ((const struct sockaddr_in *)&b->address)->sin_addr.s_addr;
    }
    if (a->address.ss_family == AF_INET6) {
        const struct sockaddr_in6 *aa = (const struct sockaddr_in6 *)&a->address;
        const struct sockaddr_in6 *bb = (const struct sockaddr_in6 *)&b->address;
        return memcmp(&aa->sin6_addr, &bb->sin6_addr, sizeof(aa->sin6_addr)) == 0 &&
               aa->sin6_scope_id == bb->sin6_scope_id;
    }
    return 0;
}

/* Reject before ENet parsing/allocation/handshake replies. peers[0].data is
 * application-owned and is preserved by the unchanged enet_peer_reset(). */
static int filter_peer(ENetHost *host, ENetEvent *event) {
    ControlENetHost *control = (ControlENetHost *)host->peers[0].data;
    (void)event;
    if (!control || !same_ip(&host->receivedPeerAddress, &control->allowed)) return 1;
    if (control->connected && !enet_address_equal(&host->receivedPeerAddress, &control->selected)) return 1;
    return 0;
}

ControlENetHost *control_enet_create(const char *bind, uint16_t port,
                                   const char *allowed, uint16_t *bound_port, int *native_error) {
    ENetAddress bind_address;
    ControlENetHost *control;
#ifndef _WIN32
    /* Match cgo's previous (result, errno) call boundary on Linux. */
    errno = 0;
#endif
    control = (ControlENetHost *)calloc(1, sizeof(*control));
    *native_error = 0;
    if (!control) goto fail;
    if (numeric_address(bind, port, &bind_address) != 0 ||
        numeric_address(allowed, 0, &control->allowed) != 0) {
        goto fail;
    }
    /* The Go adapter initializes Winsock once per process before this call,
     * and serializes Windows creation with other hosts' native operations.
     * Linux initialization is a no-op. Public ENet sources remain unchanged. */
    control->host = enet_host_create(bind_address.address.ss_family, &bind_address,
                                    1, CONTROL_CHANNELS, 0, 0);
    if (!control->host) goto fail;
    control->host->maximumPacketSize = CONTROL_MAX_PACKET;
    control->host->maximumWaitingData = CONTROL_MAX_WAITING;
    control->host->peers[0].data = control;
    control->host->intercept = filter_peer;
    if (control->host->address.address.ss_family == AF_INET) {
        *bound_port = ntohs(((struct sockaddr_in *)&control->host->address.address)->sin_port);
    } else {
        *bound_port = ntohs(((struct sockaddr_in6 *)&control->host->address.address)->sin6_port);
    }
    return control;
fail:
#ifndef _WIN32
    *native_error = errno;
#endif
    /* On Windows upstream may close/free resources before reporting failure.
     * A stale WSAGetLastError (and POSIX errno) would be misleading here. */
    free(control);
    return NULL;
}

int control_enet_service(ControlENetHost *control, uint32_t wait, ControlENetEvent *out) {
    ENetEvent event;
    int result;
    memset(out, 0, sizeof(*out));
    result = enet_host_service(control->host, &event, wait);
    if (result <= 0) return result;
    out->kind = (int)event.type;
    switch (event.type) {
    case ENET_EVENT_TYPE_CONNECT:
        control->selected = event.peer->address;
        control->connected = 1;
        /* Tight native timeout backs up the Go authenticated-message limit. */
        enet_peer_timeout(event.peer, 2, 5000, 10000);
        break;
    case ENET_EVENT_TYPE_DISCONNECT:
        control->connected = 0;
        break;
    case ENET_EVENT_TYPE_RECEIVE:
        out->packet = event.packet;
        break;
    default:
        break;
    }
    return result;
}

void control_enet_disconnect(ControlENetHost *control) {
    enet_peer_disconnect_now(&control->host->peers[0], 0);
    control->connected = 0;
}

void control_enet_destroy(ControlENetHost *control) {
    if (!control) return;
    if (control->connected) control_enet_disconnect(control);
    enet_host_destroy(control->host);
    free(control);
}
