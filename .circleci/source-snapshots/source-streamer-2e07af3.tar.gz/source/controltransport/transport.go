// SPDX-License-Identifier: GPL-3.0-only
// Package controltransport provides a bounded ENet receiver for one explicitly
// authorized control-v2 launch. It does not pair clients, issue keys, decrypt
// packets, implement input devices, or provide a plaintext/legacy fallback.
package controltransport

import (
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"net"
	"strconv"
	"sync"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/controlsecure"
)

var (
	// ErrUnavailable identifies builds without a supported cgo ENet adapter.
	ErrUnavailable   = errors.New("ENet control transport requires Linux or Windows with cgo")
	ErrClosed        = errors.New("ENet control transport closed")
	ErrAlreadyServed = errors.New("ENet control transport Serve already called")
	// ErrStop lets a handler explicitly end the launch's transport. Other
	// handler errors disconnect only that peer and allow a later connection
	// from the permitted IP, using the same handler and cryptographic state.
	ErrStop           = errors.New("stop ENet control transport")
	ErrConnectTimeout = errors.New("ENet control authentication timeout")
	ErrIdleTimeout    = errors.New("ENet control authenticated-message timeout")
)

const (
	maxPacketSize  = controlsecure.MaxPayload + 28
	channelCount   = 48
	pollInterval   = 10 * time.Millisecond
	connectTimeout = 15 * time.Second
	idleTimeout    = 30 * time.Second
)

type nativeEvent struct {
	kind   int
	packet []byte
}

const (
	eventNone = iota
	eventConnect
	eventDisconnect
	eventReceive
)

// nativeTransport is private so no native handle or ownership crosses the API.
// Its methods run on one goroutine, apart from creation before Serve starts.
type nativeTransport interface {
	service(time.Duration) (nativeEvent, error)
	disconnect()
	close()
}

// Host owns a bound UDP socket and at most one connected ENet peer. It is
// single-use: after Serve returns it is closed and cannot be restarted.
// Concurrent Close cancels Serve and its handler without racing native ENet.
type Host struct {
	mu              sync.Mutex
	native          nativeTransport
	addr            *net.UDPAddr
	started, closed bool
	cancel          context.CancelFunc
	// Fixed public limits are fields only to permit short, deterministic tests.
	connectLimit, idleLimit time.Duration
}

// Listen binds a numeric UDP address (e.g. 127.0.0.1:0 for an ephemeral port) and
// filters all incoming datagrams to an explicitly permitted unicast IP before
// ENet processes them. A port is required and DNS names are not resolved. Use
// an explicit wildcard (0.0.0.0 or ::) if needed; an empty bind IP is rejected.
// Binding and the permitted IP must use the same address family. The IP filter
// is only a traffic boundary; the handler must authenticate/authorize every
// encrypted message with the already established launch key.
func Listen(address string, allowedIP net.IP) (*Host, error) {
	bind, allowed, err := parseAddresses(address, allowedIP)
	if err != nil {
		return nil, err
	}
	n, addr, err := listenNative(bind, allowed)
	if err != nil {
		return nil, err
	}
	return &Host{native: n, addr: addr, connectLimit: connectTimeout, idleLimit: idleTimeout}, nil
}

func parseAddresses(address string, allowedIP net.IP) (*net.UDPAddr, net.IP, error) {
	host, port, err := net.SplitHostPort(address)
	if err != nil {
		return nil, nil, fmt.Errorf("invalid ENet bind address: %w", err)
	}
	ip := net.ParseIP(host)
	if ip == nil || ip.IsMulticast() || ip.Equal(net.IPv4bcast) {
		return nil, nil, errors.New("explicit numeric unicast or wildcard bind IP required")
	}
	p, err := strconv.ParseUint(port, 10, 16)
	if err != nil {
		return nil, nil, errors.New("numeric ENet bind port in 0..65535 required")
	}
	allowed := append(net.IP(nil), allowedIP...)
	if allowed.To16() == nil || allowed.IsUnspecified() || allowed.IsMulticast() || allowed.Equal(net.IPv4bcast) {
		return nil, nil, errors.New("explicit allowed unicast peer IP required")
	}
	if (ip.To4() != nil) != (allowed.To4() != nil) {
		return nil, nil, errors.New("bind and allowed peer IP families differ")
	}
	if ip4 := ip.To4(); ip4 != nil {
		ip = ip4
		allowed = allowed.To4()
	}
	return &net.UDPAddr{IP: ip, Port: int(p)}, allowed, nil
}

// Addr returns an independent copy of the bound address, available before Serve.
func (h *Host) Addr() net.Addr {
	if h.addr == nil {
		return nil
	}
	return &net.UDPAddr{IP: append(net.IP(nil), h.addr.IP...), Port: h.addr.Port, Zone: h.addr.Zone}
}

// Port returns the bound UDP port, or zero on an uninitialized Host.
func (h *Host) Port() uint16 {
	if h.addr == nil {
		return 0
	}
	return uint16(h.addr.Port)
}

// Close is idempotent. It cancels a running Serve and its handler. The native
// socket is released by Serve as soon as its current bounded service call or
// context-aware handler returns. Before Serve it releases the socket directly.
// Close never waits for the handler, so the handler may safely call Close.
func (h *Host) Close() error {
	h.mu.Lock()
	defer h.mu.Unlock()
	if h.closed {
		return nil
	}
	h.closed = true
	if h.cancel != nil {
		h.cancel()
	} else if h.native != nil {
		h.native.close()
		h.native = nil
	}
	return nil
}

// Serve dispatches complete control-v2 encrypted ENet messages in receive order.
// ENet handles reliability, acknowledgements and reassembly. The callback MUST
// authenticate/decrypt/authorize the packet (normally ControlEndpoint.Handle),
// honor ctx and retain its original launch-key/replay state across reconnects.
// It receives its own Go-owned packet bytes and is called synchronously.
//
// Invalid framing and nonfatal callback errors disconnect only the current
// peer. errors.Is(err, ErrStop) terminates Serve with that callback error.
// ENet connection or ping traffic alone does not extend the 15-second initial
// authentication limit or 30-second authenticated-message idle limit. A nil
// callback result means a successfully authenticated message. The caller must
// also cancel ctx when the parent launch ends. Returning always closes Host.
func (h *Host) Serve(ctx context.Context, handler func(context.Context, []byte) error) error {
	return h.serve(ctx, handler, nil)
}

// ServeWithDisconnect additionally invokes cleanup after a peer disconnect or
// forced reset. Input-owning launches use it to release held state immediately.
// Cleanup is synchronous, must return promptly, and must not re-enter Serve.
// Context cancellation and native errors still require the owner's final Close.
func (h *Host) ServeWithDisconnect(ctx context.Context, handler func(context.Context, []byte) error, cleanup func()) error {
	if cleanup == nil {
		return errors.New("peer-disconnect cleanup required")
	}
	return h.serve(ctx, handler, cleanup)
}

func (h *Host) serve(ctx context.Context, handler func(context.Context, []byte) error, cleanup func()) error {
	if ctx == nil || handler == nil {
		return errors.New("context and authenticated control handler required")
	}
	h.mu.Lock()
	if h.closed || h.native == nil {
		h.mu.Unlock()
		return ErrClosed
	}
	if h.started {
		h.mu.Unlock()
		return ErrAlreadyServed
	}
	h.started = true
	ctx, cancel := context.WithCancel(ctx)
	h.cancel = cancel
	n := h.native
	h.mu.Unlock()
	defer func() {
		cancel()
		h.mu.Lock()
		defer h.mu.Unlock()
		n.close()
		h.native, h.cancel, h.closed = nil, nil, true
	}()
	lastAccepted := time.Now()
	authenticated := false
	for {
		if err := ctx.Err(); err != nil {
			h.mu.Lock()
			closed := h.closed
			h.mu.Unlock()
			if closed {
				return ErrClosed
			}
			return err
		}
		limit := h.connectLimit
		if authenticated {
			limit = h.idleLimit
		}
		remaining := limit - time.Since(lastAccepted)
		if remaining <= 0 {
			if authenticated {
				return ErrIdleTimeout
			}
			return ErrConnectTimeout
		}
		wait := pollInterval
		if remaining < wait {
			wait = remaining
		}
		event, err := n.service(wait)
		if err != nil {
			return err
		}
		if event.kind == eventDisconnect && cleanup != nil {
			cleanup()
		}
		if event.kind != eventReceive {
			continue
		}
		if err := ctx.Err(); err != nil {
			continue
		}
		if !encryptedEnvelope(event.packet) {
			n.disconnect()
			if cleanup != nil {
				cleanup()
			}
			continue
		}
		if err := handler(ctx, event.packet); err != nil {
			n.disconnect()
			if cleanup != nil {
				cleanup()
			}
			if errors.Is(err, ErrStop) {
				return err
			}
			continue
		}
		lastAccepted, authenticated = time.Now(), true
	}
}

func encryptedEnvelope(packet []byte) bool {
	return len(packet) >= 28 && len(packet) <= maxPacketSize &&
		binary.LittleEndian.Uint16(packet[:2]) == 1 &&
		int(binary.LittleEndian.Uint16(packet[2:4])) == len(packet)-4
}
