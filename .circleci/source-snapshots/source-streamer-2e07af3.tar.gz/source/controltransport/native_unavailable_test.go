//go:build (!linux && !windows) || !cgo

// SPDX-License-Identifier: GPL-3.0-only
package controltransport

import (
	"errors"
	"net"
	"testing"
)

func TestUnavailableFailsExplicitly(t *testing.T) {
	if Available() {
		t.Fatal("unsupported build advertised ENet")
	}
	if _, err := Listen("127.0.0.1:0", net.IPv4(127, 0, 0, 1)); !errors.Is(err, ErrUnavailable) {
		t.Fatal(err)
	}
}
