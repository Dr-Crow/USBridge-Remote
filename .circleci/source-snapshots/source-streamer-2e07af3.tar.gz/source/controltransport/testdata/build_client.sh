#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-only
# Build the independently launched test driver with unchanged public ENet.
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "usage: $0 OUTPUT_BINARY" >&2
  exit 64
fi
here="$(cd -- "$(dirname -- "$0")" && pwd)"
enet="$here/../third_party/enet"
cc="${CC:-cc}"
# Select by the compiler target, not the shell host. In Windows CI use native
# MSYS2 UCRT64 gcc, never the POSIX-emulating /usr/bin/gcc toolchain.
target="$("$cc" -dumpmachine | tr -d '\r')"
libs=()
case "$target" in
  *-w64-mingw32)
    system_source="$enet/win32.c"
    defines=(-D_WIN32_WINNT=0x0601 -DHAS_QOS_FLOWID=1 -DHAS_PQOS_FLOWID=1)
    libs=(-lws2_32 -lwinmm)
    ;;
  *-linux-*)
    system_source="$enet/unix.c"
    defines=(-DHAS_FCNTL=1 -DHAS_IOCTL=1 -DHAS_POLL=1
      -DHAS_GETADDRINFO=1 -DHAS_GETNAMEINFO=1
      -DHAS_INET_PTON=1 -DHAS_INET_NTOP=1
      -DHAS_MSGHDR_FLAGS=1 -DHAS_SOCKLEN_T=1)
    ;;
  *)
    printf 'unsupported ENet test-client compiler target: %s\n' "$target" >&2
    exit 65
    ;;
esac
"$cc" -std=c99 -O1 -Wall -Wextra "${defines[@]}" \
  -I"$enet/include" "$here/enet_client.c" \
  "$enet/callbacks.c" "$enet/compress.c" "$enet/host.c" \
  "$enet/list.c" "$enet/packet.c" "$enet/peer.c" \
  "$enet/protocol.c" "$system_source" -o "$1" "${libs[@]}"
