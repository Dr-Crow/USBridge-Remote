/* SPDX-License-Identifier: GPL-3.0-only
 * Analyst-authored network test driver using unchanged pinned public ENet.
 * Usage: enet_client SOURCE_IP DEST_IP DEST_PORT RECORD_FILE [HOLD_MS]
 * Records: channel:u8 flags:u8 length:u32be payload:length bytes.
 * Test-driver flags: 1 = reliable, 2 = unsequenced.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "enet/enet.h"

static unsigned pending;
static unsigned long monotonic_ms(void) {
#ifdef _WIN32
    return (unsigned long)enet_time_get();
#else
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (unsigned long)t.tv_sec * 1000 + t.tv_nsec / 1000000;
#endif
}
static void released(ENetPacket *packet) { (void)packet; --pending; }
static int address(const char *ip, unsigned port, ENetAddress *out) {
    struct sockaddr_in v4;
    struct sockaddr_in6 v6;
    memset(&v4, 0, sizeof(v4));
    memset(&v6, 0, sizeof(v6));
    if (inet_pton(AF_INET, ip, &v4.sin_addr) == 1) {
        v4.sin_family = AF_INET; v4.sin_port = htons(port);
        return enet_address_set_address(out, (struct sockaddr *)&v4, sizeof(v4));
    }
    if (inet_pton(AF_INET6, ip, &v6.sin6_addr) == 1) {
        v6.sin6_family = AF_INET6; v6.sin6_port = htons(port);
        return enet_address_set_address(out, (struct sockaddr *)&v6, sizeof(v6));
    }
    return -1;
}
int main(int argc, char **argv) {
    ENetAddress local, remote;
    ENetHost *host;
    ENetPeer *peer;
    ENetEvent event;
    unsigned long started, hold_started = 0, hold = 0;
    int connected = 0, queued = 0, result = 3;
    FILE *input;
    if (argc != 5 && argc != 6) return 64;
    if (argc == 6) hold = strtoul(argv[5], NULL, 10);
    if (enet_initialize()) return 66;
    if (address(argv[1], 0, &local) || address(argv[2], strtoul(argv[3], NULL, 10), &remote)) {
        enet_deinitialize(); return 65;
    }
    host = enet_host_create(local.address.ss_family, &local, 1, 48, 0, 0);
    if (!host) { enet_deinitialize(); return 67; }
    peer = enet_host_connect(host, &remote, 48, 0);
    if (!peer) { enet_host_destroy(host); enet_deinitialize(); return 68; }
    started = monotonic_ms();
    while (monotonic_ms() - started < 3000 + hold) {
        int r = enet_host_service(host, &event, 5);
        if (r < 0) { result = 69; break; }
        if (r > 0) {
            if (event.type == ENET_EVENT_TYPE_CONNECT) {
                connected = 1;
                puts("CONNECTED"); fflush(stdout);
            } else if (event.type == ENET_EVENT_TYPE_DISCONNECT) {
                puts("DISCONNECTED"); fflush(stdout);
                result = 2; break;
            } else if (event.type == ENET_EVENT_TYPE_RECEIVE) {
                enet_packet_destroy(event.packet);
                result = 70; break; /* Host must not invent app replies. */
            }
        }
        if (connected && !queued) {
            unsigned char hdr[6];
            input = fopen(argv[4], "rb");
            if (!input) { result = 71; break; }
            while (fread(hdr, 1, 6, input) == 6) {
                size_t n = ((size_t)hdr[2] << 24) | ((size_t)hdr[3] << 16) | ((size_t)hdr[4] << 8) | hdr[5];
                unsigned flags = hdr[1] == 1 ? ENET_PACKET_FLAG_RELIABLE : ENET_PACKET_FLAG_UNSEQUENCED;
                ENetPacket *packet;
                if (n > 1024 * 1024) { result = 72; goto done_input; }
                packet = enet_packet_create(NULL, n, flags);
                if (!packet || fread(packet->data, 1, n, input) != n) { result = 73; goto done_input; }
                if (enet_peer_send(peer, hdr[0], packet)) { enet_packet_destroy(packet); result = 74; goto done_input; }
                ++pending;
                packet->freeCallback = released;
            }
            fclose(input);
            queued = 1;
            enet_host_flush(host);
        }
        if (queued && pending == 0 && peer->state == ENET_PEER_STATE_CONNECTED) {
            if (!hold_started) { hold_started = monotonic_ms(); puts("ACKED"); fflush(stdout); }
            if (monotonic_ms() - hold_started >= hold) { result = 0; break; }
        }
    }
    goto done;
done_input:
    fclose(input);
done:
    if (result == 0) enet_peer_disconnect_now(peer, 0);
    enet_host_destroy(host);
    enet_deinitialize();
    return result;
}
