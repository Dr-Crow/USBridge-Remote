#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-only
# No-capture acceptance gate; requires an already provisioned native UCRT64 job.
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "usage: $0 ARTIFACT_DIRECTORY" >&2
  exit 64
fi
mkdir -p -- "$1"
out="$(cd -- "$1" && pwd)"
here="$(cd -- "$(dirname -- "$0")" && pwd)"
source_root="$(cd -- "$here/../.." && pwd)"
export CC="${CC:-gcc}" CGO_ENABLED="${CGO_ENABLED:-1}" GOTOOLCHAIN=local
[[ "$(go env GOHOSTOS)" == windows && "$(go env GOOS)" == windows && \
   "$(go env GOARCH)" == amd64 && "$(go env CGO_ENABLED)" == 1 ]] || {
  echo 'Native Windows/amd64 Go with CGO_ENABLED=1 is required; no stub/cross-build acceptance.' >&2
  exit 65
}
[[ "$("$CC" -dumpmachine | tr -d '\r')" == x86_64-w64-mingw32 ]] || {
  echo 'Use native MSYS2 UCRT64 GCC; MSYS-target GCC is not supported.' >&2
  exit 65
}
[[ "$(go version)" == 'go version go1.26.6 '* ]] || {
  echo 'Go 1.26.6 is required.' >&2
  exit 65
}
{
  command -v go
  command -v "$CC"
  go version
  go env GOHOSTOS GOOS GOARCH CGO_ENABLED CC
  "$CC" --version
  "$CC" -dumpmachine
  git -C "$source_root" rev-parse HEAD
} > "$out/toolchain.txt"
cd -- "$source_root"
go test -count=1 -v ./controltransport 2>&1 | tee "$out/tests.txt"
go vet ./controltransport 2>&1 | tee "$out/vet.txt"
go test -race -count=1 ./controltransport 2>&1 | tee "$out/race.txt"
go test -c -o "$out/controltransport-native.test.exe" ./controltransport
objdump -p "$out/controltransport-native.test.exe" > "$out/pe-imports.txt"
if grep -Ei 'DLL Name:.*(msys-2\.0|cygwin1)\.dll' "$out/pe-imports.txt"; then
  echo 'Unexpected POSIX-emulation DLL import.' >&2
  exit 1
fi
CGO_ENABLED=0 go test -count=1 ./controltransport 2>&1 | tee "$out/no-cgo.txt"
echo 'Native ENet no-capture gate passed. Full runtime/capture acceptance is separate.'
