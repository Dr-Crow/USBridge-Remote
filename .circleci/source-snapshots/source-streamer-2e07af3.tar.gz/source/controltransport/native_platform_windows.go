//go:build windows && cgo

// SPDX-License-Identifier: GPL-3.0-only
package controltransport

/*
#include "bridge.h"
*/
import "C"

import (
	"errors"
	"sync"
)

var windowsNative struct {
	mu      sync.Mutex
	once    sync.Once
	initErr error
}

// ENet owns one process-lifetime Winsock reference and optional qWAVE library.
// Never deinitialize when an individual host closes: other hosts can still be
// receiving. Windows reclaims that reference on process exit. This adapter does
// not expose ENet's global callbacks, clock, QoS, or initialization functions.
func initializeNative() error {
	windowsNative.once.Do(func() {
		if C.enet_initialize() != 0 {
			// Upstream WSAStartup returns its own status and ENet discards it.
			// Neither errno nor a later WSAGetLastError is that error code.
			windowsNative.initErr = errors.New("initialize ENet Winsock failed")
		}
	})
	return windowsNative.initErr
}

// The pinned Win32 backend writes global pfnWSARecvMsg whenever it creates a
// socket. Serialize creation against service, disconnect and destruction for
// every host, not only against other creation calls. Service waits are bounded
// to 10 ms by Host.Serve; application handlers run after unlocking.
func lockNative()   { windowsNative.mu.Lock() }
func unlockNative() { windowsNative.mu.Unlock() }
