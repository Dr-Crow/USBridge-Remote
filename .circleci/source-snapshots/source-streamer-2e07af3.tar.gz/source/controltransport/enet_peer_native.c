//go:build (linux || windows) && cgo

// SPDX-License-Identifier: GPL-3.0-only
// Build wrapper. The included public ENet source is unchanged (MIT).
#include "third_party/enet/peer.c"
