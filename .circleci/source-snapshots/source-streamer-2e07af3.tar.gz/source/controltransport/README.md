# ENet control transport (experimental, analyst-authored adapter)

This package binds real ENet UDP transport to the existing authenticated
`session.ControlEndpoint`. It is **not** pairing, a launch/key issuer, a legacy
control implementation, an input/device backend, recovered vendor source, or
proof that a full stock client session works.

## API and ownership

```go
if !controltransport.Available() {
    return controltransport.ErrUnavailable
}
host, err := controltransport.Listen("127.0.0.1:0", net.ParseIP("127.0.0.1"))
if err != nil { return err }
defer host.Close()
// Addr() and Port() are available now, before Serve is started.
// endpoint was created once for this authenticated launch and is retained.
err = host.Serve(ctx, func(ctx context.Context, packet []byte) error {
    return endpoint.Handle(ctx, authenticatedOwner, packet)
})
```

- `Available() bool`: true for Linux+cgo and Windows+cgo builds, false otherwise.
- `Listen(address string, allowedIP net.IP) (*Host, error)`: binds immediately.
  Bind IP and port must be numeric; no DNS lookup or implicit wildcard. IPv4 and
  IPv6 (without zone IDs) are supported and must match the allowed IP's family.
- `(*Host).Addr() net.Addr`: independent `*net.UDPAddr` copy.
- `(*Host).Port() uint16`: bound port, including actual ephemeral allocation.
- `(*Host).Serve(context.Context, func(context.Context, []byte) error) error`:
  one synchronous owning loop for all native ENet operations. Serve is single-use
  and closes its host on return. Packet bytes handed to Go are owned by Go.
- `(*Host).Close() error`: idempotent, concurrency-safe cancellation. Close does
  not wait for a handler; native cleanup completes when Serve returns. The handler
  must honor its context. Calling Close inside a handler is safe.

The callback must actually authenticate, decrypt and authorize using the retained
launch endpoint. Returning nil means a valid authenticated message. The adapter
never has or generates the key. Application handlers are responsible for checking
revocation and accepting only explicitly implemented messages.

Invalid encrypted-envelope framing never reaches the callback. A callback error
normally disconnects the current peer, discards its queued traffic, and continues
waiting for the same permitted IP. Reconnection does **not** recreate the endpoint
or reset its key/nonce/replay state. Return an error wrapping `ErrStop` (for example
`errors.Join(controltransport.ErrStop, err)`) to end Serve for an explicitly fatal
condition such as revocation, a closed endpoint, or backend failure. The owner must
close the retained endpoint and other launch resources at launch termination.

## Transport and security bounds

- Exactly one concurrent ENet peer, up to 48 channels, matching the pinned public
  client's channel count. This is not a claim to support input on those channels.
- Exact configured IP filtering occurs before ENet parses packets, allocates a
  peer, or sends a handshake response. Once connected, the peer's UDP port is
  also selected; other endpoints are ignored until disconnection.
- IP filtering is not authentication. A party on the allowed IP or able to spoof
  traffic can still attempt to occupy or disrupt this one-peer transport. An
  authenticated launch, control-v2 AEAD and authorization remain mandatory.
- Only complete type-1 control-v2 envelopes with matching 16-bit lengths are
  dispatched. No plaintext negotiation or fallback exists. Maximum reassembled
  packet is 65,539 bytes (the envelope limit of `controlsecure`).
- ENet's waiting-payload threshold is 256 KiB per peer. Upstream checks the
  threshold before adding a packet, so one bounded packet can take payload bytes
  above it. ENet's separate queue and fragment metadata is additional memory;
  256 KiB is not a hard total process-memory budget. Channels and peer count are
  also bounded. Public ENet sources are unchanged, including its allocation and
  error behavior.
- Native service waits are at most 10 ms. Context is checked every iteration and
  before dispatch, including under malformed or rejected traffic.
- Initial successful authenticated message is required within 15 seconds of
  Serve. Thereafter, 30 seconds without a successful authenticated message ends
  Serve. Connect, ping, malformed, rejected and replayed traffic do not extend
  those limits. Native peer timeout is 5–10 seconds without transport progress.
- ENet sends transport acknowledgements only. They do not mean the application's
  AEAD or authorization checks succeeded. No application response is fabricated.
- No outbound application-message API, ENet compression/checksum negotiation,
  external socket adoption, NAT discovery, connect-data token validation, or
  reconnect key issuance is implemented. The connect-data field is not treated
  as an authentication credential.

## Public source provenance and build

`third_party/enet` contains unchanged public MIT-licensed source selected from
[cgutman/enet at aca87840b57f045a1f7f9299e4b1b9b8e2a5e2f1](https://github.com/cgutman/enet/tree/aca87840b57f045a1f7f9299e4b1b9b8e2a5e2f1).
This is the ENet submodule pinned by
[moonlight-common-c e913d516fab11d8fc84a35c7818cea1e455436fa](https://github.com/moonlight-stream/moonlight-common-c/tree/e913d516fab11d8fc84a35c7818cea1e455436fa).
`third_party/enet/PROVENANCE.json` records every selected source/header/license
file's SHA-256; tests check those bytes. Package attributes disable checkout
newline conversion for those pinned files, including on Windows. The enclosing Go/C bridge, build wrappers
and test driver are independently authored GPL-3.0-only code. Included ENet files
retain their MIT license. No decompiled or private service implementation is used.

Linux with a normal C toolchain and Windows with native MSYS2 UCRT64 GCC need
no system ENet library, external Go module, network fetch, or `pkg-config` package.
Go's usual cgo selection enables it:

```sh
cd source
CGO_ENABLED=1 go test -race ./controltransport
CGO_ENABLED=0 go test ./controltransport
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go test -c ./controltransport
```

Without cgo or on an unsupported OS, the same API builds but `Listen` returns
`ErrUnavailable`, and `Available` is false. There is no silent stub transport.

## Verification and reusable test driver

Linux/Windows+cgo package tests compile a separate C executable from the unchanged public
ENet sources, then exercise actual localhost UDP against the Go adapter:

- Handshake, reliable acknowledgements and encrypted start/IDR/keepalive dispatch
  into the real `session.ControlEndpoint`
- Maximum-size packet fragmentation/reassembly, channel 47 and unsequenced traffic
- Wrong source IP rejected before connection; only one concurrent peer
- Tampered ciphertext, plaintext and replay failure; valid reconnect preserves
  replay state and can accept the next authenticated sequence
- IPv6 loopback when available; repeated/concurrent Close and socket release
- Failed bind recovery, concurrent creation while receiving, and a surviving
  host remaining usable after another live host closes
- Initial/idle limits, malformed framing, fatal/nonfatal callback errors and
  context-aware handler cancellation

The test driver is not an unchanged full Moonlight client. ENet is unchanged; its
small entry point and generated encrypted fixtures are analyst-authored. These
checks prove transport/envelope integration, not pairing or full client acceptance.

Build the same helper for a larger integration harness:

```sh
bash source/controltransport/testdata/build_client.sh /tmp/enet-client
/tmp/enet-client 127.0.0.1 127.0.0.1 47999 /tmp/encrypted.records 2000
```

Arguments are source IP, destination IP, destination port, encrypted record file,
and optional hold milliseconds after outgoing packets are acknowledged. Records
are repeated `channel:u8 flags:u8 length:u32be payload:length-bytes` with flags
`1` for reliable or `2` for unsequenced; payload is the already encrypted complete
control envelope. No key is accepted on the command line. Create fixture files
with restrictive permissions and delete them after the test. The helper prints
`CONNECTED` and `ACKED`, exits 0 after successful completion, 2 on disconnect, and
3 on timeout. For unsequenced messages `ACKED` only means the outgoing buffers
were released, not a reliable acknowledgement. Unexpected app replies are errors.


## Windows native ownership and acceptance

The same unchanged source pin includes `win32.c` and its public license/hash.
Windows cgo links `ws2_32` and `winmm`, enables the SDK's numeric `inet_pton`
declarations, and uses the QOS typedefs supplied by current MinGW headers. The
adapter never calls DNS-capable `enet_address_set_host`. Address-family, numeric
IP, one-peer, exact source-IP/selected-port, channel, and packet bounds remain the
same as on Linux. Windows has no plaintext or alternate transport fallback.

The Windows adapter initializes public ENet once, retaining one process-lifetime
Winsock reference and any optional qWAVE module until process exit. It does not
call `enet_deinitialize` when a host closes. All Windows native operations,
including creation, service, disconnect, packet copying/destruction and host
cleanup, share a mutex: the unchanged backend writes a process-global
`pfnWSARecvMsg` on each socket creation. Serializing creation alone would not
protect a concurrently receiving host. Application handlers run outside that
mutex; native service waits remain bounded to 10 ms. This is deliberately a
small, bounded-host prototype, not a high-concurrency ENet service. Linux keeps
its existing independent-host path and no-op initialization.

An initialization failure stays failed for the lifetime of that process. Failed
host creation is reported generically on Windows because upstream may clean up
sockets before returning and discard the original Winsock status. POSIX `errno`
and a later cross-thread `WSAGetLastError` must not be presented as that failure.
Linux retains its POSIX error reporting. No global ENet callbacks, clock offsets
or QoS settings are changed.

Native tests need a provisioned Windows/amd64 machine with Go 1.26.6 and a native
MSYS2 UCRT64 GCC toolchain, including Bash on PATH. A no-cgo cross-build only
checks the explicit unavailable-backend stub; it is not native Windows evidence.
This implementation was developed with Linux-native tests; Windows compilation
and real Winsock execution must be recorded by a native job before claiming
Windows transport acceptance.

From a UCRT64 shell at the repository root, using an already-installed toolchain:

```sh
export CC="$(cygpath -m /ucrt64/bin/gcc.exe)"
export CGO_ENABLED=1 GOTOOLCHAIN=local
unset GOOS GOARCH
bash source/controltransport/testdata/verify_windows_native.sh artifacts/windows-enet
```

That no-capture gate verifies the host/target/compiler, runs the real independent
ENet client suite, vet and Go race tests, compiles a native test executable, and
records its PE imports. It fails if a POSIX-emulation DLL is imported. Inspect
other compiler-runtime dependencies too; execution on normal Windows PATH is a
separate packaging check. The Go race detector does not detect arbitrary C data
races; the explicit native-operation ownership is also required.

The helper's `.exe` filename, CRLF output normalization, Windows timer and build
source/library selection are shared by the Linux and Windows tests. No desktop
capture or FFmpeg process is started by this package's tests. A full runtime gate
must additionally execute `go test -count=1 ./...`, `go vet ./...`, native launch
and manifest checks, synthetic codec tests, and a separately consented Windows
GDI capture/client acceptance exercise. Those stages must be reported separately.
