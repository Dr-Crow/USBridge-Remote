//go:build linux && cgo

// SPDX-License-Identifier: GPL-3.0-only
package controltransport

// The unchanged Linux ENet initializer is a no-op. Its native receive path has
// no mutable process-global socket extension pointer, so retain the existing
// independent-host concurrency. No ENet callbacks, clock offsets or QoS options
// are changed by this package.
func initializeNative() error { return nil }
func lockNative()             {}
func unlockNative()           {}
