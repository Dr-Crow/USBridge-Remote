// SPDX-License-Identifier: GPL-3.0-only
// Bounded streaming framing for H264 emitted with explicit AUD delimiters.
package annexb

import (
	"bufio"
	"bytes"
	"errors"
	"io"
)

const MaxNAL = 8 << 20
const MaxAccessUnit = 16 << 20

type nal struct {
	raw  []byte
	kind byte
}
type nalReader struct {
	r        *bufio.Reader
	prefix   []byte
	terminal error
	limit    int
}

func (n *nalReader) next() (nal, error) {
	if n.terminal != nil {
		return nal{}, n.terminal
	}
	bad := func(err error) (nal, error) { n.terminal = err; return nal{}, err }
	prefix := n.prefix
	n.prefix = nil
	if prefix == nil {
		prefix = make([]byte, 3)
		if _, err := io.ReadFull(n.r, prefix); err != nil {
			return bad(err)
		}
		if bytes.Equal(prefix, []byte{0, 0, 0}) {
			b, err := n.r.ReadByte()
			if err != nil {
				if err == io.EOF {
					err = io.ErrUnexpectedEOF
				}
				return bad(err)
			}
			prefix = append(prefix, b)
		}
		if !bytes.Equal(prefix, []byte{0, 0, 1}) && !bytes.Equal(prefix, []byte{0, 0, 0, 1}) {
			return bad(errors.New("canonical Annex-B prefix required"))
		}
	}
	raw := append([]byte(nil), prefix...)
	prefixLen := len(prefix)
	zeros := 0
	finish := func() (nal, error) {
		if len(raw) <= prefixLen || len(raw)-prefixLen > n.limit {
			return bad(errors.New("NAL size out of bounds"))
		}
		header := raw[prefixLen]
		kind := header & 31
		if header&128 != 0 || kind == 0 || kind > 23 {
			return bad(errors.New("invalid NAL header"))
		}
		return nal{raw: raw, kind: kind}, nil
	}
	for {
		b, err := n.r.ReadByte()
		if err != nil {
			if err == io.EOF {
				n.terminal = io.EOF
				return finish()
			}
			return bad(err)
		}
		raw = append(raw, b)
		if b == 1 && zeros >= 2 {
			size := 3
			if zeros >= 3 {
				size = 4
			}
			n.prefix = append([]byte(nil), raw[len(raw)-size:]...)
			raw = raw[:len(raw)-size]
			return finish()
		}
		if b == 0 {
			zeros++
		} else {
			zeros = 0
		}
		if len(raw) > prefixLen+n.limit+4 {
			return bad(errors.New("NAL exceeds bound"))
		}
	}
}

// Reader requires each access unit to start with AUD (NAL type 9), as requested
// from the synthetic encoder. It does not infer boundaries from slice headers,
// decode H264, accept AVCC, or implement RTP. Returned units preserve exact bytes.
type Reader struct {
	n        nalReader
	pending  *nal
	terminal error
	limit    int
}

func NewReader(r io.Reader) *Reader {
	return &Reader{n: nalReader{r: bufio.NewReader(r), limit: MaxNAL}, limit: MaxAccessUnit}
}
func (r *Reader) Next() ([]byte, error) {
	if r.terminal != nil {
		return nil, r.terminal
	}
	fail := func(err error) ([]byte, error) { r.terminal = err; return nil, err }
	var first nal
	if r.pending != nil {
		first = *r.pending
		r.pending = nil
	} else {
		var err error
		first, err = r.n.next()
		if err != nil {
			return fail(err)
		}
	}
	if first.kind != 9 {
		return fail(errors.New("access unit must start with AUD"))
	}
	unit := first.raw
	vcl := false
	for {
		next, err := r.n.next()
		if err != nil {
			if err == io.EOF && vcl {
				r.terminal = io.EOF
				return unit, nil
			}
			if err == io.EOF {
				err = errors.New("access unit has no VCL NAL")
			}
			return fail(err)
		}
		if next.kind == 9 {
			if !vcl {
				return fail(errors.New("access unit has no VCL NAL"))
			}
			r.pending = &next
			return unit, nil
		}
		if len(unit)+len(next.raw) > r.limit {
			return fail(errors.New("access unit exceeds bound"))
		}
		unit = append(unit, next.raw...)
		if next.kind >= 1 && next.kind <= 5 {
			vcl = true
		}
	}
}
