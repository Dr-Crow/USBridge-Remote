// SPDX-License-Identifier: GPL-3.0-only
package annexb

import (
	"bytes"
	"io"
	"testing"
)

func unit() []byte { return []byte{0, 0, 0, 1, 9, 0xf0, 0, 0, 1, 7, 1, 2, 0, 0, 0, 1, 0x65, 3, 4} }

type fragmented struct{ io.Reader }

func (r fragmented) Read(b []byte) (int, error) {
	if len(b) > 1 {
		b = b[:1]
	}
	return r.Reader.Read(b)
}
func TestExactFragmentedUnits(t *testing.T) {
	input := append(unit(), unit()...)
	r := NewReader(fragmented{bytes.NewReader(input)})
	var output []byte
	for i := 0; i < 2; i++ {
		u, err := r.Next()
		if err != nil || !bytes.Equal(u, unit()) {
			t.Fatal(u, err)
		}
		output = append(output, u...)
	}
	if _, err := r.Next(); err != io.EOF {
		t.Fatal(err)
	}
	if !bytes.Equal(input, output) {
		t.Fatal("bytes changed")
	}
}
func TestMalformed(t *testing.T) {
	for _, b := range [][]byte{{0}, {0, 0, 1}, {1, 2, 3, 4}, {0, 0, 1, 9, 0xf0}, {0, 0, 1, 0x65, 1}, {0, 0, 1, 0x89, 1}, {0, 0, 1, 9, 1, 0, 0, 1, 9, 1}, {0, 0, 1, 9, 1, 0, 0, 1, 0, 1}} {
		r := NewReader(bytes.NewReader(b))
		if u, err := r.Next(); err == nil || u != nil {
			t.Fatal("accepted malformed", b)
		}
		if u, err := r.Next(); err == nil || u != nil {
			t.Fatal("error not sticky")
		}
	}
}
func TestLimits(t *testing.T) {
	r := NewReader(bytes.NewReader(unit()))
	r.n.limit = 1
	if _, err := r.Next(); err == nil {
		t.Fatal("NAL bound")
	}
	r = NewReader(bytes.NewReader(unit()))
	r.limit = 8
	if _, err := r.Next(); err == nil {
		t.Fatal("AU bound")
	}
}
func TestEmpty(t *testing.T) {
	if _, err := NewReader(bytes.NewReader(nil)).Next(); err != io.EOF {
		t.Fatal(err)
	}
}
func FuzzReader(f *testing.F) {
	f.Add(unit())
	f.Add(append(unit(), unit()...))
	f.Fuzz(func(t *testing.T, b []byte) {
		if len(b) > 65536 {
			return
		}
		r := NewReader(bytes.NewReader(b))
		var rebuilt []byte
		for {
			u, err := r.Next()
			if err != nil {
				if err == io.EOF && !bytes.Equal(rebuilt, b) {
					t.Fatal("successful parse changed bytes")
				}
				return
			}
			if len(u) == 0 || len(u) > MaxAccessUnit {
				t.Fatal("bad AU size")
			}
			rebuilt = append(rebuilt, u...)
		}
	})
}
