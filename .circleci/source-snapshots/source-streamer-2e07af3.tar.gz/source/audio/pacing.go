// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"context"
	"errors"
	"time"
)

// PaceFiveMillis serializes calls and spaces packet delivery by at least 5 ms.
// Late delivery resets the schedule rather than producing a catch-up burst.
// It creates no network connection and does not authorize a peer or own keys.
// The downstream sink must honor cancellation and return; packets are borrowed
// only for the synchronous call. Callers must supply packets in stream order.
func PaceFiveMillis(sink PacketSink) (PacketSink, error) {
	if sink == nil {
		return nil, errors.New("packet sink required")
	}
	gate := make(chan struct{}, 1)
	var next time.Time
	return func(ctx context.Context, packet []byte) error {
		if ctx == nil {
			return errors.New("context required")
		}
		select {
		case gate <- struct{}{}:
			defer func() { <-gate }()
		case <-ctx.Done():
			return ctx.Err()
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		if delay := time.Until(next); delay > 0 {
			timer := time.NewTimer(delay)
			defer timer.Stop()
			select {
			case <-timer.C:
			case <-ctx.Done():
				return ctx.Err()
			}
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		next = time.Now().Add(5 * time.Millisecond)
		return sink(ctx, packet)
	}, nil
}
