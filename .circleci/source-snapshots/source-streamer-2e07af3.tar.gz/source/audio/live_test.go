// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"context"
	"encoding/binary"
	"errors"
	"io"
	"sync/atomic"
	"testing"
)

func liveFixture(ctx context.Context, w io.Writer, packets int) error {
	head := make([]byte, 19)
	copy(head, "OpusHead")
	head[8] = 1
	head[9] = 2
	for _, page := range [][]byte{testPage(2, 0, []byte{19}, head), testPage(0, 1, []byte{8}, []byte("OpusTags"))} {
		if _, err := w.Write(page); err != nil {
			return err
		}
	}
	for i := 0; i < packets; i++ {
		if err := ctx.Err(); err != nil {
			return err
		}
		flags := byte(0)
		if i == packets-1 {
			flags = 4
		}
		if _, err := w.Write(testPage(flags, uint32(i+2), []byte{2}, []byte{0xec, byte(i)})); err != nil {
			return err
		}
	}
	return nil
}
func TestLiveAudioBeyondSyntheticBudget(t *testing.T) {
	p, _ := NewPacketizer(make([]byte, 16), 1, 2)
	n := 0
	stats, err := StreamLive(context.Background(), func(ctx context.Context, w io.Writer) error { return liveFixture(ctx, w, 1200) }, func(_ context.Context, b []byte) error {
		if binary.BigEndian.Uint16(b[2:4]) != uint16(n) {
			t.Fatal("sequence")
		}
		n++
		return nil
	}, p)
	if err != nil || stats.Packets != 1200 || n != 1200 {
		t.Fatal(stats, n, err)
	}
}
func TestLiveAudioCancellationJoinsEncoder(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var exited atomic.Bool
	p, _ := NewPacketizer(make([]byte, 16), 1, 2)
	n := 0
	stats, err := StreamLive(ctx, func(ctx context.Context, w io.Writer) error {
		defer exited.Store(true)
		return liveFixture(ctx, w, 1200)
	}, func(context.Context, []byte) error {
		n++
		if n == 3 {
			cancel()
		}
		return nil
	}, p)
	if !errors.Is(err, context.Canceled) || !exited.Load() || stats.Packets != 3 {
		t.Fatal(stats, err, exited.Load())
	}
}
func TestLiveAudioPreservesKeyExhaustion(t *testing.T) {
	p, _ := NewPacketizer(make([]byte, 16), 1, 2)
	p.next = 65535
	stats, err := StreamLive(context.Background(), func(ctx context.Context, w io.Writer) error { return liveFixture(ctx, w, 3) }, func(context.Context, []byte) error { return nil }, p)
	if err == nil || stats.Packets != 1 || p.next != 65536 {
		t.Fatal(stats, err, p.next)
	}
}
