// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
)

type Encoder func(context.Context, io.Writer, Pattern) error

// LiveEncoder writes one stereo Ogg Opus stream and must honor cancellation.
type LiveEncoder func(context.Context, io.Writer) error
type PacketSink func(context.Context, []byte) error
type PacketStats struct {
	Packets int
	Bytes   int64
}

// StreamPattern connects a bounded synthetic encoder to Ogg validation and the
// encrypted audio packet core. It does not pace, send UDP, add FEC, capture a
// device or establish a session. Callbacks must honor cancellation and return.
// The caller owns the packetizer and must not reuse its key for another launch.
func StreamPattern(ctx context.Context, encoder Encoder, sink PacketSink, packetizer *Packetizer, pattern Pattern) (PacketStats, error) {
	return stream(ctx, encoder, sink, packetizer, pattern, false)
}

// StreamLive accepts an ongoing Ogg Opus encoder instead of a synthetic duration.
// It retains bounded pages, codec checks, cancellation and the packetizer's key
// exhaustion policy. The legacy wire format is encrypted but not authenticated.
// This does not supply device capture, FEC, pacing, peer selection or rekeying.
func StreamLive(ctx context.Context, encoder LiveEncoder, sink PacketSink, packetizer *Packetizer) (PacketStats, error) {
	if encoder == nil {
		return PacketStats{}, errors.New("live audio encoder required")
	}
	return stream(ctx, func(ctx context.Context, w io.Writer, _ Pattern) error { return encoder(ctx, w) }, sink, packetizer, Pattern{5}, true)
}

func stream(ctx context.Context, encoder Encoder, sink PacketSink, packetizer *Packetizer, pattern Pattern, live bool) (stats PacketStats, result error) {
	if ctx == nil || encoder == nil || sink == nil || packetizer == nil {
		return stats, errors.New("context, encoder, sink and packetizer required")
	}
	if err := pattern.Validate(); err != nil {
		return stats, err
	}
	if err := ctx.Err(); err != nil {
		return stats, err
	}
	runCtx, cancel := context.WithCancel(ctx)
	reader, writer := io.Pipe()
	finished := make(chan error, 1)
	stop := context.AfterFunc(runCtx, func() { _ = reader.CloseWithError(runCtx.Err()); _ = writer.CloseWithError(runCtx.Err()) })
	defer func() {
		cancel()
		_ = reader.CloseWithError(context.Canceled)
		_ = writer.CloseWithError(context.Canceled)
		stop()
		encoderErr := <-finished
		if result == nil {
			result = encoderErr
		}
		if ctx.Err() != nil {
			result = ctx.Err()
		}
	}()
	go func() { err := encoder(runCtx, writer, pattern); _ = writer.CloseWithError(err); finished <- err }()
	ogg := NewOggReader(reader)
	head, err := ogg.Next()
	if err != nil {
		return stats, err
	}
	if len(head) != 19 || !bytes.Equal(head[:8], []byte("OpusHead")) || head[8] != 1 || head[9] != 2 || head[18] != 0 || binary.LittleEndian.Uint16(head[16:18]) != 0 {
		return stats, errors.New("version1 stereo Opus mapping0 with zero gain required")
	}
	tags, err := ogg.Next()
	if err != nil {
		return stats, err
	}
	if len(tags) < 8 || !bytes.Equal(tags[:8], []byte("OpusTags")) {
		return stats, errors.New("Opus tags required")
	}
	limit := pattern.DurationMillis/5 + 1 // Our encoder's one-frame padding/pre-skip allowance.
	for {
		opus, err := ogg.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return stats, err
		}
		if err = runCtx.Err(); err != nil {
			return stats, err
		}
		if !live && stats.Packets >= limit {
			return stats, errors.New("encoder exceeded packet budget")
		}
		if err = ValidateFiveMillisStereo(opus); err != nil {
			return stats, err
		}
		packet, err := packetizer.Packet(opus)
		if err != nil {
			return stats, err
		}
		if err = sink(runCtx, packet); err != nil {
			return stats, err
		}
		stats.Packets++
		stats.Bytes += int64(len(packet))
	}
	if (!live && stats.Packets < pattern.DurationMillis/5) || (live && stats.Packets == 0) {
		return stats, errors.New("encoder returned insufficient frames")
	}
	var tail [1]byte
	if n, err := reader.Read(tail[:]); n != 0 || err != io.EOF {
		return stats, errors.New("trailing or chained Ogg data")
	}
	return stats, nil
}
