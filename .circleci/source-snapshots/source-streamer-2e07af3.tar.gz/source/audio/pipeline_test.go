// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"context"
	"encoding/binary"
	"errors"
	"io"
	"sync/atomic"
	"testing"
	"time"
)

func streamFixture(toc byte) []byte {
	head := make([]byte, 19)
	copy(head, "OpusHead")
	head[8] = 1
	head[9] = 2
	out := testPage(2, 0, []byte{19}, head)
	out = append(out, testPage(0, 1, []byte{8}, []byte("OpusTags"))...)
	return append(out, testPage(4, 2, []byte{2, 2}, []byte{toc, 1, toc, 2})...)
}
func TestStreamPatternFixture(t *testing.T) {
	p, _ := NewPacketizer(make([]byte, 16), 1, 2)
	n := 0
	encoder := func(_ context.Context, w io.Writer, _ Pattern) error {
		_, err := w.Write(streamFixture(0xec))
		return err
	}
	stats, err := StreamPattern(context.Background(), encoder, func(_ context.Context, b []byte) error {
		if binary.BigEndian.Uint16(b[2:4]) != uint16(n) {
			t.Fatal("sequence")
		}
		n++
		return nil
	}, p, Pattern{5})
	if err != nil || stats.Packets != 2 || n != 2 {
		t.Fatal(stats, n, err)
	}
}
func TestStreamPatternFailureCleanup(t *testing.T) {
	failure := errors.New("sink failed")
	var exited atomic.Bool
	encoder := func(ctx context.Context, w io.Writer, _ Pattern) error {
		defer exited.Store(true)
		_, err := w.Write(streamFixture(0xec))
		if err != nil {
			return err
		}
		<-ctx.Done()
		return ctx.Err()
	}
	p, _ := NewPacketizer(make([]byte, 16), 1, 2)
	_, err := StreamPattern(context.Background(), encoder, func(context.Context, []byte) error { return failure }, p, Pattern{5})
	if !errors.Is(err, failure) || !exited.Load() {
		t.Fatal(err, "encoder still running")
	}
}
func TestStreamPatternCancelBlockedRead(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	var exited atomic.Bool
	encoder := func(ctx context.Context, _ io.Writer, _ Pattern) error {
		defer exited.Store(true)
		<-ctx.Done()
		return ctx.Err()
	}
	p, _ := NewPacketizer(make([]byte, 16), 1, 2)
	_, err := StreamPattern(ctx, encoder, func(context.Context, []byte) error { return nil }, p, Pattern{5})
	if !errors.Is(err, context.DeadlineExceeded) || !exited.Load() {
		t.Fatal(err, "encoder still running")
	}
}
func TestStreamPatternRejectsWrongFrame(t *testing.T) {
	for _, data := range [][]byte{streamFixture(0xe8), append(streamFixture(0xec), 1), {1, 2, 3}} {
		p, _ := NewPacketizer(make([]byte, 16), 1, 2)
		encoder := func(_ context.Context, w io.Writer, _ Pattern) error { _, err := w.Write(data); return err }
		if _, err := StreamPattern(context.Background(), encoder, func(context.Context, []byte) error { return nil }, p, Pattern{5}); err == nil {
			t.Fatal("bad stream accepted")
		}
	}
}
