// SPDX-License-Identifier: GPL-3.0-only
package audio

import "testing"

func TestFiveMillisStereoTOC(t *testing.T) {
	for b := 0; b < 256; b++ {
		ok := b == 0x8c || b == 0xac || b == 0xcc || b == 0xec
		if got := ValidateFiveMillisStereo([]byte{byte(b), 1}) == nil; got != ok {
			t.Fatalf("TOC %x accepted=%v", b, got)
		}
	}
	for _, n := range []int{0, 1, 1277} {
		p := make([]byte, n)
		if n > 0 {
			p[0] = 0xec
		}
		if ValidateFiveMillisStereo(p) == nil {
			t.Fatalf("size %d accepted", n)
		}
	}
}
