// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
)

const MaxOggPacket = 64 << 10

// OggReader is a bounded single-logical-stream reader. It validates container
// framing, CRC, sequence and continuation, not Opus codec semantics. Chaining
// and packets over64 KiB are intentionally unsupported. The caller owns I/O
// cancellation/deadlines. No resynchronization is attempted after an error.
type OggReader struct {
	r                      io.Reader
	started, ended, failed bool
	serial, sequence       uint32
	partial                []byte
	queued                 [][]byte
}

func NewOggReader(r io.Reader) *OggReader { return &OggReader{r: r} }
func oggCRC(data []byte) uint32 {
	var crc uint32
	for _, b := range data {
		crc ^= uint32(b) << 24
		for i := 0; i < 8; i++ {
			if crc&0x80000000 != 0 {
				crc = (crc << 1) ^ 0x04c11db7
			} else {
				crc <<= 1
			}
		}
	}
	return crc
}
func (r *OggReader) Next() ([]byte, error) {
	if r.failed {
		return nil, errors.New("Ogg reader failed")
	}
	if r.r == nil {
		r.failed = true
		return nil, errors.New("reader required")
	}
	for pages := 0; ; pages++ {
		if len(r.queued) > 0 {
			p := r.queued[0]
			r.queued[0] = nil
			r.queued = r.queued[1:]
			return p, nil
		}
		if r.ended {
			return nil, io.EOF
		}
		if pages >= 32 {
			r.failed = true
			return nil, errors.New("too many pages without a complete packet")
		}
		if err := r.page(); err != nil {
			r.failed = true
			return nil, err
		}
	}
}
func (r *OggReader) page() error {
	var header [27]byte
	if _, err := io.ReadFull(r.r, header[:]); err != nil {
		if err == io.EOF {
			return io.ErrUnexpectedEOF
		}
		return err
	}
	if !bytes.Equal(header[:4], []byte("OggS")) || header[4] != 0 || header[5]&^byte(7) != 0 {
		return errors.New("invalid Ogg page header")
	}
	flags := header[5]
	serial := binary.LittleEndian.Uint32(header[14:18])
	sequence := binary.LittleEndian.Uint32(header[18:22])
	if !r.started {
		if flags&2 == 0 || flags&1 != 0 || sequence != 0 {
			return errors.New("initial Ogg BOS page required")
		}
	} else if flags&2 != 0 || serial != r.serial || r.sequence == ^uint32(0) || sequence != r.sequence+1 {
		return errors.New("Ogg stream/sequence discontinuity")
	}
	if (flags&1 != 0) != (len(r.partial) > 0) {
		return errors.New("Ogg continuation mismatch")
	}
	laces := make([]byte, int(header[26]))
	if len(laces) == 0 {
		return errors.New("empty Ogg pages unsupported")
	}
	if _, err := io.ReadFull(r.r, laces); err != nil {
		return err
	}
	size := 0
	for _, n := range laces {
		size += int(n)
	}
	payload := make([]byte, size)
	if _, err := io.ReadFull(r.r, payload); err != nil {
		if err == io.EOF && size > 0 {
			return io.ErrUnexpectedEOF
		}
		return err
	}
	expected := binary.LittleEndian.Uint32(header[22:26])
	for i := 22; i < 26; i++ {
		header[i] = 0
	}
	checksum := append(append(append([]byte(nil), header[:]...), laces...), payload...)
	if oggCRC(checksum) != expected {
		return errors.New("Ogg page CRC mismatch")
	}
	offset := 0
	var completed [][]byte
	partial := append([]byte(nil), r.partial...)
	for _, size := range laces {
		n := int(size)
		if len(partial)+n > MaxOggPacket {
			return errors.New("Ogg packet exceeds bounded profile")
		}
		partial = append(partial, payload[offset:offset+n]...)
		offset += n
		if n < 255 {
			completed = append(completed, partial)
			partial = nil
		}
	}
	if flags&4 != 0 && len(partial) > 0 {
		return errors.New("partial packet at Ogg EOS")
	}
	r.started = true
	r.serial = serial
	r.sequence = sequence
	r.partial = partial
	r.queued = completed
	r.ended = flags&4 != 0
	return nil
}
