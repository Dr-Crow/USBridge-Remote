// SPDX-License-Identifier: GPL-3.0-only
// Package audio currently provides bounded synthetic audio, not microphone capture.
package audio

import (
	"context"
	"errors"
	"fmt"
	"io"
	"math"
	"os/exec"
)

const SampleRate = 48000
const Channels = 2

// Pattern is a stereo 440/880 Hz test signal at quarter-scale amplitude.
type Pattern struct{ DurationMillis int }

func (p Pattern) Validate() error {
	if p.DurationMillis < 5 || p.DurationMillis > 5000 || p.DurationMillis%5 != 0 {
		return errors.New("duration must be 5..5000 milliseconds in steps of 5")
	}
	return nil
}

type pcmReader struct{ position, total int64 }

func NewPCMReader(p Pattern) (io.Reader, error) {
	if err := p.Validate(); err != nil {
		return nil, err
	}
	return &pcmReader{total: int64(p.DurationMillis) * 48 * 4}, nil
}
func (r *pcmReader) Read(out []byte) (int, error) {
	if len(out) == 0 {
		return 0, nil
	}
	if r.position == r.total {
		return 0, io.EOF
	}
	n := len(out)
	if int64(n) > r.total-r.position {
		n = int(r.total - r.position)
	}
	for i := 0; i < n; i++ {
		pos := r.position + int64(i)
		sample := pos / 4
		channel := (pos / 2) % 2
		frequency := 440.0
		if channel == 1 {
			frequency = 880
		}
		value := uint16(int16(math.Round(8192 * math.Sin(2*math.Pi*frequency*float64(sample)/SampleRate))))
		if pos%2 == 0 {
			out[i] = byte(value)
		} else {
			out[i] = byte(value >> 8)
		}
	}
	r.position += int64(n)
	return n, nil
}

type cappedLog struct{ data []byte }

func (l *cappedLog) Write(p []byte) (int, error) {
	n := len(p)
	remaining := (64 << 10) - len(l.data)
	if len(p) > remaining {
		p = p[:remaining]
	}
	l.data = append(l.data, p...)
	return n, nil
}

// EncodePattern writes Ogg Opus with 5-ms stereo packets using a caller-selected
// trusted FFmpeg. No shell, device capture or network destination is involved.
// This is not GameStream packetization, encryption or a production audio stream.
func EncodePattern(ctx context.Context, ffmpeg string, out io.Writer, p Pattern) error {
	if ctx == nil || ffmpeg == "" || out == nil {
		return errors.New("context, trusted encoder and output required")
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	input, err := NewPCMReader(p)
	if err != nil {
		return err
	}
	args := []string{"-hide_banner", "-nostdin", "-v", "error", "-f", "s16le", "-ar", "48000", "-ac", "2", "-i", "pipe:0", "-vn", "-c:a", "libopus", "-b:a", "128k", "-application", "lowdelay", "-frame_duration", "5", "-vbr", "off", "-mapping_family", "0", "-f", "ogg", "pipe:1"}
	cmd := exec.CommandContext(ctx, ffmpeg, args...)
	cmd.Stdin = input
	cmd.Stdout = out
	log := &cappedLog{}
	cmd.Stderr = log
	if err := cmd.Run(); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return fmt.Errorf("synthetic audio encoder failed: %w: %s", err, string(log.data))
	}
	return nil
}
