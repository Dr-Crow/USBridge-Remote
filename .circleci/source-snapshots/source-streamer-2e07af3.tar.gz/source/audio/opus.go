// SPDX-License-Identifier: GPL-3.0-only
package audio

import "errors"

// ValidateFiveMillisStereo accepts the narrow single-frame CELT stereo profile
// emitted by our test encoder. RFC 6716 section 3.1 specifies the TOC bits.
// This validates framing/duration only, not compressed entropy or sample quality.
func ValidateFiveMillisStereo(packet []byte) error {
	if len(packet) < 2 || len(packet) > 1276 {
		return errors.New("single Opus frame size out of range")
	}
	toc := packet[0]
	config := toc >> 3
	if config < 16 || config%4 != 1 || toc&4 == 0 || toc&3 != 0 {
		return errors.New("one 5-ms CELT stereo frame required")
	}
	return nil
}
