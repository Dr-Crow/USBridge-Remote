// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"context"
	"errors"
	"io"
	"os"
	"sync/atomic"
	"testing"
	"time"
)

type trackedPCM struct {
	io.ReadCloser
	closed atomic.Bool
}

func (r *trackedPCM) Close() error { r.closed.Store(true); return r.ReadCloser.Close() }
func TestPCMStreamIntegration(t *testing.T) {
	ffmpeg := os.Getenv("STREAMER_FFMPEG")
	if ffmpeg == "" {
		t.Skip("trusted FFmpeg required")
	}
	a, _ := NewPCMReader(Pattern{3000})
	b, _ := NewPCMReader(Pattern{3000})
	input := &trackedPCM{ReadCloser: io.NopCloser(io.MultiReader(a, b))}
	p, _ := NewPacketizer(make([]byte, 16), 1, 2)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	stats, err := StreamLive(ctx, func(ctx context.Context, w io.Writer) error { return EncodePCMStream(ctx, ffmpeg, input, w) }, func(context.Context, []byte) error { return nil }, p)
	if err != nil || stats.Packets < 1200 || stats.Packets > 1202 || !input.closed.Load() {
		t.Fatal(stats, err, input.closed.Load())
	}
}
func TestPCMStreamCancelIntegration(t *testing.T) {
	ffmpeg := os.Getenv("STREAMER_FFMPEG")
	if ffmpeg == "" {
		t.Skip("trusted FFmpeg required")
	}
	reader, writer := io.Pipe()
	defer writer.Close()
	input := &trackedPCM{ReadCloser: reader}
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel()
	start := time.Now()
	err := EncodePCMStream(ctx, ffmpeg, input, io.Discard)
	if !errors.Is(err, context.DeadlineExceeded) || !input.closed.Load() || time.Since(start) > 2*time.Second {
		t.Fatal(err, input.closed.Load(), time.Since(start))
	}
}
