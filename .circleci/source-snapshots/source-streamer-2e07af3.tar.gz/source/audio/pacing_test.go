// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"context"
	"errors"
	"sync/atomic"
	"testing"
	"time"
)

func TestPacingSpacingAndLateReset(t *testing.T) {
	var starts []time.Time
	paced, err := PaceFiveMillis(func(_ context.Context, p []byte) error { starts = append(starts, time.Now()); return nil })
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	for i := 0; i < 4; i++ {
		if i == 2 {
			time.Sleep(15 * time.Millisecond)
		}
		if err := paced(ctx, []byte{byte(i)}); err != nil {
			t.Fatal(err)
		}
	}
	for i := 1; i < len(starts); i++ {
		if starts[i].Sub(starts[i-1]) < 5*time.Millisecond {
			t.Fatal("delivery burst", starts[i].Sub(starts[i-1]))
		}
	}
}
func TestPacingCancellationDoesNotDeliver(t *testing.T) {
	var calls atomic.Int32
	entered := make(chan struct{})
	release := make(chan struct{})
	paced, _ := PaceFiveMillis(func(ctx context.Context, _ []byte) error {
		calls.Add(1)
		close(entered)
		select {
		case <-release:
			return nil
		case <-ctx.Done():
			return ctx.Err()
		}
	})
	first := make(chan error, 1)
	go func() { first <- paced(context.Background(), nil) }()
	<-entered
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := paced(ctx, nil); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	close(release)
	if err := <-first; err != nil {
		t.Fatal(err)
	}
	if calls.Load() != 1 {
		t.Fatal("canceled call delivered")
	}
}
func TestPacingValidationAndSinkFailure(t *testing.T) {
	if _, err := PaceFiveMillis(nil); err == nil {
		t.Fatal("nil accepted")
	}
	sentinel := errors.New("sink failed")
	paced, _ := PaceFiveMillis(func(context.Context, []byte) error { return sentinel })
	if err := paced(nil, nil); err == nil {
		t.Fatal("nil context accepted")
	}
	if err := paced(context.Background(), nil); !errors.Is(err, sentinel) {
		t.Fatal(err)
	}
}
