// SPDX-License-Identifier: GPL-3.0-only
// Analyst-authored public GameStream audio wire adapter, not recovered source.
package audio

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"sync"
)

// Packetizer emits encrypted 5-ms stereo Opus data packets. The public client's
// legacy audio format uses AES-CBC without an authentication tag. Callers must
// not describe this as authenticated audio. Pairing, peer authorization, FEC,
// pacing, UDP transport and protected key negotiation are separate obligations.
// A fresh instance must own a fresh per-launch key; reuse after sequence wrap is
// rejected rather than silently repeating CBC IVs. This is an experimental core.
type Packetizer struct {
	mu                     sync.Mutex
	block                  cipher.Block
	keyID, timestamp, ssrc uint32
	next                   uint32
}

func NewPacketizer(key []byte, keyID, ssrc uint32) (*Packetizer, error) {
	if len(key) != 16 {
		return nil, errors.New("audio requires a 128-bit launch key")
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	return &Packetizer{block: block, keyID: keyID, ssrc: ssrc}, nil
}

// Packet accepts one already-validated 5-ms Opus packet, not an Ogg page or
// header. It bounds payloads to fit the client's 1400-byte receive buffer.
// It does not parse or validate Opus codec semantics. Timestamps in this
// protocol advance in milliseconds, not the standard RTP 48-kHz sample clock.
func (p *Packetizer) Packet(opus []byte) ([]byte, error) {
	if len(opus) == 0 || len(opus) > 1375 {
		return nil, errors.New("invalid Opus packet size")
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.block == nil {
		return nil, errors.New("audio packetizer is uninitialized")
	}
	if p.next >= 65536 {
		return nil, errors.New("audio sequence exhausted; fresh launch key required")
	}
	padding := aes.BlockSize - len(opus)%aes.BlockSize
	out := make([]byte, 12+len(opus)+padding)
	out[0] = 0x80
	out[1] = 97
	binary.BigEndian.PutUint16(out[2:4], uint16(p.next))
	binary.BigEndian.PutUint32(out[4:8], p.timestamp)
	binary.BigEndian.PutUint32(out[8:12], p.ssrc)
	copy(out[12:], opus)
	for i := 12 + len(opus); i < len(out); i++ {
		out[i] = byte(padding)
	}
	var iv [aes.BlockSize]byte
	binary.BigEndian.PutUint32(iv[:4], p.keyID+p.next)
	cipher.NewCBCEncrypter(p.block, iv[:]).CryptBlocks(out[12:], out[12:])
	p.next++
	p.timestamp += 5
	return out, nil
}
