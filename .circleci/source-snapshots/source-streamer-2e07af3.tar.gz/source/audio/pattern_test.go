// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"bytes"
	"context"
	"encoding/binary"
	"io"
	"testing"
)

func TestPCMFragmentationAndStereo(t *testing.T) {
	r, err := NewPCMReader(Pattern{10})
	if err != nil {
		t.Fatal(err)
	}
	all, err := io.ReadAll(r)
	if err != nil || len(all) != 10*48*4 {
		t.Fatal(len(all), err)
	}
	r, _ = NewPCMReader(Pattern{10})
	var chunks []byte
	one := make([]byte, 3)
	for {
		n, err := r.Read(one)
		chunks = append(chunks, one[:n]...)
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatal(err)
		}
	}
	if !bytes.Equal(all, chunks) {
		t.Fatal("fragmented PCM changed")
	}
	left := int16(binary.LittleEndian.Uint16(all[4:6]))
	right := int16(binary.LittleEndian.Uint16(all[6:8]))
	if left <= 0 || right <= left {
		t.Fatal(left, right)
	}
}
func TestBoundsBeforeEncoder(t *testing.T) {
	for _, n := range []int{-1, 0, 1, 5001, 10000} {
		if err := EncodePattern(context.Background(), "must-not-run", io.Discard, Pattern{n}); err == nil {
			t.Fatal(n)
		}
	}
}
func TestCancellationBeforeEncoder(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := EncodePattern(ctx, "must-not-run", io.Discard, Pattern{10}); err != context.Canceled {
		t.Fatal(err)
	}
}
func TestStderrBound(t *testing.T) {
	l := &cappedLog{}
	data := make([]byte, 100000)
	if n, err := l.Write(data); n != len(data) || err != nil || len(l.data) != 64<<10 {
		t.Fatal(n, err, len(l.data))
	}
}
