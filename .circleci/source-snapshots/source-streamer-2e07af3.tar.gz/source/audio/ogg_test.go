// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"bytes"
	"encoding/binary"
	"io"
	"testing"
)

func testPage(flags byte, seq uint32, laces, payload []byte) []byte {
	p := make([]byte, 27)
	copy(p, "OggS")
	p[5] = flags
	p[26] = byte(len(laces))
	binary.LittleEndian.PutUint32(p[14:18], 99)
	binary.LittleEndian.PutUint32(p[18:22], seq)
	p = append(p, laces...)
	p = append(p, payload...)
	binary.LittleEndian.PutUint32(p[22:26], oggCRC(p))
	return p
}
func TestOggPacketsAndContinuation(t *testing.T) {
	first := testPage(2, 0, []byte{3, 255}, append([]byte("abc"), bytes.Repeat([]byte{7}, 255)...))
	second := testPage(1|4, 1, []byte{2, 1}, []byte{8, 9, 10})
	r := NewOggReader(bytes.NewReader(append(first, second...)))
	want := [][]byte{[]byte("abc"), append(bytes.Repeat([]byte{7}, 255), 8, 9), {10}}
	for _, w := range want {
		p, err := r.Next()
		if err != nil || !bytes.Equal(p, w) {
			t.Fatal(len(p), err)
		}
	}
	if _, err := r.Next(); err != io.EOF {
		t.Fatal(err)
	}
}
func TestOggRejectsTamperTruncationSequence(t *testing.T) {
	valid := testPage(2|4, 0, []byte{3}, []byte("abc"))
	for i := 0; i < len(valid); i++ {
		r := NewOggReader(bytes.NewReader(valid[:i]))
		if _, err := r.Next(); err == nil {
			t.Fatal("truncation", i)
		}
	}
	bad := append([]byte(nil), valid...)
	bad[len(bad)-1] ^= 1
	if _, err := NewOggReader(bytes.NewReader(bad)).Next(); err == nil {
		t.Fatal("CRC")
	}
	for _, bad := range [][]byte{testPage(0, 0, []byte{1}, []byte{1}), testPage(2|1, 0, []byte{1}, []byte{1}), testPage(2|4, 0, []byte{255}, make([]byte, 255))} {
		if _, err := NewOggReader(bytes.NewReader(bad)).Next(); err == nil {
			t.Fatal("bad header/continuation")
		}
	}
	first := testPage(2, 0, []byte{1}, []byte{1})
	second := testPage(4, 2, []byte{1}, []byte{2})
	r := NewOggReader(bytes.NewReader(append(first, second...)))
	if _, err := r.Next(); err != nil {
		t.Fatal(err)
	}
	if _, err := r.Next(); err == nil {
		t.Fatal("sequence")
	}
}
func FuzzOggReader(f *testing.F) {
	f.Add(testPage(2|4, 0, []byte{3}, []byte("abc")))
	f.Add([]byte("OggS"))
	f.Fuzz(func(t *testing.T, data []byte) {
		if len(data) > 200000 {
			return
		}
		r := NewOggReader(bytes.NewReader(data))
		for n := 0; n <= len(data); n++ {
			p, err := r.Next()
			if err != nil {
				return
			}
			if len(p) > MaxOggPacket {
				t.Fatal("unbounded packet")
			}
		}
		t.Fatal("excess packets for bounded input")
	})
}

func TestOggPacketBoundAndMissingEnd(t *testing.T) {
	first := testPage(2, 0, bytes.Repeat([]byte{255}, 255), make([]byte, 65025))
	for _, last := range []byte{1, 2} {
		second := testPage(1|4, 1, []byte{255, 255, last}, make([]byte, 510+int(last)))
		r := NewOggReader(bytes.NewReader(append(append([]byte(nil), first...), second...)))
		p, err := r.Next()
		if last == 1 {
			if err != nil || len(p) != MaxOggPacket {
				t.Fatal(len(p), err)
			}
		} else if err == nil {
			t.Fatal("oversize accepted")
		}
	}
	r := NewOggReader(bytes.NewReader(testPage(2, 0, []byte{1}, []byte{1})))
	if _, err := r.Next(); err != nil {
		t.Fatal(err)
	}
	if _, err := r.Next(); err != io.ErrUnexpectedEOF {
		t.Fatal("missing EOS", err)
	}
}
