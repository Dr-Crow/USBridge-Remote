// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os/exec"
	"sync"
)

// EncodePCMStream owns input and closes it on completion or cancellation. Input
// must be signed little-endian 16-bit stereo PCM at 48 kHz; its Close must unblock
// Read. The caller must select an authorized source and a trusted FFmpeg binary.
// Output is a single 5-ms stereo Ogg Opus stream. No device, shell, network peer,
// platform capture permission or pairing is selected here. Output writes must
// be cancellable by their owner (as provided by StreamLive's pipe).
func EncodePCMStream(ctx context.Context, ffmpeg string, input io.ReadCloser, output io.Writer) error {
	if ctx == nil || ffmpeg == "" || input == nil || output == nil {
		return errors.New("context, trusted encoder, PCM input and output required")
	}
	var closeOnce sync.Once
	closeInput := func() { closeOnce.Do(func() { _ = input.Close() }) }
	defer closeInput()
	if err := ctx.Err(); err != nil {
		return err
	}
	stop := context.AfterFunc(ctx, closeInput)
	defer stop()
	args := []string{"-hide_banner", "-nostdin", "-v", "error", "-f", "s16le", "-ar", "48000", "-ac", "2", "-i", "pipe:0", "-vn", "-c:a", "libopus", "-b:a", "128k", "-application", "lowdelay", "-frame_duration", "5", "-vbr", "off", "-mapping_family", "0", "-f", "ogg", "-page_duration", "5000", "-flush_packets", "1", "pipe:1"}
	cmd := exec.CommandContext(ctx, ffmpeg, args...)
	cmd.Stdin = input
	cmd.Stdout = output
	log := &cappedLog{}
	cmd.Stderr = log
	if err := cmd.Run(); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return fmt.Errorf("PCM audio encoder failed: %w: %s", err, string(log.data))
	}
	return ctx.Err()
}
