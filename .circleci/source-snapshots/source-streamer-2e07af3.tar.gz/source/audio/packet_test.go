// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"encoding/hex"
	"sync"
	"testing"
)

func TestPacketWireAndPadding(t *testing.T) {
	key := make([]byte, 16)
	p, err := NewPacketizer(key, 0x01020304, 0x11223344)
	if err != nil {
		t.Fatal(err)
	}
	for seq := 0; seq < 3; seq++ {
		original := bytes.Repeat([]byte{byte(seq + 1)}, 16+seq)
		packet, err := p.Packet(original)
		if err != nil {
			t.Fatal(err)
		}
		if packet[0] != 0x80 || packet[1] != 97 || binary.BigEndian.Uint16(packet[2:4]) != uint16(seq) || binary.BigEndian.Uint32(packet[4:8]) != uint32(seq*5) || binary.BigEndian.Uint32(packet[8:12]) != 0x11223344 {
			t.Fatalf("bad header %x", packet[:12])
		}
		block, _ := aes.NewCipher(key)
		var iv [16]byte
		binary.BigEndian.PutUint32(iv[:4], 0x01020304+uint32(seq))
		plain := append([]byte(nil), packet[12:]...)
		cipher.NewCBCDecrypter(block, iv[:]).CryptBlocks(plain, plain)
		padding := int(plain[len(plain)-1])
		if !bytes.Equal(plain[:len(plain)-padding], original) {
			t.Fatal("payload mismatch")
		}
		for _, b := range plain[len(plain)-padding:] {
			if int(b) != padding {
				t.Fatal("bad padding")
			}
		}
	}
}

func TestPacketIndependentVector(t *testing.T) {
	// OpenSSL AES-128-CBC vector, zero key, IV 01020304000000000000000000000000,
	// plaintext 0102030405, default PKCS#7 padding.
	p, _ := NewPacketizer(make([]byte, 16), 0x01020304, 0)
	got, err := p.Packet([]byte{1, 2, 3, 4, 5})
	if err != nil {
		t.Fatal(err)
	}
	want, _ := hex.DecodeString("8651ce14cc259baa07cabb653623d85e")
	if !bytes.Equal(got[12:], want) {
		t.Fatalf("ciphertext %x, want %x", got[12:], want)
	}
}

func TestPacketBoundsAndExhaustion(t *testing.T) {
	for _, n := range []int{0, 15, 17, 32} {
		if _, err := NewPacketizer(make([]byte, n), 0, 0); err == nil {
			t.Fatalf("key %d accepted", n)
		}
	}
	p, _ := NewPacketizer(make([]byte, 16), 0xffffffff, 0)
	for _, n := range []int{0, 1376, 65536} {
		if _, err := p.Packet(make([]byte, n)); err == nil {
			t.Fatalf("payload %d accepted", n)
		}
	}
	max, err := p.Packet(make([]byte, 1375))
	if err != nil || len(max) > 1400 {
		t.Fatalf("max packet %d %v", len(max), err)
	}
	p.next = 65535
	if _, err = p.Packet([]byte{1}); err != nil {
		t.Fatal(err)
	}
	if _, err = p.Packet([]byte{1}); err == nil {
		t.Fatal("sequence reused")
	}
	var zero Packetizer
	if _, err = zero.Packet([]byte{1}); err == nil {
		t.Fatal("zero packetizer accepted")
	}
}

func TestPacketConcurrentSequences(t *testing.T) {
	p, _ := NewPacketizer(make([]byte, 16), 0, 0)
	out := make(chan uint16, 100)
	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			pkt, err := p.Packet([]byte{1})
			if err != nil {
				t.Error(err)
				return
			}
			out <- binary.BigEndian.Uint16(pkt[2:4])
		}()
	}
	wg.Wait()
	close(out)
	seen := map[uint16]bool{}
	for seq := range out {
		if seen[seq] {
			t.Fatal("duplicate sequence")
		}
		seen[seq] = true
	}
	if len(seen) != 100 {
		t.Fatal("missing packets")
	}
}
