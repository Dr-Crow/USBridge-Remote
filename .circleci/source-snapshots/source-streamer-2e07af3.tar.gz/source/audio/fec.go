// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"bytes"
	"encoding/binary"
	"errors"
)

// AudioParity produces two public-client-compatible parity datagrams for four
// complete encrypted audio data datagrams. This is error correction, NOT an
// authentication mechanism. It requires one aligned, contiguous equal-size block.
// Inputs are borrowed during this call; both outputs own their data.
func AudioParity(data [4][]byte) ([2][]byte, error) {
	var out [2][]byte
	size := len(data[0])
	if size < 28 || size > 1388 || (size-12)%16 != 0 {
		return out, errors.New("invalid encrypted audio shard size")
	}
	first := data[0]
	base := binary.BigEndian.Uint16(first[2:4])
	stamp := binary.BigEndian.Uint32(first[4:8])
	if base%4 != 0 || base > 65532 {
		return out, errors.New("aligned non-wrapping audio block required")
	}
	for i, p := range data {
		if len(p) != size || p[0] != 0x80 || p[1] != 97 || binary.BigEndian.Uint16(p[2:4]) != base+uint16(i) || binary.BigEndian.Uint32(p[4:8]) != stamp+uint32(i)*5 || !bytes.Equal(p[8:12], first[8:12]) {
			return out, errors.New("audio parity block identity, order or size mismatch")
		}
	}
	// Matrix used by the pinned public client's RtpAudioQueue.c; GF(256)
	// polynomial 0x11d matches its pinned nanors implementation.
	matrix := [2][4]byte{{0x77, 0x40, 0x38, 0x0e}, {0xc7, 0xa7, 0x0d, 0x6c}}
	for row := range out {
		p := make([]byte, size+12)
		copy(p[:12], first[:12])
		p[1] = 127
		binary.BigEndian.PutUint16(p[2:4], base+uint16(row))
		p[12] = byte(row)
		p[13] = 97
		copy(p[14:16], first[2:4])
		copy(p[16:20], first[4:8])
		copy(p[20:24], first[8:12])
		for col := range data {
			for i, b := range data[col][12:] {
				p[24+i] ^= audioGFMul(matrix[row][col], b)
			}
		}
		out[row] = p
	}
	return out, nil
}
func audioGFMul(a, b byte) byte {
	var product byte
	for b != 0 {
		if b&1 != 0 {
			product ^= a
		}
		high := a & 0x80
		a <<= 1
		if high != 0 {
			a ^= 0x1d
		}
		b >>= 1
	}
	return product
}
