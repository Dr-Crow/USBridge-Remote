// SPDX-License-Identifier: GPL-3.0-only
package audio

import (
	"encoding/binary"
	"testing"
)

func fecInputs(t *testing.T) [4][]byte {
	t.Helper()
	p, _ := NewPacketizer(make([]byte, 16), 0x01020304, 0x11223344)
	var data [4][]byte
	for i := range data {
		var err error
		data[i], err = p.Packet([]byte{0x8c, byte(i), 1})
		if err != nil {
			t.Fatal(err)
		}
	}
	return data
}
func TestAudioParityHeadersAndBounds(t *testing.T) {
	data := fecInputs(t)
	parity, err := AudioParity(data)
	if err != nil {
		t.Fatal(err)
	}
	for i, p := range parity {
		if len(p) != len(data[0])+12 || p[0] != 0x80 || p[1] != 127 || p[12] != byte(i) || p[13] != 97 || binary.BigEndian.Uint16(p[14:16]) != 0 || binary.BigEndian.Uint32(p[20:24]) != 0x11223344 {
			t.Fatal("bad parity header")
		}
	}
	for _, mutate := range []func(*[4][]byte){func(p *[4][]byte) { p[0] = nil }, func(p *[4][]byte) { p[1] = p[1][:20] }, func(p *[4][]byte) { p[2][3]++ }, func(p *[4][]byte) { p[2][7]++ }, func(p *[4][]byte) { p[3][11]++ }, func(p *[4][]byte) { p[0][1] = 127 }} {
		bad := fecInputs(t)
		mutate(&bad)
		if _, err := AudioParity(bad); err == nil {
			t.Fatal("bad block accepted")
		}
	}
}
func TestAudioGFField(t *testing.T) {
	for i := 0; i < 256; i++ {
		a := byte(i)
		if audioGFMul(a, 0) != 0 || audioGFMul(a, 1) != a || audioGFMul(a, 2) != audioGFMul(2, a) {
			t.Fatal(i)
		}
	}
	if audioGFMul(0x80, 2) != 0x1d {
		t.Fatal("wrong field polynomial")
	}
}

func FuzzAudioParity(f *testing.F) {
	p, _ := NewPacketizer(make([]byte, 16), 1, 2)
	var seed []byte
	for i := 0; i < 4; i++ {
		b, _ := p.Packet([]byte{0x8c, byte(i)})
		seed = append(seed, b...)
	}
	f.Add(seed)
	f.Add([]byte{})
	f.Fuzz(func(t *testing.T, b []byte) {
		if len(b)%4 != 0 {
			return
		}
		size := len(b) / 4
		var input [4][]byte
		for i := range input {
			input[i] = b[i*size : (i+1)*size]
		}
		out, err := AudioParity(input)
		if err != nil {
			return
		}
		for i, p := range out {
			if len(p) != size+12 || len(p) > 1400 || p[1] != 127 || p[12] != byte(i) {
				t.Fatal("invalid parity output")
			}
		}
	})
}
