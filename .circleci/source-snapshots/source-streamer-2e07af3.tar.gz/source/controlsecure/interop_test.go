// SPDX-License-Identifier: GPL-3.0-only
package controlsecure

import (
	"bytes"
	"encoding/binary"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

func TestPublicControlInterop(t *testing.T) {
	fixture := os.Getenv("CONTROL_INTEROP_BINARY")
	if fixture == "" {
		t.Skip("pinned public-client fixture required")
	}
	dir := t.TempDir()
	incoming := filepath.Join(dir, "incoming.bin")
	outgoing := filepath.Join(dir, "outgoing.bin")
	if b, e := exec.Command(fixture, "generate", incoming).CombinedOutput(); e != nil {
		t.Fatalf("%v: %s", e, b)
	}
	wire, e := os.ReadFile(incoming)
	if e != nil {
		t.Fatal(e)
	}
	h, _ := NewHost(key)
	var output bytes.Buffer
	for i := 0; i < 256; i++ {
		if len(wire) < 4 {
			t.Fatal("short record")
		}
		n := int(binary.BigEndian.Uint32(wire[:4]))
		wire = wire[4:]
		if n < 28 || n > len(wire) {
			t.Fatal("invalid record size")
		}
		m, e := h.Open(wire[:n])
		if e != nil {
			t.Fatal(i, e)
		}
		wire = wire[n:]
		if m.Type != uint16(0x200+i) || len(m.Payload) != i%64 {
			t.Fatal(i, m)
		}
		for j, b := range m.Payload {
			if b != byte(i+j) {
				t.Fatal("payload mismatch")
			}
		}
		p, e := h.Seal(m)
		if e != nil {
			t.Fatal(e)
		}
		_ = binary.Write(&output, binary.BigEndian, uint32(len(p)))
		output.Write(p)
	}
	if len(wire) != 0 {
		t.Fatal("trailing records")
	}
	if e = os.WriteFile(outgoing, output.Bytes(), 0600); e != nil {
		t.Fatal(e)
	}
	if b, e := exec.Command(fixture, "decode", outgoing).CombinedOutput(); e != nil {
		t.Fatalf("%v: %s", e, b)
	}
	bad := append([]byte(nil), output.Bytes()...)
	bad[12] ^= 1
	if e = os.WriteFile(outgoing, bad, 0600); e != nil {
		t.Fatal(e)
	}
	if e = exec.Command(fixture, "decode", outgoing).Run(); e == nil {
		t.Fatal("public client accepted corrupted tag")
	}
}
