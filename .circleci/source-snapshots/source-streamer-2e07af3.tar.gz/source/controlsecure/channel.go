// SPDX-License-Identifier: GPL-3.0-only
// Package controlsecure implements the modern public control-v2 envelope.
// This is analyst-authored code, not recovered vendor source.
package controlsecure

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"math"
	"sync"
)

const MaxPayload = math.MaxUint16 - 24

type Message struct {
	Type    uint16
	Payload []byte
}

// Host owns one authenticated launch's control key and sequence state. Retain
// it across transport reconnects; never recreate it with the same launch key.
// The caller must negotiate SS_ENC_CONTROL_V2, authenticate the launch and
// authorize every action. There is no legacy encryption or plaintext fallback.
// This envelope is not an ENet transport or an input/device implementation.
type Host struct {
	txMu, rxMu sync.Mutex
	aead       cipher.AEAD
	tx         uint64
	high       uint32
	seen       uint64
	haveRX     bool
}

func NewHost(key []byte) (*Host, error) {
	if len(key) != 16 {
		return nil, errors.New("16-byte authenticated launch key required")
	}
	b, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	a, err := cipher.NewGCM(b)
	if err != nil {
		return nil, err
	}
	return &Host{aead: a}, nil
}

func nonce(seq uint32, direction byte) [12]byte {
	var iv [12]byte
	binary.LittleEndian.PutUint32(iv[:4], seq)
	iv[10], iv[11] = direction, 'C'
	return iv
}

// Seal emits type/length/sequence, tag, then encrypted type/length/payload.
// Sequence zero is valid. Exhaustion requires a new authenticated launch key.
// A retry must resend the original packet, not encrypt with a reused sequence.
func (h *Host) Seal(m Message) ([]byte, error) {
	if len(m.Payload) > MaxPayload {
		return nil, errors.New("control payload too large")
	}
	h.txMu.Lock()
	defer h.txMu.Unlock()
	if h.tx > math.MaxUint32 {
		return nil, errors.New("control sequence exhausted")
	}
	seq := uint32(h.tx)
	h.tx++
	plain := make([]byte, 4+len(m.Payload))
	binary.LittleEndian.PutUint16(plain[:2], m.Type)
	binary.LittleEndian.PutUint16(plain[2:4], uint16(len(m.Payload)))
	copy(plain[4:], m.Payload)
	iv := nonce(seq, 'H')
	sealed := h.aead.Seal(nil, iv[:], plain, nil)
	out := make([]byte, 24+len(plain))
	binary.LittleEndian.PutUint16(out[:2], 1)
	binary.LittleEndian.PutUint16(out[2:4], uint16(len(out)-4))
	binary.LittleEndian.PutUint32(out[4:8], seq)
	copy(out[8:24], sealed[len(plain):])
	copy(out[24:], sealed[:len(plain)])
	return out, nil
}

// Open accepts each authenticated sequence at most once, allowing a 64-packet
// reorder window across ENet channels. Older packets fail closed; this bounded
// replay policy is ours, not a claim about the stock host. No sequence wrap is
// permitted with the same key. Failed authentication/framing never moves state.
func (h *Host) Open(packet []byte) (Message, error) {
	if len(packet) < 28 || len(packet) > MaxPayload+28 ||
		binary.LittleEndian.Uint16(packet[:2]) != 1 ||
		int(binary.LittleEndian.Uint16(packet[2:4])) != len(packet)-4 {
		return Message{}, errors.New("invalid control envelope")
	}
	h.rxMu.Lock()
	defer h.rxMu.Unlock()
	seq := binary.LittleEndian.Uint32(packet[4:8])
	if h.haveRX && seq <= h.high {
		delta := h.high - seq
		if delta >= 64 || h.seen&(uint64(1)<<delta) != 0 {
			return Message{}, errors.New("replayed or expired control sequence")
		}
	}
	sealed := make([]byte, len(packet)-8)
	copy(sealed, packet[24:])
	copy(sealed[len(packet)-24:], packet[8:24])
	iv := nonce(seq, 'C')
	plain, err := h.aead.Open(nil, iv[:], sealed, nil)
	if err != nil {
		return Message{}, errors.New("control authentication failed")
	}
	if len(plain) < 4 || int(binary.LittleEndian.Uint16(plain[2:4])) != len(plain)-4 {
		return Message{}, errors.New("invalid control payload length")
	}
	if !h.haveRX {
		h.high, h.seen, h.haveRX = seq, 1, true
	} else if seq > h.high {
		h.seen = h.seen<<(seq-h.high) | 1
		h.high = seq
	} else {
		h.seen |= uint64(1) << (h.high - seq)
	}
	return Message{Type: binary.LittleEndian.Uint16(plain[:2]), Payload: plain[4:]}, nil
}
