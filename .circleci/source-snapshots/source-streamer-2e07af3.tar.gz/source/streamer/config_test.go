// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"os"
	"runtime"
	"testing"
)

func testConfig() Config {
	executable, err := os.Executable()
	if err != nil {
		panic(err)
	}
	display := ":99"
	if runtime.GOOS == "windows" {
		display = "desktop"
	}
	return Config{SchemaVersion: 1, Owner: "test-owner", SessionID: "test-session", KeyB64: base64.StdEncoding.EncodeToString([]byte("0123456789abcdef")), KeyID: 17, PeerIP: "127.0.0.1", VideoPort: 51000, AudioPort: 51001, Display: display, CaptureConsent: true, FFmpeg: executable, Width: 128, Height: 72, FPS: 30, PixelFormat: "yuv420p", PacketSize: 1024, AudioMode: "silence", MaxSeconds: 10}
}
func TestConfigStrictDecoding(t *testing.T) {
	good, _ := json.Marshal(testConfig())
	if _, err := DecodeConfig(good); err != nil {
		t.Fatal(err)
	}
	for _, data := range [][]byte{nil, []byte("null"), []byte("[]"), append(append([]byte(nil), good...), good...), append(good[:len(good)-1], []byte(`,"schema_version":1}`)...), bytes.ReplaceAll(good, []byte(`"schema_version"`), []byte(`"unexpected"`)), bytes.Repeat([]byte(" "), MaxConfigBytes+1)} {
		if _, err := DecodeConfig(data); err == nil {
			t.Fatal("invalid input accepted")
		}
	}
}
func TestConfigRejectsUnsupportedSecurityAndFormat(t *testing.T) {
	cases := []func(*Config){func(c *Config) { c.SchemaVersion = 2 }, func(c *Config) { c.Owner = "" }, func(c *Config) { c.SessionID = "../bad" }, func(c *Config) { c.KeyB64 = "bad" }, func(c *Config) { c.KeyB64 = base64.StdEncoding.EncodeToString(make([]byte, 32)) }, func(c *Config) { c.CaptureConsent = false }, func(c *Config) { c.PeerIP = "192.168.1.2" }, func(c *Config) { c.VideoPort = c.AudioPort }, func(c *Config) { c.VideoPort = -1 }, func(c *Config) { c.AudioPort = 65536 }, func(c *Config) { c.FFmpeg = "ffmpeg" }, func(c *Config) { c.Display = "localhost:99" }, func(c *Config) { c.Display = ":99999" }, func(c *Config) { c.Display = ":99.99" }, func(c *Config) { c.MaxSeconds = 301 }, func(c *Config) { c.MaxSeconds = 0 }, func(c *Config) { c.AudioMode = "microphone" }, func(c *Config) { c.Width = 127 }, func(c *Config) { c.PacketSize = 1472 }, func(c *Config) { c.FPS = 121 }}
	for i, change := range cases {
		c := testConfig()
		change(&c)
		if err := c.Validate(); err == nil {
			t.Fatalf("invalid case %d accepted", i)
		}
	}
}

func TestNativePlatformConfigBoundaries(t *testing.T) {
	c := testConfig()
	if runtime.GOOS == "windows" {
		for _, path := range []string{`\\server\share\ffmpeg.exe`, `C:ffmpeg.exe`, `\\?\C:\ffmpeg.exe`, `C:\trusted\ffmpeg.cmd`} {
			c.FFmpeg = path
			if c.Validate() == nil {
				t.Fatal("unsafe executable", path)
			}
		}
		c = testConfig()
		c.InputConsent = true
		if c.Validate() == nil {
			t.Fatal("unimplemented Windows input accepted")
		}
		c = testConfig()
		c.Display = ":99"
		if c.Validate() == nil {
			t.Fatal("X11 fallback on Windows")
		}
	} else {
		c.Display = "desktop"
		if c.Validate() == nil {
			t.Fatal("Windows display fallback on other platform")
		}
	}
}

func TestCaptureCapabilityMatchesNativePlatform(t *testing.T) {
	capabilities := Manifest("fixture")
	present := map[string]bool{}
	for _, c := range capabilities.Capabilities {
		if present[c] {
			t.Fatal("duplicate", c)
		}
		present[c] = true
	}
	if present["video-x11-h264"] != (runtime.GOOS == "linux") || present["video-windows-gdi-h264"] != (runtime.GOOS == "windows") {
		t.Fatal("wrong capture platform", capabilities)
	}
	if runtime.GOOS == "windows" && (capabilities.Limits.Input || present["input-x11-keyboard-mouse"]) {
		t.Fatal("Windows input claimed", capabilities)
	}
}
