// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"github.com/Dr-Crow/rustshine-research/source/controltransport"
	"github.com/Dr-Crow/rustshine-research/source/session"
	"net"
	"os"
	"testing"
	"time"
)

func TestLaunchCancelReleasesBoundSockets(t *testing.T) {
	if !launchPlatformSupported() || !controltransport.Available() {
		t.Skip("native launch unavailable; unsupported-platform rejection tested separately")
	}
	cfg := testConfig()
	cfg.FFmpeg, _ = os.Executable()
	l, err := NewLaunch(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	ready := l.Ready()
	if ready.RTSPAddress == "" || ready.ControlAddress == "" {
		t.Fatal(ready)
	}
	l.Cancel()
	if err = l.Run(); err != nil {
		t.Fatal(err)
	}
	if err = l.Run(); err == nil {
		t.Fatal("launch reused")
	}
	tcp, err := net.Listen("tcp4", ready.RTSPAddress)
	if err != nil {
		t.Fatal("RTSP socket retained", err)
	}
	tcp.Close()
	addr, _ := net.ResolveUDPAddr("udp4", ready.ControlAddress)
	udp, err := net.ListenUDP("udp4", addr)
	if err != nil {
		t.Fatal("control socket retained", err)
	}
	udp.Close()
}
func TestTokenBoundRendezvousRejectsWrongTokenAndPeer(t *testing.T) {
	server := receiver(t)
	good, bad := receiver(t), receiver(t)
	token, err := newPingToken()
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	type outcome struct {
		peer *net.UDPAddr
		err  error
	}
	done := make(chan outcome, 1)
	go func() { p, e := waitForPing(ctx, server, 0, token); done <- outcome{p, e} }()
	addr := server.LocalAddr().(*net.UDPAddr)
	bad.WriteToUDP([]byte("PING"), addr)
	bad.WriteToUDP(make([]byte, 20), addr)
	select {
	case <-done:
		t.Fatal("invalid ping selected peer")
	case <-time.After(20 * time.Millisecond):
	}
	good.WriteToUDP(append([]byte(token), 0, 0, 0, 1), addr)
	out := <-done
	if out.err != nil || out.peer.Port != good.LocalAddr().(*net.UDPAddr).Port {
		t.Fatal(out)
	}
}

func TestUnavailableLaunchPlatformFailsClosed(t *testing.T) {
	if launchPlatformSupported() && controltransport.Available() {
		t.Skip("native launch is supported")
	}
	launch, err := NewLaunch(context.Background(), testConfig())
	if launch != nil || err == nil {
		t.Fatal("unsupported platform reserved a launch", launch, err)
	}
}

func encryptedClientControl(t *testing.T, key []byte, sequence uint32) []byte {
	t.Helper()
	block, err := aes.NewCipher(key)
	if err != nil {
		t.Fatal(err)
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		t.Fatal(err)
	}
	plain := []byte{0, 2, 8, 0, 4, 0, 0, 0, 0, 0, 0, 0}
	var nonce [12]byte
	binary.LittleEndian.PutUint32(nonce[:], sequence)
	nonce[10], nonce[11] = 'C', 'C'
	sealed := aead.Seal(nil, nonce[:], plain, nil)
	p := make([]byte, 24+len(plain))
	binary.LittleEndian.PutUint16(p, 1)
	binary.LittleEndian.PutUint16(p[2:], uint16(len(p)-4))
	binary.LittleEndian.PutUint32(p[4:], sequence)
	copy(p[8:24], sealed[len(plain):])
	copy(p[24:], sealed[:len(plain)])
	return p
}
func TestRejectedControlReleasesOwnedInputAndAborts(t *testing.T) {
	for _, kind := range []string{"replay", "authentication", "malformed"} {
		t.Run(kind, func(t *testing.T) {
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			f := &ownedInputFixture{}
			backend := &Backend{ctx: ctx, cancel: cancel, abort: cancel, input: f, started: true, cfg: Config{Owner: "owner", InputConsent: true}}
			key := []byte("0123456789abcdef")
			endpoint, err := session.NewControlEndpoint("owner", key, backend, func(context.Context, string) error { return nil })
			if err != nil {
				t.Fatal(err)
			}
			launch := &Launch{ctx: ctx, cancel: cancel, backend: backend, controlEndpoint: endpoint}
			p := encryptedClientControl(t, key, 0)
			if err = launch.handleControl(ctx, p); err != nil {
				t.Fatal(err)
			}
			switch kind {
			case "authentication":
				p = encryptedClientControl(t, key, 1)
				p[8] ^= 1
			case "malformed":
				p = []byte{1}
			}
			if err = launch.handleControl(ctx, p); err == nil || ctx.Err() == nil || f.closed != 1 {
				t.Fatal("rejection retained input or launch", err, f.closed)
			}
			backend.CloseControl()
			if f.closed != 1 {
				t.Fatal("repeated cleanup")
			}
		})
	}
}
