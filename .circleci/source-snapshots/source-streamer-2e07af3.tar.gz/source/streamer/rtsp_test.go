// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"encoding/binary"
	"github.com/Dr-Crow/rustshine-research/source/controltransport"
	"io"
	"net"
	"os"
	"strings"
	"testing"
	"time"
)

func clientEnvelope(key, plain []byte, sequence uint32) []byte {
	block, _ := aes.NewCipher(key)
	aead, _ := cipher.NewGCM(block)
	nonce := make([]byte, 12)
	binary.LittleEndian.PutUint32(nonce, sequence)
	nonce[10] = 'C'
	nonce[11] = 'R'
	sealed := aead.Seal(nil, nonce, plain, nil)
	packet := make([]byte, len(plain)+24)
	binary.BigEndian.PutUint32(packet, 0x80000000|uint32(len(plain)))
	binary.BigEndian.PutUint32(packet[4:], sequence)
	copy(packet[8:24], sealed[len(plain):])
	copy(packet[24:], sealed[:len(plain)])
	return packet
}
func TestTeardownFlushesEncryptedReplyBeforeLaunchCancellation(t *testing.T) {
	if !launchPlatformSupported() || !controltransport.Available() {
		t.Skip("native ENet unavailable")
	}
	for i := 0; i < 20; i++ {
		cfg := testConfig()
		cfg.FFmpeg, _ = os.Executable()
		l, err := NewLaunch(context.Background(), cfg)
		if err != nil {
			t.Fatal(err)
		}
		done := make(chan error, 1)
		go func() { done <- l.Run() }()
		conn, err := net.DialTimeout("tcp", l.Ready().RTSPAddress, time.Second)
		if err != nil {
			l.Cancel()
			t.Fatal(err)
		}
		conn.SetDeadline(time.Now().Add(time.Second))
		key, _ := base64.StdEncoding.DecodeString(cfg.KeyB64)
		conn.Write(clientEnvelope(key, []byte("TEARDOWN / RTSP/1.0\r\nCSeq: 1\r\nSession: test-session\r\n\r\n"), 1))
		reply, err := io.ReadAll(conn)
		conn.Close()
		if err != nil {
			l.Cancel()
			t.Fatal(err)
		}
		if len(reply) < 24 {
			l.Cancel()
			t.Fatal("TEARDOWN reply lost during cleanup")
		}
		block, _ := aes.NewCipher(key)
		aead, _ := cipher.NewGCM(block)
		nonce := make([]byte, 12)
		binary.LittleEndian.PutUint32(nonce, binary.BigEndian.Uint32(reply[4:8]))
		nonce[10] = 'H'
		nonce[11] = 'R'
		plain, err := aead.Open(nil, nonce, append(append([]byte(nil), reply[24:]...), reply[8:24]...), nil)
		if err != nil || !strings.HasPrefix(string(plain), "RTSP/1.0 200 ") {
			l.Cancel()
			t.Fatal(err, string(plain))
		}
		select {
		case err = <-done:
			if err != nil {
				t.Fatal(err)
			}
		case <-time.After(time.Second):
			l.Cancel()
			t.Fatal("launch failed to join")
		}
	}
}
