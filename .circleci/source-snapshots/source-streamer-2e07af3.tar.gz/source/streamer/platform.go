// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"context"
	"errors"
	"io"
	"path/filepath"
	"runtime"
	"strings"

	"github.com/Dr-Crow/rustshine-research/source/media"
)

func launchPlatformSupported() bool { return runtime.GOOS == "linux" || runtime.GOOS == "windows" }

// Platform selection never falls back to an ambient display, executable on PATH,
// remote share, other operating-system backend, or an unconsented input device.
func validatePlatformConfig(c Config) error {
	if !c.CaptureConsent {
		return errors.New("explicit capture consent required")
	}
	switch runtime.GOOS {
	case "windows":
		if err := media.ValidateWindowsGDIDisplay(c.Display); err != nil {
			return err
		}
		if c.InputConsent {
			return errors.New("native Windows input is not implemented")
		}
		volume := filepath.VolumeName(c.FFmpeg)
		if !filepath.IsAbs(c.FFmpeg) || len(volume) != 2 || volume[1] != ':' || !strings.EqualFold(filepath.Ext(c.FFmpeg), ".exe") {
			return errors.New("absolute local Windows FFmpeg .exe required")
		}
	default:
		if err := media.ValidateX11Display(c.Display); err != nil {
			return err
		}
		if !filepath.IsAbs(c.FFmpeg) {
			return errors.New("absolute trusted FFmpeg path required")
		}
	}
	return nil
}

func captureLaunchVideo(ctx context.Context, c Config, out io.Writer) error {
	switch runtime.GOOS {
	case "linux":
		return media.CaptureX11LiveIntra(ctx, c.FFmpeg, c.Display, out, c.Pattern())
	case "windows":
		return media.CaptureWindowsGDILiveIntra(ctx, c.FFmpeg, c.Display, out, c.Pattern())
	default:
		return errors.New("native capture platform unavailable")
	}
}
