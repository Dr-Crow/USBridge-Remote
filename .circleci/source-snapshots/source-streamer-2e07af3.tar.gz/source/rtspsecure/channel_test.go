// SPDX-License-Identifier: GPL-3.0-only
package rtspsecure

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"io"
	"math"
	"os"
	"sync"
	"sync/atomic"
	"testing"
)

type vector struct {
	Direction string `json:"direction"`
	Sequence  uint32 `json:"sequence"`
	Key       string `json:"key_hex"`
	Plain     string `json:"plaintext_hex"`
	Packet    string `json:"packet_hex"`
}

func vectors(t testing.TB) []vector {
	t.Helper()
	b, err := os.ReadFile("testdata/vectors.json")
	if err != nil {
		t.Fatal(err)
	}
	var v []vector
	if err = json.Unmarshal(b, &v); err != nil {
		t.Fatal(err)
	}
	return v
}
func unhex(t testing.TB, s string) []byte {
	t.Helper()
	b, err := hex.DecodeString(s)
	if err != nil {
		t.Fatal(err)
	}
	return b
}
func host(t testing.TB, key []byte) *Host {
	t.Helper()
	h, err := NewHost(key)
	if err != nil {
		t.Fatal(err)
	}
	return h
}
func TestIndependentVectors(t *testing.T) {
	for _, v := range vectors(t) {
		h := host(t, unhex(t, v.Key))
		plain, packet := unhex(t, v.Plain), unhex(t, v.Packet)
		if v.Direction == "C" {
			got, err := h.Open(packet)
			if err != nil || !bytes.Equal(got, plain) {
				t.Fatal(v.Direction, v.Sequence, err)
			}
		} else {
			h.txSeq = v.Sequence - 1
			got, err := h.Seal(plain)
			if err != nil || !bytes.Equal(got, packet) {
				t.Fatal(v.Direction, v.Sequence, err)
			}
		}
	}
}
func TestTamperingNeverConsumesValidSequence(t *testing.T) {
	v := vectors(t)[0]
	packet := unhex(t, v.Packet)
	for _, at := range []int{0, 3, 4, 7, 8, 23, 24, len(packet) - 1} {
		t.Run(string(rune('A'+at)), func(t *testing.T) {
			h := host(t, unhex(t, v.Key))
			bad := append([]byte(nil), packet...)
			bad[at] ^= 1
			if p, err := h.Open(bad); err == nil || p != nil {
				t.Fatal("tamper accepted")
			}
			if p, err := h.Open(packet); err != nil || !bytes.Equal(p, unhex(t, v.Plain)) {
				t.Fatal("failed auth consumed sequence", err)
			}
		})
	}
}
func TestRejectReplayDirectionAndWrongKey(t *testing.T) {
	v := vectors(t)
	h := host(t, unhex(t, v[0].Key))
	if _, err := h.Open(unhex(t, v[0].Packet)); err != nil {
		t.Fatal(err)
	}
	if _, err := h.Open(unhex(t, v[0].Packet)); err == nil {
		t.Fatal("replay accepted")
	}
	h = host(t, unhex(t, v[0].Key))
	if _, err := h.Open(unhex(t, v[3].Packet)); err == nil {
		t.Fatal("host direction accepted as client")
	}
	h = host(t, bytes.Repeat([]byte{99}, 16))
	if _, err := h.Open(unhex(t, v[0].Packet)); err == nil {
		t.Fatal("wrong key accepted")
	}
}
func TestBoundsAndExhaustion(t *testing.T) {
	v := vectors(t)[0]
	h := host(t, unhex(t, v.Key))
	for _, b := range [][]byte{nil, {}, make([]byte, MaxPlaintext+1)} {
		if _, err := h.Seal(b); err == nil {
			t.Fatal("bad plain accepted")
		}
	}
	h.txSeq = math.MaxUint32
	if _, err := h.Seal([]byte("x")); err == nil {
		t.Fatal("counter wrapped")
	}
	p := unhex(t, v.Packet)
	for _, b := range [][]byte{nil, p[:23], p[:len(p)-1], append(append([]byte(nil), p...), 0)} {
		if _, err := h.Open(b); err == nil {
			t.Fatal("bad framing accepted")
		}
	}
	if _, err := NewHost([]byte("bad")); err == nil {
		t.Fatal("bad key length accepted")
	}
}

type tinyReader struct{ io.Reader }

func (r tinyReader) Read(p []byte) (int, error) {
	if len(p) > 1 {
		p = p[:1]
	}
	return r.Reader.Read(p)
}
func TestFragmentedAndConsecutiveReads(t *testing.T) {
	v := vectors(t)
	h := host(t, unhex(t, v[0].Key))
	data := append(unhex(t, v[0].Packet), unhex(t, v[1].Packet)...)
	r := tinyReader{bytes.NewReader(data)}
	for i := 0; i < 2; i++ {
		p, err := h.Read(r)
		if err != nil || !bytes.Equal(p, unhex(t, v[i].Plain)) {
			t.Fatal(err)
		}
	}
	if _, err := h.Read(r); err != io.EOF {
		t.Fatal(err)
	}
	h = host(t, unhex(t, v[0].Key))
	if _, err := h.Read(bytes.NewReader(data[:25])); err != io.ErrUnexpectedEOF {
		t.Fatal(err)
	}
}
func TestConcurrentReplay(t *testing.T) {
	v := vectors(t)[0]
	h := host(t, unhex(t, v.Key))
	p := unhex(t, v.Packet)
	var accepted atomic.Int32
	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if _, err := h.Open(p); err == nil {
				accepted.Add(1)
			}
		}()
	}
	wg.Wait()
	if accepted.Load() != 1 {
		t.Fatal(accepted.Load())
	}
}
func FuzzOpen(f *testing.F) {
	v := vectors(f)[0]
	key := unhex(f, v.Key)
	f.Add(unhex(f, v.Packet))
	f.Add([]byte("RTSP/1.0 200 OK\r\n\r\n"))
	f.Fuzz(func(t *testing.T, p []byte) {
		if len(p) > MaxPlaintext+HeaderSize+1 {
			return
		}
		h := host(t, key)
		plain, err := h.Open(p)
		if err != nil {
			if plain != nil {
				t.Fatal("plaintext on failure")
			}
			return
		}
		if len(plain) == 0 || len(plain) > MaxPlaintext {
			t.Fatal("bad accepted size")
		}
		if _, err = h.Open(p); err == nil {
			t.Fatal("accepted replay")
		}
	})
}
