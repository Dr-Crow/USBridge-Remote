// SPDX-License-Identifier: GPL-3.0-only
// Analyst-authored host-side encrypted RTSP envelope, using Go's AES-GCM.
package rtspsecure

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"io"
	"math"
	"sync"
)

const HeaderSize = 24
const MaxPlaintext = (1 << 20) + (64 << 10)
const encryptedBit uint32 = 0x80000000

// Host is one launch's encrypted RTSP state. The caller MUST supply a fresh
// authenticated 16-byte launch key and retain this instance across connections
// in that launch. Never recreate Host with the same key and reset counters.
// There is no key generation, pairing, network listener or plaintext fallback.
// Each direction is serialized independently; accepted client sequences must
// increase. That replay policy is ours, not a claim about stock host behavior.
type Host struct {
	txMu, rxMu   sync.Mutex
	aead         cipher.AEAD
	txSeq, rxSeq uint32
}

func NewHost(launchKey []byte) (*Host, error) {
	if len(launchKey) != 16 {
		return nil, errors.New("RTSP requires a 16-byte launch key")
	}
	block, err := aes.NewCipher(launchKey)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return &Host{aead: gcm}, nil
}
func nonce(seq uint32, direction byte) [12]byte {
	var n [12]byte
	binary.LittleEndian.PutUint32(n[:4], seq)
	n[10] = direction
	n[11] = 'R'
	return n
}

// Seal encrypts a host response. Sequence exhaustion fails rather than reusing
// a GCM nonce. Callers retain the packet if they need to repeat an identical send.
func (h *Host) Seal(plain []byte) ([]byte, error) {
	h.txMu.Lock()
	defer h.txMu.Unlock()
	if len(plain) == 0 || len(plain) > MaxPlaintext {
		return nil, errors.New("RTSP plaintext size out of bounds")
	}
	if h.txSeq == math.MaxUint32 {
		return nil, errors.New("RTSP sequence exhausted; fresh launch key required")
	}
	h.txSeq++
	n := nonce(h.txSeq, 'H')
	sealed := h.aead.Seal(nil, n[:], plain, nil)
	packet := make([]byte, HeaderSize+len(plain))
	binary.BigEndian.PutUint32(packet[:4], encryptedBit|uint32(len(plain)))
	binary.BigEndian.PutUint32(packet[4:8], h.txSeq)
	copy(packet[8:24], sealed[len(plain):])
	copy(packet[24:], sealed[:len(plain)])
	return packet, nil
}
func payloadLength(header []byte) (int, error) {
	if len(header) < HeaderSize {
		return 0, errors.New("short encrypted RTSP header")
	}
	word := binary.BigEndian.Uint32(header[:4])
	n := word & ^encryptedBit
	if word&encryptedBit == 0 || n == 0 || n > MaxPlaintext {
		return 0, errors.New("invalid encrypted RTSP framing")
	}
	return int(n), nil
}

// Open authenticates a client packet before updating replay state or returning
// any plaintext. Wrong direction/key/tag, truncation, surplus bytes and replay
// fail closed. Packet error details never contain payload or key material.
func (h *Host) Open(packet []byte) ([]byte, error) {
	h.rxMu.Lock()
	defer h.rxMu.Unlock()
	size, err := payloadLength(packet)
	if err != nil {
		return nil, err
	}
	if len(packet) != HeaderSize+size {
		return nil, errors.New("encrypted RTSP length mismatch")
	}
	seq := binary.BigEndian.Uint32(packet[4:8])
	if seq == 0 || seq <= h.rxSeq {
		return nil, errors.New("encrypted RTSP sequence replay or wrap")
	}
	n := nonce(seq, 'C')
	sealed := make([]byte, size+16)
	copy(sealed, packet[24:])
	copy(sealed[size:], packet[8:24])
	plain, err := h.aead.Open(nil, n[:], sealed, nil)
	if err != nil {
		return nil, errors.New("encrypted RTSP authentication failed")
	}
	h.rxSeq = seq
	return plain, nil
}

// Read authenticates one length-delimited packet. Reader deadlines/cancellation
// belong to the authenticated transport adapter. Size is checked before allocating.
func (h *Host) Read(r io.Reader) ([]byte, error) {
	packet, err := ReadPacket(r)
	if err != nil {
		return nil, err
	}
	return h.Open(packet)
}

// ReadPacket reads bounded ciphertext framing only. The returned bytes are NOT
// authenticated and must pass Host.Open or EncryptedEndpoint.Exchange before use.
func ReadPacket(r io.Reader) ([]byte, error) {
	if r == nil {
		return nil, errors.New("reader required")
	}
	header := make([]byte, HeaderSize)
	if _, err := io.ReadFull(r, header); err != nil {
		return nil, err
	}
	n, err := payloadLength(header)
	if err != nil {
		return nil, err
	}
	packet := make([]byte, HeaderSize+n)
	copy(packet, header)
	if _, err = io.ReadFull(r, packet[HeaderSize:]); err != nil {
		return nil, err
	}
	return packet, nil
}
