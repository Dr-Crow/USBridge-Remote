/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef CONTROLTRANSPORT_BRIDGE_H
#define CONTROLTRANSPORT_BRIDGE_H
#include <stdint.h>
#include "enet/enet.h"
typedef struct ControlENetHost ControlENetHost;
typedef struct ControlENetEvent {
    int kind;
    ENetPacket *packet;
} ControlENetEvent;
ControlENetHost *control_enet_create(const char *, uint16_t, const char *, uint16_t *);
int control_enet_service(ControlENetHost *, uint32_t, ControlENetEvent *);
void control_enet_disconnect(ControlENetHost *);
void control_enet_destroy(ControlENetHost *);
#endif
