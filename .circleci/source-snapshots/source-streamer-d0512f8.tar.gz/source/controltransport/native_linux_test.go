//go:build linux && cgo

// SPDX-License-Identifier: GPL-3.0-only
package controltransport

import (
	"bytes"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/binary"
	"errors"
	"fmt"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/controlsecure"
	"github.com/Dr-Crow/rustshine-research/source/session"
)

var clientBinary string

func TestMain(m *testing.M) {
	dir, err := os.MkdirTemp("", "controltransport-enet-client-")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	clientBinary = filepath.Join(dir, "enet-client")
	out, err := exec.Command("bash", "testdata/build_client.sh", clientBinary).CombinedOutput()
	if err != nil {
		fmt.Fprintf(os.Stderr, "build unchanged ENet test client: %v\n%s", err, out)
		os.RemoveAll(dir)
		os.Exit(1)
	}
	code := m.Run()
	os.RemoveAll(dir)
	os.Exit(code)
}

type networkRecord struct {
	channel     byte
	payload     []byte
	unsequenced bool
}

func recordsFile(t *testing.T, records ...networkRecord) string {
	t.Helper()
	var data bytes.Buffer
	for _, r := range records {
		data.WriteByte(r.channel)
		flag := byte(1)
		if r.unsequenced {
			flag = 2
		}
		data.WriteByte(flag)
		binary.Write(&data, binary.BigEndian, uint32(len(r.payload)))
		data.Write(r.payload)
	}
	path := filepath.Join(t.TempDir(), "encrypted-control.records")
	if err := os.WriteFile(path, data.Bytes(), 0600); err != nil {
		t.Fatal(err)
	}
	return path
}
func clientCommand(t *testing.T, ctx context.Context, h *Host, source string, hold int, records ...networkRecord) *exec.Cmd {
	t.Helper()
	a := h.Addr().(*net.UDPAddr)
	return exec.CommandContext(ctx, clientBinary, source, a.IP.String(), fmt.Sprint(a.Port), recordsFile(t, records...), fmt.Sprint(hold))
}
func mustClient(t *testing.T, h *Host, records ...networkRecord) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	out, err := clientCommand(t, ctx, h, h.Addr().(*net.UDPAddr).IP.String(), 0, records...).CombinedOutput()
	if err != nil || !strings.Contains(string(out), "CONNECTED\n") || !strings.Contains(string(out), "ACKED\n") {
		t.Fatalf("ENet client: %v: %s", err, out)
	}
}
func openNative(t *testing.T, bind, allowed string, handler func(context.Context, []byte) error) (*Host, <-chan error) {
	t.Helper()
	h, err := Listen(bind, net.ParseIP(allowed))
	if err != nil {
		t.Fatal(err)
	}
	if h.Port() == 0 || h.Addr() == nil {
		t.Fatal("port not bound before Serve")
	}
	done := make(chan error, 1)
	go func() { done <- h.Serve(context.Background(), handler) }()
	t.Cleanup(func() {
		h.Close()
		select {
		case <-done:
		case <-time.After(time.Second):
			t.Error("native service did not close")
		}
	})
	return h, done
}
func clientEnvelope(seq uint32, typ uint16, payload []byte) []byte {
	block, _ := aes.NewCipher(make([]byte, 16))
	gcm, _ := cipher.NewGCM(block)
	iv := make([]byte, 12)
	binary.LittleEndian.PutUint32(iv, seq)
	iv[10], iv[11] = 'C', 'C'
	plain := make([]byte, 4+len(payload))
	binary.LittleEndian.PutUint16(plain, typ)
	binary.LittleEndian.PutUint16(plain[2:], uint16(len(payload)))
	copy(plain[4:], payload)
	sealed := gcm.Seal(nil, iv, plain, nil)
	out := framed(28 + len(payload))
	binary.LittleEndian.PutUint32(out[4:], seq)
	copy(out[8:24], sealed[len(plain):])
	copy(out[24:], sealed[:len(plain)])
	return out
}

type testBackend struct{ start, idr, ping, closed atomic.Int32 }

func (b *testBackend) StartControl(context.Context) error { b.start.Add(1); return nil }
func (b *testBackend) Keepalive(context.Context) error    { b.ping.Add(1); return nil }
func (b *testBackend) RequestIDR(context.Context) error   { b.idr.Add(1); return nil }
func (b *testBackend) CloseControl() error                { b.closed.Add(1); return nil }

func TestNativeENetControlEndpoint(t *testing.T) {
	if !Available() {
		t.Fatal("Linux cgo did not advertise ENet")
	}
	backend := &testBackend{}
	var authorized atomic.Int32
	endpoint, err := session.NewControlEndpoint("owner", make([]byte, 16), backend, func(context.Context, string) error { authorized.Add(1); return nil })
	if err != nil {
		t.Fatal(err)
	}
	defer endpoint.Close()
	h, _ := openNative(t, "127.0.0.1:0", "127.0.0.1", func(ctx context.Context, p []byte) error { return endpoint.Handle(ctx, "owner", p) })
	mustClient(t, h,
		networkRecord{payload: clientEnvelope(0, 0x0302, []byte{0, 0})},
		networkRecord{payload: clientEnvelope(1, 0x0307, []byte{0})},
		networkRecord{channel: 1, payload: clientEnvelope(2, 0x0200, []byte{4, 0, 0, 0, 0, 0, 0, 0})},
	)
	if backend.idr.Load() != 1 || backend.start.Load() != 1 || backend.ping.Load() != 1 || authorized.Load() != 3 {
		t.Fatalf("dispatch counts: idr=%d start=%d ping=%d auth=%d", backend.idr.Load(), backend.start.Load(), backend.ping.Load(), authorized.Load())
	}
}

func TestNativeENetFragmentationAndAllChannels(t *testing.T) {
	secure, _ := controlsecure.NewHost(make([]byte, 16))
	var count atomic.Int32
	var got []byte
	h, _ := openNative(t, "127.0.0.1:0", "127.0.0.1", func(_ context.Context, p []byte) error {
		message, err := secure.Open(p)
		if err != nil {
			return errors.Join(ErrStop, err)
		}
		if len(message.Payload) > 100 {
			got = append([]byte(nil), message.Payload...)
		}
		count.Add(1)
		return nil
	})
	payload := bytes.Repeat([]byte{0x15, 0xee, 0x91}, controlsecure.MaxPayload/3)
	payload = append(payload, make([]byte, controlsecure.MaxPayload-len(payload))...)
	mustClient(t, h, networkRecord{channel: 47, payload: clientEnvelope(0, 0x5502, payload)}, networkRecord{channel: 0, payload: clientEnvelope(1, 0x5502, []byte{7}), unsequenced: true})
	if count.Load() != 2 || !bytes.Equal(got, payload) {
		t.Fatal("fragmented/control-channel payload mismatch")
	}
}

func TestNativeRejectsWrongIPBeforeConnection(t *testing.T) {
	var called atomic.Int32
	h, _ := openNative(t, "127.0.0.1:0", "127.0.0.1", func(context.Context, []byte) error { called.Add(1); return nil })
	ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	out, err := clientCommand(t, ctx, h, "127.0.0.2", 0, networkRecord{payload: clientEnvelope(0, 0x307, []byte{0})}).CombinedOutput()
	cancel()
	if err == nil || strings.Contains(string(out), "CONNECTED") || called.Load() != 0 {
		t.Fatalf("wrong peer admitted: %v %s", err, out)
	}
	mustClient(t, h, networkRecord{payload: clientEnvelope(0, 0x307, []byte{0})})
	if called.Load() != 1 {
		t.Fatal("rejected peer occupied allowed peer slot")
	}
}

func TestNativeTamperPlaintextReplayAndReconnect(t *testing.T) {
	secure, _ := controlsecure.NewHost(make([]byte, 16))
	var good atomic.Int32
	h, _ := openNative(t, "127.0.0.1:0", "127.0.0.1", func(_ context.Context, p []byte) error {
		_, err := secure.Open(p)
		if err == nil {
			good.Add(1)
		}
		return err
	})
	bad := clientEnvelope(0, 0x307, []byte{0})
	bad[8] ^= 1
	for _, packet := range [][]byte{bad, {7, 3, 0}} {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		_, _ = clientCommand(t, ctx, h, "127.0.0.1", 0, networkRecord{payload: packet}).CombinedOutput()
		cancel()
		if good.Load() != 0 {
			t.Fatal("invalid packet reached successful handler")
		}
	}
	mustClient(t, h, networkRecord{payload: clientEnvelope(0, 0x307, []byte{0})})
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	_, _ = clientCommand(t, ctx, h, "127.0.0.1", 0, networkRecord{payload: clientEnvelope(0, 0x307, []byte{0})}).CombinedOutput()
	cancel()
	if good.Load() != 1 {
		t.Fatal("replay accepted after reconnect")
	}
	mustClient(t, h, networkRecord{payload: clientEnvelope(1, 0x307, []byte{0})})
	if good.Load() != 2 {
		t.Fatal("same launch did not accept next authenticated sequence")
	}
}

func TestNativeSinglePeer(t *testing.T) {
	accepted := make(chan struct{}, 4)
	h, _ := openNative(t, "127.0.0.1:0", "127.0.0.1", func(context.Context, []byte) error { accepted <- struct{}{}; return nil })
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	first := clientCommand(t, ctx, h, "127.0.0.1", 500, networkRecord{payload: clientEnvelope(0, 0x307, []byte{0})})
	var output bytes.Buffer
	first.Stdout = &output
	first.Stderr = &output
	if err := first.Start(); err != nil {
		t.Fatal(err)
	}
	select {
	case <-accepted:
	case <-time.After(time.Second):
		t.Fatal("first peer did not connect")
	}
	secondCtx, secondCancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	out, err := clientCommand(t, secondCtx, h, "127.0.0.1", 0, networkRecord{payload: clientEnvelope(1, 0x307, []byte{0})}).CombinedOutput()
	secondCancel()
	if err == nil || strings.Contains(string(out), "CONNECTED") {
		t.Fatalf("second concurrent peer admitted: %v %s", err, out)
	}
	if err := first.Wait(); err != nil {
		t.Fatalf("first peer: %v %s", err, output.String())
	}
	mustClient(t, h, networkRecord{payload: clientEnvelope(2, 0x307, []byte{0})})
}

func TestNativeIPv6AndCancellation(t *testing.T) {
	probe, err := net.ListenUDP("udp6", &net.UDPAddr{IP: net.IPv6loopback})
	if err != nil {
		t.Skipf("IPv6 unavailable: %v", err)
	}
	probe.Close()
	h, _ := openNative(t, "[::1]:0", "::1", func(context.Context, []byte) error { return nil })
	mustClient(t, h, networkRecord{payload: clientEnvelope(0, 0x307, []byte{0})})
}

func TestNativeCloseUnblocksAndReleasesPort(t *testing.T) {
	for range 10 {
		h, err := Listen("127.0.0.1:0", net.IPv4(127, 0, 0, 1))
		if err != nil {
			t.Fatal(err)
		}
		addr := h.Addr().(*net.UDPAddr)
		ctx, cancel := context.WithCancel(context.Background())
		done := make(chan error, 1)
		go func() { done <- h.Serve(ctx, func(context.Context, []byte) error { return nil }) }()
		var wg sync.WaitGroup
		for range 4 {
			wg.Go(func() { h.Close() })
		}
		wg.Wait()
		cancel()
		select {
		case err := <-done:
			if !errors.Is(err, ErrClosed) && !errors.Is(err, context.Canceled) {
				t.Fatal(err)
			}
		case <-time.After(500 * time.Millisecond):
			t.Fatal("close blocked")
		}
		socket, err := net.ListenUDP("udp4", addr)
		if err != nil {
			t.Fatalf("port leaked: %v", err)
		}
		socket.Close()
	}
}

func TestNativeRejectedTrafficDoesNotBlockCancellation(t *testing.T) {
	h, err := Listen("127.0.0.1:0", net.IPv4(127, 0, 0, 1))
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan error, 1)
	go func() {
		done <- h.Serve(ctx, func(context.Context, []byte) error { t.Error("malformed datagram dispatched"); return nil })
	}()
	socket, err := net.DialUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 2)}, h.Addr().(*net.UDPAddr))
	if err != nil {
		h.Close()
		t.Fatal(err)
	}
	stop := make(chan struct{})
	flooded := make(chan struct{})
	go func() {
		defer close(flooded)
		for {
			select {
			case <-stop:
				return
			default:
				socket.Write(make([]byte, 64))
			}
		}
	}()
	time.Sleep(30 * time.Millisecond)
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Error(err)
		}
	case <-time.After(time.Second):
		t.Error("rejected traffic blocked service cancellation")
	}
	close(stop)
	socket.Close()
	<-flooded
	h.Close()
}
