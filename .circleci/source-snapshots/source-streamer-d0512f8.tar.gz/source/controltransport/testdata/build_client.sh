#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-only
# Build the independently launched test driver with unchanged public ENet.
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "usage: $0 OUTPUT_BINARY" >&2
  exit 64
fi
here="$(cd -- "$(dirname -- "$0")" && pwd)"
enet="$here/../third_party/enet"
"${CC:-cc}" -std=c99 -O1 -Wall -Wextra \
  -DHAS_FCNTL=1 -DHAS_IOCTL=1 -DHAS_POLL=1 \
  -DHAS_GETADDRINFO=1 -DHAS_GETNAMEINFO=1 \
  -DHAS_INET_PTON=1 -DHAS_INET_NTOP=1 \
  -DHAS_MSGHDR_FLAGS=1 -DHAS_SOCKLEN_T=1 \
  -I"$enet/include" "$here/enet_client.c" \
  "$enet/callbacks.c" "$enet/compress.c" "$enet/host.c" \
  "$enet/list.c" "$enet/packet.c" "$enet/peer.c" \
  "$enet/protocol.c" "$enet/unix.c" -o "$1"
