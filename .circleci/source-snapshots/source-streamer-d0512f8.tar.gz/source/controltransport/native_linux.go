//go:build linux && cgo

// SPDX-License-Identifier: GPL-3.0-only
package controltransport

/*
#cgo CFLAGS: -std=c99 -I${SRCDIR}/third_party/enet/include -DHAS_FCNTL=1 -DHAS_IOCTL=1 -DHAS_POLL=1 -DHAS_GETADDRINFO=1 -DHAS_GETNAMEINFO=1 -DHAS_INET_PTON=1 -DHAS_INET_NTOP=1 -DHAS_MSGHDR_FLAGS=1 -DHAS_SOCKLEN_T=1
#include <stdlib.h>
#include "bridge.h"
*/
import "C"

import (
	"errors"
	"fmt"
	"net"
	"time"
	"unsafe"
)

type enetNative struct{ host *C.ControlENetHost }

func listenNative(bind *net.UDPAddr, allowed net.IP) (nativeTransport, *net.UDPAddr, error) {
	b := C.CString(bind.IP.String())
	defer C.free(unsafe.Pointer(b))
	a := C.CString(allowed.String())
	defer C.free(unsafe.Pointer(a))
	var port C.uint16_t
	n, errno := C.control_enet_create(b, C.uint16_t(bind.Port), a, &port)
	if n == nil {
		if errno != nil {
			return nil, nil, fmt.Errorf("bind ENet control socket: %w", errno)
		}
		return nil, nil, errors.New("could not allocate ENet control host")
	}
	return &enetNative{host: n}, &net.UDPAddr{IP: append(net.IP(nil), bind.IP...), Port: int(port)}, nil
}

func (n *enetNative) service(wait time.Duration) (nativeEvent, error) {
	var event C.ControlENetEvent
	// Round up to a millisecond to avoid spinning near a deadline.
	ms := (wait + time.Millisecond - 1) / time.Millisecond
	if C.control_enet_service(n.host, C.uint32_t(ms), &event) < 0 {
		return nativeEvent{}, errors.New("ENet control service failed")
	}
	out := nativeEvent{kind: int(event.kind)}
	if event.packet != nil {
		defer C.enet_packet_destroy(event.packet)
		if event.packet.dataLength > C.size_t(maxPacketSize) {
			return nativeEvent{}, errors.New("ENet control packet exceeded bound")
		}
		out.packet = C.GoBytes(unsafe.Pointer(event.packet.data), C.int(event.packet.dataLength))
	}
	return out, nil
}
func (n *enetNative) disconnect() { C.control_enet_disconnect(n.host) }
func (n *enetNative) close()      { C.control_enet_destroy(n.host); n.host = nil }

// Available reports whether this build includes the native ENet adapter.
func Available() bool { return true }
