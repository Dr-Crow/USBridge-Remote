//go:build !linux || !cgo

// SPDX-License-Identifier: GPL-3.0-only
package controltransport

import "net"

func listenNative(*net.UDPAddr, net.IP) (nativeTransport, *net.UDPAddr, error) {
	return nil, nil, ErrUnavailable
}

// Available reports whether this build includes the native ENet adapter.
func Available() bool { return false }
