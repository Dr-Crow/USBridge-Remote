// SPDX-License-Identifier: GPL-3.0-only
package session

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"sync"

	"github.com/Dr-Crow/rustshine-research/source/controlsecure"
)

// ControlBackend is the deliberately small implemented control profile. It
// must honor context and never re-enter its endpoint. A real encoder must
// implement RequestIDR before advertising this capability. Other message
// families (input, rumble, HDR and reference-frame feedback) remain unsupported.
type ControlBackend interface {
	StartControl(context.Context) error
	Keepalive(context.Context) error
	RequestIDR(context.Context) error
	CloseControl() error
}

// ControlEndpoint binds control-v2 encryption to one authenticated launch and
// its authorizer. It consumes complete ENet payloads; ENet, pairing and peer
// selection are external. Use the same unique launch key lifetime contract as
// EncryptedEndpoint, with one retained instance for each protocol channel.
type ControlEndpoint struct {
	mu        sync.Mutex
	owner     string
	channel   *controlsecure.Host
	backend   ControlBackend
	authorize Authorize
	closed    bool
}

func NewControlEndpoint(owner string, key []byte, backend ControlBackend, auth Authorize) (*ControlEndpoint, error) {
	if owner == "" || backend == nil || auth == nil {
		return nil, errors.New("owner, control backend and authorizer required")
	}
	c, err := controlsecure.NewHost(key)
	if err != nil {
		return nil, err
	}
	return &ControlEndpoint{owner: owner, channel: c, backend: backend, authorize: auth}, nil
}

// Handle authorizes even malformed packets, then authenticates/decrypts them
// before dispatch. Authentication/replay failures invoke no backend action.
// Revocation and backend failure close this endpoint; unsupported messages
// return an explicit error. The connection owner decides whether to terminate
// the overall launch. No application acknowledgement is fabricated: these
// messages are acknowledged at the ENet transport layer by the transport owner.
func (e *ControlEndpoint) Handle(ctx context.Context, principal string, packet []byte) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if ctx == nil {
		return errors.New("context required")
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	if e.closed {
		return errors.New("control endpoint closed")
	}
	if principal != e.owner {
		return errors.New("control principal mismatch")
	}
	if err := e.authorize(ctx, principal); err != nil {
		return errors.Join(err, e.close())
	}
	m, err := e.channel.Open(packet)
	if err != nil {
		return err
	}
	switch m.Type {
	case 0x0302:
		if len(m.Payload) != 2 || m.Payload[0] != 0 || m.Payload[1] != 0 {
			return errors.New("invalid IDR request")
		}
		err = e.backend.RequestIDR(ctx)
	case 0x0307:
		if len(m.Payload) != 1 || m.Payload[0] != 0 {
			return errors.New("invalid control start")
		}
		err = e.backend.StartControl(ctx)
	case 0x0200:
		// The public client sends eight bytes but initializes only the first
		// six. The last two bytes have no validated semantic meaning here.
		if len(m.Payload) != 8 || binary.LittleEndian.Uint16(m.Payload[:2]) != 4 {
			return errors.New("invalid control keepalive")
		}
		err = e.backend.Keepalive(ctx)
	case 0x0206:
		// The public client always announces haptics support at startup, even
		// when no input has occurred. Accept precisely this capability notice;
		// it does not enable an input device or claim a rumble output backend.
		if !bytes.Equal(m.Payload, []byte{0, 0, 0, 6, 0x0d, 0, 0, 0, 1, 0}) {
			return errors.New("unsupported input message")
		}
	case 0x5502:
		// Automatic frame/FEC receive telemetry, with no encoder action. It
		// carries no authorization or input. Validate the fixed wire bounds.
		if len(m.Payload) != 21 || m.Payload[18] > 100 || m.Payload[20] < 1 || m.Payload[20] > 4 || m.Payload[19] >= m.Payload[20] {
			return errors.New("invalid frame reception telemetry")
		}
	default:
		return errors.New("unsupported control message")
	}
	if err != nil {
		return errors.Join(err, e.close())
	}
	return nil
}
func (e *ControlEndpoint) close() error {
	if e.closed {
		return nil
	}
	e.closed = true
	return e.backend.CloseControl()
}
func (e *ControlEndpoint) Close() error { e.mu.Lock(); defer e.mu.Unlock(); return e.close() }
