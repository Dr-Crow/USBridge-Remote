// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"context"
	"encoding/base64"
	"errors"
	"net"
	"os"
	"runtime"
	"sync"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/controltransport"
	"github.com/Dr-Crow/rustshine-research/source/session"
)

type Capabilities struct {
	SchemaVersion int      `json:"schema_version"`
	Component     string   `json:"component"`
	Profile       string   `json:"profile"`
	Version       string   `json:"version"`
	Platform      string   `json:"platform"`
	Capabilities  []string `json:"capabilities"`
	Limits        Limits   `json:"limits"`
}
type Limits struct {
	LoopbackOnly bool `json:"loopback_only"`
	MaxSeconds   int  `json:"max_seconds"`
	Input        bool `json:"input"`
	NativeAudio  bool `json:"native_audio"`
}

func Manifest(version string) Capabilities {
	caps := []string{"rtsp-encrypted", "audio-silence"}
	if runtime.GOOS == "linux" {
		caps = append(caps, "video-x11-h264")
	}
	if controltransport.Available() {
		caps = append(caps, "control-enet")
	}
	return Capabilities{1, "source-streamer", Profile, version, runtime.GOOS + "-" + runtime.GOARCH, caps, Limits{true, 300, false, false}}
}

type Ready struct {
	SchemaVersion  int      `json:"schema_version"`
	Event          string   `json:"event"`
	SessionID      string   `json:"session_id"`
	RTSPAddress    string   `json:"rtsp_address"`
	ControlAddress string   `json:"control_address"`
	Capabilities   []string `json:"capabilities"`
}
type Launch struct {
	ctx             context.Context
	cancel          context.CancelFunc
	listener        net.Listener
	control         *controltransport.Host
	endpoint        *session.EncryptedEndpoint
	controlEndpoint *session.ControlEndpoint
	backend         *Backend
	ready           Ready
	runMu           sync.Mutex
	used            bool
}

// NewLaunch validates and reserves sockets only. No capture occurs before an
// authenticated encrypted RTSP PLAY and each authorized UDP receiver's ping.
// The supervisor is responsible for pairing, consent, key issuance and any
// forwarding. Direct unauthenticated Internet exposure is not supported.
func NewLaunch(ctx context.Context, cfg Config) (*Launch, error) {
	if ctx == nil {
		return nil, errors.New("launch context required")
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	if runtime.GOOS != "linux" || !controltransport.Available() {
		return nil, errors.New("source-streamer launch requires Linux with ENet cgo support")
	}
	info, err := os.Stat(cfg.FFmpeg)
	if err != nil || !info.Mode().IsRegular() || info.Mode().Perm()&0111 == 0 {
		return nil, errors.New("trusted FFmpeg path must be an executable regular file")
	}
	runCtx, cancel := context.WithTimeout(ctx, time.Duration(cfg.MaxSeconds)*time.Second)
	l := &Launch{ctx: runCtx, cancel: cancel}
	success := false
	defer func() {
		if !success {
			cancel()
			if l.listener != nil {
				l.listener.Close()
			}
			if l.control != nil {
				l.control.Close()
			}
			if l.backend != nil {
				l.backend.Close()
			}
		}
	}()
	l.listener, err = net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	l.control, err = controltransport.Listen("127.0.0.1:0", net.IPv4(127, 0, 0, 1))
	if err != nil {
		return nil, err
	}
	l.backend, err = newBackend(runCtx, cancel, cfg, l.control.Port())
	if err != nil {
		return nil, err
	}
	auth := func(ctx context.Context, owner string) error {
		if err := ctx.Err(); err != nil {
			return err
		}
		if err := runCtx.Err(); err != nil {
			return err
		}
		if owner != cfg.Owner {
			return errors.New("launch owner mismatch")
		}
		return nil
	}
	key, _ := base64.StdEncoding.Strict().DecodeString(cfg.KeyB64)
	l.endpoint, err = session.NewEncryptedEndpoint(cfg.Owner, cfg.SessionID, key, l.backend, auth)
	if err != nil {
		return nil, err
	}
	l.controlEndpoint, err = session.NewControlEndpoint(cfg.Owner, key, l.backend, auth)
	if err != nil {
		return nil, err
	}
	l.ready = Ready{1, "ready", cfg.SessionID, l.listener.Addr().String(), l.control.Addr().String(), Manifest("").Capabilities}
	success = true
	return l, nil
}
func (l *Launch) Ready() Ready {
	r := l.ready
	r.Capabilities = append([]string(nil), r.Capabilities...)
	return r
}
func (l *Launch) Cancel()      { l.cancel() }
func (l *Launch) Stats() Stats { return l.backend.Snapshot() }

// Run owns all launch resources and waits for codec, control and RTSP cleanup.
// A launch is single-use; reconnecting RTSP never resets cryptographic counters.
func (l *Launch) Run() error {
	l.runMu.Lock()
	if l.used {
		l.runMu.Unlock()
		return errors.New("launch already used")
	}
	l.used = true
	l.runMu.Unlock()
	defer l.cancel()
	controlDone := make(chan error, 1)
	go func() {
		err := l.control.Serve(l.ctx, func(ctx context.Context, p []byte) error {
			err := l.controlEndpoint.Handle(ctx, l.backend.cfg.Owner, p)
			if l.ctx.Err() != nil {
				return errors.Join(controltransport.ErrStop, err)
			}
			return err
		})
		l.cancel()
		controlDone <- err
	}()
	_, rtspErr := session.ServeLaunch(l.ctx, l.listener, l.endpoint, 8)
	l.cancel()
	_ = l.control.Close()
	controlErr := <-controlDone
	_ = l.controlEndpoint.Close()
	backendErr := l.backend.Close()
	if backendErr != nil {
		return backendErr
	}
	// Parent cancellation, TEARDOWN and duration are clean shutdowns, but
	// cancellation must not hide a simultaneous transport failure.
	return errors.Join(withoutCancellation(rtspErr), withoutCancellation(controlErr))
}

func withoutCancellation(err error) error {
	if err == nil || err == context.Canceled || err == context.DeadlineExceeded || err == controltransport.ErrClosed || err == controltransport.ErrStop {
		return nil
	}
	if joined, ok := err.(interface{ Unwrap() []error }); ok {
		var result error
		for _, child := range joined.Unwrap() {
			result = errors.Join(result, withoutCancellation(child))
		}
		return result
	}
	return err
}
