// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"context"
	"github.com/Dr-Crow/rustshine-research/source/controltransport"
	"net"
	"os"
	"testing"
	"time"
)

func TestLaunchCancelReleasesBoundSockets(t *testing.T) {
	if !controltransport.Available() {
		t.Skip("native transport unavailable")
	}
	cfg := testConfig()
	cfg.FFmpeg, _ = os.Executable()
	l, err := NewLaunch(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	ready := l.Ready()
	if ready.RTSPAddress == "" || ready.ControlAddress == "" {
		t.Fatal(ready)
	}
	l.Cancel()
	if err = l.Run(); err != nil {
		t.Fatal(err)
	}
	if err = l.Run(); err == nil {
		t.Fatal("launch reused")
	}
	tcp, err := net.Listen("tcp4", ready.RTSPAddress)
	if err != nil {
		t.Fatal("RTSP socket retained", err)
	}
	tcp.Close()
	addr, _ := net.ResolveUDPAddr("udp4", ready.ControlAddress)
	udp, err := net.ListenUDP("udp4", addr)
	if err != nil {
		t.Fatal("control socket retained", err)
	}
	udp.Close()
}
func TestTokenBoundRendezvousRejectsWrongTokenAndPeer(t *testing.T) {
	server := receiver(t)
	good, bad := receiver(t), receiver(t)
	token, err := newPingToken()
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	type outcome struct {
		peer *net.UDPAddr
		err  error
	}
	done := make(chan outcome, 1)
	go func() { p, e := waitForPing(ctx, server, 0, token); done <- outcome{p, e} }()
	addr := server.LocalAddr().(*net.UDPAddr)
	bad.WriteToUDP([]byte("PING"), addr)
	bad.WriteToUDP(make([]byte, 20), addr)
	select {
	case <-done:
		t.Fatal("invalid ping selected peer")
	case <-time.After(20 * time.Millisecond):
	}
	good.WriteToUDP(append([]byte(token), 0, 0, 0, 1), addr)
	out := <-done
	if out.err != nil || out.peer.Port != good.LocalAddr().(*net.UDPAddr).Port {
		t.Fatal(out)
	}
}
