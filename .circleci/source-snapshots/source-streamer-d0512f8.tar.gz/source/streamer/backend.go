// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/subtle"
	"encoding/base64"
	"errors"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/audio"
	"github.com/Dr-Crow/rustshine-research/source/gamestreamvideo"
	"github.com/Dr-Crow/rustshine-research/source/media"
	"github.com/Dr-Crow/rustshine-research/source/sdp"
	"github.com/Dr-Crow/rustshine-research/source/session"
)

type Stats struct {
	VideoFrames        int `json:"video_frames"`
	VideoPackets       int `json:"video_packets"`
	AudioPackets       int `json:"audio_packets"`
	AudioParityPackets int `json:"audio_parity_packets"`
}

// Backend retains the launch lifetime independently of the five-second RTSP
// transaction lifetime. It owns UDP sockets, codec goroutines and key state.
// Closed/failing media always cancels the whole launch and joins the other track.
type Backend struct {
	mu                          sync.Mutex
	cfg                         Config
	ctx                         context.Context
	cancel                      context.CancelFunc
	abort                       context.CancelFunc
	video, audio                *net.UDPConn
	videoToken, audioToken      string
	controlPort                 uint16
	configured, started, closed bool
	wg                          sync.WaitGroup
	videoEncoder                media.LiveEncoder
	audioEncoder                audio.LiveEncoder
	stats                       Stats
	result                      error
}

func newBackend(ctx context.Context, abort context.CancelFunc, cfg Config, controlPort uint16) (*Backend, error) {
	mediaCtx, cancel := context.WithCancel(ctx)
	success := false
	defer func() {
		if !success {
			cancel()
		}
	}()
	b := &Backend{cfg: cfg, ctx: mediaCtx, cancel: cancel, abort: abort, controlPort: controlPort}
	var err error
	b.video, err = net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		return nil, err
	}
	b.audio, err = net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		b.video.Close()
		return nil, err
	}
	if cfg.VideoPort == 0 {
		b.videoToken, err = newPingToken()
		if err != nil {
			b.video.Close()
			b.audio.Close()
			return nil, err
		}
	}
	if cfg.AudioPort == 0 {
		b.audioToken, err = newPingToken()
		if err != nil {
			b.video.Close()
			b.audio.Close()
			return nil, err
		}
	}
	b.videoEncoder = func(ctx context.Context, w io.Writer) error {
		return media.CaptureX11LiveIntra(ctx, cfg.FFmpeg, cfg.Display, w, cfg.Pattern())
	}
	b.audioEncoder = func(ctx context.Context, w io.Writer) error {
		return audio.EncodePCMStream(ctx, cfg.FFmpeg, &silencePCM{}, w)
	}
	success = true
	return b, nil
}

func (b *Backend) Describe(ctx context.Context) ([]byte, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return []byte("v=0\r\na=x-ss-general.featureFlags:0\r\na=x-ss-general.encryptionSupported:7\r\na=x-ss-general.encryptionRequested:7\r\nm=video 0 RTP/AVP 96\r\na=rtpmap:96 H264/90000\r\nm=audio 0 RTP/AVP 97\r\na=rtpmap:97 opus/48000/2\r\n"), nil
}
func (b *Backend) Setup(ctx context.Context, s session.Stream) (uint16, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed {
		return 0, errors.New("backend closed")
	}
	switch s {
	case session.Video:
		return uint16(b.video.LocalAddr().(*net.UDPAddr).Port), nil
	case session.Audio:
		return uint16(b.audio.LocalAddr().(*net.UDPAddr).Port), nil
	case session.Control:
		return b.controlPort, nil
	}
	return 0, errors.New("unsupported stream")
}

// SetupHeaders exposes tokens only to the encrypted RTSP response builder.
func (b *Backend) SetupHeaders(stream session.Stream) map[string]string {
	token := ""
	switch stream {
	case session.Video:
		token = b.videoToken
	case session.Audio:
		token = b.audioToken
	}
	if token == "" {
		return nil
	}
	return map[string]string{"x-ss-ping-payload": token}
}
func newPingToken() (string, error) {
	var token [12]byte
	if _, err := rand.Read(token[:]); err != nil {
		return "", err
	}
	return base64.RawStdEncoding.EncodeToString(token[:]), nil
}

func (b *Backend) Configure(ctx context.Context, c sdp.VideoRequest) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed || b.started {
		return errors.New("backend cannot be configured")
	}
	chroma := uint32(0)
	if b.cfg.PixelFormat == "yuv444p" {
		chroma = 1
	}
	if c.Width != uint32(b.cfg.Width) || c.Height != uint32(b.cfg.Height) || c.FPS != uint32(b.cfg.FPS) || c.PacketSize != uint32(b.cfg.PacketSize) || c.ChromaSampling != chroma || !c.HasEncryptionFlags || c.EncryptionFlags != 7 {
		return errors.New("ANNOUNCE must match authorized format and require all encryption")
	}
	if (c.HasAudioChannels && c.AudioChannels != 2) || (c.HasAudioChannelMask && c.AudioChannelMask != 3) || (c.HasAudioPacketDuration && c.AudioPacketDuration != 5) || (c.HasAudioSurround && c.AudioSurround != 0) || (c.HasAudioQuality && c.AudioQuality != 0) {
		return errors.New("only five-millisecond stereo audio is supported")
	}
	b.configured = true
	return nil
}
func (b *Backend) Start(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed || b.started || !b.configured {
		return errors.New("backend is not ready to start")
	}
	if err := b.ctx.Err(); err != nil {
		return err
	}
	key, _ := base64.StdEncoding.Strict().DecodeString(b.cfg.KeyB64)
	cipher, err := gamestreamvideo.NewVideoCipher(key)
	if err != nil {
		return err
	}
	pipeline, err := media.NewEncryptedPipeline(b.cfg.PacketSize, cipher)
	if err != nil {
		return err
	}
	ap, err := audio.NewPacketizer(key, b.cfg.KeyID, 0)
	if err != nil {
		return err
	}
	// Copies of the config no longer need the secret once all cipher state exists.
	b.cfg.KeyB64 = ""
	b.started = true
	b.wg.Add(2)
	go func() {
		defer b.wg.Done()
		var stats media.PipelineStats
		peer, err := waitForPing(b.ctx, b.video, b.cfg.VideoPort, b.videoToken)
		if err == nil {
			stats, err = pipeline.RunLive(b.ctx, b.videoEncoder, udpSink(b.video, peer), b.cfg.FPS)
		}
		b.finish(err, func() { b.stats.VideoFrames = stats.Frames; b.stats.VideoPackets = stats.Packets })
	}()
	go func() {
		defer b.wg.Done()
		var stats audio.PacketStats
		peer, err := waitForPing(b.ctx, b.audio, b.cfg.AudioPort, b.audioToken)
		if err == nil {
			paced, _ := audio.PaceFiveMillis(b.audioSink(peer))
			stats, err = audio.StreamLive(b.ctx, b.audioEncoder, paced, ap)
		}
		b.finish(err, func() { b.stats.AudioPackets = stats.Packets })
	}()
	return nil
}
func (b *Backend) finish(err error, save func()) {
	b.mu.Lock()
	save()
	unexpected := b.ctx.Err() == nil
	if unexpected {
		if err == nil {
			err = errors.New("media stream ended unexpectedly")
		}
		b.result = errors.Join(b.result, err)
	}
	b.mu.Unlock()
	b.cancel()
	if unexpected {
		b.abort()
	}
}
func (b *Backend) audioSink(peer *net.UDPAddr) audio.PacketSink {
	sink := udpSink(b.audio, peer)
	var block [4][]byte
	index := 0
	return func(ctx context.Context, p []byte) error {
		if err := sink(ctx, p); err != nil {
			return err
		}
		block[index] = append(block[index][:0], p...)
		index++
		if index == 4 {
			parity, err := audio.AudioParity(block)
			if err != nil {
				return err
			}
			for _, packet := range parity {
				if err = sink(ctx, packet); err != nil {
					return err
				}
				b.mu.Lock()
				b.stats.AudioParityPackets++
				b.mu.Unlock()
			}
			index = 0
		}
		return nil
	}
}
func udpSink(conn *net.UDPConn, peer *net.UDPAddr) func(context.Context, []byte) error {
	return func(ctx context.Context, p []byte) error {
		if err := ctx.Err(); err != nil {
			return err
		}
		deadline := time.Now().Add(time.Second)
		if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
			deadline = d
		}
		if err := conn.SetWriteDeadline(deadline); err != nil {
			return err
		}
		n, err := conn.WriteToUDP(p, peer)
		if err != nil {
			return err
		}
		if n != len(p) {
			return io.ErrShortWrite
		}
		return nil
	}
}
func (b *Backend) StartControl(ctx context.Context) error { return b.checkControl(ctx) }
func (b *Backend) Keepalive(ctx context.Context) error    { return b.checkControl(ctx) }

// Every captured frame is IDR; there is no stale reference chain to invalidate.
func (b *Backend) RequestIDR(ctx context.Context) error { return b.checkControl(ctx) }
func (b *Backend) checkControl(ctx context.Context) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed {
		return errors.New("backend closed")
	}
	return b.ctx.Err()
}
func (b *Backend) CloseControl() error { b.cancel(); b.abort(); return nil }
func (b *Backend) Close() error {
	b.mu.Lock()
	if !b.closed {
		b.closed = true
		b.cancel()
		_ = b.video.Close()
		_ = b.audio.Close()
	}
	b.mu.Unlock()
	b.wg.Wait()
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.result
}
func (b *Backend) Snapshot() Stats { b.mu.Lock(); defer b.mu.Unlock(); return b.stats }

type silencePCM struct{ closed atomic.Bool }

func (s *silencePCM) Read(p []byte) (int, error) {
	if s.closed.Load() {
		return 0, io.EOF
	}
	clear(p)
	return len(p), nil
}
func (s *silencePCM) Close() error { s.closed.Store(true); return nil }

// Exact-port mode accepts only the authorized peer's legacy ping. Rendezvous
// mode accepts a 96-bit unpredictable token carried inside encrypted SETUP.
// In either case the returned peer is immutable for the rest of the launch.
func waitForPing(ctx context.Context, conn *net.UDPConn, port int, token string) (*net.UDPAddr, error) {
	deadline := time.Now().Add(15 * time.Second)
	var p [64]byte
	for {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		next := time.Now().Add(100 * time.Millisecond)
		if deadline.Before(next) {
			next = deadline
		}
		if err := conn.SetReadDeadline(next); err != nil {
			return nil, err
		}
		n, peer, err := conn.ReadFromUDP(p[:])
		if err == nil && peer.IP.Equal(net.IPv4(127, 0, 0, 1)) {
			if port != 0 && peer.Port == port && bytes.Equal(p[:n], []byte("PING")) {
				return peer, nil
			}
			if port == 0 && len(token) == 16 && n == 20 && subtle.ConstantTimeCompare(p[:16], []byte(token)) == 1 {
				return peer, nil
			}
		}
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		if err != nil {
			if e, ok := err.(net.Error); !ok || !e.Timeout() {
				return nil, err
			}
		}
		if !time.Now().Before(deadline) {
			return nil, errors.New("authorized media receiver ping timed out")
		}
	}
}
