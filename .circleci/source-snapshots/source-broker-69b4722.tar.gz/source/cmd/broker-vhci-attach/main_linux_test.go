//go:build linux

// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"bytes"
	"context"
	"strings"
	"testing"
	"time"
)

func validOptions() options {
	return options{address: "127.0.0.1:3241", name: "localhost", cert: "client.pem", key: "client.key", ca: "ca.pem", pin: strings.Repeat("01", 32), bus: "1-2", vendor: "1234", product: "abcd", consent: true, duration: time.Minute}
}
func TestHostConsentAndSelectionRequired(t *testing.T) {
	for _, change := range []func(*options){func(o *options) { o.consent = false }, func(o *options) { o.duration = 0 }, func(o *options) { o.vendor = "0" }, func(o *options) { o.product = "fffff" }, func(o *options) { o.address = "0.0.0.0:3241" }, func(o *options) { o.pin = strings.Repeat("0", 64) }} {
		o := validOptions()
		change(&o)
		if _, err := o.policy(); err == nil {
			t.Fatal("invalid policy accepted")
		}
	}
	if _, err := validOptions().policy(); err != nil {
		t.Fatal(err)
	}
}
func TestCapabilitiesDoNotClaimHardwareAcceptance(t *testing.T) {
	var out bytes.Buffer
	if err := execute(context.Background(), []string{"--capabilities"}, &out); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(out.String(), `"kernel_attachment_tested":false`) || !strings.Contains(out.String(), `"plaintext_listener":false`) || !strings.Contains(out.String(), `"interface_class_validated":false`) || !strings.Contains(out.String(), `"trusted_exporter_required":true`) {
		t.Fatal(out.String())
	}
}
