//go:build linux

// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/linuxvhci"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/localtls"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

var version = "dev"

type options struct {
	address, name, cert, key, ca, pin, bus string
	vendor, product                        string
	consent                                bool
	duration                               time.Duration
	showVersion, capabilities              bool
}

func parse(args []string) (options, error) {
	var o options
	f := flag.NewFlagSet("broker-vhci-attach", flag.ContinueOnError)
	f.SetOutput(io.Discard)
	f.StringVar(&o.address, "server", "", "literal private/loopback TLS server IP:port")
	f.StringVar(&o.name, "server-name", "", "expected server certificate name")
	f.StringVar(&o.cert, "client-cert", "", "client certificate PEM file")
	f.StringVar(&o.key, "client-key", "", "private key PEM file")
	f.StringVar(&o.ca, "server-ca", "", "server CA PEM file")
	f.StringVar(&o.pin, "server-sha256", "", "exact server leaf DER SHA256")
	f.StringVar(&o.bus, "bus-id", "", "explicit remote device bus ID")
	f.StringVar(&o.vendor, "vendor-id", "", "required exact vendor ID in hex")
	f.StringVar(&o.product, "product-id", "", "required exact product ID in hex")
	f.BoolVar(&o.consent, "host-consent", false, "authorize this remote USB device's exposure to this host kernel")
	f.DurationVar(&o.duration, "duration", 0, "required session lifetime 1s..24h")
	f.BoolVar(&o.showVersion, "version", false, "source version")
	f.BoolVar(&o.capabilities, "capabilities", false, "experimental role/capabilities")
	if err := f.Parse(args); err != nil {
		return o, err
	}
	if f.NArg() != 0 {
		return o, errors.New("no positional arguments accepted")
	}
	return o, nil
}
func (o options) policy() (linuxvhci.Policy, error) {
	parseID := func(s string) (uint16, error) {
		v, err := strconv.ParseUint(strings.TrimPrefix(s, "0x"), 16, 16)
		if err != nil || v == 0 {
			return 0, errors.New("nonzero hexadecimal device ID required")
		}
		return uint16(v), nil
	}
	vid, e1 := parseID(o.vendor)
	pid, e2 := parseID(o.product)
	if e1 != nil || e2 != nil || !o.consent || o.duration < time.Second || o.duration > 24*time.Hour {
		return linuxvhci.Policy{}, errors.New("host consent, exact VID/PID and bounded duration required")
	}
	if err := localtls.ValidateAddress(o.address); err != nil {
		return linuxvhci.Policy{}, err
	}
	if _, err := usbip.EncodeNegotiationRequest(usbip.NegotiationRequest{Code: usbip.RequestImport, BusID: o.bus}); err != nil {
		return linuxvhci.Policy{}, err
	}
	pin, err := hex.DecodeString(o.pin)
	if err != nil || len(pin) != 32 || o.name == "" || o.cert == "" || o.key == "" || o.ca == "" {
		return linuxvhci.Policy{}, errors.New("operator identity, server trust and exact pin required")
	}
	var nonzero byte
	for _, b := range pin {
		nonzero |= b
	}
	if nonzero == 0 {
		return linuxvhci.Policy{}, errors.New("nonzero exact server pin required")
	}
	return linuxvhci.Policy{HostConsent: true, BusID: o.bus, Vendor: vid, Product: pid, Lifetime: o.duration}, nil
}
func credential(path string) ([]byte, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, errors.New("credential file unavailable")
	}
	defer f.Close()
	s, err := f.Stat()
	if err != nil || !s.Mode().IsRegular() || s.Size() > 1<<20 {
		return nil, errors.New("bounded regular credential file required")
	}
	b, err := io.ReadAll(io.LimitReader(f, (1<<20)+1))
	if err != nil || len(b) > 1<<20 {
		return nil, errors.New("credential read failed")
	}
	return b, nil
}
func (o options) identity() (localtls.ClientIdentity, error) {
	cert, err := credential(o.cert)
	if err != nil {
		return localtls.ClientIdentity{}, err
	}
	key, err := credential(o.key)
	if err != nil {
		return localtls.ClientIdentity{}, err
	}
	ca, err := credential(o.ca)
	if err != nil {
		return localtls.ClientIdentity{}, err
	}
	pair, err := tls.X509KeyPair(cert, key)
	if err != nil {
		return localtls.ClientIdentity{}, errors.New("invalid client identity")
	}
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(ca) {
		return localtls.ClientIdentity{}, errors.New("invalid server CA")
	}
	pin, _ := hex.DecodeString(o.pin)
	id := localtls.ClientIdentity{Certificate: pair, Roots: roots, ServerName: o.name}
	copy(id.ServerPin[:], pin)
	return id, nil
}

// Process-owned output with a finite wait even for inherited synchronous pipes.
func event(ctx context.Context, out io.Writer, value any) error {
	b, err := json.Marshal(value)
	if err != nil {
		return err
	}
	b = append(b, '\n')
	done := make(chan error, 1)
	go func() {
		n, e := out.Write(b)
		if e == nil && n != len(b) {
			e = io.ErrShortWrite
		}
		done <- e
	}()
	timer := time.NewTimer(5 * time.Second)
	defer timer.Stop()
	select {
	case err := <-done:
		return err
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return errors.New("output blocked")
	}
}
func execute(ctx context.Context, args []string, out io.Writer) error {
	o, err := parse(args)
	if err != nil {
		return err
	}
	if o.showVersion {
		return event(ctx, out, map[string]any{"version": version})
	}
	if o.capabilities {
		return event(ctx, out, map[string]any{"component": "source-broker-vhci", "profile": "linux-vhci-socketpair-v1-experimental", "role": "usbip-kernel-importer-linux", "version": version, "kernel_attachment_tested": false, "physical_usb_tested": false, "plaintext_listener": false, "interface_class_validated": false, "trusted_exporter_required": true})
	}
	policy, err := o.policy()
	if err != nil {
		return err
	}
	if err := linuxvhci.Preflight(); err != nil {
		return errors.New("existing VHCI controller and preauthorized attach permission required")
	}
	identity, err := o.identity()
	if err != nil {
		return err
	}
	importContext, stop := context.WithTimeout(ctx, 10*time.Second)
	conn, desc, err := localtls.OpenImportedStream(importContext, o.address, identity, o.bus)
	stop()
	if err != nil {
		return errors.New("authenticated import failed")
	}
	defer conn.Close()
	if err := event(ctx, out, map[string]any{"event": "imported", "bus_id": desc.BusID, "role": "usbip-kernel-importer-linux"}); err != nil {
		return err
	}
	err = linuxvhci.Run(ctx, conn, desc, policy, func(a linuxvhci.Attachment) error {
		return event(ctx, out, map[string]any{"event": "kernel_attach_accepted", "port": a.Port, "bus_id": a.Device.BusID, "enumeration_verified": false, "physical_usb_verified": false})
	})
	if err != nil && !errors.Is(err, context.Canceled) && !errors.Is(err, context.DeadlineExceeded) {
		return err
	}
	// A signal may already have canceled ctx; this terminal event has its own
	// bounded output context after the bridge has released its owned sockets.
	return event(context.Background(), out, map[string]any{"event": "stopped", "enumeration_verified": false})
}
func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if err := execute(ctx, os.Args[1:], os.Stdout); err != nil {
		fmt.Fprintln(os.Stderr, "experimental VHCI session failed:", err)
		os.Exit(1)
	}
}
