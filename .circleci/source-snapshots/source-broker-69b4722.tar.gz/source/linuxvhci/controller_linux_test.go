//go:build linux

// SPDX-License-Identifier: GPL-3.0-only
package linuxvhci

import (
	"os"
	"path/filepath"
	"testing"
)

func TestStatusParsingAndHubChoice(t *testing.T) {
	text := "hub port sta spd dev sockfd local_busid\nhs 0000 006 002 00010002 000015 1-2\nhs 0001 004 000 00000000 000000 0-0\nss 0008 004 000 00000000 000000 0-0\n"
	ports, err := ParseStatus([]byte(text), 16)
	if err != nil {
		t.Fatal(err)
	}
	if p, err := selectPort(ports, 2); err != nil || p != 1 {
		t.Fatal(p, err)
	}
	if p, err := selectPort(ports, 5); err != nil || p != 8 {
		t.Fatal(p, err)
	}
	for _, bad := range []string{"", "wrong header\n", "hub port sta spd dev sockfd local_busid\nhs 0 4 0 0 0\n", "hub port sta spd dev sockfd local_busid\nhs 0 4 0 0 0 0-0\nhs 0 4 0 0 0 0-0\n", "hub port sta spd dev sockfd local_busid\nhs 16 4 0 0 0 0-0\n"} {
		if _, err := ParseStatus([]byte(bad), 16); err == nil {
			t.Fatal("malformed status accepted", bad)
		}
	}
}
func FuzzStatus(f *testing.F) {
	f.Add([]byte("hub port sta spd dev sockfd local_busid\nhs 0 4 0 0 0 0-0\n"))
	f.Fuzz(func(t *testing.T, b []byte) {
		ports, err := ParseStatus(b, 16)
		if err == nil {
			if len(ports) > 16 {
				t.Fatal("unbounded ports")
			}
			seen := map[uint32]bool{}
			for _, p := range ports {
				if p.Number >= 16 || seen[p.Number] {
					t.Fatal(p)
				}
				seen[p.Number] = true
			}
		}
	})
}

func TestExactSysfsAttachRecord(t *testing.T) {
	root := t.TempDir()
	if err := os.WriteFile(filepath.Join(root, "attach"), nil, 0600); err != nil {
		t.Fatal(err)
	}
	directory, err := os.OpenRoot(root)
	if err != nil {
		t.Fatal(err)
	}
	defer directory.Close()
	d := &sysfsController{root: directory}
	if err := d.attach(7, 123, sampleDescription()); err != nil {
		t.Fatal(err)
	}
	b, err := os.ReadFile(filepath.Join(root, "attach"))
	if err != nil || string(b) != "7 123 65538 2\n" {
		t.Fatal(string(b), err)
	}
}
