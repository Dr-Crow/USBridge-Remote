//go:build linux

// SPDX-License-Identifier: GPL-3.0-only
package linuxvhci

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
	"syscall"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

const controllerPath = "/sys/devices/platform/vhci_hcd.0"
const maxPorts = 4096

type Port struct {
	Hub                          string
	Number, State, Speed, Device uint32
}

// ParseStatus handles the current seven-column Linux VHCI status layout. Only
// controller zero's status is selected by this experimental adapter; no port
// count or hub offset is hardcoded. Other controller status.N files are unused.
func ParseStatus(data []byte, nports uint32) ([]Port, error) {
	if nports < 1 || nports > maxPorts || len(data) > 64<<10 {
		return nil, errors.New("invalid bounded controller status")
	}
	s := bufio.NewScanner(strings.NewReader(string(data)))
	if !s.Scan() || strings.Join(strings.Fields(s.Text()), " ") != "hub port sta spd dev sockfd local_busid" {
		return nil, errors.New("unrecognized VHCI status header")
	}
	seen := map[uint32]bool{}
	var ports []Port
	for s.Scan() {
		fields := strings.Fields(s.Text())
		if len(fields) != 7 || (fields[0] != "hs" && fields[0] != "ss") {
			return nil, errors.New("malformed VHCI status row")
		}
		parse := func(value string, base int) (uint32, error) {
			n, err := strconv.ParseUint(value, base, 32)
			return uint32(n), err
		}
		port, e1 := parse(fields[1], 10)
		state, e2 := parse(fields[2], 10)
		speed, e3 := parse(fields[3], 10)
		device, e4 := parse(fields[4], 16)
		_, e5 := parse(fields[5], 10)
		if e1 != nil || e2 != nil || e3 != nil || e4 != nil || e5 != nil || port >= nports || seen[port] || state < 4 || state > 7 || speed > 6 || len(fields[6]) > 64 {
			return nil, errors.New("invalid VHCI status field")
		}
		seen[port] = true
		ports = append(ports, Port{Hub: fields[0], Number: port, State: state, Speed: speed, Device: device})
	}
	if s.Err() != nil || len(ports) == 0 {
		return nil, errors.New("empty or unreadable VHCI status")
	}
	return ports, nil
}
func selectPort(ports []Port, speed uint32) (uint32, error) {
	hub := "hs"
	if speed >= 5 {
		hub = "ss"
	}
	for _, p := range ports {
		if p.State == 4 && p.Hub == hub {
			return p.Number, nil
		}
	}
	return 0, errors.New("no compatible free VHCI port")
}

type sysfsController struct{ root *os.Root }

func openController() (*sysfsController, error) {
	var stat syscall.Statfs_t
	if err := syscall.Statfs(controllerPath, &stat); err != nil {
		return nil, errors.New("existing VHCI controller unavailable")
	}
	if uint64(stat.Type) != 0x62656572 {
		return nil, errors.New("VHCI controller path is not sysfs")
	}
	root, err := os.OpenRoot(controllerPath)
	if err != nil {
		return nil, err
	}
	d := &sysfsController{root: root}
	if _, err := d.ports(); err != nil {
		root.Close()
		return nil, err
	}
	f, err := root.OpenFile("attach", os.O_WRONLY, 0)
	if err != nil {
		root.Close()
		return nil, errors.New("existing VHCI attach permission required")
	}
	_ = f.Close()
	return d, nil
}
func (d *sysfsController) close() error { return d.root.Close() }
func (d *sysfsController) read(name string) ([]byte, error) {
	f, err := d.root.Open(name)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	b, err := io.ReadAll(io.LimitReader(f, (64<<10)+1))
	if err != nil || len(b) > 64<<10 {
		return nil, errors.New("controller attribute exceeds bound")
	}
	return b, nil
}
func (d *sysfsController) ports() ([]Port, error) {
	b, err := d.read("nports")
	if err != nil {
		return nil, err
	}
	n, err := strconv.ParseUint(strings.TrimSpace(string(b)), 10, 32)
	if err != nil {
		return nil, err
	}
	status, err := d.read("status")
	if err != nil {
		return nil, err
	}
	return ParseStatus(status, uint32(n))
}
func (d *sysfsController) attach(port uint32, fd uintptr, device usbip.DeviceDescription) error {
	if port >= maxPorts || fd > 1<<31-1 {
		return errors.New("attach values out of range")
	}
	b := []byte(fmt.Sprintf("%d %d %d %d\n", port, fd, device.Bus<<16|device.Number, device.Speed))
	f, err := d.root.OpenFile("attach", os.O_WRONLY, 0)
	if err != nil {
		return err
	}
	defer f.Close()
	n, err := f.Write(b)
	if err == nil && n != len(b) {
		err = io.ErrShortWrite
	}
	return err
}

// Preflight only checks the existing fixed sysfs controller/status and attach
// permission. It does not attach, load a driver, elevate or change permissions.
func Preflight() error {
	d, err := openController()
	if err != nil {
		return err
	}
	return d.close()
}
