//go:build linux

// SPDX-License-Identifier: GPL-3.0-only
package linuxvhci

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"errors"
	"io"
	"math/big"
	"net"
	"os"
	"sync/atomic"
	"syscall"
	"testing"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/localtls"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

func sampleDescription() usbip.DeviceDescription {
	return usbip.DeviceDescription{BusID: "1-2", Bus: 1, Number: 2, Speed: 2, Vendor: 0x1234, Product: 0xabcd, Configurations: 1, Configuration: 1, InterfaceCount: 1}
}
func samplePolicy() Policy {
	return Policy{HostConsent: true, BusID: "1-2", Vendor: 0x1234, Product: 0xabcd, Lifetime: 3 * time.Second}
}

type fakeController struct {
	read  func() ([]Port, error)
	write func(uint32, uintptr, usbip.DeviceDescription) error
}

func (d fakeController) ports() ([]Port, error) {
	if d.read != nil {
		return d.read()
	}
	return []Port{{Hub: "hs", Number: 7, State: 4}, {Hub: "ss", Number: 8, State: 4}}, nil
}
func (d fakeController) attach(p uint32, f uintptr, v usbip.DeviceDescription) error {
	return d.write(p, f, v)
}
func duplicateKernel(t *testing.T, fd uintptr) net.Conn {
	t.Helper()
	flags, _, err := syscall.Syscall(syscall.SYS_FCNTL, fd, syscall.F_GETFD, 0)
	if err != 0 || flags&syscall.FD_CLOEXEC == 0 {
		t.Fatal("kernel descriptor lacks close-on-exec", err)
	}
	copy, err2 := syscall.Dup(int(fd))
	if err2 != nil {
		t.Fatal(err2)
	}
	syscall.CloseOnExec(copy)
	file := os.NewFile(uintptr(copy), "simulated-kernel")
	conn, err3 := net.FileConn(file)
	file.Close()
	if err3 != nil {
		t.Fatal(err3)
	}
	return conn
}
func awaitBridge(t *testing.T, done <-chan error) error {
	t.Helper()
	select {
	case err := <-done:
		return err
	case <-time.After(2 * time.Second):
		t.Fatal("bridge failed to join")
		return nil
	}
}

func TestSocketpairBidirectionalAndCancel(t *testing.T) {
	remote, conn := net.Pipe()
	defer remote.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	kernelCh := make(chan net.Conn, 1)
	ready := make(chan Attachment, 1)
	driver := fakeController{write: func(port uint32, fd uintptr, d usbip.DeviceDescription) error {
		if port != 7 || d.BusID != "1-2" {
			t.Error(port, d)
		}
		kernelCh <- duplicateKernel(t, fd)
		return nil
	}}
	done := make(chan error, 1)
	go func() {
		done <- run(ctx, conn, sampleDescription(), samplePolicy(), driver, func(a Attachment) error { ready <- a; return nil })
	}()
	kernel := <-kernelCh
	defer kernel.Close()
	<-ready
	_ = kernel.SetDeadline(time.Now().Add(time.Second))
	_ = remote.SetDeadline(time.Now().Add(time.Second))
	for _, direction := range []bool{false, true} {
		from, to := net.Conn(kernel), net.Conn(remote)
		if direction {
			from, to = to, from
		}
		write := make(chan error, 1)
		go func() { _, err := from.Write([]byte{0, 1, 2, 255}); write <- err }()
		var b [4]byte
		if _, err := io.ReadFull(to, b[:]); err != nil || b != [4]byte{0, 1, 2, 255} {
			t.Fatal(b, err)
		}
		if err := <-write; err != nil {
			t.Fatal(err)
		}
	}
	cancel()
	if err := awaitBridge(t, done); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	var b [1]byte
	if _, err := kernel.Read(b[:]); err == nil {
		t.Fatal("kernel peer did not observe closure")
	}
}
func TestAttachRaceRefreshAndCancellation(t *testing.T) {
	for _, mode := range []string{"busy", "denied", "cancel during accepted write"} {
		t.Run(mode, func(t *testing.T) {
			remote, conn := net.Pipe()
			defer remote.Close()
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			var reads, writes int
			var kernel net.Conn
			var calledReady bool
			driver := fakeController{read: func() ([]Port, error) { reads++; return []Port{{Hub: "hs", Number: uint32(reads), State: 4}}, nil }, write: func(port uint32, fd uintptr, d usbip.DeviceDescription) error {
				writes++
				if mode == "denied" {
					return syscall.EACCES
				}
				if mode == "busy" && writes == 1 {
					return syscall.EBUSY
				}
				kernel = duplicateKernel(t, fd)
				cancel()
				return nil
			}}
			err := run(ctx, conn, sampleDescription(), samplePolicy(), driver, func(Attachment) error { calledReady = true; return nil })
			if calledReady {
				t.Fatal("canceled attach advertised readiness")
			}
			if mode == "denied" {
				if !errors.Is(err, syscall.EACCES) {
					t.Fatal(err)
				}
			} else {
				if !errors.Is(err, context.Canceled) {
					t.Fatal(err)
				}
				defer kernel.Close()
				kernel.SetReadDeadline(time.Now().Add(time.Second))
				var b [1]byte
				if _, err := kernel.Read(b[:]); err == nil {
					t.Fatal("owned peer leaked")
				}
			}
			if mode == "busy" && (reads != 2 || writes != 2) {
				t.Fatal("busy reused stale port state", reads, writes)
			}
		})
	}
}
func TestPolicyRejectsBeforeTakingConnection(t *testing.T) {
	for _, edit := range []func(*Policy, *usbip.DeviceDescription){func(p *Policy, d *usbip.DeviceDescription) { p.HostConsent = false }, func(p *Policy, d *usbip.DeviceDescription) { p.Vendor = 1 }, func(p *Policy, d *usbip.DeviceDescription) { d.Bus = 65536 }, func(p *Policy, d *usbip.DeviceDescription) { d.Class = 8 }, func(p *Policy, d *usbip.DeviceDescription) { d.InterfaceCount = 2 }, func(p *Policy, d *usbip.DeviceDescription) { p.Lifetime = 0 }} {
		remote, conn := net.Pipe()
		p, d := samplePolicy(), sampleDescription()
		edit(&p, &d)
		if err := run(context.Background(), conn, d, p, fakeController{}, nil); err == nil {
			t.Fatal("invalid host policy accepted")
		}
		if err := conn.SetDeadline(time.Now().Add(time.Second)); err != nil {
			t.Fatal("invalid call consumed stream", err)
		}
		remote.Close()
		conn.Close()
	}
}

func TestRemoteEOFDuringAcceptedAttachDoesNotReportReady(t *testing.T) {
	remote, conn := net.Pipe()
	defer remote.Close()
	calledReady := false
	driver := fakeController{write: func(_ uint32, fd uintptr, _ usbip.DeviceDescription) error {
		kernel := duplicateKernel(t, fd)
		defer kernel.Close()
		// Wait for relay cleanup inside the in-flight accepted attach. This
		// makes the peer-EOF/readiness race deterministic without a sleep.
		remote.Close()
		kernel.SetReadDeadline(time.Now().Add(time.Second))
		var b [1]byte
		if _, err := kernel.Read(b[:]); !errors.Is(err, io.EOF) {
			t.Fatal("relay did not close before attach returned", err)
		}
		return nil
	}}
	err := run(context.Background(), conn, sampleDescription(), samplePolicy(), driver, func(Attachment) error { calledReady = true; return nil })
	if err == nil || calledReady {
		t.Fatal("closed stream advertised readiness", err, calledReady)
	}
}

type tlsBackend struct{ closed atomic.Int32 }

func (b *tlsBackend) List(context.Context, string) ([]usbip.DeviceDescription, error) {
	return nil, nil
}
func (b *tlsBackend) Open(_ context.Context, _ string, id string) (usbip.DeviceDescription, usbip.DeviceBackend, error) {
	if id != "1-2" {
		return usbip.DeviceDescription{}, nil, errors.New("denied")
	}
	return sampleDescription(), b, nil
}
func (b *tlsBackend) Transfer(_ context.Context, r usbip.Request) (usbip.TransferResult, error) {
	return usbip.TransferResult{ActualLength: 1, Data: []byte{42}}, nil
}
func (b *tlsBackend) Close() error { b.closed.Add(1); return nil }
func testIdentity(t *testing.T) (tls.Certificate, tls.Certificate, *x509.CertPool) {
	t.Helper()
	pub, key, _ := ed25519.GenerateKey(rand.Reader)
	root := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "ephemeral bridge CA"}, NotBefore: time.Now().Add(-time.Minute), NotAfter: time.Now().Add(time.Hour), IsCA: true, BasicConstraintsValid: true, KeyUsage: x509.KeyUsageCertSign | x509.KeyUsageDigitalSignature}
	der, err := x509.CreateCertificate(rand.Reader, root, root, pub, key)
	if err != nil {
		t.Fatal(err)
	}
	ca, _ := x509.ParseCertificate(der)
	pool := x509.NewCertPool()
	pool.AddCert(ca)
	leaf := func(n int64, usage x509.ExtKeyUsage) tls.Certificate {
		p, k, _ := ed25519.GenerateKey(rand.Reader)
		desc := &x509.Certificate{SerialNumber: big.NewInt(n), DNSNames: []string{"localhost"}, NotBefore: root.NotBefore, NotAfter: root.NotAfter, KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{usage}}
		der, err := x509.CreateCertificate(rand.Reader, desc, ca, p, key)
		if err != nil {
			t.Fatal(err)
		}
		return tls.Certificate{Certificate: [][]byte{der}, PrivateKey: k}
	}
	return leaf(2, x509.ExtKeyUsageServerAuth), leaf(3, x509.ExtKeyUsageClientAuth), pool
}
func TestAuthenticatedImportSocketpairFakeKernel(t *testing.T) {
	server, client, pool := testIdentity(t)
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	backend := &tlsBackend{}
	serverDone := make(chan error, 1)
	go func() {
		serverDone <- localtls.ServeTLS(ctx, listener, server, pool, sha256.Sum256(client.Certificate[0]), backend)
	}()
	importContext, stopImport := context.WithCancel(ctx)
	conn, desc, err := localtls.OpenImportedStream(importContext, listener.Addr().String(), localtls.ClientIdentity{Certificate: client, Roots: pool, ServerName: "localhost", ServerPin: sha256.Sum256(server.Certificate[0])}, "1-2")
	// Negotiation cancellation after handoff must not close the owned stream.
	stopImport()
	if err != nil {
		t.Fatal(err)
	}
	kernelCh := make(chan net.Conn, 1)
	ready := make(chan struct{})
	done := make(chan error, 1)
	go func() {
		done <- run(ctx, conn, desc, samplePolicy(), fakeController{write: func(_ uint32, fd uintptr, _ usbip.DeviceDescription) error {
			kernelCh <- duplicateKernel(t, fd)
			return nil
		}}, func(Attachment) error { close(ready); return nil })
	}()
	kernel := <-kernelCh
	defer kernel.Close()
	<-ready
	kernel.SetDeadline(time.Now().Add(time.Second))
	req := usbip.Request{Command: usbip.CmdSubmit, Sequence: 1, Device: 1<<16 | 2, Direction: 1, Endpoint: 1, TransferLength: 1, PacketCount: -1}
	wire, err := usbip.EncodeRequest(req)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := kernel.Write(wire); err != nil {
		t.Fatal(err)
	}
	reply, err := usbip.ReadReply(kernel, func(seq uint32) (usbip.Request, bool) { return req, seq == 1 })
	if err != nil || reply.Status != 0 || len(reply.Data) != 1 || reply.Data[0] != 42 {
		t.Fatal(reply, err)
	}
	// Real VHCI shutdown calls kernel_sock_shutdown before dropping its ref.
	if err := kernel.(*net.UnixConn).CloseWrite(); err != nil {
		t.Fatal(err)
	}
	if err := awaitBridge(t, done); err == nil {
		t.Fatal("kernel shutdown not reported")
	}
	cancel()
	select {
	case <-serverDone:
	case <-time.After(time.Second):
		t.Fatal("server cleanup blocked")
	}
	if backend.closed.Load() != 1 {
		t.Fatal("remote claim not released", backend.closed.Load())
	}
}

func TestCancellationUnblocksBothDirectionsUnderBackpressure(t *testing.T) {
	remote, conn := net.Pipe()
	defer remote.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	kernelCh := make(chan net.Conn, 1)
	ready := make(chan struct{})
	done := make(chan error, 1)
	go func() {
		done <- run(ctx, conn, sampleDescription(), samplePolicy(), fakeController{write: func(_ uint32, fd uintptr, _ usbip.DeviceDescription) error {
			kernelCh <- duplicateKernel(t, fd)
			return nil
		}}, func(Attachment) error { close(ready); return nil })
	}()
	kernel := <-kernelCh
	defer kernel.Close()
	<-ready
	writing := make(chan struct{})
	written := make(chan error, 1)
	go func() { close(writing); _, err := kernel.Write(make([]byte, 2<<20)); written <- err }()
	<-writing
	cancel()
	if err := awaitBridge(t, done); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	select {
	case err := <-written:
		if err == nil {
			t.Fatal("blocked write unexpectedly completed")
		}
	case <-time.After(time.Second):
		t.Fatal("kernel write remained blocked after cancellation")
	}
}
