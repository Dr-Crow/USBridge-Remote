//go:build linux

// SPDX-License-Identifier: GPL-3.0-only
// Package linuxvhci is an experimental one-session Linux VHCI adapter. Kernel
// attachment is opt-in and unverified on real VHCI here. It never loads drivers,
// changes permissions or exposes a plaintext listener.
package linuxvhci

import (
	"context"
	"errors"
	"io"
	"net"
	"os"
	"sync"
	"syscall"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

// Policy is local host authorization, separate from the exporter's consent.
// Vendor/product and bus ID identify exactly the remote device approved for
// exposure to this host's kernel. Remote descriptors are not trusted input to
// the kernel merely because the network peer is authenticated.
// IMPORT metadata does not contain interface classes: this policy is NOT a
// client-enforced HID allowlist. The operator must trust the selected exporter
// and device before authorizing kernel exposure.
type Policy struct {
	HostConsent     bool
	BusID           string
	Vendor, Product uint16
	Lifetime        time.Duration
}

func (p Policy) validate(d usbip.DeviceDescription) error {
	if !p.HostConsent || p.BusID == "" || p.Vendor == 0 || p.Product == 0 || p.Lifetime < time.Second || p.Lifetime > 24*time.Hour {
		return errors.New("explicit host consent, exact device identity and bounded lifetime required")
	}
	if d.BusID != p.BusID || d.Vendor != p.Vendor || d.Product != p.Product || d.Bus == 0 || d.Bus > 65535 || d.Number == 0 || d.Number > 65535 {
		return errors.New("imported device differs from host policy")
	}
	if (d.Class != 0 && d.Class != 3) || d.Subclass != 0 || d.Configurations != 1 || d.InterfaceCount != 1 || d.Configuration == 0 {
		return errors.New("import metadata outside supported single-interface profile")
	}
	if d.Speed != 1 && d.Speed != 2 && d.Speed != 3 && d.Speed != 5 {
		return errors.New("unsupported device speed")
	}
	return nil
}

// Attachment reports only the accepted kernel attach write. Enumeration and
// class-driver operation require separate observation and hardware acceptance.
type Attachment struct {
	Port   uint32
	Device usbip.DeviceDescription
}

type controller interface {
	ports() ([]Port, error)
	attach(uint32, uintptr, usbip.DeviceDescription) error
}

// Run consumes an already authenticated/imported stream after valid arguments.
// Preflight should be called before remote import to avoid claiming a device
// when the host has no usable existing controller. No automatic detach by port
// occurs: cleanup closes the exact owned socket peer, avoiding port reuse races.
func Run(ctx context.Context, conn net.Conn, description usbip.DeviceDescription, policy Policy, ready func(Attachment) error) error {
	if ctx == nil || conn == nil {
		return errors.New("context and owned imported stream required")
	}
	if err := policy.validate(description); err != nil {
		return err
	}
	driver, err := openController()
	if err != nil {
		_ = conn.Close()
		return err
	}
	defer driver.close()
	return run(ctx, conn, description, policy, driver, ready)
}

func run(ctx context.Context, conn net.Conn, d usbip.DeviceDescription, p Policy, driver controller, ready func(Attachment) error) error {
	if ctx == nil || conn == nil || driver == nil {
		return errors.New("bridge dependencies required")
	}
	if err := p.validate(d); err != nil {
		return err
	}
	defer conn.Close()
	run, cancel := context.WithTimeout(ctx, p.Lifetime)
	defer cancel()
	if err := run.Err(); err != nil {
		return err
	}
	kernel, peer, err := socketPair()
	if err != nil {
		return err
	}
	// K stays owned until attach has returned. Cancellation closes P immediately,
	// so a racing successful attach observes EOF without any fd-reuse window.
	defer kernel.Close()
	var once sync.Once
	closeStreams := func() { once.Do(func() { _ = peer.Close(); _ = conn.SetDeadline(time.Now()); _ = conn.Close() }) }
	stop := context.AfterFunc(run, closeStreams)
	defer stop()
	defer closeStreams()
	var workers sync.WaitGroup
	workers.Add(2)
	copyStream := func(dst io.Writer, src io.Reader) {
		defer workers.Done()
		_, _ = io.CopyBuffer(dst, src, make([]byte, 32<<10))
		closeStreams()
	}
	go copyStream(conn, peer)
	go copyStream(peer, conn)
	defer func() { closeStreams(); workers.Wait() }()
	attachContext, stopAttach := context.WithTimeout(run, 5*time.Second)
	defer stopAttach()
	var selected uint32
	for {
		if err := attachContext.Err(); err != nil {
			return err
		}
		select {
		case <-streamClosed(peer):
			return errors.New("imported stream ended before attach")
		default:
		}
		ports, err := driver.ports()
		if err != nil {
			return err
		}
		selected, err = selectPort(ports, d.Speed)
		if err != nil {
			return err
		}
		if err = attachContext.Err(); err != nil {
			return err
		}
		err = driver.attach(selected, kernel.Fd(), d)
		if err == nil {
			break
		}
		if !errors.Is(err, syscall.EBUSY) && !errors.Is(err, syscall.EAGAIN) {
			return err
		}
		timer := time.NewTimer(25 * time.Millisecond)
		select {
		case <-timer.C:
		case <-attachContext.Done():
			timer.Stop()
			return attachContext.Err()
		}
	}
	if err := run.Err(); err != nil {
		return err
	}
	select {
	case <-streamClosed(peer):
		return errors.New("imported stream ended during attach")
	default:
	}
	if ready != nil {
		if err := ready(Attachment{Port: selected, Device: d}); err != nil {
			return err
		}
	}
	// Wait for this exact peer/session to end, then join both copy workers.
	select {
	case <-run.Done():
		return run.Err()
	case <-streamClosed(peer):
		return errors.New("owned USB/IP bridge disconnected")
	}
}

// streamClosed is supplied by the stream-copy owner through a lifecycle wrapper.
// It creates no read competing with either relay direction.
type trackedConn struct {
	net.Conn
	done chan struct{}
	once sync.Once
}

func (c *trackedConn) Close() error {
	var err error
	c.once.Do(func() { close(c.done); err = c.Conn.Close() })
	return err
}
func streamClosed(c net.Conn) <-chan struct{} { return c.(*trackedConn).done }

func socketPair() (*os.File, net.Conn, error) {
	fds, err := syscall.Socketpair(syscall.AF_UNIX, syscall.SOCK_STREAM|syscall.SOCK_CLOEXEC, 0)
	if err != nil {
		return nil, nil, err
	}
	kernel := os.NewFile(uintptr(fds[0]), "vhci-kernel")
	file := os.NewFile(uintptr(fds[1]), "vhci-relay")
	peer, err := net.FileConn(file)
	_ = file.Close()
	if err != nil {
		_ = kernel.Close()
		return nil, nil, err
	}
	return kernel, &trackedConn{Conn: peer, done: make(chan struct{})}, nil
}
