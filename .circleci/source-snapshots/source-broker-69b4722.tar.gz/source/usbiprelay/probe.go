// SPDX-License-Identifier: GPL-3.0-only
package usbiprelay

import (
	"context"
	"encoding/binary"
	"errors"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

// Selection is explicit trusted operator policy, never filled from wire input.
type Selection struct {
	BusID           string
	Vendor, Product uint16
}

// HIDSnapshot validates a bounded descriptor snapshot only. It does not prove
// report-descriptor safety, future descriptor stability, kernel compatibility,
// driver ownership or actual enumeration. The exporter/device must be trusted.
type HIDSnapshot struct {
	Device        usbip.DeviceDescriptor
	Configuration usbip.ConfigurationDescriptor
}

// ProbeHID reads standard descriptors on this same owned upstream session.
// It permits only one configuration, interface zero/alt zero, non-boot HID and
// basic interrupt endpoints. No local stream, driver or listener is opened.
// After valid arguments, any failed probe closes the import before returning.
// Success keeps it open, with probe IDs reserved in its upstream namespace for
// subsequent Serve use. Callers must not expose a device before this succeeds.
func ProbeHID(ctx context.Context, remote *usbip.ConcurrentDevice, selection Selection) (snapshot HIDSnapshot, result error) {
	if ctx == nil || remote == nil || remote.Capacity() == 0 || selection.BusID == "" || selection.Vendor == 0 || selection.Product == 0 {
		return snapshot, errors.New("owned imported session and exact trusted device selection required")
	}
	defer func() {
		if result != nil {
			_ = remote.Close()
		}
	}()
	imported := remote.Description()
	if imported.BusID != selection.BusID || imported.Vendor != selection.Vendor || imported.Product != selection.Product || imported.Configurations != 1 || imported.InterfaceCount != 1 || imported.Configuration == 0 || imported.Speed < 1 || imported.Speed > 3 {
		return snapshot, errors.New("import identity/profile differs from policy")
	}
	snapshot.Device, result = remote.ReadDeviceDescriptor(ctx)
	if result != nil {
		return snapshot, result
	}
	d := snapshot.Device
	packetZeroOK := validControlPacket(imported.Speed, d.MaxPacketSize0)
	if !packetZeroOK || d.Class != imported.Class || d.Subclass != imported.Subclass || d.Protocol != imported.Protocol || d.DeviceVersion != imported.BCD || d.VendorID != selection.Vendor || d.ProductID != selection.Product || d.ConfigurationCount != 1 || (d.Class != 0 && d.Class != 3) || d.Subclass != 0 || d.Protocol != 0 {
		return snapshot, errors.New("device descriptor differs from basic HID policy")
	}
	snapshot.Configuration, result = remote.ReadConfigurationDescriptor(ctx, 0)
	if result != nil {
		return snapshot, result
	}
	c := snapshot.Configuration
	if c.Interfaces != 1 || c.Value != imported.Configuration || c.Attributes&0x9f != 0x80 {
		return snapshot, errors.New("configuration differs from imported profile")
	}
	if result = validateHIDRecords(c, imported.Speed); result != nil {
		return snapshot, result
	}
	return snapshot, nil
}
func validateHIDRecords(c usbip.ConfigurationDescriptor, speed uint32) error {
	maxPacket, minInterval, maxInterval := uint16(0), byte(1), byte(255)
	switch speed {
	case 1:
		maxPacket, minInterval = 8, 10
	case 2:
		maxPacket = 64
	case 3:
		maxPacket, maxInterval = 1024, 16
	default:
		return errors.New("basic HID snapshot supports only low/full/high speed")
	}
	interfaces, hids, endpoints, expected := 0, 0, 0, 0
	seen := map[byte]bool{}
	for _, r := range c.Records {
		if len(r) < 2 {
			return errors.New("short subordinate descriptor")
		}
		switch r[1] {
		case 4:
			interfaces++
			if interfaces != 1 || len(r) != 9 || r[2] != 0 || r[3] != 0 || r[4] == 0 || r[4] > 30 || r[5] != 3 || r[6] != 0 || r[7] != 0 {
				return errors.New("single non-boot HID interface zero/alternate zero required")
			}
			expected = int(r[4])
		case 0x21:
			hids++
			if interfaces != 1 || hids != 1 || len(r) < 9 || r[5] != 1 || len(r) != 9 || r[6] != 0x22 || binary.LittleEndian.Uint16(r[7:9]) == 0 || binary.LittleEndian.Uint16(r[7:9]) > usbip.MaxConfigurationBytes {
				return errors.New("one bounded HID report descriptor reference required")
			}
		case 5:
			endpoints++
			if interfaces != 1 || hids != 1 || len(r) != 7 || r[2]&0x70 != 0 || r[2]&15 == 0 || seen[r[2]] || r[3] != 3 || binary.LittleEndian.Uint16(r[4:6]) == 0 || binary.LittleEndian.Uint16(r[4:6]) > maxPacket || r[6] < minInterval || r[6] > maxInterval {
				return errors.New("unique basic interrupt endpoint required")
			}
			seen[r[2]] = true
		default:
			return errors.New("descriptor outside supported basic HID profile")
		}
	}
	if interfaces != 1 || hids != 1 || endpoints != expected {
		return errors.New("incomplete HID configuration")
	}
	return nil
}

func validControlPacket(speed uint32, size byte) bool {
	switch speed {
	case 1:
		return size == 8
	case 2:
		return size == 8 || size == 16 || size == 32 || size == 64
	case 3:
		return size == 64
	default:
		return false
	}
}
