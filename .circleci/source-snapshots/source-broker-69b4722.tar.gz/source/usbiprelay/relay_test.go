// SPDX-License-Identifier: GPL-3.0-only
package usbiprelay

import (
	"context"
	"errors"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

const remoteID = 1<<16 | 2
const localID = 9<<16 | 7

type fixtureBackend struct {
	transfer func(context.Context, usbip.Request) (usbip.TransferResult, error)
	closed   atomic.Int32
}

func (b *fixtureBackend) Transfer(ctx context.Context, r usbip.Request) (usbip.TransferResult, error) {
	return b.transfer(ctx, r)
}
func (b *fixtureBackend) Close() error { b.closed.Add(1); return nil }
func (b *fixtureBackend) List(context.Context, string) ([]usbip.DeviceDescription, error) {
	return nil, nil
}
func (b *fixtureBackend) Open(_ context.Context, _ string, id string) (usbip.DeviceDescription, usbip.DeviceBackend, error) {
	if id != "1-2" {
		return usbip.DeviceDescription{}, nil, errors.New("not authorized")
	}
	return usbip.DeviceDescription{BusID: "1-2", Bus: 1, Number: 2, Speed: 2, InterfaceCount: 1, Vendor: 0x1234, Product: 0xabcd, BCD: 0x100, Configuration: 1, Configurations: 1}, b, nil
}
func upstream(t *testing.T, b *fixtureBackend, capacity int) (*usbip.ConcurrentDevice, context.CancelFunc, <-chan error) {
	t.Helper()
	server, conn := net.Pipe()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	done := make(chan error, 1)
	go func() {
		done <- usbip.ServeDeviceSession(ctx, server, "test-owner", b, func(context.Context, string) error { return nil }, capacity)
	}()
	remote, err := usbip.ImportConcurrentDevice(ctx, conn, "1-2", capacity)
	if err != nil {
		cancel()
		t.Fatal(err)
	}
	t.Cleanup(func() { remote.Close(); cancel() })
	return remote, cancel, done
}
func await(t *testing.T, done <-chan error) error {
	t.Helper()
	select {
	case e := <-done:
		return e
	case <-time.After(time.Second):
		t.Fatal("relay/server did not join")
		return nil
	}
}
func submit(seq, endpoint uint32) usbip.Request {
	return usbip.Request{Command: usbip.CmdSubmit, Sequence: seq, Device: localID, Direction: 1, Endpoint: endpoint, TransferLength: 1, PacketCount: -1}
}
func send(t *testing.T, c net.Conn, r usbip.Request) {
	t.Helper()
	p, e := usbip.EncodeRequest(r)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = c.Write(p); e != nil {
		t.Fatal(e)
	}
}
func reply(t *testing.T, c net.Conn, requests map[uint32]usbip.Request) usbip.Reply {
	t.Helper()
	c.SetReadDeadline(time.Now().Add(time.Second))
	r, e := usbip.ReadReply(c, func(seq uint32) (usbip.Request, bool) { r, ok := requests[seq]; return r, ok })
	if e != nil {
		t.Fatal(e)
	}
	return r
}
func start(t *testing.T, ctx context.Context, remote *usbip.ConcurrentDevice, capacity int) (net.Conn, <-chan error) {
	t.Helper()
	local, kernel := net.Pipe()
	done := make(chan error, 1)
	go func() { done <- Serve(ctx, local, remote, localID, capacity) }()
	t.Cleanup(func() { kernel.Close() })
	return kernel, done
}
func TestDescriptorPreflightKeepsIndependentRelaySequences(t *testing.T) {
	descriptor := []byte{18, 1, 0, 2, 0, 0, 0, 64, 0x34, 0x12, 0xcd, 0xab, 0, 1, 1, 2, 3, 1}
	configuration := []byte{9, 2, 25, 0, 1, 1, 0, 0x80, 50, 9, 4, 0, 0, 1, 3, 0, 0, 0, 7, 5, 0x81, 3, 8, 0, 10}
	seen := make(chan usbip.Request, 4)
	backend := &fixtureBackend{transfer: func(_ context.Context, r usbip.Request) (usbip.TransferResult, error) {
		var p []byte
		if r.Endpoint == 0 {
			if r.Setup[3] == 1 {
				p = descriptor
			} else {
				p = configuration[:int(r.TransferLength)]
			}
		} else {
			seen <- r
			p = []byte{42}
		}
		return usbip.TransferResult{ActualLength: int32(len(p)), Data: p}, nil
	}}
	remote, _, serverDone := upstream(t, backend, 4)
	if d, e := remote.ReadDeviceDescriptor(context.Background()); e != nil || d.VendorID != 0x1234 {
		t.Fatal(d, e)
	}
	if d, e := remote.ReadConfigurationDescriptor(context.Background(), 0); e != nil || d.Interfaces != 1 {
		t.Fatal(d, e)
	}
	kernel, done := start(t, context.Background(), remote, 4)
	for i := uint32(1); i <= 2; i++ {
		r := submit(i, 1)
		send(t, kernel, r)
		got := reply(t, kernel, map[uint32]usbip.Request{i: r})
		upstream := <-seen
		if upstream.Sequence != i+3 || upstream.Device != remoteID || got.Sequence != i || got.ActualLength != 1 || got.Data[0] != 42 {
			t.Fatal(upstream, got)
		}
	}
	kernel.Close()
	if e := await(t, done); e != nil {
		t.Fatal(e)
	}
	if e := await(t, serverDone); e != nil {
		t.Fatal(e)
	}
	if backend.closed.Load() != 1 {
		t.Fatal("backend close count", backend.closed.Load())
	}
}
func TestRelayUnlinkPreservesOtherTransferAndSession(t *testing.T) {
	entered := make(chan struct{}, 1)
	backend := &fixtureBackend{transfer: func(ctx context.Context, r usbip.Request) (usbip.TransferResult, error) {
		if r.Endpoint == 1 {
			entered <- struct{}{}
			<-ctx.Done()
			return usbip.TransferResult{}, ctx.Err()
		}
		return usbip.TransferResult{ActualLength: 1, Data: []byte{7}}, nil
	}}
	remote, _, serverDone := upstream(t, backend, 4)
	kernel, done := start(t, context.Background(), remote, 4)
	one, three := submit(1, 1), submit(3, 2)
	unlink := usbip.Request{Command: usbip.CmdUnlink, Sequence: 2, Device: localID, UnlinkSequence: 1}
	send(t, kernel, one)
	<-entered
	send(t, kernel, three)
	send(t, kernel, unlink)
	requests := map[uint32]usbip.Request{2: unlink, 3: three}
	seen := map[uint32]bool{}
	for i := 0; i < 2; i++ {
		r := reply(t, kernel, requests)
		if seen[r.Sequence] {
			t.Fatal("duplicate reply")
		}
		seen[r.Sequence] = true
		if r.Sequence == 2 && r.Status != -104 {
			t.Fatal(r)
		}
		if r.Sequence == 3 && (r.Status != 0 || r.ActualLength != 1) {
			t.Fatal(r)
		}
	}
	four := submit(4, 2)
	send(t, kernel, four)
	if r := reply(t, kernel, map[uint32]usbip.Request{4: four}); r.Status != 0 {
		t.Fatal(r)
	}
	kernel.Close()
	if e := await(t, done); e != nil {
		t.Fatal(e)
	}
	_ = await(t, serverDone)
}
func TestRelayRemoteLossEndsIdleLocalStream(t *testing.T) {
	backend := &fixtureBackend{transfer: func(context.Context, usbip.Request) (usbip.TransferResult, error) { return usbip.TransferResult{}, nil }}
	remote, stopRemote, serverDone := upstream(t, backend, 2)
	kernel, done := start(t, context.Background(), remote, 2)
	stopRemote()
	kernel.SetReadDeadline(time.Now().Add(time.Second))
	var b [1]byte
	if _, e := kernel.Read(b[:]); !errors.Is(e, io.EOF) {
		t.Fatal(e)
	}
	if e := await(t, done); e == nil {
		t.Fatal("remote failure reported success")
	}
	_ = await(t, serverDone)
}
func TestRelayCancellationJoinsBlockedReply(t *testing.T) {
	returned := make(chan struct{}, 1)
	backend := &fixtureBackend{transfer: func(context.Context, usbip.Request) (usbip.TransferResult, error) {
		returned <- struct{}{}
		return usbip.TransferResult{ActualLength: 1, Data: []byte{1}}, nil
	}}
	remote, _, serverDone := upstream(t, backend, 2)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	kernel, done := start(t, ctx, remote, 2)
	send(t, kernel, submit(1, 1))
	<-returned
	cancel()
	if e := await(t, done); !errors.Is(e, context.Canceled) {
		t.Fatal(e)
	}
	_ = await(t, serverDone)
	if backend.closed.Load() != 1 {
		t.Fatal("backend not joined")
	}
}
func TestRelayRejectsCapacityBeforeOwnership(t *testing.T) {
	backend := &fixtureBackend{transfer: func(context.Context, usbip.Request) (usbip.TransferResult, error) { return usbip.TransferResult{}, nil }}
	remote, _, serverDone := upstream(t, backend, 1)
	local, kernel := net.Pipe()
	defer local.Close()
	defer kernel.Close()
	if e := Serve(context.Background(), local, remote, localID, 2); e == nil {
		t.Fatal("incompatible capacity accepted")
	}
	select {
	case <-remote.Done():
		t.Fatal("invalid call consumed upstream")
	default:
	}
	if e := local.SetDeadline(time.Now().Add(time.Second)); e != nil {
		t.Fatal("invalid call consumed local", e)
	}
	remote.Close()
	_ = await(t, serverDone)
}

func TestRelayQueuedCancelDoesNotReachUpstream(t *testing.T) {
	entered := make(chan struct{}, 2)
	var calls atomic.Int32
	backend := &fixtureBackend{transfer: func(ctx context.Context, r usbip.Request) (usbip.TransferResult, error) {
		calls.Add(1)
		entered <- struct{}{}
		<-ctx.Done()
		return usbip.TransferResult{}, ctx.Err()
	}}
	remote, _, serverDone := upstream(t, backend, 4)
	kernel, done := start(t, context.Background(), remote, 4)
	send(t, kernel, submit(1, 1))
	<-entered
	send(t, kernel, submit(2, 1))
	queued := usbip.Request{Command: usbip.CmdUnlink, Sequence: 3, Device: localID, UnlinkSequence: 2}
	send(t, kernel, queued)
	if r := reply(t, kernel, map[uint32]usbip.Request{3: queued}); r.Status != -104 {
		t.Fatal(r)
	}
	if calls.Load() != 1 {
		t.Fatal("queued transfer overtook active endpoint", calls.Load())
	}
	active := usbip.Request{Command: usbip.CmdUnlink, Sequence: 4, Device: localID, UnlinkSequence: 1}
	send(t, kernel, active)
	if r := reply(t, kernel, map[uint32]usbip.Request{4: active}); r.Status != -104 {
		t.Fatal(r)
	}
	kernel.Close()
	if e := await(t, done); e != nil {
		t.Fatal(e)
	}
	_ = await(t, serverDone)
}

type notifyingConn struct {
	net.Conn
	once    sync.Once
	writing chan struct{}
}

func (c *notifyingConn) Write(b []byte) (int, error) {
	c.once.Do(func() { close(c.writing) })
	return c.Conn.Write(b)
}
func TestRelayWinningCompletionPrecedesLateUnlink(t *testing.T) {
	backend := &fixtureBackend{transfer: func(context.Context, usbip.Request) (usbip.TransferResult, error) {
		return usbip.TransferResult{ActualLength: 1, Data: []byte{3}}, nil
	}}
	remote, _, serverDone := upstream(t, backend, 2)
	raw, kernel := net.Pipe()
	defer kernel.Close()
	local := &notifyingConn{Conn: raw, writing: make(chan struct{})}
	done := make(chan error, 1)
	go func() { done <- Serve(context.Background(), local, remote, localID, 2) }()
	one := submit(1, 1)
	send(t, kernel, one)
	select {
	case <-local.writing:
	case <-time.After(time.Second):
		t.Fatal("completion did not reach blocked writer")
	}
	unlink := usbip.Request{Command: usbip.CmdUnlink, Sequence: 2, Device: localID, UnlinkSequence: 1}
	send(t, kernel, unlink)
	requests := map[uint32]usbip.Request{1: one, 2: unlink}
	if r := reply(t, kernel, requests); r.Sequence != 1 || r.Status != 0 {
		t.Fatal("late unlink overtook completion", r)
	}
	if r := reply(t, kernel, requests); r.Sequence != 2 || r.Status != 0 {
		t.Fatal(r)
	}
	kernel.Close()
	if e := await(t, done); e != nil {
		t.Fatal(e)
	}
	_ = await(t, serverDone)
}
