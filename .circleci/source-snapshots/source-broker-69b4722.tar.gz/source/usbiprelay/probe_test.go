// SPDX-License-Identifier: GPL-3.0-only
package usbiprelay

import (
	"context"
	"encoding/binary"
	"testing"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

func hidConfiguration() []byte {
	return []byte{9, 2, 34, 0, 1, 1, 0, 0x80, 50, 9, 4, 0, 0, 1, 3, 0, 0, 0, 9, 0x21, 0x11, 1, 0, 1, 0x22, 16, 0, 7, 5, 0x81, 3, 8, 0, 10}
}
func TestProbeHIDRejectsBeforeAnyLocalExposure(t *testing.T) {
	for _, mode := range []string{"valid", "wrong_identity", "boot", "storage", "alternate", "bulk", "duplicate_endpoint", "missing_hid", "malformed_hid", "oversize", "changed_header", "short", "bad_ep0", "bad_attributes"} {
		t.Run(mode, func(t *testing.T) {
			config := hidConfiguration()
			switch mode {
			case "bad_attributes":
				config[7] = 0
			case "boot":
				config[15] = 1
			case "storage":
				config[14] = 8
			case "alternate":
				config[12] = 1
			case "bulk":
				config[30] = 2
			case "duplicate_endpoint":
				config[13] = 2
				config = append(config, config[27:]...)
				binary.LittleEndian.PutUint16(config[2:4], uint16(len(config)))
			case "missing_hid":
				config = append(config[:18], config[27:]...)
				binary.LittleEndian.PutUint16(config[2:4], uint16(len(config)))
			case "malformed_hid":
				config[23] = 2
			case "oversize":
				binary.LittleEndian.PutUint16(config[2:4], 4097)
			}
			backend := &fixtureBackend{transfer: func(_ context.Context, r usbip.Request) (usbip.TransferResult, error) {
				if r.Endpoint != 0 || r.Direction != 1 || r.Setup[0] != 0x80 || r.Setup[1] != 6 {
					t.Error("probe issued a non-descriptor transfer")
				}
				p := []byte{18, 1, 0, 2, 0, 0, 0, 64, 0x34, 0x12, 0xcd, 0xab, 0, 1, 1, 2, 3, 1}
				if r.Setup[3] == 2 {
					p = append([]byte(nil), config[:int(r.TransferLength)]...)
					if mode == "changed_header" && len(p) > 9 {
						p[5] = 2
					}
				} else if mode == "bad_ep0" {
					p[7] = 1
				} else if mode == "wrong_identity" {
					p[8] = 0xff
				}
				if mode == "short" {
					p = p[:len(p)-1]
				}
				return usbip.TransferResult{ActualLength: int32(len(p)), Data: p}, nil
			}}
			remote, _, done := upstream(t, backend, 4)
			snapshot, err := ProbeHID(context.Background(), remote, Selection{BusID: "1-2", Vendor: 0x1234, Product: 0xabcd})
			if mode == "valid" {
				if err != nil || snapshot.Configuration.Interfaces != 1 {
					t.Fatal(snapshot, err)
				}
				select {
				case <-remote.Done():
					t.Fatal("valid preflight closed session")
				default:
				}
				remote.Close()
			} else {
				if err == nil {
					t.Fatal("untrusted descriptor accepted")
				}
				select {
				case <-remote.Done():
				default:
					t.Fatal("rejected descriptor retained import")
				}
			}
			_ = await(t, done)
			if backend.closed.Load() != 1 {
				t.Fatal("import not released")
			}
		})
	}
}

func TestHIDSnapshotSpeedSpecificEndpointLimits(t *testing.T) {
	for _, tc := range []struct {
		speed    uint32
		packet   uint16
		interval byte
		valid    bool
	}{
		{1, 8, 10, true}, {1, 9, 10, false}, {1, 8, 9, false}, {2, 64, 255, true}, {2, 65, 10, false}, {3, 1024, 16, true}, {3, 1025, 16, false}, {3, 8, 17, false}, {5, 1024, 16, false}, {0, 8, 10, false},
	} {
		p := hidConfiguration()
		binary.LittleEndian.PutUint16(p[31:33], tc.packet)
		p[33] = tc.interval
		c, e := usbip.ParseConfigurationDescriptor(p)
		if e != nil {
			t.Fatal(e)
		}
		if e = validateHIDRecords(c, tc.speed); (e == nil) != tc.valid {
			t.Fatal(tc, e)
		}
	}
	for _, tc := range []struct {
		speed uint32
		size  byte
		valid bool
	}{{1, 8, true}, {1, 64, false}, {2, 8, true}, {2, 64, true}, {2, 9, false}, {3, 64, true}, {3, 8, false}, {5, 9, false}} {
		if validControlPacket(tc.speed, tc.size) != tc.valid {
			t.Fatal(tc)
		}
	}
}

func FuzzHIDSnapshot(f *testing.F) {
	f.Add(hidConfiguration(), uint32(2))
	f.Add([]byte{}, uint32(0))
	f.Fuzz(func(t *testing.T, data []byte, speed uint32) {
		c, err := usbip.ParseConfigurationDescriptor(data)
		if err != nil {
			return
		}
		if err = validateHIDRecords(c, speed); err == nil {
			if speed < 1 || speed > 3 || len(data) > usbip.MaxConfigurationBytes || len(c.Records) < 3 || len(c.Records) > 32 {
				t.Fatal("unbounded profile accepted")
			}
		}
	})
}
