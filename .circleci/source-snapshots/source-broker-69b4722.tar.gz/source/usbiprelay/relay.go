// SPDX-License-Identifier: GPL-3.0-only
// Package usbiprelay bridges a trusted, already imported local USB/IP stream to
// an already authenticated ConcurrentDevice. It opens no listener or driver and
// grants no host/device authorization. Callers must establish those boundaries.
package usbiprelay

import (
	"context"
	"errors"
	"fmt"
	"net"
	"sync/atomic"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

// Serve transfers ownership of local and remote after argument validation.
// localDevice is the exact device ID expected from the caller's trusted local
// endpoint. Upstream device and sequence IDs are assigned only by remote. Its
// previous descriptor probes therefore cannot collide with local/kernel IDs.
// The caller must stop issuing its own transfers before handing remote over.
// Capacity is 1..64 and cannot exceed the remote client's configured capacity.
// EOF, cancellation and either peer's failure close both sides and join workers.
// This bounded non-ISO protocol relay is not a byte-transparent/kernel adapter.
func Serve(ctx context.Context, local net.Conn, remote *usbip.ConcurrentDevice, localDevice uint32, capacity int) (result error) {
	if ctx == nil || local == nil || remote == nil || localDevice == 0 || capacity < 1 || capacity > 64 || capacity > remote.Capacity() {
		return errors.New("trusted local stream, imported remote, device ID and compatible bounded capacity required")
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	run, cancel := context.WithCancelCause(ctx)
	watch, stopWatch := context.WithCancel(context.Background())
	backend := &forwarder{remote: remote, stopWatch: stopWatch}
	watchDone := make(chan struct{})
	go func() {
		defer close(watchDone)
		select {
		case <-remote.Done():
			if !backend.closing.Load() {
				cancel(fmt.Errorf("upstream USB/IP session closed: %w", remote.Err()))
				_ = local.Close()
			}
		case <-watch.Done():
		}
	}()
	defer func() {
		// Mark owner cleanup before closing upstream, so it cannot be mistaken for
		// an unsolicited remote failure by the single lifecycle watcher.
		backend.closing.Store(true)
		stopWatch()
		_ = local.Close()
		_ = remote.Close()
		cancel(nil)
		<-watchDone
	}()
	result = usbip.ServeImported(run, local, backend, localDevice, capacity)
	if cause := context.Cause(run); cause != nil {
		result = errors.Join(result, cause)
	}
	return result
}

type forwarder struct {
	remote    *usbip.ConcurrentDevice
	stopWatch context.CancelFunc
	closing   atomic.Bool
}

func (*forwarder) SerializeEndpoints() bool { return true }
func (f *forwarder) Transfer(ctx context.Context, r usbip.Request) (usbip.TransferResult, error) {
	// Remote.Transfer assigns its own device and globally unique upstream ID.
	// Local SUBMIT/UNLINK and completion identities stay in ServeImported.
	r.Sequence, r.Device = 0, 0
	reply, err := f.remote.Transfer(ctx, r)
	if err != nil {
		return usbip.TransferResult{}, err
	}
	return usbip.TransferResult{Status: reply.Status, ActualLength: reply.ActualLength, Data: reply.Data}, nil
}
func (f *forwarder) Close() error {
	f.closing.Store(true)
	f.stopWatch()
	return f.remote.Close()
}
