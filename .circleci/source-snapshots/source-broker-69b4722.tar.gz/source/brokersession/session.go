// SPDX-License-Identifier: GPL-3.0-only
// Package brokersession is a bounded, independently authored local subprocess
// interface to an explicitly consented, mutually authenticated USB/IP import.
// It never attaches a USB device to the local operating system.
package brokersession

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"sync"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/localtls"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

const MaxLine = 64 << 10
const MaxPayload = 16 << 10

// Config is versioned independently of the stock USBP transport. Credentials
// are operator-provisioned local file paths; no private key material is emitted.
type Config struct {
	Version         int    `json:"version"`
	Address         string `json:"address"`
	CertificateFile string `json:"certificate_file"`
	KeyFile         string `json:"key_file"`
	CAFile          string `json:"ca_file"`
	ServerName      string `json:"server_name"`
	ServerPin       string `json:"server_pin"`
	BusID           string `json:"bus_id"`
	Consent         bool   `json:"consent"`
	Capacity        int    `json:"capacity"`
}

type command struct {
	Op        string  `json:"op"`
	ID        string  `json:"id,omitempty"`
	Direction *uint32 `json:"direction,omitempty"`
	Endpoint  *uint32 `json:"endpoint,omitempty"`
	Length    *int32  `json:"length,omitempty"`
	Flags     uint32  `json:"flags,omitempty"`
	Setup     []int   `json:"setup,omitempty"`
	Data      []byte  `json:"data,omitempty"`
	TimeoutMS int     `json:"timeout_ms,omitempty"`
}
type frame struct {
	data []byte
	err  error
}
type result struct {
	id    string
	reply usbip.Reply
	err   error
}
type sessionDevice interface {
	Description() usbip.DeviceDescription
	Transfer(context.Context, usbip.Request) (usbip.Reply, error)
	Close() error
}
type opener func(context.Context, Config) (sessionDevice, error)

// decodeObject rejects duplicate and unknown top-level fields, non-objects and
// trailing values. The protocol has no nested input objects.
func decodeObject(data []byte, value any) error {
	if len(data) == 0 || len(data) > MaxLine {
		return errors.New("invalid JSON line length")
	}
	check := json.NewDecoder(bytes.NewReader(data))
	first, err := check.Token()
	if err != nil || first != json.Delim('{') {
		return errors.New("JSON object required")
	}
	seen := map[string]bool{}
	allowed := map[string]bool{}
	typ := reflect.TypeOf(value).Elem()
	for i := 0; i < typ.NumField(); i++ {
		name := typ.Field(i).Tag.Get("json")
		if at := bytes.IndexByte([]byte(name), ','); at >= 0 {
			name = name[:at]
		}
		allowed[name] = true
	}
	for check.More() {
		token, err := check.Token()
		if err != nil {
			return err
		}
		key, ok := token.(string)
		if !ok || seen[key] || !allowed[key] {
			return errors.New("duplicate or unknown JSON field")
		}
		seen[key] = true
		var raw json.RawMessage
		if err := check.Decode(&raw); err != nil {
			return err
		}
	}
	if _, err := check.Token(); err != nil {
		return err
	}
	if _, err := check.Token(); err != io.EOF {
		return errors.New("trailing JSON value")
	}
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	return d.Decode(value)
}

func validateConfig(c Config) error {
	if c.Version != 1 || !c.Consent || c.Capacity < 1 || c.Capacity > 16 || c.ServerName == "" || len(c.ServerName) > 253 {
		return errors.New("version, explicit consent, capacity and server name required")
	}
	if err := localtls.ValidateAddress(c.Address); err != nil {
		return err
	}
	if _, err := usbip.EncodeNegotiationRequest(usbip.NegotiationRequest{Code: usbip.RequestImport, BusID: c.BusID}); err != nil {
		return err
	}
	pin, err := hex.DecodeString(c.ServerPin)
	if err != nil || len(pin) != 32 || bytes.Equal(pin, make([]byte, 32)) {
		return errors.New("exact nonzero server certificate pin required")
	}
	for _, p := range []string{c.CertificateFile, c.KeyFile, c.CAFile} {
		if !filepath.IsAbs(p) || len(p) > 4096 {
			return errors.New("absolute credential file paths required")
		}
	}
	return nil
}
func readCredential(path string) ([]byte, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, errors.New("credential file unavailable")
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil || !info.Mode().IsRegular() || info.Size() <= 0 || info.Size() > 1<<20 {
		return nil, errors.New("bounded regular credential file required")
	}
	b, err := io.ReadAll(io.LimitReader(f, (1<<20)+1))
	if err != nil || len(b) > 1<<20 {
		return nil, errors.New("credential file read failed")
	}
	return b, nil
}
func openDevice(ctx context.Context, c Config) (sessionDevice, error) {
	certificate, err := readCredential(c.CertificateFile)
	if err != nil {
		return nil, err
	}
	key, err := readCredential(c.KeyFile)
	if err != nil {
		return nil, err
	}
	ca, err := readCredential(c.CAFile)
	if err != nil {
		return nil, err
	}
	identity, err := tls.X509KeyPair(certificate, key)
	if err != nil {
		return nil, errors.New("invalid client identity")
	}
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(ca) {
		return nil, errors.New("invalid server CA")
	}
	pin, _ := hex.DecodeString(c.ServerPin)
	var exact [32]byte
	copy(exact[:], pin)
	return localtls.OpenConcurrentDevice(ctx, c.Address, localtls.ClientIdentity{Certificate: identity, Roots: roots, ServerName: c.ServerName, ServerPin: exact}, c.BusID, c.Capacity)
}

var validID = regexp.MustCompile(`^[A-Za-z0-9_.-]{1,64}$`)

func (c command) request() (usbip.Request, error) {
	if !validID.MatchString(c.ID) || c.Direction == nil || c.Endpoint == nil || c.Length == nil || *c.Length < 0 || *c.Length > MaxPayload || c.TimeoutMS < 0 || c.TimeoutMS > 10000 || (len(c.Setup) != 0 && len(c.Setup) != 8) {
		return usbip.Request{}, errors.New("invalid transfer fields")
	}
	r := usbip.Request{Command: usbip.CmdSubmit, Direction: *c.Direction, Endpoint: *c.Endpoint, TransferLength: *c.Length, Flags: c.Flags, Data: c.Data, PacketCount: -1}
	for i, v := range c.Setup {
		if v < 0 || v > 255 {
			return r, errors.New("invalid setup byte")
		}
		r.Setup[i] = byte(v)
	}
	_, err := usbip.EncodeRequest(r)
	return r, err
}
func (c command) controlOnly() bool {
	return c.Direction == nil && c.Endpoint == nil && c.Length == nil && c.Flags == 0 && len(c.Setup) == 0 && len(c.Data) == 0 && c.TimeoutMS == 0
}

// Run owns input until it returns. The caller must make output writes bounded
// and interruptible (the CLI uses a five-second pipe write deadline). Initial
// config and commands are newline-delimited JSON. EOF cancels and joins work.
func Run(ctx context.Context, input io.ReadCloser, output io.Writer) error {
	return run(ctx, input, output, openDevice)
}

// RunProcess is exclusively for a short-lived executable that exits immediately
// after return. It joins all device workers and closes the authenticated session,
// but does not wait for an inherited stdin read that some OS pipes cannot cancel.
// Never use it in a persistent host process: Run is the reusable library API.
func RunProcess(ctx context.Context, input io.Reader, output io.Writer) error {
	if input == nil {
		return errors.New("input required")
	}
	return runIO(ctx, io.NopCloser(input), output, openDevice, false)
}
func run(ctx context.Context, input io.ReadCloser, output io.Writer, open opener) error {
	return runIO(ctx, input, output, open, true)
}
func runIO(ctx context.Context, input io.ReadCloser, output io.Writer, open opener, joinInput bool) error {
	if ctx == nil || input == nil || output == nil {
		return errors.New("context and streams required")
	}
	run, cancel := context.WithCancel(ctx)
	frames := make(chan frame, 1)
	readerDone := make(chan struct{})
	go func() {
		defer close(readerDone)
		defer close(frames)
		s := bufio.NewScanner(input)
		s.Buffer(make([]byte, 4096), MaxLine+1)
		for s.Scan() {
			b := append([]byte(nil), s.Bytes()...)
			if len(b) > MaxLine {
				select {
				case frames <- frame{err: errors.New("input line too long")}:
				case <-run.Done():
				}
				return
			}
			select {
			case frames <- frame{data: b}:
			case <-run.Done():
				return
			}
		}
		if err := s.Err(); err != nil {
			select {
			case frames <- frame{err: errors.New("input read failed")}:
			case <-run.Done():
			}
		}
	}()
	stopRead := context.AfterFunc(run, func() {
		if joinInput {
			_ = input.Close()
		}
	})
	defer func() {
		cancel()
		stopRead()
		if joinInput {
			_ = input.Close()
			<-readerDone
		}
	}()
	write := func(event any) error { return json.NewEncoder(output).Encode(event) }
	var first frame
	select {
	case f, ok := <-frames:
		if !ok {
			return errors.New("session config required")
		}
		first = f
	case <-run.Done():
		return run.Err()
	}
	var config Config
	if first.err != nil || decodeObject(first.data, &config) != nil || validateConfig(config) != nil {
		_ = write(map[string]any{"event": "error", "error": "invalid_config"})
		return errors.New("invalid session configuration")
	}
	d, err := open(run, config)
	if err != nil {
		_ = write(map[string]any{"event": "error", "error": "import_failed"})
		return errors.New("authenticated device import failed")
	}
	var deviceDone <-chan struct{}
	if state, ok := d.(interface{ Done() <-chan struct{} }); ok {
		deviceDone = state.Done()
	}
	active := map[string]context.CancelFunc{}
	finished := make(chan result, config.Capacity)
	var workers sync.WaitGroup
	defer func() { cancel(); _ = d.Close(); workers.Wait() }()
	desc := d.Description()
	if err := write(map[string]any{"event": "ready", "protocol_version": 1, "role": "usbip-importer-client", "os_attached": false, "capacity": config.Capacity, "device": map[string]any{"bus_id": desc.BusID, "bus": desc.Bus, "number": desc.Number, "vendor_id": desc.Vendor, "product_id": desc.Product}}); err != nil {
		return err
	}
	stopping := false
	for !stopping {
		select {
		case <-run.Done():
			return run.Err()
		case <-deviceDone:
			_ = write(map[string]any{"event": "error", "error": "session_closed"})
			return errors.New("imported device session closed")
		case r := <-finished:
			if stop, ok := active[r.id]; ok {
				stop()
				delete(active, r.id)
			}
			event := map[string]any{"event": "complete", "id": r.id}
			if r.err != nil {
				code := "transfer_failed"
				if errors.Is(r.err, context.Canceled) {
					code = "canceled"
				} else if errors.Is(r.err, context.DeadlineExceeded) {
					code = "deadline_exceeded"
				}
				event["error"] = code
			} else {
				event["status"] = r.reply.Status
				event["actual_length"] = r.reply.ActualLength
				data := r.reply.Data
				if data == nil {
					data = []byte{}
				}
				event["data"] = data
			}
			if err := write(event); err != nil {
				return err
			}
		case f, ok := <-frames:
			if !ok {
				stopping = true
				continue
			}
			var c command
			if f.err != nil || decodeObject(f.data, &c) != nil {
				_ = write(map[string]any{"event": "error", "error": "invalid_command"})
				return errors.New("invalid session command")
			}
			switch c.Op {
			case "close":
				if c.ID != "" || !c.controlOnly() {
					return errors.New("invalid close command")
				}
				stopping = true
			case "cancel":
				if !validID.MatchString(c.ID) || !c.controlOnly() {
					return errors.New("invalid cancel command")
				}
				stop, ok := active[c.ID]
				if !ok {
					if err := write(map[string]any{"event": "error", "id": c.ID, "error": "unknown_transfer"}); err != nil {
						return err
					}
					continue
				}
				stop()
				if err := write(map[string]any{"event": "cancel_requested", "id": c.ID}); err != nil {
					return err
				}
			case "transfer":
				r, err := c.request()
				if err != nil {
					_ = write(map[string]any{"event": "error", "error": "invalid_transfer"})
					return errors.New("invalid transfer")
				}
				code := ""
				if _, ok := active[c.ID]; ok {
					code = "duplicate_transfer"
				} else if len(active) == config.Capacity {
					code = "capacity_exhausted"
				}
				if code != "" {
					if err := write(map[string]any{"event": "error", "id": c.ID, "error": code}); err != nil {
						return err
					}
					continue
				}
				timeout := 10 * time.Second
				if c.TimeoutMS > 0 {
					timeout = time.Duration(c.TimeoutMS) * time.Millisecond
				}
				transfer, stop := context.WithTimeout(run, timeout)
				active[c.ID] = stop
				workers.Add(1)
				go func(id string, r usbip.Request) {
					defer workers.Done()
					reply, err := d.Transfer(transfer, r)
					finished <- result{id: id, reply: reply, err: err}
				}(c.ID, r)
			default:
				_ = write(map[string]any{"event": "error", "error": "invalid_operation"})
				return errors.New("unknown session operation")
			}
		}
	}
	cancel()
	_ = d.Close()
	workers.Wait()
	// EOF/close is a terminal session operation; no per-transfer completion is
	// promised afterward. The stopped event guarantees local workers are joined.
	return write(map[string]any{"event": "stopped"})
}
