// SPDX-License-Identifier: GPL-3.0-only
package brokersession_test

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/brokersession"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/localtls"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

type deniedRegistry struct{ opens atomic.Int32 }

func (*deniedRegistry) List(context.Context, string) ([]usbip.DeviceDescription, error) {
	return nil, errors.New("denied")
}
func (r *deniedRegistry) Open(context.Context, string, string) (usbip.DeviceDescription, usbip.DeviceBackend, error) {
	r.opens.Add(1)
	return usbip.DeviceDescription{}, nil, errors.New("operator has not authorized this device")
}

type countedListener struct {
	net.Listener
	accepted atomic.Int32
}

func (l *countedListener) Accept() (net.Conn, error) {
	c, err := l.Listener.Accept()
	if err == nil {
		l.accepted.Add(1)
	}
	return c, err
}

// Every negative case runs the real executable and TLS service. The registry
// always refuses device access, so the fixture cannot acquire a device even if
// a regression accidentally gets past an earlier trust/consent gate.
func TestPortableSessionRejectsUnauthorizedStartup(t *testing.T) {
	binary := os.Getenv("BROKER_SESSION_BINARY")
	if binary == "" {
		t.Skip("build script supplies exact BROKER_SESSION_BINARY")
	}
	for _, mode := range []string{"missing_consent", "forbidden_address", "wrong_server_name", "wrong_server_pin", "wrong_server_ca", "wrong_client_pin", "untrusted_client", "device_not_authorized"} {
		t.Run(mode, func(t *testing.T) {
			server, client, ca, pool := sessionIdentities(t)
			_, otherClient, otherCA, _ := sessionIdentities(t)
			acceptedClient := sha256.Sum256(client.Certificate[0])
			if mode == "wrong_client_pin" {
				acceptedClient = sha256.Sum256(otherClient.Certificate[0])
			}
			if mode == "untrusted_client" {
				client = otherClient
			}
			raw, err := net.Listen("tcp", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			listener := &countedListener{Listener: raw}
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			defer cancel()
			registry := &deniedRegistry{}
			done := make(chan error, 1)
			go func() { done <- localtls.ServeTLS(ctx, listener, server, pool, acceptedClient, registry) }()
			defer func() {
				cancel()
				select {
				case <-done:
				case <-time.After(time.Second):
					t.Error("TLS server did not join")
				}
			}()
			dir := t.TempDir()
			write := func(name string, data []byte) string {
				p := filepath.Join(dir, name)
				if err := os.WriteFile(p, data, 0600); err != nil {
					t.Fatal(err)
				}
				return p
			}
			key, err := x509.MarshalPKCS8PrivateKey(client.PrivateKey)
			if err != nil {
				t.Fatal(err)
			}
			keyPEM := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: key})
			pin := sha256.Sum256(server.Certificate[0])
			config := brokersession.Config{Version: 1, Address: listener.Addr().String(), CertificateFile: write("client.pem", pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: client.Certificate[0]})), KeyFile: write("key.pem", keyPEM), CAFile: write("ca.pem", pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: ca})), ServerName: "localhost", ServerPin: hex.EncodeToString(pin[:]), BusID: "1-2", Consent: true, Capacity: 1}
			expectedError := "import_failed"
			switch mode {
			case "missing_consent":
				config.Consent = false
				expectedError = "invalid_config"
			case "forbidden_address":
				config.Address = "203.0.113.1:3241"
				expectedError = "invalid_config"
			case "wrong_server_name":
				config.ServerName = "wrong.invalid"
			case "wrong_server_pin":
				config.ServerPin = strings.Repeat("01", 32)
			case "wrong_server_ca":
				config.CAFile = write("other-ca.pem", pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: otherCA}))
			}
			encoded, err := json.Marshal(config)
			if err != nil {
				t.Fatal(err)
			}
			cmd := exec.CommandContext(ctx, binary, "--session-stdin")
			cmd.WaitDelay = time.Second
			cmd.Stdin = bytes.NewReader(append(encoded, '\n'))
			var out, stderr bytes.Buffer
			cmd.Stdout, cmd.Stderr = &out, &stderr
			err = cmd.Run()
			if err == nil || ctx.Err() != nil {
				t.Fatal("startup did not promptly reject", err, ctx.Err())
			}
			var event map[string]any
			if err := json.Unmarshal(bytes.TrimSpace(out.Bytes()), &event); err != nil {
				t.Fatal("one typed error event required", err, out.String())
			}
			if event["event"] != "error" || event["error"] != expectedError {
				t.Fatal(event)
			}
			if bytes.Contains(out.Bytes(), keyPEM) || bytes.Contains(stderr.Bytes(), keyPEM) || strings.Contains(out.String()+stderr.String(), "PRIVATE KEY") {
				t.Fatal("private key appeared in process output")
			}
			wantOpens := int32(0)
			if mode == "device_not_authorized" {
				wantOpens = 1
			}
			if got := registry.opens.Load(); got != wantOpens {
				t.Fatal("unauthorized registry access", got, wantOpens)
			}
			if expectedError == "invalid_config" && listener.accepted.Load() != 0 {
				t.Fatal("invalid configuration made a network connection")
			}
		})
	}
}
