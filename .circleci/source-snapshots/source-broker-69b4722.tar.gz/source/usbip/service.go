// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"errors"
	"io"
	"net"
	"sync"
	"time"
)

// Registry exposes only devices the authenticated principal may list or claim.
// Open must enforce operator consent and exclusive ownership, honor context and
// return actual backend capabilities. It must not silently detach protected OS
// devices. Returning an error may include a partial backend; it will be closed.
type Registry interface {
	List(context.Context, string) ([]DeviceDescription, error)
	Open(context.Context, string, string) (DeviceDescription, DeviceBackend, error)
}
type AuthorizeDeviceSession func(context.Context, string) error

type onceBackend struct {
	DeviceBackend
	once sync.Once
	err  error
}

func (b *onceBackend) SerializeEndpoints() bool {
	policy, ok := b.DeviceBackend.(EndpointOrderedBackend)
	return ok && policy.SerializeEndpoints()
}

func (b *onceBackend) Close() error {
	b.once.Do(func() { b.err = b.DeviceBackend.Close() })
	return b.err
}

func writeNegotiation(ctx context.Context, c net.Conn, b []byte) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	deadline := time.Now().Add(5 * time.Second)
	if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
		deadline = d
	}
	if err := c.SetWriteDeadline(deadline); err != nil {
		return err
	}
	for len(b) > 0 {
		n, err := c.Write(b)
		if err != nil {
			return err
		}
		if n <= 0 {
			return io.ErrShortWrite
		}
		b = b[n:]
	}
	return nil
}

// ServeDeviceSession connects negotiation to the imported URB runner. It owns
// conn once arguments validate. The connection must already be authenticated
// and encrypted, and principal must come from that verified transport, never a
// caller-controlled message field. This function creates no listener or keys.
// The session owner MUST cancel ctx on authorization revocation/disconnect.
func ServeDeviceSession(ctx context.Context, conn net.Conn, principal string, registry Registry, authorize AuthorizeDeviceSession, capacity int) (result error) {
	if ctx == nil || conn == nil || principal == "" || registry == nil || authorize == nil || capacity < 1 || capacity > 64 {
		return errors.New("authenticated session dependencies required")
	}
	stop := context.AfterFunc(ctx, func() { _ = conn.Close() })
	defer func() { stop(); _ = conn.Close() }()
	if err := authorize(ctx, principal); err != nil {
		return err
	}
	req, err := ReadNegotiationRequest(conn)
	if err != nil {
		return err
	}
	if err = ctx.Err(); err != nil {
		return err
	}
	if err = authorize(ctx, principal); err != nil {
		return err
	}
	if req.Code == RequestDeviceList {
		ds, err := registry.List(ctx, principal)
		if err != nil {
			return err
		}
		b, err := EncodeDeviceListReply(ds)
		if err != nil {
			return err
		}
		if err = authorize(ctx, principal); err != nil {
			return err
		}
		return writeNegotiation(ctx, conn, b)
	}
	description, rawBackend, openErr := registry.Open(ctx, principal, req.BusID)
	var backend *onceBackend
	if rawBackend != nil {
		backend = &onceBackend{DeviceBackend: rawBackend}
		defer func() { result = errors.Join(result, backend.Close()) }()
	}
	fail := func(reason error) error {
		b, _ := EncodeImportReply(1, nil)
		return errors.Join(reason, writeNegotiation(ctx, conn, b))
	}
	if openErr != nil {
		return fail(openErr)
	}
	if backend == nil || description.BusID != req.BusID {
		return fail(errors.New("registry did not claim requested device"))
	}
	// USB/IP packs the bus and device number into the two 16-bit halves.
	if description.Bus > 65535 || description.Number > 65535 {
		return fail(errors.New("device address exceeds USB/IP bounds"))
	}
	b, err := EncodeImportReply(0, &description)
	if err != nil {
		return fail(err)
	}
	if err = ctx.Err(); err != nil {
		return err
	}
	if err = authorize(ctx, principal); err != nil {
		return err
	}
	if err = writeNegotiation(ctx, conn, b); err != nil {
		return err
	}
	device := description.Bus<<16 | description.Number
	return ServeImported(ctx, conn, backend, device, capacity)
}
