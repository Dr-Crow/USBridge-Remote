// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"errors"
	"net"
	"sync"
	"testing"
	"time"
)

func concurrentRequest() Request { r := request(0); r.Device = 0; return r }

func TestConcurrentClientOutOfOrder(t *testing.T) {
	const count = 8
	arrivals := make(chan uint32, count)
	release := make([]chan struct{}, count+1)
	for i := 1; i <= count; i++ {
		release[i] = make(chan struct{})
	}
	registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
			arrivals <- r.Sequence
			select {
			case <-release[r.Sequence]:
				return TransferResult{ActualLength: 1, Data: []byte{byte(r.Sequence)}}, nil
			case <-ctx.Done():
				return TransferResult{}, ctx.Err()
			}
		}}, nil
	}}
	server, conn := net.Pipe()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() { done <- ServeDeviceSession(ctx, server, "paired-test-owner", registry, allowTestOwner, count) }()
	device, err := ImportConcurrentDevice(context.Background(), conn, "1-2", count)
	if err != nil {
		t.Fatal(err)
	}
	defer device.Close()
	replies := make(chan Reply, count)
	var wg sync.WaitGroup
	for i := 0; i < count; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r, e := device.Transfer(context.Background(), concurrentRequest())
			if e != nil {
				t.Error(e)
			}
			replies <- r
		}()
	}
	for i := 0; i < count; i++ {
		select {
		case <-arrivals:
		case <-time.After(time.Second):
			t.Fatal("submits did not pipeline")
		}
	}
	for i := count; i > 0; i-- {
		close(release[i])
		select {
		case r := <-replies:
			if r.Sequence != uint32(i) || len(r.Data) != 1 || r.Data[0] != byte(i) {
				t.Fatal(r)
			}
		case <-time.After(time.Second):
			t.Fatal("completion blocked behind prior URB")
		}
	}
	wg.Wait()
	device.Close()
	if e := awaitSession(t, done); e != nil {
		t.Fatal(e)
	}
}

func TestConcurrentQueuedCancellationAndActiveCancellation(t *testing.T) {
	entered := make(chan struct{})
	exited := make(chan struct{})
	registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
			close(entered)
			<-ctx.Done()
			close(exited)
			return TransferResult{}, ctx.Err()
		}}, nil
	}}
	conn, done := serviceFixture(t, registry, allowTestOwner)
	device, e := ImportConcurrentDevice(context.Background(), conn, "1-2", 1)
	if e != nil {
		t.Fatal(e)
	}
	defer device.Close()
	ctx, cancel := context.WithCancel(context.Background())
	active := make(chan error, 1)
	go func() { _, e := device.Transfer(ctx, concurrentRequest()); active <- e }()
	<-entered
	queued, stop := context.WithCancel(context.Background())
	stop()
	if _, e = device.Transfer(queued, concurrentRequest()); !errors.Is(e, context.Canceled) {
		t.Fatal(e)
	}
	select {
	case <-device.done:
		t.Fatal("queued cancellation killed active request")
	default:
	}
	// Wait until the SUBMIT writer has finished before canceling an active URB.
	device.writer <- struct{}{}
	<-device.writer
	cancel()
	select {
	case e := <-active:
		if !errors.Is(e, context.Canceled) {
			t.Fatal(e)
		}
	case <-time.After(time.Second):
		t.Fatal("active cancel stuck")
	}
	select {
	case <-device.done:
		t.Fatal("per-transfer cancellation closed session")
	default:
	}
	device.Close()
	_ = awaitSession(t, done)
	select {
	case <-exited:
	default:
		t.Fatal("backend not canceled")
	}
}

func TestConcurrentRejectsUnmatchedCompletion(t *testing.T) {
	server, client := net.Pipe()
	defer server.Close()
	serverDone := make(chan struct{})
	go func() {
		defer close(serverDone)
		_, _ = ReadNegotiationRequest(server)
		desc := sampleDevice()
		b, _ := EncodeImportReply(0, &desc)
		_ = writeAll(server, b)
		r, e := ReadRequest(server)
		if e != nil {
			return
		}
		r.Sequence += 100
		b, _ = EncodeSubmitReply(r, 0, 0, nil)
		_ = writeAll(server, b)
	}()
	d, e := ImportConcurrentDevice(context.Background(), client, "1-2", 2)
	if e != nil {
		t.Fatal(e)
	}
	defer d.Close()
	if _, e = d.Transfer(context.Background(), concurrentRequest()); e == nil {
		t.Fatal("unmatched completion accepted")
	}
	<-serverDone
}

func TestConcurrentInvalidCapacityRetainsConnection(t *testing.T) {
	for _, n := range []int{0, 65} {
		s, c := net.Pipe()
		if d, e := ImportConcurrentDevice(context.Background(), c, "1-2", n); e == nil || d != nil {
			t.Fatal(n)
		}
		if e := c.SetDeadline(time.Now().Add(time.Second)); e != nil {
			t.Fatal("invalid constructor consumed connection", e)
		}
		s.Close()
		c.Close()
	}
}

func TestConcurrentUnlinkKeepsOtherTransfersAndCapacity(t *testing.T) {
	entered := make(chan uint32, 4)
	release := make(chan struct{})
	registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
			entered <- r.Endpoint
			if r.Endpoint == 1 {
				<-ctx.Done()
				return TransferResult{}, ctx.Err()
			}
			select {
			case <-release:
				return TransferResult{ActualLength: 1, Data: []byte{byte(r.Endpoint)}}, nil
			case <-ctx.Done():
				return TransferResult{}, ctx.Err()
			}
		}}, nil
	}}
	server, conn := net.Pipe()
	run, stop := context.WithTimeout(context.Background(), 3*time.Second)
	defer stop()
	done := make(chan error, 1)
	go func() { done <- ServeDeviceSession(run, server, "paired-test-owner", registry, allowTestOwner, 2) }()
	d, err := ImportConcurrentDevice(run, conn, "1-2", 2)
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	ctx, cancel := context.WithCancel(run)
	canceled := make(chan error, 1)
	r := concurrentRequest()
	r.Endpoint = 1
	go func() { _, err := d.Transfer(ctx, r); canceled <- err }()
	if <-entered != 1 {
		t.Fatal("wrong first endpoint")
	}
	other := make(chan Reply, 1)
	go func() {
		r := concurrentRequest()
		r.Endpoint = 2
		reply, err := d.Transfer(run, r)
		if err != nil {
			t.Error(err)
		}
		other <- reply
	}()
	if <-entered != 2 {
		t.Fatal("wrong second endpoint")
	}
	d.writer <- struct{}{}
	<-d.writer
	cancel()
	if err := <-canceled; !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	select {
	case <-d.done:
		t.Fatal("unrelated URB was interrupted")
	default:
	}
	// Reuse the canceled slot while the other URB is still pending. A successful
	// UNLINK ack must not outrun release of the server's capacity reservation.
	third := make(chan Reply, 1)
	go func() {
		r := concurrentRequest()
		r.Endpoint = 3
		reply, err := d.Transfer(run, r)
		if err != nil {
			t.Error(err)
		}
		third <- reply
	}()
	if <-entered != 3 {
		t.Fatal("canceled slot was not reusable")
	}
	close(release)
	if r := <-other; len(r.Data) != 1 || r.Data[0] != 2 {
		t.Fatal(r)
	}
	if r := <-third; len(r.Data) != 1 || r.Data[0] != 3 {
		t.Fatal(r)
	}
	d.Close()
	if err := awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
}

func TestConcurrentUnlinkCompletionOrder(t *testing.T) {
	for _, ackFirst := range []bool{false, true} {
		t.Run(map[bool]string{false: "completion first", true: "ack first"}[ackFirst], func(t *testing.T) {
			server, client := net.Pipe()
			defer server.Close()
			entered := make(chan struct{})
			serverDone := make(chan error, 1)
			go func() {
				_, _ = ReadNegotiationRequest(server)
				desc := sampleDevice()
				b, _ := EncodeImportReply(0, &desc)
				_ = writeAll(server, b)
				r, err := ReadRequest(server)
				if err != nil {
					serverDone <- err
					return
				}
				close(entered)
				u, err := ReadRequest(server)
				if err != nil {
					serverDone <- err
					return
				}
				if u.Command != CmdUnlink || u.UnlinkSequence != r.Sequence || u.Sequence <= r.Sequence || u.Device != r.Device {
					serverDone <- errors.New("invalid unlink identity")
					return
				}
				reply, _ := EncodeSubmitReply(r, 0, 1, []byte{4})
				ack := EncodeUnlinkReply(u.Sequence, 0)
				if ackFirst {
					_ = writeAll(server, ack)
					_ = writeAll(server, reply)
				} else {
					_ = writeAll(server, reply)
					_ = writeAll(server, ack)
				}
				r, err = ReadRequest(server)
				if err == nil {
					reply, _ = EncodeSubmitReply(r, 0, 1, []byte{5})
					err = writeAll(server, reply)
				}
				serverDone <- err
			}()
			d, err := ImportConcurrentDevice(context.Background(), client, "1-2", 1)
			if err != nil {
				t.Fatal(err)
			}
			defer d.Close()
			ctx, cancel := context.WithCancel(context.Background())
			completed := make(chan error, 1)
			go func() { _, err := d.Transfer(ctx, concurrentRequest()); completed <- err }()
			<-entered
			d.writer <- struct{}{}
			<-d.writer
			cancel()
			if err := <-completed; !errors.Is(err, context.Canceled) {
				t.Fatal(err)
			}
			r, err := d.Transfer(context.Background(), concurrentRequest())
			if err != nil || len(r.Data) != 1 || r.Data[0] != 5 {
				t.Fatal(r, err)
			}
			if err := <-serverDone; err != nil {
				t.Fatal(err)
			}
		})
	}
}

func TestConcurrentUnlinkInvalidStatusIsFatal(t *testing.T) {
	server, client := net.Pipe()
	defer server.Close()
	entered := make(chan struct{})
	go func() {
		_, _ = ReadNegotiationRequest(server)
		desc := sampleDevice()
		b, _ := EncodeImportReply(0, &desc)
		_ = writeAll(server, b)
		_, _ = ReadRequest(server)
		close(entered)
		u, err := ReadRequest(server)
		if err == nil {
			_ = writeAll(server, EncodeUnlinkReply(u.Sequence, 7))
		}
	}()
	d, err := ImportConcurrentDevice(context.Background(), client, "1-2", 1)
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	ctx, cancel := context.WithCancel(context.Background())
	completed := make(chan error, 1)
	go func() { _, err := d.Transfer(ctx, concurrentRequest()); completed <- err }()
	<-entered
	d.writer <- struct{}{}
	<-d.writer
	cancel()
	if err := <-completed; !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	select {
	case <-d.done:
	default:
		t.Fatal("invalid cancellation response accepted")
	}
}

func TestConcurrentUnlinkCleanupDeadlineIsFatal(t *testing.T) {
	// Exercise the bounded cleanup path directly with a shorter deadline; the
	// public Transfer method always allows a fixed five seconds for cleanup.
	server, client := net.Pipe()
	defer server.Close()
	c := &ConcurrentDevice{conn: client, next: 2, pending: make(map[uint32]*pendingTransfer), done: make(chan struct{}), writer: make(chan struct{}, 1)}
	p := &pendingTransfer{request: request(1), result: make(chan Reply, 1)}
	c.pending[1] = p
	go func() { _, _ = ReadRequest(server) }()
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Millisecond)
	defer cancel()
	if err := c.retireCanceled(ctx, p); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	select {
	case <-c.done:
	default:
		t.Fatal("unsettled cancellation left session open")
	}
}

func TestConcurrentConnectionLifecycle(t *testing.T) {
	registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) { return TransferResult{}, nil }}, nil
	}}
	conn, done := serviceFixture(t, registry, allowTestOwner)
	d, err := ImportConcurrentDevice(context.Background(), conn, "1-2", 1)
	if err != nil {
		t.Fatal(err)
	}
	if d.Err() != nil {
		t.Fatal(d.Err())
	}
	select {
	case <-d.Done():
		t.Fatal("new connection closed")
	default:
	}
	d.Close()
	select {
	case <-d.Done():
	default:
		t.Fatal("close did not signal lifecycle")
	}
	if !errors.Is(d.Err(), net.ErrClosed) {
		t.Fatal(d.Err())
	}
	if err := awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
}
