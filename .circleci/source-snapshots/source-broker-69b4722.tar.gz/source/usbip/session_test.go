// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"sync/atomic"
	"testing"
	"time"
)

func serveFixture(t *testing.T, b DeviceBackend) (net.Conn, context.CancelFunc, <-chan error) {
	t.Helper()
	server, client := net.Pipe()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	done := make(chan error, 1)
	go func() { done <- ServeImported(ctx, server, b, 7, 2) }()
	_ = client.SetDeadline(time.Now().Add(2 * time.Second))
	t.Cleanup(func() { cancel(); _ = client.Close() })
	return client, cancel, done
}
func sendRequest(t *testing.T, c net.Conn, r Request) {
	t.Helper()
	b, err := EncodeRequest(r)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = c.Write(b); err != nil {
		t.Fatal(err)
	}
}
func awaitSession(t *testing.T, done <-chan error) error {
	t.Helper()
	select {
	case err := <-done:
		return err
	case <-time.After(4 * time.Second):
		t.Fatal("session failed to clean up")
		return nil
	}
}
func TestImportedSessionSubmitAndDisconnect(t *testing.T) {
	var closed atomic.Bool
	c, _, done := serveFixture(t, &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) {
		return TransferResult{ActualLength: 3, Data: []byte{1, 2, 3}}, nil
	}, close: func() error { closed.Store(true); return nil }})
	req := request(1)
	sendRequest(t, c, req)
	reply, err := ReadReply(c, func(seq uint32) (Request, bool) { return req, seq == 1 })
	if err != nil || !bytes.Equal(reply.Data, []byte{1, 2, 3}) {
		t.Fatal(err, reply)
	}
	_ = c.Close()
	if err = awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
	if !closed.Load() {
		t.Fatal("backend not closed")
	}
}
func TestImportedSessionCancelUnblocksReadAndBackend(t *testing.T) {
	entered := make(chan struct{})
	var active atomic.Int32
	c, cancel, done := serveFixture(t, &fakeDevice{transfer: func(ctx context.Context, _ Request) (TransferResult, error) {
		active.Add(1)
		defer active.Add(-1)
		close(entered)
		<-ctx.Done()
		return TransferResult{}, ctx.Err()
	}, close: func() error {
		if active.Load() != 0 {
			t.Error("close before join")
		}
		return nil
	}})
	sendRequest(t, c, request(1))
	<-entered
	cancel()
	if err := awaitSession(t, done); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}
func TestImportedSessionUnlink(t *testing.T) {
	c, _, done := serveFixture(t, &fakeDevice{transfer: func(ctx context.Context, _ Request) (TransferResult, error) {
		<-ctx.Done()
		return TransferResult{}, ctx.Err()
	}})
	sendRequest(t, c, request(1))
	sendRequest(t, c, Request{Command: CmdUnlink, Device: 7, Sequence: 2, UnlinkSequence: 1})
	var b [48]byte
	if _, err := io.ReadFull(c, b[:]); err != nil {
		t.Fatal(err)
	}
	if binary.BigEndian.Uint32(b[:]) != RetUnlink || int32(binary.BigEndian.Uint32(b[20:])) != -104 {
		t.Fatal("unlink acknowledgement")
	}
	_ = c.Close()
	if err := awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
}
func TestImportedSessionRejectsReplay(t *testing.T) {
	c, _, done := serveFixture(t, &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) { return TransferResult{}, nil }})
	req := request(5)
	sendRequest(t, c, req)
	if _, err := ReadReply(c, func(uint32) (Request, bool) { return req, true }); err != nil {
		t.Fatal(err)
	}
	sendRequest(t, c, req)
	if err := awaitSession(t, done); err == nil {
		t.Fatal("completed command replay accepted")
	}
}
func TestImportedSessionAllowsSequenceWrap(t *testing.T) {
	c, _, done := serveFixture(t, &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) { return TransferResult{}, nil }})
	for _, seq := range []uint32{^uint32(0), 0, 1} {
		req := request(seq)
		sendRequest(t, c, req)
		if _, err := ReadReply(c, func(s uint32) (Request, bool) { return req, s == seq }); err != nil {
			t.Fatal(err)
		}
	}
	_ = c.Close()
	if err := awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
}
func TestImportedSessionMalformedCloses(t *testing.T) {
	var closed atomic.Bool
	c, _, done := serveFixture(t, &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) {
		t.Error("malformed request reached backend")
		return TransferResult{}, nil
	}, close: func() error { closed.Store(true); return nil }})
	bad := make([]byte, 48)
	binary.BigEndian.PutUint32(bad, 99)
	if _, err := c.Write(bad); err != nil {
		t.Fatal(err)
	}
	if err := awaitSession(t, done); err == nil || !closed.Load() {
		t.Fatal(err, closed.Load())
	}
}

func TestImportedSessionOutOfOrderCompletions(t *testing.T) {
	release := make(chan struct{})
	c, _, done := serveFixture(t, &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
		if r.Sequence == 1 {
			select {
			case <-release:
			case <-ctx.Done():
				return TransferResult{}, ctx.Err()
			}
		}
		return TransferResult{ActualLength: 1, Data: []byte{byte(r.Sequence)}}, nil
	}})
	sendRequest(t, c, request(1))
	sendRequest(t, c, request(2))
	lookup := func(seq uint32) (Request, bool) { return request(seq), seq == 1 || seq == 2 }
	first, err := ReadReply(c, lookup)
	if err != nil || first.Sequence != 2 {
		t.Fatal(first, err)
	}
	close(release)
	second, err := ReadReply(c, lookup)
	if err != nil || second.Sequence != 1 {
		t.Fatal(second, err)
	}
	_ = c.Close()
	if err := awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
}

func TestImportedSessionCompletionPrecedesLateUnlink(t *testing.T) {
	for i := 0; i < 100; i++ {
		ready := make(chan struct{})
		c, _, done := serveFixture(t, &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) {
			close(ready)
			return TransferResult{ActualLength: 1, Data: []byte{1}}, nil
		}})
		sub := request(1)
		unlink := Request{Command: CmdUnlink, Device: 7, Sequence: 2, UnlinkSequence: 1}
		sendRequest(t, c, sub)
		<-ready
		sendRequest(t, c, unlink)
		lookup := func(s uint32) (Request, bool) {
			if s == 1 {
				return sub, true
			}
			return unlink, s == 2
		}
		first, err := ReadReply(c, lookup)
		if err != nil {
			t.Fatal(err)
		}
		if first.Command == RetSubmit {
			second, err := ReadReply(c, lookup)
			if err != nil || second.Command != RetUnlink || second.Status != 0 {
				t.Fatal(second, err)
			}
		} else if first.Command != RetUnlink || first.Status != -104 {
			t.Fatal("late unlink overtook winning completion", first)
		}
		c.Close()
		if err := awaitSession(t, done); err != nil {
			t.Fatal(err)
		}
	}
}

func TestImportedSessionAcceptsKernelSubmitUnlinkInterleaving(t *testing.T) {
	c, _, done := serveFixture(t, &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
		if r.Sequence == 1 {
			<-ctx.Done()
			return TransferResult{}, ctx.Err()
		}
		return TransferResult{}, nil
	}})
	one, three := request(1), request(3)
	unlink := Request{Command: CmdUnlink, Device: 7, Sequence: 2, UnlinkSequence: 1}
	sendRequest(t, c, one)
	sendRequest(t, c, three)
	sendRequest(t, c, unlink)
	lookup := func(seq uint32) (Request, bool) {
		if seq == 2 {
			return unlink, true
		}
		return three, seq == 3
	}
	var gotSubmit, gotUnlink bool
	for i := 0; i < 2; i++ {
		reply, err := ReadReply(c, lookup)
		if err != nil {
			t.Fatal(err)
		}
		if reply.Command == RetUnlink {
			if reply.Status != -104 {
				t.Fatal(reply)
			}
			gotUnlink = true
		} else {
			gotSubmit = true
		}
	}
	if !gotSubmit || !gotUnlink {
		t.Fatal("missing interleaved command result")
	}
	c.Close()
	if err := awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
}

func TestCommandHistoryBoundedAndOutOfOrder(t *testing.T) {
	var h commandHistory
	for _, seq := range []uint32{1, 3, 2, ^uint32(0), 0} {
		if !h.accept(seq) {
			t.Fatal(seq)
		}
	}
	for _, seq := range []uint32{1, 3, 2, ^uint32(0), 0} {
		if h.accept(seq) {
			t.Fatal("duplicate accepted", seq)
		}
	}
	for seq := uint32(10); seq < 10+recentCommandLimit; seq++ {
		if !h.accept(seq) {
			t.Fatal(seq)
		}
	}
	if len(h.seen) != recentCommandLimit {
		t.Fatal("unbounded history", len(h.seen))
	}
	if !h.accept(1) {
		t.Fatal("retired ID could not be reused outside bounded history")
	}
}

func TestLiveIDCannotBeReusedAfterHistoryEviction(t *testing.T) {
	c, _, done := serveFixture(t, &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
		<-ctx.Done()
		return TransferResult{}, ctx.Err()
	}})
	sendRequest(t, c, request(1))
	for seq := uint32(2); seq < 2+recentCommandLimit; seq++ {
		u := Request{Command: CmdUnlink, Sequence: seq, Device: 7, UnlinkSequence: 999999}
		sendRequest(t, c, u)
		if _, err := ReadReply(c, func(n uint32) (Request, bool) { return u, n == seq }); err != nil {
			t.Fatal(err)
		}
	}
	sendRequest(t, c, request(1))
	if err := awaitSession(t, done); err == nil {
		t.Fatal("live duplicate escaped after cache eviction")
	}
}
