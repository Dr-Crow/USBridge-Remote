// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"sync"
	"time"
)

// ServeImported serves URBs on a caller-supplied, already authenticated and
// imported connection. It creates no listener and implements no authentication.
// Pairing, encrypted transport, operator consent, and exclusive device claiming
// MUST precede this call. Cancel ctx when that authorization is revoked.
// After successful argument validation it owns conn and backend until cleanup.
// The backend must honor cancellation as required by DeviceBackend.
func ServeImported(ctx context.Context, conn net.Conn, backend DeviceBackend, device uint32, capacity int) (result error) {
	if ctx == nil || conn == nil || backend == nil {
		return errors.New("context, imported connection and backend required")
	}
	e, err := NewExecutor(ctx, backend, device, capacity)
	if err != nil {
		return err
	}
	run, cancel := context.WithCancel(ctx)
	stop := context.AfterFunc(run, func() { _ = conn.Close() })
	// Track only unsent SUBMIT completions. A late UNLINK must not overtake its
	// winning completion: Linux VHCI retires the original URB on RET_UNLINK.
	var sentMu sync.Mutex
	sent := make(map[uint32]chan struct{})
	var writeMu sync.Mutex
	write := func(data []byte) error {
		writeMu.Lock()
		defer writeMu.Unlock()
		if err := run.Err(); err != nil {
			return err
		}
		deadline := time.Now().Add(5 * time.Second)
		if d, ok := run.Deadline(); ok && d.Before(deadline) {
			deadline = d
		}
		if err := conn.SetWriteDeadline(deadline); err != nil {
			return err
		}
		for len(data) > 0 {
			n, err := conn.Write(data)
			if err != nil {
				return err
			}
			if n <= 0 {
				return io.ErrShortWrite
			}
			data = data[n:]
		}
		return nil
	}
	writerDone := make(chan error, 1)
	go func() {
		for {
			c, err := e.Next(run)
			if err != nil {
				writerDone <- err
				return
			}
			if err = write(c.Wire); err != nil {
				cancel()
				writerDone <- err
				return
			}
			sentMu.Lock()
			if signal, ok := sent[c.Sequence]; ok {
				close(signal)
				delete(sent, c.Sequence)
			}
			sentMu.Unlock()
		}
	}()
	defer func() {
		cancel()
		_ = conn.Close()
		stop()
		closeErr := e.Close()
		writerErr := <-writerDone
		if writerErr == context.Canceled || writerErr == io.EOF {
			writerErr = nil
		}
		result = errors.Join(result, closeErr, writerErr)
		if ctx.Err() != nil {
			result = errors.Join(ctx.Err(), result)
		}
	}()
	var recent commandHistory
	for {
		request, err := ReadRequest(conn)
		if err == io.EOF {
			return nil
		}
		if err != nil {
			return err
		}
		// USB/IP IDs correlate commands; Linux VHCI can send SUBMIT 1, SUBMIT
		// 3, then UNLINK 2 because it drains two queues independently. Enforce
		// live uniqueness and bounded recent duplicates, not monotonic order.
		sentMu.Lock()
		_, live := sent[request.Sequence]
		sentMu.Unlock()
		if live || !recent.accept(request.Sequence) {
			return errors.New("duplicate USB/IP command sequence")
		}
		if request.Command == CmdSubmit {
			sentMu.Lock()
			sent[request.Sequence] = make(chan struct{})
			sentMu.Unlock()
			if err = e.Submit(request); err != nil {
				return err
			}
		} else {
			sentMu.Lock()
			signal := sent[request.UnlinkSequence]
			sentMu.Unlock()
			ack, err := e.Unlink(request)
			if err != nil {
				return err
			}
			if int32(binary.BigEndian.Uint32(ack[20:24])) == 0 && signal != nil {
				select {
				case <-signal:
				case <-run.Done():
					return run.Err()
				}
			} else if signal != nil {
				sentMu.Lock()
				delete(sent, request.UnlinkSequence)
				sentMu.Unlock()
			}
			if err = write(ack); err != nil {
				return err
			}
		}
	}
}

// Authentication/replay resistance belongs to the encrypted transport. Keep a
// fixed recent-command cache to catch accidental duplicate application IDs while
// allowing legal out-of-order queues, wraparound and bounded lifetime memory.
// Still-live SUBMIT IDs are separately reserved until their response is sent.
const recentCommandLimit = 1024

type commandHistory struct {
	seen        map[uint32]struct{}
	order       [recentCommandLimit]uint32
	next, count int
}

func (h *commandHistory) accept(sequence uint32) bool {
	if h.seen == nil {
		h.seen = make(map[uint32]struct{}, recentCommandLimit)
	}
	if _, exists := h.seen[sequence]; exists {
		return false
	}
	if h.count == recentCommandLimit {
		delete(h.seen, h.order[h.next])
	} else {
		h.count++
	}
	h.order[h.next] = sequence
	h.next = (h.next + 1) % recentCommandLimit
	h.seen[sequence] = struct{}{}
	return true
}
