// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
)

// MaxConfigurationBytes is a defensive local limit, not the USB specification's
// maximum. Larger configurations are explicitly rejected, never truncated.
const MaxConfigurationBytes = 4096

// ConfigurationDescriptor preserves subordinate descriptors, including unknown
// class/vendor records. Records own their bytes. This does not select a config.
type ConfigurationDescriptor struct {
	Interfaces, Value, StringIndex, Attributes, MaxPower byte
	Records                                              [][]byte
}

func configurationLength(p []byte) (int, error) {
	if len(p) < 9 || p[0] != 9 || p[1] != 2 {
		return 0, errors.New("invalid configuration descriptor header")
	}
	n := int(binary.LittleEndian.Uint16(p[2:4]))
	if n < 9 || n > MaxConfigurationBytes {
		return 0, errors.New("configuration descriptor exceeds local bounds")
	}
	return n, nil
}

// ParseConfigurationDescriptor validates framing, not every class-specific
// descriptor's meaning. It must not be used to infer hardware support or consent.
func ParseConfigurationDescriptor(p []byte) (ConfigurationDescriptor, error) {
	n, err := configurationLength(p)
	if err != nil {
		return ConfigurationDescriptor{}, err
	}
	if n != len(p) {
		return ConfigurationDescriptor{}, errors.New("configuration total length mismatch")
	}
	d := ConfigurationDescriptor{Interfaces: p[4], Value: p[5], StringIndex: p[6], Attributes: p[7], MaxPower: p[8]}
	for at := 9; at < n; {
		if n-at < 2 {
			return ConfigurationDescriptor{}, errors.New("truncated subordinate descriptor")
		}
		size := int(p[at])
		if size < 2 || size > n-at {
			return ConfigurationDescriptor{}, errors.New("invalid subordinate descriptor length")
		}
		d.Records = append(d.Records, append([]byte(nil), p[at:at+size]...))
		at += size
	}
	return d, nil
}

// ReadConfigurationDescriptor reads a zero-based descriptor index (not a
// configuration value). Both requests are read-only standard GET_DESCRIPTOR.
// The existing import's authentication, device consent and deadlines still apply.
func (d *ImportedDevice) ReadConfigurationDescriptor(ctx context.Context, index byte) (ConfigurationDescriptor, error) {
	return readConfigurationDescriptor(ctx, d, index)
}

// ReadConfigurationDescriptor uses the same bounded read-only probe while
// retaining this client's upstream sequence namespace.
func (d *ConcurrentDevice) ReadConfigurationDescriptor(ctx context.Context, index byte) (ConfigurationDescriptor, error) {
	return readConfigurationDescriptor(ctx, d, index)
}

func readConfigurationDescriptor(ctx context.Context, d descriptorTransferer, index byte) (ConfigurationDescriptor, error) {
	read := func(size int) ([]byte, error) {
		setup := [8]byte{0x80, 6, index, 2, 0, 0, byte(size), byte(size >> 8)}
		r, err := d.Transfer(ctx, Request{Command: CmdSubmit, Direction: 1, TransferLength: int32(size), PacketCount: -1, Setup: setup})
		if err != nil {
			return nil, err
		}
		if r.Status != 0 {
			return nil, fmt.Errorf("configuration descriptor transfer failed: status %d", r.Status)
		}
		if r.ActualLength != int32(size) || len(r.Data) != size {
			return nil, errors.New("short configuration descriptor response")
		}
		return r.Data, nil
	}
	header, err := read(9)
	if err != nil {
		return ConfigurationDescriptor{}, err
	}
	n, err := configurationLength(header)
	if err != nil {
		return ConfigurationDescriptor{}, err
	}
	if n == 9 {
		return ParseConfigurationDescriptor(header)
	}
	body, err := read(n)
	if err != nil {
		return ConfigurationDescriptor{}, err
	}
	if !bytes.Equal(header, body[:9]) {
		return ConfigurationDescriptor{}, errors.New("configuration header changed between reads")
	}
	return ParseConfigurationDescriptor(body)
}
