// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"encoding/binary"
	"errors"
	"net"
	"os"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type writeBoundaryConn struct {
	submitted       atomic.Int32
	beforeDeadline  func()
	beforeOnce      sync.Once
	callbackRelease chan struct{}
	net.Conn
	partial                        bool
	once                           sync.Once
	interruptedOnce                sync.Once
	accepted, interrupted, release chan struct{}
}

func (c *writeBoundaryConn) Write(b []byte) (int, error) {
	selected := false
	if len(b) >= 48 && binary.BigEndian.Uint32(b) == CmdSubmit {
		c.submitted.Add(1)
		c.once.Do(func() { selected = true })
	}
	if !selected {
		return c.Conn.Write(b)
	}
	if c.partial {
		n, err := c.Conn.Write(b[:16])
		if err != nil {
			return n, err
		}
		close(c.accepted)
		<-c.interrupted
		return n, os.ErrDeadlineExceeded
	}
	n, err := c.Conn.Write(b)
	if err == nil && n == len(b) {
		close(c.accepted)
		<-c.release
	}
	return n, err
}
func (c *writeBoundaryConn) SetWriteDeadline(d time.Time) error {
	interrupt := !d.IsZero() && !d.After(time.Now().Add(time.Millisecond))
	if !interrupt && c.beforeDeadline != nil {
		c.beforeOnce.Do(c.beforeDeadline)
	}
	err := c.Conn.SetWriteDeadline(d)
	if interrupt {
		first := false
		c.interruptedOnce.Do(func() { close(c.interrupted); first = true })
		if first && c.callbackRelease != nil {
			<-c.callbackRelease
		}
	}
	return err
}
func boundaryRequest() Request { r := concurrentRequest(); r.Endpoint = 1; return r }

func TestConcurrentCancellationAtWriteReturnBoundary(t *testing.T) {
	for _, partial := range []bool{false, true} {
		name := "complete"
		if partial {
			name = "partial"
		}
		t.Run(name, func(t *testing.T) {
			registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
				return sampleDevice(), &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
					if r.Endpoint == 1 {
						<-ctx.Done()
						return TransferResult{}, ctx.Err()
					}
					return TransferResult{ActualLength: 1, Data: []byte{7}}, nil
				}}, nil
			}}
			raw, serverDone := serviceFixture(t, registry, allowTestOwner)
			conn := &writeBoundaryConn{Conn: raw, partial: partial, accepted: make(chan struct{}), interrupted: make(chan struct{}), release: make(chan struct{})}
			device, err := ImportConcurrentDevice(context.Background(), conn, "1-2", 2)
			if err != nil {
				t.Fatal(err)
			}
			defer device.Close()
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			finished := make(chan error, 1)
			go func() { _, e := device.Transfer(ctx, boundaryRequest()); finished <- e }()
			select {
			case <-conn.accepted:
			case <-time.After(time.Second):
				t.Fatal("write did not reach boundary")
			}
			cancel()
			select {
			case <-conn.interrupted:
			case <-time.After(time.Second):
				t.Fatal("cancellation did not interrupt write")
			}
			close(conn.release)
			select {
			case e := <-finished:
				if e == nil {
					t.Fatal("cancellation was ignored")
				}
			case <-time.After(time.Second):
				t.Fatal("canceled transfer did not settle")
			}
			if partial {
				select {
				case <-device.Done():
				default:
					t.Fatal("partial write kept session usable")
				}
				if _, e := device.Transfer(context.Background(), concurrentRequest()); e == nil {
					t.Fatal("partial stream reused")
				}
			} else {
				select {
				case <-device.Done():
					t.Fatal("fully accepted frame closed unrelated work", device.Err())
				default:
				}
				next := concurrentRequest()
				next.Endpoint = 2
				if r, e := device.Transfer(context.Background(), next); e != nil || r.Status != 0 || r.ActualLength != 1 {
					t.Fatal(r, e)
				}
			}
			device.Close()
			err = awaitSession(t, serverDone)
			if !partial && err != nil && !errors.Is(err, context.Canceled) {
				t.Fatal(err)
			}
		})
	}
}

func TestConcurrentCancelBeforeWriteDiscardsOnlyUnsentRequest(t *testing.T) {
	registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) {
			return TransferResult{ActualLength: 1, Data: []byte{7}}, nil
		}}, nil
	}}
	raw, serverDone := serviceFixture(t, registry, allowTestOwner)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	conn := &writeBoundaryConn{Conn: raw, beforeDeadline: cancel, accepted: make(chan struct{}), interrupted: make(chan struct{}), release: make(chan struct{})}
	close(conn.release)
	device, err := ImportConcurrentDevice(context.Background(), conn, "1-2", 2)
	if err != nil {
		t.Fatal(err)
	}
	defer device.Close()
	if _, err = device.Transfer(ctx, boundaryRequest()); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	if conn.submitted.Load() != 0 {
		t.Fatal("canceled-before-write request reached transport")
	}
	device.mu.Lock()
	pending := len(device.pending)
	device.mu.Unlock()
	if pending != 0 {
		t.Fatal("unsent request remained pending", pending)
	}
	if r, e := device.Transfer(context.Background(), concurrentRequest()); e != nil || r.Status != 0 {
		t.Fatal(r, e)
	}
	device.Close()
	_ = awaitSession(t, serverDone)
}
func TestConcurrentCancelCallbackJoinsBeforeNextWriter(t *testing.T) {
	registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
			if r.Endpoint == 1 {
				<-ctx.Done()
				return TransferResult{}, ctx.Err()
			}
			return TransferResult{ActualLength: 1, Data: []byte{7}}, nil
		}}, nil
	}}
	raw, serverDone := serviceFixture(t, registry, allowTestOwner)
	conn := &writeBoundaryConn{Conn: raw, accepted: make(chan struct{}), interrupted: make(chan struct{}), release: make(chan struct{}), callbackRelease: make(chan struct{})}
	device, err := ImportConcurrentDevice(context.Background(), conn, "1-2", 2)
	if err != nil {
		t.Fatal(err)
	}
	defer device.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	first := make(chan error, 1)
	go func() { _, e := device.Transfer(ctx, boundaryRequest()); first <- e }()
	<-conn.accepted
	cancel()
	<-conn.interrupted
	close(conn.release)
	next := make(chan error, 1)
	go func() {
		r := concurrentRequest()
		r.Endpoint = 2
		reply, e := device.Transfer(context.Background(), r)
		if e == nil && reply.Status != 0 {
			e = errors.New("next transfer failed")
		}
		next <- e
	}()
	select {
	case device.writer <- struct{}{}:
		<-device.writer
		t.Fatal("writer released before cancellation callback joined")
	default:
	}
	close(conn.callbackRelease)
	select {
	case e := <-first:
		if !errors.Is(e, context.Canceled) {
			t.Fatal(e)
		}
	case <-time.After(time.Second):
		t.Fatal("first did not settle")
	}
	select {
	case e := <-next:
		if e != nil {
			t.Fatal("stale deadline affected next writer", e)
		}
	case <-time.After(time.Second):
		t.Fatal("next writer blocked")
	}
	device.Close()
	_ = awaitSession(t, serverDone)
}
