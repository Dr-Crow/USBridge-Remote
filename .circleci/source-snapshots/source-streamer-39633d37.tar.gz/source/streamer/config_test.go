// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"testing"
)

func testConfig() Config {
	return Config{SchemaVersion: 1, Owner: "test-owner", SessionID: "test-session", KeyB64: base64.StdEncoding.EncodeToString([]byte("0123456789abcdef")), KeyID: 17, PeerIP: "127.0.0.1", VideoPort: 51000, AudioPort: 51001, Display: ":99", CaptureConsent: true, FFmpeg: "/usr/bin/ffmpeg", Width: 128, Height: 72, FPS: 30, PixelFormat: "yuv420p", PacketSize: 1024, AudioMode: "silence", MaxSeconds: 10}
}
func TestConfigStrictDecoding(t *testing.T) {
	good, _ := json.Marshal(testConfig())
	if _, err := DecodeConfig(good); err != nil {
		t.Fatal(err)
	}
	for _, data := range [][]byte{nil, []byte("null"), []byte("[]"), append(append([]byte(nil), good...), good...), append(good[:len(good)-1], []byte(`,"schema_version":1}`)...), bytes.ReplaceAll(good, []byte(`"schema_version"`), []byte(`"unexpected"`)), bytes.Repeat([]byte(" "), MaxConfigBytes+1)} {
		if _, err := DecodeConfig(data); err == nil {
			t.Fatal("invalid input accepted")
		}
	}
}
func TestConfigRejectsUnsupportedSecurityAndFormat(t *testing.T) {
	cases := []func(*Config){func(c *Config) { c.SchemaVersion = 2 }, func(c *Config) { c.Owner = "" }, func(c *Config) { c.SessionID = "../bad" }, func(c *Config) { c.KeyB64 = "bad" }, func(c *Config) { c.KeyB64 = base64.StdEncoding.EncodeToString(make([]byte, 32)) }, func(c *Config) { c.CaptureConsent = false }, func(c *Config) { c.PeerIP = "192.168.1.2" }, func(c *Config) { c.VideoPort = c.AudioPort }, func(c *Config) { c.VideoPort = -1 }, func(c *Config) { c.AudioPort = 65536 }, func(c *Config) { c.FFmpeg = "ffmpeg" }, func(c *Config) { c.Display = "localhost:99" }, func(c *Config) { c.MaxSeconds = 301 }, func(c *Config) { c.MaxSeconds = 0 }, func(c *Config) { c.AudioMode = "microphone" }, func(c *Config) { c.Width = 127 }, func(c *Config) { c.PacketSize = 1472 }, func(c *Config) { c.FPS = 121 }}
	for i, change := range cases {
		c := testConfig()
		change(&c)
		if err := c.Validate(); err == nil {
			t.Fatalf("invalid case %d accepted", i)
		}
	}
}
