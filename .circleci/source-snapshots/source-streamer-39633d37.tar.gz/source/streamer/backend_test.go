// SPDX-License-Identifier: GPL-3.0-only
package streamer

import (
	"context"
	"errors"
	"io"
	"net"
	"sync/atomic"
	"testing"
	"time"

	"github.com/Dr-Crow/rustshine-research/source/sdp"
	"github.com/Dr-Crow/rustshine-research/source/session"
)

func receiver(t *testing.T) *net.UDPConn {
	t.Helper()
	c, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { c.Close() })
	return c
}
func backendForTest(t *testing.T) (*Backend, *net.UDPConn, *net.UDPConn) {
	t.Helper()
	v, a := receiver(t), receiver(t)
	cfg := testConfig()
	cfg.VideoPort = v.LocalAddr().(*net.UDPAddr).Port
	cfg.AudioPort = a.LocalAddr().(*net.UDPAddr).Port
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	t.Cleanup(cancel)
	b, err := newBackend(ctx, cancel, cfg, 55555)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { b.Close() })
	return b, v, a
}
func requested(c Config) sdp.VideoRequest {
	return sdp.VideoRequest{Width: uint32(c.Width), Height: uint32(c.Height), FPS: uint32(c.FPS), PacketSize: uint32(c.PacketSize), EncryptionFlags: 7, HasEncryptionFlags: true}
}
func ping(t *testing.T, c *net.UDPConn, port uint16) {
	t.Helper()
	if _, err := c.WriteToUDP([]byte("PING"), &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: int(port)}); err != nil {
		t.Fatal(err)
	}
}
func TestBackendLaunchLifetimeOutlivesRTSPTransaction(t *testing.T) {
	b, v, a := backendForTest(t)
	started := make(chan string, 2)
	var joined atomic.Int32
	encoder := func(name string) func(context.Context, io.Writer) error {
		return func(ctx context.Context, _ io.Writer) error {
			defer joined.Add(1)
			started <- name
			<-ctx.Done()
			return ctx.Err()
		}
	}
	b.videoEncoder = encoder("video")
	b.audioEncoder = encoder("audio")
	if err := b.Configure(context.Background(), requested(b.cfg)); err != nil {
		t.Fatal(err)
	}
	transaction, cancel := context.WithCancel(context.Background())
	if err := b.Start(transaction); err != nil {
		t.Fatal(err)
	}
	cancel()
	select {
	case <-started:
		t.Fatal("capture started before receiver ping")
	case <-time.After(15 * time.Millisecond):
	}
	vp, _ := b.Setup(context.Background(), session.Video)
	ap, _ := b.Setup(context.Background(), session.Audio)
	ping(t, v, vp)
	ping(t, a, ap)
	for i := 0; i < 2; i++ {
		select {
		case <-started:
		case <-time.After(time.Second):
			t.Fatal("media did not start after transaction ended")
		}
	}
	if b.ctx.Err() != nil {
		t.Fatal("RTSP connection lifetime canceled media")
	}
	if err := b.Close(); err != nil {
		t.Fatal(err)
	}
	if joined.Load() != 2 {
		t.Fatal("codec goroutines not joined")
	}
	if err := b.Start(context.Background()); err == nil {
		t.Fatal("reused key lifetime")
	}
	if err := b.Close(); err != nil {
		t.Fatal("close is not idempotent", err)
	}
}
func TestBackendEncoderFailureCancelsOtherTrack(t *testing.T) {
	b, v, a := backendForTest(t)
	failure := errors.New("capture failed")
	var joined atomic.Bool
	b.videoEncoder = func(context.Context, io.Writer) error { return failure }
	b.audioEncoder = func(ctx context.Context, _ io.Writer) error { defer joined.Store(true); <-ctx.Done(); return ctx.Err() }
	if err := b.Configure(context.Background(), requested(b.cfg)); err != nil {
		t.Fatal(err)
	}
	if err := b.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	vp, _ := b.Setup(context.Background(), session.Video)
	ap, _ := b.Setup(context.Background(), session.Audio)
	ping(t, a, ap)
	ping(t, v, vp)
	select {
	case <-b.ctx.Done():
	case <-time.After(time.Second):
		t.Fatal("failure did not cancel launch")
	}
	if err := b.Close(); !errors.Is(err, failure) {
		t.Fatal("lost root failure", err)
	}
	// Cancellation can win the audio preflight; in either case Close joined it.
	_ = joined.Load()
}
func TestBackendRejectsDowngradeAndMismatch(t *testing.T) {
	b, _, _ := backendForTest(t)
	if err := b.Start(context.Background()); err == nil {
		t.Fatal("start before configure")
	}
	for _, change := range []func(*sdp.VideoRequest){func(c *sdp.VideoRequest) { c.EncryptionFlags = 3 }, func(c *sdp.VideoRequest) { c.HasEncryptionFlags = false }, func(c *sdp.VideoRequest) { c.Width++ }, func(c *sdp.VideoRequest) { c.ChromaSampling = 1 }} {
		c := requested(b.cfg)
		change(&c)
		if err := b.Configure(context.Background(), c); err == nil {
			t.Fatal("unsupported config accepted")
		}
	}
	if b.started || b.configured {
		t.Fatal("failed configuration modified state")
	}
}
func TestCancellationFilteringPreservesFailure(t *testing.T) {
	e := errors.New("transport failed")
	if err := withoutCancellation(errors.Join(context.Canceled, e)); !errors.Is(err, e) {
		t.Fatal(err)
	}
	if err := withoutCancellation(errors.Join(context.Canceled, context.DeadlineExceeded)); err != nil {
		t.Fatal(err)
	}
}
