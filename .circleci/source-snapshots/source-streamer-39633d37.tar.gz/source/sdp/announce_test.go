// SPDX-License-Identifier: GPL-3.0-only
package sdp

import (
	"strings"
	"testing"
)

const fixture = "v=0\r\no=android 0 14 IN IPv4 192.0.2.1\r\ns=NVIDIA Streaming Client\r\na=x-nv-video[0].clientViewportWd:1920 \r\na=x-nv-video[0].clientViewportHt:1080 \r\na=x-nv-video[0].maxFPS:60 \r\na=x-nv-video[0].packetSize:1024 \r\nt=0 0\r\nm=video 47998  \r\n"

func TestVideoRequest(t *testing.T) {
	v, err := ParseVideoRequest([]byte(fixture))
	if err != nil {
		t.Fatal(err)
	}
	if v.Width != 1920 || v.Height != 1080 || v.FPS != 60 || v.PacketSize != 1024 || v.HasEncryptionFlags || v.HasChromaSampling {
		t.Fatalf("wrong result: %+v", v)
	}
	for _, flags := range []string{"0", "7", "4294967295"} {
		v, err = ParseVideoRequest([]byte(fixture + "a=x-ss-general.encryptionEnabled:" + flags + " \r\na=x-ss-video[0].chromaSamplingType:1 \r\n"))
		if err != nil || !v.HasEncryptionFlags || !v.HasChromaSampling || v.ChromaSampling != 1 {
			t.Fatalf("optional fields: %+v %v", v, err)
		}
	}
}

func TestInvalidVideoRequest(t *testing.T) {
	tests := map[string]string{
		"missing encryption value": fixture + "a=x-ss-general.encryptionEnabled\r\n",
		"empty":                    "", "version": strings.Replace(fixture, "v=0", "v=1", 1),
		"missing":              strings.Replace(fixture, "a=x-nv-video[0].maxFPS:60 \r\n", "", 1),
		"zero":                 strings.Replace(fixture, ":60 ", ":0 ", 1),
		"negative":             strings.Replace(fixture, ":60 ", ":-60 ", 1),
		"plus":                 strings.Replace(fixture, ":60 ", ":+60 ", 1),
		"fraction":             strings.Replace(fixture, ":60 ", ":59.94 ", 1),
		"overflow":             strings.Replace(fixture, ":60 ", ":4294967296 ", 1),
		"duplicate":            fixture + "a=x-nv-video[0].maxFPS:60 \r\n",
		"duplicate version":    fixture + "v=0\r\n",
		"bare newline":         strings.Replace(fixture, "\r\n", "\n", 1),
		"unterminated":         strings.TrimSuffix(fixture, "\r\n"),
		"NUL":                  fixture + "a=unknown:\x00\r\n",
		"empty line":           fixture + "\r\n",
		"huge line":            fixture + "a=unknown:" + strings.Repeat("x", MaxLine) + "\r\n",
		"huge body":            strings.Repeat("x", MaxBody+1),
		"many lines":           fixture + strings.Repeat("a=x\r\n", MaxLines),
		"unknown chroma":       fixture + "a=x-ss-video[0].chromaSamplingType:2 \r\n",
		"duplicate encryption": fixture + "a=x-ss-general.encryptionEnabled:1\r\na=x-ss-general.encryptionEnabled:0\r\n",
	}
	for name, body := range tests {
		t.Run(name, func(t *testing.T) {
			v, err := ParseVideoRequest([]byte(body))
			if err == nil {
				t.Fatalf("accepted %+v", v)
			}
			if v != (VideoRequest{}) {
				t.Fatal("partial config escaped error")
			}
		})
	}
}
func TestUnknownFields(t *testing.T) {
	if _, err := ParseVideoRequest([]byte(fixture + "a=unknown:hello\r\na=unknown:again\r\na=sendonly\r\n")); err != nil {
		t.Fatal(err)
	}
}
func FuzzVideoRequest(f *testing.F) {
	f.Add([]byte(fixture))
	f.Add([]byte(fixture + "a=x-ss-general.encryptionEnabled:0 \r\n"))
	f.Fuzz(func(t *testing.T, b []byte) {
		v, err := ParseVideoRequest(b)
		if err != nil {
			if v != (VideoRequest{}) {
				t.Fatal("partial config")
			}
			return
		}
		if v.Width == 0 || v.Height == 0 || v.FPS == 0 || v.PacketSize == 0 || v.ChromaSampling > 1 {
			t.Fatal("invalid accepted config")
		}
	})
}
