// SPDX-License-Identifier: GPL-3.0-only
package media

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os/exec"
	"regexp"
	"runtime"
	"strconv"
	"strings"
)

var localDisplay = regexp.MustCompile(`^:[0-9]{1,5}(\.[0-9]{1,2})?$`)

func validateX11Display(display string) error {
	if !localDisplay.MatchString(display) {
		return errors.New("explicit local X11 display required, such as :99")
	}
	parts := strings.Split(display[1:], ".")
	number, _ := strconv.Atoi(parts[0])
	if number > 65535 {
		return errors.New("X11 display out of bounds")
	}
	if len(parts) == 2 {
		screen, _ := strconv.Atoi(parts[1])
		if screen > 15 {
			return errors.New("X11 screen out of bounds")
		}
	}
	return nil
}

// CaptureX11 encodes an explicitly selected local X11 display. The caller must
// have operator permission to capture that display and supply a trusted FFmpeg.
// No DISPLAY default, network X11 address, camera or desktop portal is selected.
// This bounded Linux-only adapter does not implement Wayland/KMS or audio.
func CaptureX11(ctx context.Context, ffmpeg, display string, out io.Writer, p Pattern) error {
	return captureX11(ctx, ffmpeg, display, out, p, false, false)
}

// CaptureX11Live reads the explicitly selected, operator-authorized local X11
// display until canceled. Frames is unused; dimensions/rate/pixel format retain
// the bounded format validation. No camera, audio, portal or network capture is
// selected. The caller must cancel the context and join the enclosing pipeline.
func CaptureX11Live(ctx context.Context, ffmpeg, display string, out io.Writer, p Pattern) error {
	p.Frames = 1
	return captureX11(ctx, ffmpeg, display, out, p, true, false)
}

// CaptureX11LiveIntra uses an independently decodable IDR for every frame. This
// deliberately high-bandwidth profile satisfies keyframe requests without
// pretending the FFmpeg subprocess supports dynamic encoder control.
func CaptureX11LiveIntra(ctx context.Context, ffmpeg, display string, out io.Writer, p Pattern) error {
	p.Frames = 1
	return captureX11(ctx, ffmpeg, display, out, p, true, true)
}

func captureX11(ctx context.Context, ffmpeg, display string, out io.Writer, p Pattern, live, intra bool) error {
	if ctx == nil || ffmpeg == "" || out == nil {
		return errors.New("context, encoder and output required")
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := p.Validate(); err != nil {
		return err
	}
	if err := validateX11Display(display); err != nil {
		return err
	}
	if runtime.GOOS != "linux" {
		return errors.New("X11 capture adapter requires Linux")
	}
	args := []string{"-hide_banner", "-nostdin", "-v", "error", "-f", "x11grab", "-draw_mouse", "0", "-video_size", fmt.Sprintf("%dx%d", p.Width, p.Height), "-framerate", strconv.Itoa(p.FPS), "-i", display, "-frames:v", strconv.Itoa(p.Frames), "-an", "-pix_fmt", p.PixelFormat, "-c:v", "libx264", "-qp", "0", "-preset", "ultrafast", "-x264-params", "aud=1:repeat-headers=1", "-threads", "1", "-f", "h264", "pipe:1"}
	if live {
		// Remove only the frame-limit option; all capture/encoding parameters
		// remain the same as the validated bounded adapter.
		for i := 0; i < len(args); i++ {
			if args[i] == "-frames:v" {
				args = append(args[:i], args[i+2:]...)
				break
			}
		}
	}
	if intra {
		for i := range args {
			if args[i] == "aud=1:repeat-headers=1" {
				args[i] += ":keyint=1:min-keyint=1:scenecut=0"
			}
		}
		args = append(args[:len(args)-1], "-tune", "zerolatency", args[len(args)-1])
	}
	cmd := exec.CommandContext(ctx, ffmpeg, args...)
	cmd.Stdout = out
	log := &cappedLog{}
	cmd.Stderr = log
	if err := cmd.Run(); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return fmt.Errorf("X11 capture failed: %w: %s", err, string(log.b))
	}
	return nil
}
