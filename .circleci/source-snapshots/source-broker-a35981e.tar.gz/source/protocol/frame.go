// SPDX-License-Identifier: GPL-3.0-only
// Wire layout derived from USBridge-Remote client/internal/usbpass/usbaes_protocol.go.
// See ../../docs/SOURCE_CORE.md for provenance and compatibility limits.
package protocol

import (
	"encoding/binary"
	"errors"
	"fmt"
)

const HeaderSize = 12
const Version byte = 1
const MaxPayload = 16 << 20
const (
	Hello    byte = 1
	HelloAck byte = 2
	Attach   byte = 3
	Detach   byte = 4
	Reset    byte = 8
)

// Frame is one complete USBP control frame. Payload aliases the decoded input.
// Encryption/authentication belongs to the surrounding transport, not this codec.
type Frame struct {
	Type    byte
	Payload []byte
}

func Encode(kind byte, payload []byte) ([]byte, error) {
	if len(payload) > MaxPayload {
		return nil, errors.New("payload exceeds reconstruction limit")
	}
	out := make([]byte, HeaderSize+len(payload))
	copy(out, "USBP")
	out[4], out[5] = Version, kind
	binary.BigEndian.PutUint32(out[8:12], uint32(len(payload)))
	copy(out[12:], payload)
	return out, nil
}

// Decode accepts exactly one frame, rejecting trailing bytes. Callers handling a
// byte stream must delimit frames first. Length checks use uint64 to avoid overflow.
func Decode(buf []byte) (Frame, error) {
	if len(buf) < HeaderSize {
		return Frame{}, errors.New("truncated header")
	}
	if string(buf[:4]) != "USBP" {
		return Frame{}, errors.New("bad magic")
	}
	if buf[4] != Version {
		return Frame{}, fmt.Errorf("unsupported version %d", buf[4])
	}
	if buf[6] != 0 || buf[7] != 0 {
		return Frame{}, errors.New("nonzero reserved header")
	}
	size := uint64(binary.BigEndian.Uint32(buf[8:12]))
	if size > MaxPayload {
		return Frame{}, errors.New("payload exceeds reconstruction limit")
	}
	if uint64(len(buf)) != HeaderSize+size {
		return Frame{}, errors.New("payload length mismatch")
	}
	return Frame{Type: buf[5], Payload: buf[12:]}, nil
}

func EncodeHello(role, version byte) ([]byte, error) { return Encode(Hello, []byte{role, version}) }
func EncodeDetach(id uint32) ([]byte, error) {
	p := make([]byte, 4)
	binary.BigEndian.PutUint32(p, id)
	return Encode(Detach, p)
}
func DecodeHelloAck(payload []byte) (bool, string, error) {
	if len(payload) < 5 {
		return false, "", errors.New("truncated hello acknowledgement")
	}
	n := uint64(binary.BigEndian.Uint32(payload[1:5]))
	if n != uint64(len(payload)-5) {
		return false, "", errors.New("hello acknowledgement length mismatch")
	}
	return payload[0] != 0, string(payload[5:]), nil
}
