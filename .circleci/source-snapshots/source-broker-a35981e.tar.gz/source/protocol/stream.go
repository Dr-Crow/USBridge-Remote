// SPDX-License-Identifier: GPL-3.0-only
package protocol

import (
	"encoding/binary"
	"errors"
	"io"
)

// ReadFrame consumes exactly one plaintext USBP frame. It does not implement the
// AES-GCM envelope or open a socket. Callers must authenticate/decrypt first.
// Header fields and the local payload limit are checked before allocation.
func ReadFrame(r io.Reader) (Frame, error) {
	var header [HeaderSize]byte
	if _, err := io.ReadFull(r, header[:]); err != nil {
		return Frame{}, err
	}
	if string(header[:4]) != "USBP" || header[4] != Version || header[6] != 0 || header[7] != 0 {
		return Frame{}, errors.New("invalid USBP stream header")
	}
	size := uint64(binary.BigEndian.Uint32(header[8:]))
	if size > MaxPayload {
		return Frame{}, errors.New("payload exceeds reconstruction limit")
	}
	payload := make([]byte, int(size))
	if _, err := io.ReadFull(r, payload); err != nil {
		return Frame{}, err
	}
	return Frame{Type: header[5], Payload: payload}, nil
}

// WriteFrame writes one plaintext frame, including writers that return a short
// write without an error. A write error can leave a partial frame on the stream;
// callers must discard that stream rather than retrying a whole frame on it.
func WriteFrame(w io.Writer, frame Frame) error {
	raw, err := Encode(frame.Type, frame.Payload)
	if err != nil {
		return err
	}
	for len(raw) > 0 {
		n, err := w.Write(raw)
		if n < 0 || n > len(raw) {
			return errors.New("invalid writer byte count")
		}
		raw = raw[n:]
		if err != nil {
			return err
		}
		if n == 0 {
			return io.ErrShortWrite
		}
	}
	return nil
}
