package protocol

import (
	"bytes"
	"encoding/hex"
	"testing"
)

func TestKnownVectors(t *testing.T) {
	for _, tc := range []struct {
		name, wire string
		kind       byte
		payload    []byte
	}{
		{"hello-client-v1", "5553425001010000000000020101", Hello, []byte{1, 1}},
		{"ack-ok", "55534250010200000000000701000000026f6b", HelloAck, []byte{1, 0, 0, 0, 2, 'o', 'k'}},
		{"detach", "55534250010400000000000412345678", Detach, []byte{0x12, 0x34, 0x56, 0x78}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			raw, err := hex.DecodeString(tc.wire)
			if err != nil {
				t.Fatal(err)
			}
			f, err := Decode(raw)
			if err != nil || f.Type != tc.kind || !bytes.Equal(f.Payload, tc.payload) {
				t.Fatalf("decode %+v %v", f, err)
			}
			out, err := Encode(tc.kind, tc.payload)
			if err != nil || !bytes.Equal(out, raw) {
				t.Fatalf("encode %x %v", out, err)
			}
		})
	}
	ack, detail, err := DecodeHelloAck([]byte{1, 0, 0, 0, 2, 'o', 'k'})
	if err != nil || !ack || detail != "ok" {
		t.Fatal(ack, detail, err)
	}
}
func TestMalformedFrames(t *testing.T) {
	valid, _ := EncodeHello(1, 1)
	for i := 0; i < len(valid); i++ {
		if _, err := Decode(valid[:i]); err == nil {
			t.Fatalf("accepted prefix %d", i)
		}
	}
	for _, index := range []int{0, 4, 6, 7, 8, 11} {
		b := append([]byte(nil), valid...)
		b[index] ^= 0xff
		if _, err := Decode(b); err == nil {
			t.Fatalf("accepted invalid header byte %d", index)
		}
	}
	if _, err := Decode(append(valid, 0)); err == nil {
		t.Fatal("accepted trailing byte")
	}
	if _, err := Encode(Hello, make([]byte, MaxPayload+1)); err == nil {
		t.Fatal("accepted oversize")
	}
	for _, p := range [][]byte{nil, {1}, {1, 0, 0, 0, 5, 'a'}, {1, 255, 255, 255, 255}} {
		if _, _, err := DecodeHelloAck(p); err == nil {
			t.Fatalf("accepted malformed ack %x", p)
		}
	}
}
func TestHelpers(t *testing.T) {
	h, _ := EncodeHello(1, 1)
	if hex.EncodeToString(h) != "5553425001010000000000020101" {
		t.Fatal(h)
	}
	d, _ := EncodeDetach(0x12345678)
	if hex.EncodeToString(d) != "55534250010400000000000412345678" {
		t.Fatal(d)
	}
}
func FuzzDecode(f *testing.F) {
	raw, _ := EncodeHello(1, 1)
	f.Add(raw)
	f.Add([]byte("USBP"))
	f.Fuzz(func(t *testing.T, b []byte) {
		frame, err := Decode(b)
		if err != nil {
			return
		}
		out, err := Encode(frame.Type, frame.Payload)
		if err != nil || !bytes.Equal(b, out) {
			t.Fatalf("roundtrip failed: %v", err)
		}
	})
}
