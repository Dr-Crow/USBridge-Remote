package protocol

import (
	"bytes"
	"encoding/hex"
	"reflect"
	"testing"
)

func TestAttachVector(t *testing.T) {
	a := Attachment{BusID: "1-2", VID: 0x1234, PID: 0xabcd, Speed: 3, DeviceDescriptor: []byte{1, 2}, ConfigurationDescriptor: []byte{3}, ExportHost: "127.0.0.1", ExportService: "3240", TunnelNonce: []byte{0xaa, 0xbb}}
	const expected = "55534250010300000000003200000003312d321234abcd030000000201020000000103000000093132372e302e302e31000000043332343000000002aabb"
	raw, err := EncodeAttach(a)
	if err != nil {
		t.Fatal(err)
	}
	if hex.EncodeToString(raw) != expected {
		t.Fatalf("got %x", raw)
	}
	f, err := Decode(raw)
	if err != nil {
		t.Fatal(err)
	}
	got, err := DecodeAttach(f.Payload)
	if err != nil || !reflect.DeepEqual(a, got) {
		t.Fatalf("%+v %v", got, err)
	}
	for i := 0; i < len(f.Payload); i++ {
		if _, err := DecodeAttach(f.Payload[:i]); err == nil {
			t.Fatalf("accepted prefix %d", i)
		}
	}
	if _, err := DecodeAttach(append(f.Payload, 0)); err == nil {
		t.Fatal("accepted trailing byte")
	}
}
func FuzzAttach(f *testing.F) {
	raw, _ := EncodeAttach(Attachment{BusID: "1-2", ExportHost: "127.0.0.1"})
	f.Add(raw[12:])
	f.Add([]byte{255, 255, 255, 255})
	f.Fuzz(func(t *testing.T, p []byte) {
		a, err := DecodeAttach(p)
		if err != nil {
			return
		}
		encoded, err := EncodeAttach(a)
		if err != nil || !bytes.Equal(encoded[12:], p) {
			t.Fatalf("attachment roundtrip: %v", err)
		}
	})
}
