// SPDX-License-Identifier: GPL-3.0-only
package protocol

import (
	"encoding/hex"
	"testing"
)

func TestControlPayloadDirections(t *testing.T) {
	hello, _ := EncodeHello(1, 1)
	f, err := Decode(hello)
	if err != nil {
		t.Fatal(err)
	}
	role, version, err := DecodeHello(f.Payload)
	if err != nil || role != 1 || version != 1 {
		t.Fatal("hello inverse", err)
	}
	detach, _ := EncodeDetach(0x12345678)
	f, err = Decode(detach)
	if err != nil {
		t.Fatal(err)
	}
	id, err := DecodeDetach(f.Payload)
	if err != nil || id != 0x12345678 {
		t.Fatal("detach inverse", err)
	}
	ack, err := EncodeHelloAck(true, "ok")
	if err != nil {
		t.Fatal(err)
	}
	if hex.EncodeToString(ack) != "55534250010200000000000701000000026f6b" {
		t.Fatal("source-derived ack vector mismatch")
	}
	for _, ok := range []bool{false, true} {
		for _, detail := range []string{"", "ok", "\x00\xff"} {
			raw, err := EncodeHelloAck(ok, detail)
			if err != nil {
				t.Fatal(err)
			}
			f, err := Decode(raw)
			if err != nil || f.Type != HelloAck {
				t.Fatal(err)
			}
			got, text, err := DecodeHelloAck(f.Payload)
			if err != nil || got != ok || text != detail {
				t.Fatal("ack inverse", err)
			}
		}
	}
	for n := 0; n < 8; n++ {
		if _, _, err := DecodeHello(make([]byte, n)); (err == nil) != (n == 2) {
			t.Fatal("hello length", n)
		}
		if _, err := DecodeDetach(make([]byte, n)); (err == nil) != (n == 4) {
			t.Fatal("detach length", n)
		}
	}
	if _, err := EncodeHelloAck(true, string(make([]byte, MaxPayload-4))); err == nil {
		t.Fatal("oversize ack accepted")
	}
}
func FuzzControlPayloads(f *testing.F) {
	f.Add([]byte{1, 1})
	f.Add([]byte{1, 0, 0, 0, 2, 'o', 'k'})
	f.Add([]byte{})
	f.Fuzz(func(t *testing.T, p []byte) {
		if role, v, err := DecodeHello(p); err == nil {
			raw, _ := EncodeHello(role, v)
			out, e := Decode(raw)
			if e != nil || string(out.Payload) != string(p) {
				t.Fatal("hello roundtrip")
			}
		}
		if id, err := DecodeDetach(p); err == nil {
			raw, _ := EncodeDetach(id)
			out, e := Decode(raw)
			if e != nil || string(out.Payload) != string(p) {
				t.Fatal("detach roundtrip")
			}
		}
		if ok, detail, err := DecodeHelloAck(p); err == nil && len(detail) <= MaxPayload-5 {
			raw, e := EncodeHelloAck(ok, detail)
			if e != nil {
				t.Fatal(e)
			}
			out, e := Decode(raw)
			if e != nil {
				t.Fatal(e)
			}
			ok2, d2, e := DecodeHelloAck(out.Payload)
			if e != nil || ok2 != ok || d2 != detail {
				t.Fatal("ack semantic roundtrip")
			}
		}
	})
}
