// SPDX-License-Identifier: GPL-3.0-only
package protocol

import (
	"encoding/binary"
	"errors"
)

// Attachment describes an export offered over the authenticated control channel.
// The codec does not dial ExportHost or validate/activate USB descriptors.
// TunnelNonce must be transported inside the authenticated encrypted session;
// this module does not create or replace session keys.
type Attachment struct {
	BusID                                     string
	VID, PID                                  uint16
	Speed                                     byte
	DeviceDescriptor, ConfigurationDescriptor []byte
	ExportHost, ExportService                 string
	TunnelNonce                               []byte
}

func appendField(out, field []byte) []byte {
	var n [4]byte
	binary.BigEndian.PutUint32(n[:], uint32(len(field)))
	out = append(out, n[:]...)
	return append(out, field...)
}
func EncodeAttach(a Attachment) ([]byte, error) {
	fields := [][]byte{[]byte(a.BusID), a.DeviceDescriptor, a.ConfigurationDescriptor, []byte(a.ExportHost), []byte(a.ExportService), a.TunnelNonce}
	size := uint64(5 + 4*len(fields))
	for _, v := range fields {
		size += uint64(len(v))
	}
	if size > MaxPayload {
		return nil, errors.New("attachment exceeds reconstruction limit")
	}
	p := make([]byte, 0, int(size))
	p = appendField(p, fields[0])
	var ids [5]byte
	binary.BigEndian.PutUint16(ids[:2], a.VID)
	binary.BigEndian.PutUint16(ids[2:4], a.PID)
	ids[4] = a.Speed
	p = append(p, ids[:]...)
	for _, v := range fields[1:] {
		p = appendField(p, v)
	}
	return Encode(Attach, p)
}

type reader struct {
	data []byte
	at   int
}

func (r *reader) take(n uint64) ([]byte, error) {
	if n > uint64(len(r.data)-r.at) {
		return nil, errors.New("truncated attachment")
	}
	p := r.data[r.at : r.at+int(n)]
	r.at += int(n)
	return p, nil
}
func (r *reader) field() ([]byte, error) {
	n, err := r.take(4)
	if err != nil {
		return nil, err
	}
	return r.take(uint64(binary.BigEndian.Uint32(n)))
}

// DecodeAttach returns views into the input for byte fields; callers retaining
// fields beyond the input buffer lifetime should copy them.
func DecodeAttach(p []byte) (Attachment, error) {
	if len(p) > MaxPayload {
		return Attachment{}, errors.New("attachment exceeds reconstruction limit")
	}
	r := reader{data: p}
	bus, err := r.field()
	if err != nil {
		return Attachment{}, err
	}
	ids, err := r.take(5)
	if err != nil {
		return Attachment{}, err
	}
	fields := make([][]byte, 5)
	for i := range fields {
		fields[i], err = r.field()
		if err != nil {
			return Attachment{}, err
		}
	}
	if r.at != len(p) {
		return Attachment{}, errors.New("trailing attachment data")
	}
	return Attachment{BusID: string(bus), VID: binary.BigEndian.Uint16(ids[:2]), PID: binary.BigEndian.Uint16(ids[2:4]), Speed: ids[4], DeviceDescriptor: fields[0], ConfigurationDescriptor: fields[1], ExportHost: string(fields[2]), ExportService: string(fields[3]), TunnelNonce: fields[4]}, nil
}
