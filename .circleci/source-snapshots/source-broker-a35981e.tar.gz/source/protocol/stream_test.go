// SPDX-License-Identifier: GPL-3.0-only
package protocol

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"testing"
)

type byteReader struct{ io.Reader }

func (r byteReader) Read(p []byte) (int, error) {
	if len(p) > 1 {
		p = p[:1]
	}
	return r.Reader.Read(p)
}

type shortWriter struct{ bytes.Buffer }

func (w *shortWriter) Write(p []byte) (int, error) {
	if len(p) > 2 {
		p = p[:2]
	}
	return w.Buffer.Write(p)
}

type stoppedWriter struct {
	n   int
	err error
}

func (w stoppedWriter) Write([]byte) (int, error) { return w.n, w.err }

func TestStreamFragmentationAndConcatenation(t *testing.T) {
	var w shortWriter
	for _, f := range []Frame{{Hello, []byte{1, 1}}, {Detach, []byte{0, 0, 0, 7}}, {Reset, nil}} {
		if err := WriteFrame(&w, f); err != nil {
			t.Fatal(err)
		}
	}
	r := byteReader{bytes.NewReader(w.Bytes())}
	for _, want := range []Frame{{Hello, []byte{1, 1}}, {Detach, []byte{0, 0, 0, 7}}, {Reset, nil}} {
		got, err := ReadFrame(r)
		if err != nil || got.Type != want.Type || !bytes.Equal(got.Payload, want.Payload) {
			t.Fatalf("got %#v, %v", got, err)
		}
	}
	if _, err := ReadFrame(r); !errors.Is(err, io.EOF) {
		t.Fatalf("expected clean EOF, got %v", err)
	}
}
func TestStreamTruncation(t *testing.T) {
	raw, _ := EncodeHello(1, 1)
	for n := 0; n < len(raw); n++ {
		_, err := ReadFrame(bytes.NewReader(raw[:n]))
		if err == nil {
			t.Fatalf("accepted %d bytes", n)
		}
	}
}
func TestStreamRejectsHeaderBeforePayload(t *testing.T) {
	base, _ := Encode(Hello, nil)
	for _, mutate := range []func([]byte){func(b []byte) { b[0] = 'X' }, func(b []byte) { b[4] = 2 }, func(b []byte) { b[6] = 1 }, func(b []byte) { b[7] = 1 }, func(b []byte) { binary.BigEndian.PutUint32(b[8:], MaxPayload+1) }} {
		header := append([]byte(nil), base...)
		mutate(header)
		r := bytes.NewReader(append(header, 99))
		if _, err := ReadFrame(r); err == nil {
			t.Fatal("invalid header accepted")
		}
		if r.Len() != 1 {
			t.Fatal("read payload before rejecting header")
		}
	}
}
func TestStreamWriteFailures(t *testing.T) {
	failure := errors.New("fixture write failure")
	for _, w := range []stoppedWriter{{0, nil}, {-1, nil}, {999, nil}, {1, failure}} {
		if err := WriteFrame(w, Frame{Hello, []byte{1, 1}}); err == nil {
			t.Fatal("write error ignored")
		}
	}
}
func FuzzStreamFrame(f *testing.F) {
	seed, _ := EncodeHello(1, 1)
	f.Add(seed)
	f.Fuzz(func(t *testing.T, raw []byte) {
		if len(raw) > MaxPayload+HeaderSize {
			return
		}
		r := bytes.NewReader(raw)
		got, err := ReadFrame(r)
		if err != nil {
			return
		}
		consumed := len(raw) - r.Len()
		exact, err := Decode(raw[:consumed])
		if err != nil || exact.Type != got.Type || !bytes.Equal(exact.Payload, got.Payload) {
			t.Fatal("stream/exact parser mismatch")
		}
	})
}
