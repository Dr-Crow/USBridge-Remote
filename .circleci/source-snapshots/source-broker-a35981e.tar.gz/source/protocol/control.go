// SPDX-License-Identifier: GPL-3.0-only
package protocol

import (
	"encoding/binary"
	"errors"
)

// DecodeHello decodes the inverse of the public client's two-byte encoder.
// Role/version negotiation is a separate server policy, not guessed here.
func DecodeHello(payload []byte) (role, version byte, err error) {
	if len(payload) != 2 {
		return 0, 0, errors.New("hello payload must contain exactly two bytes")
	}
	return payload[0], payload[1], nil
}

// EncodeHelloAck is the inverse of the public client's acknowledgement decoder.
// Detail is opaque bytes represented as a Go string, just like that decoder.
func EncodeHelloAck(ok bool, detail string) ([]byte, error) {
	if len(detail) > MaxPayload-5 {
		return nil, errors.New("hello acknowledgement exceeds reconstruction limit")
	}
	p := make([]byte, 5+len(detail))
	if ok {
		p[0] = 1
	}
	binary.BigEndian.PutUint32(p[1:5], uint32(len(detail)))
	copy(p[5:], detail)
	return Encode(HelloAck, p)
}
func DecodeDetach(payload []byte) (uint32, error) {
	if len(payload) != 4 {
		return 0, errors.New("detach payload must contain exactly four bytes")
	}
	return binary.BigEndian.Uint32(payload), nil
}
