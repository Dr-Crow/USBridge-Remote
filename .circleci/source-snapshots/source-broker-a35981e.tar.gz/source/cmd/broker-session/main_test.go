// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"bytes"
	"context"
	"errors"
	"io"
	"testing"
	"time"
)

func TestProcessOutput(t *testing.T) {
	var buffer bytes.Buffer
	writer := processOutput{ctx: context.Background(), writer: &buffer, timeout: time.Second}
	if n, err := writer.Write([]byte("one")); err != nil || n != 3 || buffer.String() != "one" {
		t.Fatal(n, err)
	}
	input, output := io.Pipe()
	defer input.Close()
	defer output.Close()
	writer = processOutput{ctx: context.Background(), writer: output, timeout: time.Millisecond}
	if _, err := writer.Write([]byte("blocked")); err == nil {
		t.Fatal("unbounded output write")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	writer = processOutput{ctx: ctx, writer: output, timeout: time.Second}
	if _, err := writer.Write([]byte("cancel")); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}
