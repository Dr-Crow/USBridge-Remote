// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/signal"
	"runtime"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/brokersession"
)

var version = "dev"

// A CLI may inherit synchronous pipes without OS deadline support. At most one
// output write is outstanding; timeout/cancellation ends the session, joins its
// device workers, and exits this process. A blocked I/O goroutine is never reused.
// This wrapper must not be embedded in a persistent process.
type processOutput struct {
	ctx     context.Context
	writer  io.Writer
	timeout time.Duration
}

func (o processOutput) Write(p []byte) (int, error) {
	type result struct {
		n   int
		err error
	}
	done := make(chan result, 1)
	data := append([]byte(nil), p...)
	go func() { n, err := o.writer.Write(data); done <- result{n, err} }()
	timer := time.NewTimer(o.timeout)
	defer timer.Stop()
	select {
	case r := <-done:
		if r.err == nil && r.n != len(data) {
			return r.n, io.ErrShortWrite
		}
		return r.n, r.err
	case <-o.ctx.Done():
		return 0, o.ctx.Err()
	case <-timer.C:
		return 0, errors.New("session output deadline exceeded")
	}
}
func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, "usage: broker-session --capabilities | --version | --session-stdin")
		os.Exit(2)
	}
	switch os.Args[1] {
	case "--version":
		fmt.Println(version)
		return
	case "--capabilities":
		_ = json.NewEncoder(os.Stdout).Encode(map[string]any{"component": "source-broker", "profile": "source-broker-v1", "schema_version": 1, "platform": runtime.GOOS + "/" + runtime.GOARCH, "version": version, "session_supported": true, "capabilities": []string{"tls13-pinned", "usbip-transfer", "usbip-unlink"}, "role": "usbip-importer-client", "os_attached": false})
		return
	case "--session-stdin":
		ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
		defer stop()
		if err := brokersession.RunProcess(ctx, os.Stdin, processOutput{ctx: ctx, writer: os.Stdout, timeout: 5 * time.Second}); err != nil && !errors.Is(err, context.Canceled) && !errors.Is(err, io.EOF) {
			fmt.Fprintln(os.Stderr, "broker-session failed; inspect bounded JSON event")
			os.Exit(1)
		}
	default:
		fmt.Fprintln(os.Stderr, "unknown mode")
		os.Exit(2)
	}
}
