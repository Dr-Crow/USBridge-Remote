// SPDX-License-Identifier: GPL-3.0-only
package main

import "testing"

func TestInvalidDestinationRejectedBeforeReadingCredentials(t *testing.T) {
	for _, s := range []string{"example.com:3241", "8.8.8.8:3241", "127.0.0.1:0"} {
		if err := run(s, "localhost", "absent", "absent", "absent", ""); err == nil {
			t.Fatal(s)
		}
	}
}
