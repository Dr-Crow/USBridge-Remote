// SPDX-License-Identifier: GPL-3.0-only
// Read-only device listing for the independent mutual-TLS broker service.
package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/localtls"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
	"os"
	"time"
)

var version = "development"

func main() {
	address := flag.String("server", "", "required literal private/loopback IP:port")
	name := flag.String("server-name", "", "expected name/IP in server certificate")
	cert := flag.String("client-cert", "", "operator-provisioned client certificate PEM")
	key := flag.String("client-key", "", "operator-provisioned client private key PEM")
	ca := flag.String("server-ca", "", "trusted server CA PEM")
	pin := flag.String("server-sha256", "", "exact server certificate DER SHA256, 64 hex digits")
	show := flag.Bool("version", false, "print source commit")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if err := run(*address, *name, *cert, *key, *ca, *pin); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(address, name, certPath, keyPath, caPath, pinText string) error {
	if flag.NArg() != 0 {
		return errors.New("no positional arguments accepted")
	}
	if err := localtls.ValidateAddress(address); err != nil {
		return err
	}
	pin, err := hex.DecodeString(pinText)
	if err != nil || len(pin) != 32 {
		return errors.New("server-sha256 must have 64 hexadecimal digits")
	}
	cert, err := tls.LoadX509KeyPair(certPath, keyPath)
	if err != nil {
		return err
	}
	pem, err := os.ReadFile(caPath)
	if err != nil {
		return err
	}
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(pem) {
		return errors.New("invalid server CA PEM")
	}
	identity := localtls.ClientIdentity{Certificate: cert, Roots: roots, ServerName: name}
	copy(identity.ServerPin[:], pin)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	conn, err := localtls.Dial(ctx, address, identity)
	if err != nil {
		return err
	}
	defer conn.Close()
	deadline, _ := ctx.Deadline()
	if err := conn.SetDeadline(deadline); err != nil {
		return err
	}
	request, err := usbip.EncodeNegotiationRequest(usbip.NegotiationRequest{Code: usbip.RequestDeviceList})
	if err != nil {
		return err
	}
	if _, err := conn.Write(request); err != nil {
		return err
	}
	devices, err := usbip.ReadDeviceListReply(conn)
	if err != nil {
		return err
	}
	return json.NewEncoder(os.Stdout).Encode(devices)
}
