// SPDX-License-Identifier: GPL-3.0-only
package main

import (
	"strings"
	"testing"
)

func TestInvalidArgumentsBeforeCredentials(t *testing.T) {
	for _, tc := range []struct{ address, bus string }{{"example.com:3241", "1-2"}, {"8.8.8.8:3241", "1-2"}, {"127.0.0.1:3241", ""}, {"127.0.0.1:3241", strings.Repeat("x", 32)}} {
		err := run(tc.address, "localhost", "absent", "absent", "absent", "", tc.bus)
		if err == nil || strings.Contains(err.Error(), "absent") {
			t.Fatal("argument validation must precede credential reads", err)
		}
	}
}

func TestConfigurationIndexValidation(t *testing.T) {
	for _, index := range []int{-2, 256} {
		if err := runWithConfiguration("", "", "", "", "", "", "", index); err == nil || err.Error() != "configuration-index must be -1 (disabled) or 0..255" {
			t.Fatal(index, err)
		}
	}
}
