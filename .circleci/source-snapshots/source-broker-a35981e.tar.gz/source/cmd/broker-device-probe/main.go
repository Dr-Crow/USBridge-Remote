// SPDX-License-Identifier: GPL-3.0-only
// Explicit standard-descriptor probe for the independent mutual-TLS broker service.
package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/localtls"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
	"os"
	"time"
)

var version = "development"

func main() {
	address := flag.String("server", "", "required literal private/loopback IP:port")
	name := flag.String("server-name", "", "expected name/IP in server certificate")
	cert := flag.String("client-cert", "", "operator-provisioned client certificate PEM")
	key := flag.String("client-key", "", "operator-provisioned client private key PEM")
	ca := flag.String("server-ca", "", "trusted server CA PEM")
	pin := flag.String("server-sha256", "", "exact server certificate DER SHA256, 64 hex digits")
	bus := flag.String("bus-id", "", "required explicitly consented device bus ID")
	config := flag.Int("configuration-index", -1, "optional zero-based configuration descriptor index 0..255; read only")
	show := flag.Bool("version", false, "print source commit")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if err := runWithConfiguration(*address, *name, *cert, *key, *ca, *pin, *bus, *config); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(address, name, certPath, keyPath, caPath, pinText, busID string) error {
	return runWithConfiguration(address, name, certPath, keyPath, caPath, pinText, busID, -1)
}
func runWithConfiguration(address, name, certPath, keyPath, caPath, pinText, busID string, config int) error {
	if config < -1 || config > 255 {
		return errors.New("configuration-index must be -1 (disabled) or 0..255")
	}
	if flag.NArg() != 0 {
		return errors.New("no positional arguments accepted")
	}
	if err := localtls.ValidateAddress(address); err != nil {
		return err
	}
	if _, err := usbip.EncodeNegotiationRequest(usbip.NegotiationRequest{Code: usbip.RequestImport, BusID: busID}); err != nil {
		return err
	}
	pin, err := hex.DecodeString(pinText)
	if err != nil || len(pin) != 32 {
		return errors.New("server-sha256 must have 64 hexadecimal digits")
	}
	cert, err := tls.LoadX509KeyPair(certPath, keyPath)
	if err != nil {
		return err
	}
	pem, err := os.ReadFile(caPath)
	if err != nil {
		return err
	}
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(pem) {
		return errors.New("invalid server CA PEM")
	}
	identity := localtls.ClientIdentity{Certificate: cert, Roots: roots, ServerName: name}
	copy(identity.ServerPin[:], pin)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	device, err := localtls.OpenDevice(ctx, address, identity, busID)
	if err != nil {
		return err
	}
	defer device.Close()
	descriptor, err := device.ReadDeviceDescriptor(ctx)
	if err != nil {
		return err
	}
	var configuration *usbip.ConfigurationDescriptor
	if config >= 0 {
		if config >= int(descriptor.ConfigurationCount) {
			return errors.New("configuration-index exceeds device descriptor count")
		}
		c, err := device.ReadConfigurationDescriptor(ctx, byte(config))
		if err != nil {
			return err
		}
		configuration = &c
	}
	return json.NewEncoder(os.Stdout).Encode(struct {
		Device        usbip.DeviceDescription
		Descriptor    usbip.DeviceDescriptor
		Configuration *usbip.ConfigurationDescriptor `json:",omitempty"`
	}{device.Description(), descriptor, configuration})
}
