// SPDX-License-Identifier: GPL-3.0-only
// Offline request inspector. Never opens sockets or accesses USB devices.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
	"io"
	"os"
)

var version = "development"

func main() {
	path := flag.String("file", "", "bounded non-ISO USB/IP request stream")
	show := flag.Bool("version", false, "print source version")
	flag.Parse()
	if *show {
		fmt.Println(version)
		return
	}
	if *path == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "--file required")
		os.Exit(2)
	}
	if err := run(*path); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(path string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	stats := struct {
		Requests, Submits, Unlinks int
		OutBytes                   int64
	}{}
	for {
		r, err := usbip.ReadRequest(f)
		if err == io.EOF {
			break
		}
		if err != nil {
			return fmt.Errorf("request %d: %w", stats.Requests+1, err)
		}
		stats.Requests++
		if stats.Requests > 10000 {
			return fmt.Errorf("request count limit exceeded")
		}
		if r.Command == usbip.CmdSubmit {
			stats.Submits++
			stats.OutBytes += int64(len(r.Data))
		} else {
			stats.Unlinks++
		}
	}
	return json.NewEncoder(os.Stdout).Encode(stats)
}
