// SPDX-License-Identifier: GPL-3.0-only
// Offline diagnostic only: not a USB broker and never opens a network connection.
package main

import (
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/protocol"
	"os"
)

var version = "dev"

func main() {
	input := flag.String("hex", "", "one complete USBP frame encoded as hexadecimal")
	showVersion := flag.Bool("version", false, "print source build version")
	flag.Parse()
	if *showVersion {
		fmt.Println(version)
		return
	}
	if *input == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "usage: broker-protocol-inspect --hex HEX; this is not a runtime USB broker")
		os.Exit(2)
	}
	raw, err := hex.DecodeString(*input)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	frame, err := protocol.Decode(raw)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	// Do not print payloads; they may contain user-provided device/session data.
	if err := json.NewEncoder(os.Stdout).Encode(struct {
		Version      byte `json:"version"`
		Type         byte `json:"type"`
		PayloadBytes int  `json:"payload_bytes"`
	}{protocol.Version, frame.Type, len(frame.Payload)}); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
