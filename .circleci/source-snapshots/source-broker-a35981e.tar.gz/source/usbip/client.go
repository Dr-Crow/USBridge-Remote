// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"sync/atomic"
	"time"
)

// ImportedDevice owns one already-authenticated, encrypted connection and one
// explicitly selected device. It serializes transfers; it is not a kernel VHCI
// driver and does not attach devices to the local OS. Cancellation closes the
// session, allowing the server to cancel and join outstanding hardware work.
type ImportedDevice struct {
	conn        net.Conn
	description DeviceDescription
	gate        chan struct{}
	next        uint64
	closed      atomic.Bool
}

// ImportDevice consumes conn once arguments validate. Caller must establish
// authenticated transport and owner consent before calling; a bus ID alone is
// not authorization. Failure closes the connection. It opens no listener.
func ImportDevice(ctx context.Context, conn net.Conn, busID string) (*ImportedDevice, error) {
	if ctx == nil || conn == nil {
		return nil, errors.New("context and authenticated connection required")
	}
	wire, err := EncodeNegotiationRequest(NegotiationRequest{Code: RequestImport, BusID: busID})
	if err != nil {
		return nil, err
	}
	ok := false
	defer func() {
		if !ok {
			_ = conn.Close()
		}
	}()
	stop := context.AfterFunc(ctx, func() { _ = conn.Close() })
	defer stop()
	if err = operationDeadline(ctx, conn); err != nil {
		return nil, err
	}
	if err = writeAll(conn, wire); err != nil {
		return nil, err
	}
	description, status, err := ReadImportReply(conn)
	if err != nil {
		return nil, err
	}
	if status != 0 {
		return nil, fmt.Errorf("device import rejected: status %d", status)
	}
	if description == nil || description.BusID != busID || description.Bus > 65535 || description.Number > 65535 {
		return nil, errors.New("imported device identity mismatch")
	}
	if err = ctx.Err(); err != nil {
		return nil, err
	}
	if err = conn.SetDeadline(time.Time{}); err != nil {
		return nil, err
	}
	ok = true
	return &ImportedDevice{conn: conn, description: *description, next: 1, gate: make(chan struct{}, 1)}, nil
}
func operationDeadline(ctx context.Context, c net.Conn) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	end := time.Now().Add(10 * time.Second)
	if d, ok := ctx.Deadline(); ok && d.Before(end) {
		end = d
	}
	return c.SetDeadline(end)
}
func (d *ImportedDevice) Description() DeviceDescription {
	desc := d.description
	desc.Interfaces = append([][3]byte(nil), desc.Interfaces...)
	return desc
}
func (d *ImportedDevice) Close() error {
	if d == nil || d.conn == nil {
		return nil
	}
	if d.closed.Swap(true) {
		return nil
	}
	return d.conn.Close()
}

// Transfer assigns the device and a unique sequence. Supply CmdSubmit with
// zero Sequence and Device. It does not accept caller-chosen unrelated device
// identifiers or raw unlink commands. An I/O/protocol failure is session-fatal.
// This deliberately narrow synchronous API does not implement pipelined URBs.
func (d *ImportedDevice) Transfer(ctx context.Context, req Request) (reply Reply, result error) {
	if ctx == nil {
		return reply, errors.New("context required")
	}
	if req.Command != CmdSubmit || req.Sequence != 0 || req.Device != 0 {
		return reply, errors.New("submit with unassigned sequence/device required")
	}
	if d == nil || d.conn == nil || d.gate == nil {
		return reply, errors.New("imported device required")
	}
	select {
	case d.gate <- struct{}{}:
		defer func() { <-d.gate }()
	case <-ctx.Done():
		return reply, ctx.Err()
	}
	if d.closed.Load() {
		return reply, net.ErrClosed
	}
	if d.next > 0xffffffff {
		return reply, errors.New("transfer sequence exhausted")
	}
	req.Sequence = uint32(d.next)
	req.Device = d.description.Bus<<16 | d.description.Number
	wire, err := EncodeRequest(req)
	if err != nil {
		return reply, err
	}
	if err = ctx.Err(); err != nil {
		return reply, err
	}
	d.next++
	stop := context.AfterFunc(ctx, func() { _ = d.Close() })
	defer stop()
	defer func() {
		if result != nil {
			_ = d.Close()
		}
	}()
	if err = operationDeadline(ctx, d.conn); err != nil {
		return reply, err
	}
	if err = writeAll(d.conn, wire); err != nil {
		return reply, err
	}
	reply, err = ReadReply(d.conn, func(seq uint32) (Request, bool) { return req, seq == req.Sequence })
	if ctx.Err() != nil {
		return reply, ctx.Err()
	}
	if err != nil {
		return reply, err
	}
	if err = d.conn.SetDeadline(time.Time{}); err != nil {
		return reply, err
	}
	return reply, nil
}

func writeAll(w io.Writer, b []byte) error {
	for len(b) > 0 {
		n, err := w.Write(b)
		if err != nil {
			return err
		}
		if n <= 0 {
			return io.ErrShortWrite
		}
		b = b[n:]
	}
	return nil
}
