// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"bytes"
	"context"
	"encoding/binary"
	"testing"
)

func configurationVector() []byte {
	return []byte{9, 2, 25, 0, 1, 1, 0, 0x80, 50, 9, 4, 0, 0, 1, 3, 0, 0, 0, 7, 5, 0x81, 3, 8, 0, 10}
}
func TestParseConfigurationDescriptor(t *testing.T) {
	p := configurationVector()
	d, err := ParseConfigurationDescriptor(p)
	if err != nil || d.Value != 1 || d.Interfaces != 1 || len(d.Records) != 2 || d.Records[1][2] != 0x81 {
		t.Fatal(d, err)
	}
	p[11] = 99
	if d.Records[0][2] != 0 {
		t.Fatal("record aliases input")
	}
	for n := 0; n < len(p); n++ {
		if _, err := ParseConfigurationDescriptor(p[:n]); err == nil {
			t.Fatal("accepted truncation", n)
		}
	}
	for _, offset := range []int{0, 1, 9, 18} {
		q := configurationVector()
		q[offset] = 0
		if _, err := ParseConfigurationDescriptor(q); err == nil {
			t.Fatal("accepted invalid record", offset)
		}
	}
	q := configurationVector()
	q[9] = 255
	if _, err := ParseConfigurationDescriptor(q); err == nil {
		t.Fatal("accepted overrun")
	}
	q = append(configurationVector(), 1)
	binary.LittleEndian.PutUint16(q[2:4], uint16(len(q)))
	if _, err := ParseConfigurationDescriptor(q); err == nil {
		t.Fatal("accepted trailing partial")
	}
	q = configurationVector()
	q[10] = 255
	if _, err := ParseConfigurationDescriptor(q); err != nil {
		t.Fatal("unknown descriptor should be preserved", err)
	}
}
func TestReadConfigurationDescriptor(t *testing.T) {
	for _, mode := range []string{"valid", "changed", "short", "stall", "oversize"} {
		t.Run(mode, func(t *testing.T) {
			calls := 0
			reg := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
				return sampleDevice(), &fakeDevice{transfer: func(_ context.Context, r Request) (TransferResult, error) {
					calls++
					size := 9
					if calls == 2 {
						size = 25
					}
					want := [8]byte{0x80, 6, 3, 2, 0, 0, byte(size), 0}
					if r.Setup != want || r.Endpoint != 0 || r.Direction != 1 || r.TransferLength != int32(size) {
						t.Errorf("unexpected request: %+v", r)
					}
					p := configurationVector()[:size]
					if mode == "oversize" {
						p[2] = 1
						p[3] = 0x20
					}
					if mode == "changed" && calls == 2 {
						p[5] = 2
					}
					if mode == "short" {
						p = p[:len(p)-1]
					}
					status := int32(0)
					if mode == "stall" {
						status = -32
						p = nil
					}
					return TransferResult{Status: status, ActualLength: int32(len(p)), Data: p}, nil
				}}, nil
			}}
			c, done := serviceFixture(t, reg, allowTestOwner)
			d, err := ImportDevice(context.Background(), c, "1-2")
			if err != nil {
				t.Fatal(err)
			}
			_, err = d.ReadConfigurationDescriptor(context.Background(), 3)
			if (err == nil) != (mode == "valid") {
				t.Fatal("unexpected result", err)
			}
			wantCalls := 1
			if mode == "valid" || mode == "changed" {
				wantCalls = 2
			}
			if calls != wantCalls {
				t.Fatal("request count", calls, wantCalls)
			}
			d.Close()
			_ = awaitSession(t, done)
		})
	}
}
func FuzzConfigurationDescriptor(f *testing.F) {
	f.Add(configurationVector())
	f.Add([]byte{})
	f.Add([]byte{9, 2, 9, 0, 0, 1, 0, 0x80, 0})
	f.Fuzz(func(t *testing.T, p []byte) {
		d, err := ParseConfigurationDescriptor(p)
		if err != nil {
			return
		}
		if len(p) < 9 || len(p) > MaxConfigurationBytes || int(binary.LittleEndian.Uint16(p[2:4])) != len(p) {
			t.Fatal("accepted bad envelope")
		}
		out := append([]byte(nil), p[:9]...)
		for _, r := range d.Records {
			if len(r) < 2 || int(r[0]) != len(r) {
				t.Fatal("bad record")
			}
			out = append(out, r...)
		}
		if !bytes.Equal(p, out) {
			t.Fatal("record reconstruction differs")
		}
	})
}
