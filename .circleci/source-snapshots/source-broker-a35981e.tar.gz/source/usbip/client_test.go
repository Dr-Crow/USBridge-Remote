// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"errors"
	"net"
	"sync/atomic"
	"testing"
	"time"
)

func TestImportedClientTransfersAndCloses(t *testing.T) {
	var closed atomic.Int32
	registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{transfer: func(_ context.Context, r Request) (TransferResult, error) {
			if r.Device != 1<<16|2 || r.Sequence < 1 {
				t.Error("wrong device/sequence")
			}
			return TransferResult{ActualLength: 1, Data: []byte{byte(r.Sequence)}}, nil
		}, close: func() error { closed.Add(1); return nil }}, nil
	}}
	conn, done := serviceFixture(t, registry, allowTestOwner)
	device, err := ImportDevice(context.Background(), conn, "1-2")
	if err != nil {
		t.Fatal(err)
	}
	for i := 1; i <= 3; i++ {
		r := request(0)
		r.Device = 0
		reply, err := device.Transfer(context.Background(), r)
		if err != nil || reply.Sequence != uint32(i) || len(reply.Data) != 1 || reply.Data[0] != byte(i) {
			t.Fatal(reply, err)
		}
	}
	if err = device.Close(); err != nil {
		t.Fatal(err)
	}
	if err = awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
	if closed.Load() != 1 {
		t.Fatal("backend close count", closed.Load())
	}
	r := request(0)
	r.Device = 0
	if _, err = device.Transfer(context.Background(), r); !errors.Is(err, net.ErrClosed) {
		t.Fatal(err)
	}
}
func TestImportedClientCancellationJoinsBackend(t *testing.T) {
	var exited, closed atomic.Bool
	registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{transfer: func(ctx context.Context, _ Request) (TransferResult, error) {
			<-ctx.Done()
			exited.Store(true)
			return TransferResult{}, ctx.Err()
		}, close: func() error { closed.Store(true); return nil }}, nil
	}}
	conn, done := serviceFixture(t, registry, allowTestOwner)
	device, err := ImportDevice(context.Background(), conn, "1-2")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	r := request(0)
	r.Device = 0
	if _, err = device.Transfer(ctx, r); err == nil {
		t.Fatal("timeout accepted")
	}
	_ = awaitSession(t, done)
	if !exited.Load() || !closed.Load() {
		t.Fatal("backend not joined/closed")
	}
}
func TestImportedClientRejectsIdentityMismatch(t *testing.T) {
	s, c := net.Pipe()
	defer s.Close()
	done := make(chan struct{})
	go func() {
		defer close(done)
		_, _ = ReadNegotiationRequest(s)
		d := sampleDevice()
		d.BusID = "9-9"
		b, _ := EncodeImportReply(0, &d)
		_ = writeAll(s, b)
	}()
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if d, err := ImportDevice(ctx, c, "1-2"); err == nil || d != nil {
		t.Fatal("wrong device accepted")
	}
	<-done
}
func TestQueuedTransferCancellation(t *testing.T) {
	s, c := net.Pipe()
	defer s.Close()
	defer c.Close()
	d := &ImportedDevice{conn: c, gate: make(chan struct{}, 1), next: 1}
	d.gate <- struct{}{}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	r := request(0)
	r.Device = 0
	if _, err := d.Transfer(ctx, r); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}
