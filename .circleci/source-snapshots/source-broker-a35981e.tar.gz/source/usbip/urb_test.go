// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"bytes"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"io"
	"reflect"
	"testing"
)

func TestRequestGoldenAndFragmentation(t *testing.T) {
	// Header fixture agrees with the Linux USB/IP documentation's interrupt-IN example.
	const fixture = "0000000100000d050001000f00000001000000010000020000000040ffffffff00000000000000040000000000000000"
	b, err := hex.DecodeString(fixture)
	if err != nil {
		t.Fatal(err)
	}
	got, err := ReadRequest(&oneByte{bytes.NewReader(b)})
	if err != nil {
		t.Fatal(err)
	}
	want := Request{Command: CmdSubmit, Sequence: 0xd05, Device: 0x1000f, Direction: 1, Endpoint: 1, Flags: 0x200, TransferLength: 64, StartFrame: -1, PacketCount: 0, Interval: 4}
	if !reflect.DeepEqual(got, want) {
		t.Fatal(got)
	}
	encoded, err := EncodeRequest(got)
	if err != nil || !bytes.Equal(encoded, b) {
		t.Fatal(err)
	}
}

type oneByte struct{ io.Reader }

func (r *oneByte) Read(p []byte) (int, error) {
	if len(p) > 1 {
		p = p[:1]
	}
	return r.Reader.Read(p)
}
func TestOutAndFollowingUnlink(t *testing.T) {
	r := Request{Command: CmdSubmit, Sequence: 7, Direction: 0, Endpoint: 1, TransferLength: 3, PacketCount: -1, Data: []byte{2, 3, 4}}
	a, _ := EncodeRequest(r)
	u := Request{Command: CmdUnlink, Sequence: 8, UnlinkSequence: 7}
	b, _ := EncodeRequest(u)
	stream := bytes.NewReader(append(a, b...))
	got, err := ReadRequest(stream)
	if err != nil || !reflect.DeepEqual(got, r) {
		t.Fatal(got, err)
	}
	got, err = ReadRequest(stream)
	if err != nil || !reflect.DeepEqual(got, u) {
		t.Fatal(got, err)
	}
	if _, err = ReadRequest(stream); err != io.EOF {
		t.Fatal(err)
	}
}
func TestReplies(t *testing.T) {
	req := Request{Command: CmdSubmit, Sequence: 7, Direction: 1, TransferLength: 3, PacketCount: -1}
	b, err := EncodeSubmitReply(req, 0, 3, []byte{1, 2, 3})
	if err != nil {
		t.Fatal(err)
	}
	if len(b) != 51 || binary.BigEndian.Uint32(b[:4]) != RetSubmit || binary.BigEndian.Uint32(b[24:28]) != 3 || binary.BigEndian.Uint32(b[32:36]) != 0xffffffff {
		t.Fatal("reply fields")
	}
	if !bytes.Equal(b[8:20], make([]byte, 12)) {
		t.Fatal("nonzero server reserved fields")
	}
	req.Direction = 0
	if _, err = EncodeSubmitReply(req, 0, 3, []byte{1, 2, 3}); err == nil {
		t.Fatal("OUT data accepted")
	}
	b, err = EncodeSubmitReply(req, 0, 3, nil)
	if err != nil || len(b) != 48 {
		t.Fatal(err)
	}
	if _, err = EncodeSubmitReply(req, 0, 4, nil); err == nil {
		t.Fatal("oversized reply accepted")
	}
	u := EncodeUnlinkReply(8, -104)
	if len(u) != 48 || binary.BigEndian.Uint32(u[:4]) != RetUnlink || int32(binary.BigEndian.Uint32(u[20:24])) != -104 {
		t.Fatal("unlink fields")
	}
}
func TestRequestRejectsInvalid(t *testing.T) {
	base := Request{Command: CmdSubmit, Direction: 1, TransferLength: 64, PacketCount: -1}
	for _, change := range []func(*Request){
		func(r *Request) { r.TransferLength = -1 }, func(r *Request) { r.TransferLength = MaxTransfer + 1 },
		func(r *Request) { r.Direction = 2 }, func(r *Request) { r.Endpoint = 16 }, func(r *Request) { r.PacketCount = 1 },
		func(r *Request) { r.PacketCount = -2 }, func(r *Request) { r.Command = 99 },
	} {
		r := base
		change(&r)
		if _, err := EncodeRequest(r); err == nil {
			t.Fatal(r)
		}
	}
	b, _ := EncodeRequest(base)
	for n := 0; n < len(b); n++ {
		if _, err := ReadRequest(bytes.NewReader(b[:n])); err == nil {
			t.Fatal("truncated header", n)
		}
	}
	binary.BigEndian.PutUint32(b[32:36], 1)
	if _, err := ReadRequest(bytes.NewReader(b)); !errors.Is(err, ErrUnsupportedISO) {
		t.Fatal(err)
	}
	u, _ := EncodeRequest(Request{Command: CmdUnlink})
	u[47] = 1
	if _, err := ReadRequest(bytes.NewReader(u)); err == nil {
		t.Fatal("padding")
	}
}
func TestTruncatedOutAndLengthPreallocation(t *testing.T) {
	r := Request{Command: CmdSubmit, TransferLength: 3, PacketCount: -1, Data: []byte{1, 2, 3}}
	b, _ := EncodeRequest(r)
	if _, err := ReadRequest(bytes.NewReader(b[:len(b)-1])); err != io.ErrUnexpectedEOF {
		t.Fatal(err)
	}
	if _, err := ReadRequest(bytes.NewReader(b[:48])); err != io.ErrUnexpectedEOF {
		t.Fatal("missing OUT payload", err)
	}
	binary.BigEndian.PutUint32(b[24:28], 0x7fffffff)
	if _, err := ReadRequest(bytes.NewReader(b[:48])); err == nil || err == io.EOF {
		t.Fatal("unchecked length", err)
	}
}
func FuzzRequest(f *testing.F) {
	seed, _ := EncodeRequest(Request{Command: CmdSubmit, Direction: 1, PacketCount: -1})
	f.Add(seed)
	f.Fuzz(func(t *testing.T, b []byte) {
		if len(b) > MaxTransfer+HeaderSize {
			return
		}
		reader := bytes.NewReader(b)
		r, err := ReadRequest(reader)
		if err != nil {
			return
		}
		out, err := EncodeRequest(r)
		if err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(out, b[:len(b)-reader.Len()]) {
			t.Fatal("roundtrip differs")
		}
	})
}
