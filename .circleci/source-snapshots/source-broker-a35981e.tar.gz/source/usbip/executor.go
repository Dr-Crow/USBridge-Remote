// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"errors"
	"io"
	"sync"
)

var ErrCapacity = errors.New("USB/IP transfer capacity exhausted")
var ErrClosed = errors.New("USB/IP executor closed")

type TransferResult struct {
	Status, ActualLength int32
	Data                 []byte
}

// DeviceBackend is owned by one Executor after successful construction.
// Transfer must honor cancellation and return; Close runs only after every
// Transfer has returned. Backends must not re-enter Executor.Close from either method.
type DeviceBackend interface {
	Transfer(context.Context, Request) (TransferResult, error)
	Close() error
}

// EndpointOrderedBackend requests FIFO execution within each endpoint/direction.
// Endpoint zero shares one lane across both directions. This preserves native
// control/OUT side-effect order; unrelated endpoints may execute concurrently.
// Wrappers must explicitly forward this policy to avoid losing it by embedding
// only the DeviceBackend interface.
type EndpointOrderedBackend interface {
	DeviceBackend
	SerializeEndpoints() bool
}

type Completion struct {
	Sequence uint32
	Wire     []byte
	Err      error
}
type operation struct {
	cancel  context.CancelFunc
	request Request
	done    chan struct{}
	turn    chan struct{}
	lane    uint32
}

// Executor is an in-process, device-bound transfer lifecycle. Authentication,
// import negotiation and operator device consent must precede construction.
// Capacity includes executing AND completed-but-unconsumed transfers.
type Executor struct {
	mu                 sync.Mutex
	ctx                context.Context
	cancel             context.CancelFunc
	backend            DeviceBackend
	device             uint32
	capacity, occupied int
	closed             bool
	pending            map[uint32]*operation
	lanes              map[uint32][]*operation
	reserved           map[uint32]bool
	ready              chan Completion
	workers            sync.WaitGroup
	closeOnce          sync.Once
	closeErr           error
}

func NewExecutor(ctx context.Context, backend DeviceBackend, device uint32, capacity int) (*Executor, error) {
	if ctx == nil || backend == nil || capacity < 1 || capacity > 64 {
		return nil, errors.New("context, backend and capacity 1..64 required")
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	run, cancel := context.WithCancel(ctx)
	e := &Executor{ctx: run, cancel: cancel, backend: backend, device: device, capacity: capacity, pending: map[uint32]*operation{}, reserved: map[uint32]bool{}, ready: make(chan Completion, capacity)}
	if policy, ok := backend.(EndpointOrderedBackend); ok && policy.SerializeEndpoints() {
		e.lanes = make(map[uint32][]*operation)
	}
	go func() { <-run.Done(); _ = e.Close() }()
	return e, nil
}
func (e *Executor) Submit(request Request) error {
	if request.Command != CmdSubmit || request.Device != e.device {
		return errors.New("submit for imported device required")
	}
	if _, err := EncodeRequest(request); err != nil {
		return err
	}
	request.Data = append([]byte(nil), request.Data...)
	e.mu.Lock()
	if e.closed || e.ctx.Err() != nil {
		e.mu.Unlock()
		return ErrClosed
	}
	if e.reserved[request.Sequence] {
		e.mu.Unlock()
		return errors.New("duplicate pending sequence")
	}
	if e.occupied == e.capacity {
		e.mu.Unlock()
		return ErrCapacity
	}
	ctx, cancel := context.WithCancel(e.ctx)
	op := &operation{cancel: cancel, request: request, done: make(chan struct{})}
	e.pending[request.Sequence] = op
	e.reserved[request.Sequence] = true
	e.occupied++
	e.workers.Add(1)
	if e.lanes != nil {
		op.lane = request.Endpoint
		if request.Endpoint != 0 {
			op.lane |= request.Direction << 4
		}
		op.turn = make(chan struct{})
		queue := e.lanes[op.lane]
		e.lanes[op.lane] = append(queue, op)
		if len(queue) == 0 {
			close(op.turn)
		}
	}
	e.mu.Unlock()
	go e.execute(ctx, op)
	return nil
}
func (e *Executor) execute(ctx context.Context, op *operation) {
	defer e.workers.Done()
	defer close(op.done)
	defer e.releaseLane(op)
	defer op.cancel()
	var result TransferResult
	var err error
	if op.turn != nil {
		select {
		case <-op.turn:
		case <-ctx.Done():
		}
	}
	if err = ctx.Err(); err == nil {
		result, err = e.backend.Transfer(ctx, op.request)
	}
	e.mu.Lock()
	// UNLINK or Close won the race: suppress this submission's completion.
	if e.closed || e.ctx.Err() != nil || e.pending[op.request.Sequence] != op {
		if e.pending[op.request.Sequence] == op {
			delete(e.pending, op.request.Sequence)
		}
		e.occupied--
		delete(e.reserved, op.request.Sequence)
		e.mu.Unlock()
		return
	}
	delete(e.pending, op.request.Sequence)
	e.mu.Unlock()
	if err != nil {
		result = TransferResult{Status: -5}
	}
	wire, encodeErr := EncodeSubmitReply(op.request, result.Status, result.ActualLength, result.Data)
	if encodeErr != nil {
		err = errors.Join(err, encodeErr)
		wire, _ = EncodeSubmitReply(op.request, -5, 0, nil)
	}
	// There can be at most capacity occupied slots, including this completion.
	// Thus this buffer cannot block even when a consumer stops reading.
	e.ready <- Completion{Sequence: op.request.Sequence, Wire: wire, Err: err}
}

// releaseLane also removes canceled waiting operations immediately. Removing a
// middle entry never advances the head, so a canceled queued request cannot
// allow its successor to overtake an earlier native operation.
func (e *Executor) releaseLane(op *operation) {
	if op.turn == nil {
		return
	}
	e.mu.Lock()
	defer e.mu.Unlock()
	queue := e.lanes[op.lane]
	for i, item := range queue {
		if item != op {
			continue
		}
		copy(queue[i:], queue[i+1:])
		queue[len(queue)-1] = nil
		queue = queue[:len(queue)-1]
		if len(queue) == 0 {
			delete(e.lanes, op.lane)
		} else {
			e.lanes[op.lane] = queue
			if i == 0 {
				close(queue[0].turn)
			}
		}
		return
	}
}

// Unlink atomically selects cancellation versus completion. A successful
// cancellation returns -ECONNRESET and suppresses RET_SUBMIT; if completion has
// already won it returns status zero. Successful cancellation joins the backend
// operation before acknowledging, so its capacity slot is reusable on receipt.
// The transport must serialize writes.
func (e *Executor) Unlink(request Request) ([]byte, error) {
	if request.Command != CmdUnlink || request.Device != e.device {
		return nil, errors.New("unlink for imported device required")
	}
	if _, err := EncodeRequest(request); err != nil {
		return nil, err
	}
	e.mu.Lock()
	if e.closed || e.ctx.Err() != nil {
		e.mu.Unlock()
		return nil, ErrClosed
	}
	if e.reserved[request.Sequence] {
		e.mu.Unlock()
		return nil, errors.New("unlink sequence already active")
	}
	op := e.pending[request.UnlinkSequence]
	if op != nil {
		delete(e.pending, request.UnlinkSequence)
		op.cancel()
	}
	e.mu.Unlock()
	status := int32(0)
	if op != nil {
		<-op.done
		status = -104
	}
	return EncodeUnlinkReply(request.Sequence, status), nil
}

// Next releases one capacity slot when a completion is consumed. After Close,
// already-selected completions may still be drained, followed by io.EOF.
func (e *Executor) Next(ctx context.Context) (Completion, error) {
	if ctx == nil {
		return Completion{}, errors.New("context required")
	}
	select {
	case <-ctx.Done():
		return Completion{}, ctx.Err()
	case completion, ok := <-e.ready:
		if !ok {
			return Completion{}, io.EOF
		}
		e.mu.Lock()
		e.occupied--
		delete(e.reserved, completion.Sequence)
		e.mu.Unlock()
		return completion, nil
	}
}
func (e *Executor) Close() error {
	e.closeOnce.Do(func() {
		e.mu.Lock()
		e.closed = true
		e.cancel()
		for sequence, op := range e.pending {
			delete(e.pending, sequence)
			op.cancel()
		}
		e.mu.Unlock()
		e.workers.Wait()
		e.closeErr = e.backend.Close()
		close(e.ready)
	})
	return e.closeErr
}
