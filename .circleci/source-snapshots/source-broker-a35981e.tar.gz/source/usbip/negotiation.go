// SPDX-License-Identifier: GPL-3.0-only
// Analyst-authored USB/IP negotiation codec. No device authorization or I/O.
package usbip

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"strings"
)

const Version uint16 = 0x0111
const (
	RequestImport     uint16 = 0x8003
	ReplyImport       uint16 = 3
	RequestDeviceList uint16 = 0x8005
	ReplyDeviceList   uint16 = 5
	MaxDevices               = 256
)

type NegotiationRequest struct {
	Code  uint16
	BusID string
}
type DeviceDescription struct {
	Path, BusID                                                              string
	Bus, Number, Speed                                                       uint32
	Vendor, Product, BCD                                                     uint16
	Class, Subclass, Protocol, Configuration, Configurations, InterfaceCount byte
	Interfaces                                                               [][3]byte
}

func readExact(r io.Reader, b []byte) error {
	_, err := io.ReadFull(r, b)
	if err == io.EOF {
		return io.ErrUnexpectedEOF
	}
	return err
}
func common(code uint16, status uint32) []byte {
	b := make([]byte, 8)
	binary.BigEndian.PutUint16(b, Version)
	binary.BigEndian.PutUint16(b[2:], code)
	binary.BigEndian.PutUint32(b[4:], status)
	return b
}
func readCommon(r io.Reader) (uint16, uint32, error) {
	if r == nil {
		return 0, 0, errors.New("reader required")
	}
	var b [8]byte
	if _, err := io.ReadFull(r, b[:]); err != nil {
		return 0, 0, err
	}
	if binary.BigEndian.Uint16(b[:]) != Version {
		return 0, 0, errors.New("unsupported USB/IP version")
	}
	return binary.BigEndian.Uint16(b[2:]), binary.BigEndian.Uint32(b[4:]), nil
}
func fixedString(b []byte) (string, error) {
	n := bytes.IndexByte(b, 0)
	if n < 0 {
		return "", errors.New("unterminated fixed string")
	}
	for _, v := range b[n:] {
		if v != 0 {
			return "", errors.New("nonzero string padding")
		}
	}
	return string(b[:n]), nil
}
func putString(b []byte, s string) error {
	if len(s) >= len(b) || strings.ContainsRune(s, 0) {
		return errors.New("invalid fixed string")
	}
	copy(b, s)
	return nil
}
func ReadNegotiationRequest(r io.Reader) (NegotiationRequest, error) {
	code, status, err := readCommon(r)
	if err != nil {
		return NegotiationRequest{}, err
	}
	q := NegotiationRequest{Code: code}
	if status != 0 {
		return q, errors.New("nonzero request status")
	}
	switch code {
	case RequestDeviceList:
		return q, nil
	case RequestImport:
		var b [32]byte
		if err = readExact(r, b[:]); err != nil {
			return q, err
		}
		q.BusID, err = fixedString(b[:])
		if err == nil && q.BusID == "" {
			err = errors.New("empty bus ID")
		}
		return q, err
	default:
		return q, errors.New("unsupported negotiation request")
	}
}
func EncodeNegotiationRequest(q NegotiationRequest) ([]byte, error) {
	b := common(q.Code, 0)
	switch q.Code {
	case RequestDeviceList:
		if q.BusID != "" {
			return nil, errors.New("device list has no bus ID")
		}
	case RequestImport:
		if q.BusID == "" {
			return nil, errors.New("empty bus ID")
		}
		s := make([]byte, 32)
		if err := putString(s, q.BusID); err != nil {
			return nil, err
		}
		b = append(b, s...)
	default:
		return nil, errors.New("unsupported negotiation request")
	}
	return b, nil
}
func encodeDevice(d DeviceDescription, withInterfaces bool) ([]byte, error) {
	if d.BusID == "" || len(d.Interfaces) > 255 || (withInterfaces && len(d.Interfaces) != int(d.InterfaceCount)) {
		return nil, errors.New("invalid device description")
	}
	b := make([]byte, 312)
	if err := putString(b[:256], d.Path); err != nil {
		return nil, err
	}
	if err := putString(b[256:288], d.BusID); err != nil {
		return nil, err
	}
	for i, v := range []uint32{d.Bus, d.Number, d.Speed} {
		binary.BigEndian.PutUint32(b[288+i*4:], v)
	}
	for i, v := range []uint16{d.Vendor, d.Product, d.BCD} {
		binary.BigEndian.PutUint16(b[300+i*2:], v)
	}
	copy(b[306:], []byte{d.Class, d.Subclass, d.Protocol, d.Configuration, d.Configurations, d.InterfaceCount})
	if withInterfaces {
		for _, v := range d.Interfaces {
			b = append(b, v[0], v[1], v[2], 0)
		}
	}
	return b, nil
}
func readDevice(r io.Reader, withInterfaces bool) (DeviceDescription, error) {
	var d DeviceDescription
	var b [312]byte
	if err := readExact(r, b[:]); err != nil {
		return d, err
	}
	var err error
	d.Path, err = fixedString(b[:256])
	if err != nil {
		return d, err
	}
	d.BusID, err = fixedString(b[256:288])
	if err != nil {
		return d, err
	}
	if d.BusID == "" {
		return d, errors.New("empty bus ID")
	}
	d.Bus = binary.BigEndian.Uint32(b[288:])
	d.Number = binary.BigEndian.Uint32(b[292:])
	d.Speed = binary.BigEndian.Uint32(b[296:])
	d.Vendor = binary.BigEndian.Uint16(b[300:])
	d.Product = binary.BigEndian.Uint16(b[302:])
	d.BCD = binary.BigEndian.Uint16(b[304:])
	d.Class = b[306]
	d.Subclass = b[307]
	d.Protocol = b[308]
	d.Configuration = b[309]
	d.Configurations = b[310]
	d.InterfaceCount = b[311]
	if withInterfaces {
		d.Interfaces = make([][3]byte, int(d.InterfaceCount))
		for i := range d.Interfaces {
			var x [4]byte
			if err := readExact(r, x[:]); err != nil {
				return d, err
			}
			if x[3] != 0 {
				return d, errors.New("nonzero interface padding")
			}
			copy(d.Interfaces[i][:], x[:3])
		}
	}
	return d, nil
}

// ReadDeviceListReply leaves following bytes untouched, including vendor HID
// extensions. It does not imply permission to open any listed device.
func ReadDeviceListReply(r io.Reader) ([]DeviceDescription, error) {
	code, status, err := readCommon(r)
	if err != nil {
		return nil, err
	}
	if code != ReplyDeviceList || status != 0 {
		return nil, errors.New("unsuccessful device list reply")
	}
	var n [4]byte
	if err = readExact(r, n[:]); err != nil {
		return nil, err
	}
	count := binary.BigEndian.Uint32(n[:])
	if count > MaxDevices {
		return nil, errors.New("device count exceeds bound")
	}
	ds := make([]DeviceDescription, 0, int(count))
	for i := uint32(0); i < count; i++ {
		d, err := readDevice(r, true)
		if err != nil {
			return nil, err
		}
		ds = append(ds, d)
	}
	return ds, nil
}
func EncodeDeviceListReply(ds []DeviceDescription) ([]byte, error) {
	if len(ds) > MaxDevices {
		return nil, errors.New("device count exceeds bound")
	}
	b := append(common(ReplyDeviceList, 0), 0, 0, 0, 0)
	binary.BigEndian.PutUint32(b[8:], uint32(len(ds)))
	for _, d := range ds {
		x, err := encodeDevice(d, true)
		if err != nil {
			return nil, err
		}
		b = append(b, x...)
	}
	return b, nil
}

// Import success describes a backend already opened with caller authorization.
// The codec never opens it or generates a successful attachment itself.
func EncodeImportReply(status uint32, d *DeviceDescription) ([]byte, error) {
	b := common(ReplyImport, status)
	if status != 0 {
		if d != nil {
			return nil, errors.New("failed import has no body")
		}
		return b, nil
	}
	if d == nil {
		return nil, errors.New("successful import requires description")
	}
	x, err := encodeDevice(*d, false)
	if err != nil {
		return nil, err
	}
	return append(b, x...), nil
}
func ReadImportReply(r io.Reader) (*DeviceDescription, uint32, error) {
	code, status, err := readCommon(r)
	if err != nil {
		return nil, 0, err
	}
	if code != ReplyImport {
		return nil, 0, errors.New("unexpected reply code")
	}
	if status != 0 {
		return nil, status, nil
	}
	d, err := readDevice(r, false)
	if err != nil {
		return nil, 0, err
	}
	return &d, 0, nil
}
