// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"encoding/binary"
	"errors"
	"fmt"
)

// DeviceDescriptor is the fixed standard USB device descriptor, not a string
// descriptor. Reading it does not select a configuration or attach an OS driver.
type DeviceDescriptor struct {
	USBVersion                                                       uint16
	Class, Subclass, Protocol, MaxPacketSize0                        byte
	VendorID, ProductID, DeviceVersion                               uint16
	ManufacturerIndex, ProductIndex, SerialIndex, ConfigurationCount byte
}

// ReadDeviceDescriptor sends only the standard device-to-host GET_DESCRIPTOR
// request on endpoint zero. The imported session remains subject to the server's
// consent and backend restrictions. A HID-only backend may reject this request.
func (d *ImportedDevice) ReadDeviceDescriptor(ctx context.Context) (DeviceDescriptor, error) {
	r, err := d.Transfer(ctx, Request{Command: CmdSubmit, Direction: 1,
		TransferLength: 18, PacketCount: -1, Setup: [8]byte{0x80, 6, 0, 1, 0, 0, 18, 0}})
	if err != nil {
		return DeviceDescriptor{}, err
	}
	if r.Status != 0 {
		return DeviceDescriptor{}, fmt.Errorf("device descriptor transfer failed: status %d", r.Status)
	}
	if r.ActualLength != 18 || len(r.Data) != 18 {
		return DeviceDescriptor{}, errors.New("device descriptor must contain exactly 18 bytes")
	}
	return ParseDeviceDescriptor(r.Data)
}

// ParseDeviceDescriptor validates the fixed descriptor envelope and decodes USB
// little-endian fields. It does not interpret manufacturer-controlled strings.
func ParseDeviceDescriptor(p []byte) (DeviceDescriptor, error) {
	if len(p) != 18 || p[0] != 18 || p[1] != 1 {
		return DeviceDescriptor{}, errors.New("invalid standard device descriptor")
	}
	return DeviceDescriptor{USBVersion: binary.LittleEndian.Uint16(p[2:4]),
		Class: p[4], Subclass: p[5], Protocol: p[6], MaxPacketSize0: p[7],
		VendorID: binary.LittleEndian.Uint16(p[8:10]), ProductID: binary.LittleEndian.Uint16(p[10:12]),
		DeviceVersion: binary.LittleEndian.Uint16(p[12:14]), ManufacturerIndex: p[14],
		ProductIndex: p[15], SerialIndex: p[16], ConfigurationCount: p[17]}, nil
}
