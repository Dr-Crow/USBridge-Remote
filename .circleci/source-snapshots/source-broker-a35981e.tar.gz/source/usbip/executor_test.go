// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type fakeDevice struct {
	transfer func(context.Context, Request) (TransferResult, error)
	close    func() error
}

func (f *fakeDevice) Transfer(ctx context.Context, r Request) (TransferResult, error) {
	return f.transfer(ctx, r)
}
func (f *fakeDevice) Close() error {
	if f.close != nil {
		return f.close()
	}
	return nil
}
func request(seq uint32) Request {
	return Request{Command: CmdSubmit, Sequence: seq, Device: 7, Direction: 1, TransferLength: 3, PacketCount: -1}
}
func newEngine(t *testing.T, b DeviceBackend, capacity int) *Executor {
	t.Helper()
	e, err := NewExecutor(context.Background(), b, 7, capacity)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = e.Close() })
	return e
}
func next(t *testing.T, e *Executor) Completion {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	c, err := e.Next(ctx)
	if err != nil {
		t.Fatal(err)
	}
	return c
}
func TestExecutorCompletionAndLateUnlink(t *testing.T) {
	e := newEngine(t, &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) {
		return TransferResult{ActualLength: 3, Data: []byte{1, 2, 3}}, nil
	}}, 2)
	req := request(1)
	if err := e.Submit(req); err != nil {
		t.Fatal(err)
	}
	c := next(t, e)
	if c.Err != nil {
		t.Fatal(c.Err)
	}
	decoded, err := ReadReply(bytes.NewReader(c.Wire), func(seq uint32) (Request, bool) { return req, seq == 1 })
	if err != nil || !bytes.Equal(decoded.Data, []byte{1, 2, 3}) {
		t.Fatal(decoded, err)
	}
	ack, err := e.Unlink(Request{Command: CmdUnlink, Sequence: 2, Device: 7, UnlinkSequence: 1})
	if err != nil || int32(binary.BigEndian.Uint32(ack[20:24])) != 0 {
		t.Fatal(err)
	}
}
func TestExecutorUnlinkWinsAndCloseJoins(t *testing.T) {
	started := make(chan struct{})
	var active, closed atomic.Int32
	backend := &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
		active.Add(1)
		defer active.Add(-1)
		close(started)
		<-ctx.Done()
		return TransferResult{}, ctx.Err()
	}, close: func() error {
		if active.Load() != 0 {
			t.Error("backend closed during transfer")
		}
		closed.Add(1)
		return nil
	}}
	e := newEngine(t, backend, 1)
	if err := e.Submit(request(1)); err != nil {
		t.Fatal(err)
	}
	<-started
	if _, err := e.Unlink(Request{Command: CmdUnlink, Sequence: 2, Device: 8, UnlinkSequence: 1}); err == nil {
		t.Fatal("other device cancellation")
	}
	ack, err := e.Unlink(Request{Command: CmdUnlink, Sequence: 2, Device: 7, UnlinkSequence: 1})
	if err != nil || int32(binary.BigEndian.Uint32(ack[20:24])) != -104 {
		t.Fatal(err)
	}
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); _ = e.Close() }()
	}
	wg.Wait()
	if closed.Load() != 1 {
		t.Fatal(closed.Load())
	}
	if _, err := e.Next(context.Background()); err != io.EOF {
		t.Fatal("cancelled submit completed", err)
	}
	if err := e.Submit(request(3)); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
}
func TestExecutorCapacityIncludesQueuedCompletion(t *testing.T) {
	e := newEngine(t, &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) { return TransferResult{}, nil }}, 1)
	if err := e.Submit(request(1)); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(3 * time.Second)
	for len(e.ready) == 0 && time.Now().Before(deadline) {
		time.Sleep(time.Millisecond)
	}
	if len(e.ready) != 1 {
		t.Fatal("completion did not queue")
	}
	if err := e.Submit(request(2)); !errors.Is(err, ErrCapacity) {
		t.Fatal("queued completion did not reserve slot", err)
	}
	if err := e.Submit(request(1)); err == nil {
		t.Fatal("queued sequence reused")
	}
	next(t, e)
	if err := e.Submit(request(2)); err != nil {
		t.Fatal(err)
	}
	next(t, e)
}
func TestExecutorBackendFailureAndInvalidResult(t *testing.T) {
	for _, fail := range []bool{false, true} {
		e := newEngine(t, &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) {
			if fail {
				return TransferResult{}, errors.New("device failed")
			}
			return TransferResult{ActualLength: 4, Data: []byte{1, 2, 3, 4}}, nil
		}}, 1)
		if err := e.Submit(request(1)); err != nil {
			t.Fatal(err)
		}
		c := next(t, e)
		if c.Err == nil {
			t.Fatal("backend failure hidden")
		}
		if len(c.Wire) != 48 || int32(binary.BigEndian.Uint32(c.Wire[20:24])) != -5 {
			t.Fatal("failure serialized as success")
		}
	}
}
func TestExecutorOwnsOutBuffer(t *testing.T) {
	release := make(chan struct{})
	seen := make(chan []byte, 1)
	e := newEngine(t, &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
		select {
		case <-release:
		case <-ctx.Done():
			return TransferResult{}, ctx.Err()
		}
		seen <- append([]byte(nil), r.Data...)
		return TransferResult{ActualLength: 3}, nil
	}}, 1)
	req := request(1)
	req.Direction = 0
	req.Data = []byte{1, 2, 3}
	if err := e.Submit(req); err != nil {
		t.Fatal(err)
	}
	req.Data[0] = 9
	close(release)
	next(t, e)
	if !bytes.Equal(<-seen, []byte{1, 2, 3}) {
		t.Fatal("caller mutated backend buffer")
	}
}
func TestExecutorParentCancelClosesBackend(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	e, err := NewExecutor(ctx, &fakeDevice{transfer: func(ctx context.Context, _ Request) (TransferResult, error) {
		<-ctx.Done()
		return TransferResult{}, ctx.Err()
	}, close: func() error { close(done); return nil }}, 7, 1)
	if err != nil {
		t.Fatal(err)
	}
	if err = e.Submit(request(1)); err != nil {
		t.Fatal(err)
	}
	cancel()
	select {
	case <-done:
	case <-time.After(3 * time.Second):
		t.Fatal("parent cancellation did not close backend")
	}
	if _, err = e.Next(context.Background()); err != io.EOF {
		t.Fatal("canceled parent completed", err)
	}
	if err = e.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestCompletionUnlinkRaceHasOneWinner(t *testing.T) {
	for i := 0; i < 100; i++ {
		release := make(chan struct{})
		e, err := NewExecutor(context.Background(), &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
			select {
			case <-release:
				return TransferResult{}, nil
			case <-ctx.Done():
				return TransferResult{}, ctx.Err()
			}
		}}, 7, 1)
		if err != nil {
			t.Fatal(err)
		}
		if err = e.Submit(request(1)); err != nil {
			t.Fatal(err)
		}
		go close(release)
		ack, err := e.Unlink(Request{Command: CmdUnlink, Sequence: 2, Device: 7, UnlinkSequence: 1})
		if err != nil {
			t.Fatal(err)
		}
		_ = e.Close()
		completions := 0
		for {
			_, err := e.Next(context.Background())
			if err == io.EOF {
				break
			}
			if err != nil {
				t.Fatal(err)
			}
			completions++
		}
		status := int32(binary.BigEndian.Uint32(ack[20:24]))
		if (status == -104 && completions != 0) || (status == 0 && completions != 1) {
			t.Fatal("two winners or lost completion", status, completions)
		}
	}
}

func TestUnlinkAcknowledgmentJoinsBackendAndReleasesCapacity(t *testing.T) {
	started := make(chan struct{})
	canceled := make(chan struct{})
	release := make(chan struct{})
	e := newEngine(t, &fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
		if r.Sequence != 1 {
			return TransferResult{}, nil
		}
		close(started)
		<-ctx.Done()
		close(canceled)
		<-release
		return TransferResult{}, ctx.Err()
	}}, 1)
	if err := e.Submit(request(1)); err != nil {
		t.Fatal(err)
	}
	<-started
	ack := make(chan error, 1)
	go func() {
		_, err := e.Unlink(Request{Command: CmdUnlink, Sequence: 2, Device: 7, UnlinkSequence: 1})
		ack <- err
	}()
	<-canceled
	select {
	case <-ack:
		t.Fatal("acknowledged before canceled backend joined")
	default:
	}
	close(release)
	if err := <-ack; err != nil {
		t.Fatal(err)
	}
	if err := e.Submit(request(3)); err != nil {
		t.Fatal("acknowledgment did not release capacity", err)
	}
	next(t, e)
}
