// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"bytes"
	"encoding/binary"
	"io"
	"testing"
)

func TestRepliesResolveOutOfOrderDirections(t *testing.T) {
	pending := map[uint32]Request{
		1: {Command: CmdSubmit, Sequence: 1, Direction: 1, TransferLength: 3, PacketCount: -1},
		2: {Command: CmdSubmit, Sequence: 2, Direction: 0, TransferLength: 3, PacketCount: -1},
		3: {Command: CmdUnlink, Sequence: 3, UnlinkSequence: 1},
	}
	lookup := func(seq uint32) (Request, bool) { r, ok := pending[seq]; return r, ok }
	second, _ := EncodeSubmitReply(pending[2], 0, 3, nil)
	first, _ := EncodeSubmitReply(pending[1], 0, 3, []byte{1, 2, 3})
	stream := &oneByte{bytes.NewReader(append(append(second, first...), EncodeUnlinkReply(3, 0)...))}
	r, err := ReadReply(stream, lookup)
	if err != nil || r.Sequence != 2 || len(r.Data) != 0 || r.ActualLength != 3 {
		t.Fatal(r, err)
	}
	r, err = ReadReply(stream, lookup)
	if err != nil || r.Sequence != 1 || !bytes.Equal(r.Data, []byte{1, 2, 3}) {
		t.Fatal(r, err)
	}
	r, err = ReadReply(stream, lookup)
	if err != nil || r.Command != RetUnlink || r.Sequence != 3 {
		t.Fatal(r, err)
	}
	if _, err = ReadReply(stream, lookup); err != io.EOF {
		t.Fatal(err)
	}
	if len(pending) != 3 {
		t.Fatal("codec retired pending requests")
	}
}
func TestReplyRejectsUnknownOversizedAndTruncated(t *testing.T) {
	req := Request{Command: CmdSubmit, Sequence: 1, Direction: 1, TransferLength: 3, PacketCount: -1}
	lookup := func(seq uint32) (Request, bool) { return req, seq == 1 }
	base, _ := EncodeSubmitReply(req, 0, 3, []byte{1, 2, 3})
	for _, change := range []func([]byte){
		func(b []byte) { binary.BigEndian.PutUint32(b[4:8], 99) },
		func(b []byte) { binary.BigEndian.PutUint32(b[24:28], 4) },
		func(b []byte) { binary.BigEndian.PutUint32(b[24:28], 0xffffffff) },
		func(b []byte) { binary.BigEndian.PutUint32(b[32:36], 2) },
		func(b []byte) { b[8] = 1 }, func(b []byte) { b[40] = 1 },
	} {
		b := append([]byte(nil), base...)
		change(b)
		if _, err := ReadReply(bytes.NewReader(b), lookup); err == nil {
			t.Fatal("invalid reply accepted")
		}
	}
	for _, n := range []int{48, 49, 50} {
		if _, err := ReadReply(bytes.NewReader(base[:n]), lookup); err != io.ErrUnexpectedEOF {
			t.Fatal(n, err)
		}
	}
	if _, err := ReadReply(bytes.NewReader(EncodeUnlinkReply(1, 0)), lookup); err == nil {
		t.Fatal("wrong reply kind")
	}
}
func FuzzReply(f *testing.F) {
	request := Request{Command: CmdSubmit, Sequence: 1, Direction: 1, TransferLength: MaxTransfer, PacketCount: -1}
	seed, _ := EncodeSubmitReply(request, 0, 3, []byte{1, 2, 3})
	f.Add(seed)
	f.Fuzz(func(t *testing.T, b []byte) {
		if len(b) > MaxTransfer+HeaderSize {
			return
		}
		r, err := ReadReply(bytes.NewReader(b), func(seq uint32) (Request, bool) { return request, seq == 1 })
		if err != nil {
			return
		}
		if r.Sequence != 1 || r.ActualLength < 0 || int(r.ActualLength) != len(r.Data) || len(r.Data) > MaxTransfer {
			t.Fatal("unbounded or mismatched reply")
		}
	})
}
