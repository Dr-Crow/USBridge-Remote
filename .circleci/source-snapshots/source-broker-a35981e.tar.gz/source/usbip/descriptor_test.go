// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"testing"
)

func descriptorVector() []byte {
	return []byte{18, 1, 0, 2, 0, 0, 0, 64, 0x34, 0x12, 0xcd, 0xab, 0, 1, 1, 2, 3, 1}
}
func TestParseDeviceDescriptor(t *testing.T) {
	p := descriptorVector()
	d, err := ParseDeviceDescriptor(p)
	if err != nil || d.USBVersion != 0x200 || d.VendorID != 0x1234 || d.ProductID != 0xabcd || d.DeviceVersion != 0x100 || d.SerialIndex != 3 {
		t.Fatal(d, err)
	}
	for n := 0; n < 18; n++ {
		if _, err := ParseDeviceDescriptor(p[:n]); err == nil {
			t.Fatal("accepted truncation", n)
		}
	}
	for _, bad := range [][]byte{append(append([]byte(nil), p...), 0), append([]byte{17}, p[1:]...), append([]byte{18, 2}, p[2:]...)} {
		if _, err := ParseDeviceDescriptor(bad); err == nil {
			t.Fatal("accepted invalid descriptor")
		}
	}
}
func TestImportedDeviceDescriptorRequest(t *testing.T) {
	for _, tc := range []struct {
		name      string
		status    int32
		data      []byte
		wantError bool
	}{
		{"valid", 0, descriptorVector(), false}, {"stall", -32, nil, true}, {"short", 0, descriptorVector()[:8], true}, {"wrong-type", 0, make([]byte, 18), true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			registry := fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
				return sampleDevice(), &fakeDevice{transfer: func(_ context.Context, r Request) (TransferResult, error) {
					if r.Command != CmdSubmit || r.Endpoint != 0 || r.Direction != 1 || r.TransferLength != 18 || r.Setup != [8]byte{0x80, 6, 0, 1, 0, 0, 18, 0} || len(r.Data) != 0 {
						t.Errorf("unexpected descriptor request: %+v", r)
					}
					return TransferResult{Status: tc.status, ActualLength: int32(len(tc.data)), Data: tc.data}, nil
				}}, nil
			}}
			conn, done := serviceFixture(t, registry, allowTestOwner)
			d, err := ImportDevice(context.Background(), conn, "1-2")
			if err != nil {
				t.Fatal(err)
			}
			got, err := d.ReadDeviceDescriptor(context.Background())
			if (err != nil) != tc.wantError {
				t.Fatal(got, err)
			}
			d.Close()
			_ = awaitSession(t, done)
		})
	}
}

// FuzzParseDeviceDescriptor covers the untrusted descriptor returned by a
// selected device. A valid envelope permits every byte-valued device field.
func FuzzParseDeviceDescriptor(f *testing.F) {
	f.Add(descriptorVector())
	f.Add([]byte{})
	f.Add(make([]byte, 18))
	f.Fuzz(func(t *testing.T, p []byte) {
		d, err := ParseDeviceDescriptor(p)
		valid := len(p) == 18 && p[0] == 18 && p[1] == 1
		if (err == nil) != valid {
			t.Fatalf("envelope acceptance mismatch: size=%d error=%v", len(p), err)
		}
		if err != nil {
			return
		}
		// Reconstruct all fields independently to check byte order and offsets.
		q := []byte{18, 1, byte(d.USBVersion), byte(d.USBVersion >> 8),
			d.Class, d.Subclass, d.Protocol, d.MaxPacketSize0,
			byte(d.VendorID), byte(d.VendorID >> 8), byte(d.ProductID), byte(d.ProductID >> 8),
			byte(d.DeviceVersion), byte(d.DeviceVersion >> 8), d.ManufacturerIndex,
			d.ProductIndex, d.SerialIndex, d.ConfigurationCount}
		for i := range p {
			if p[i] != q[i] {
				t.Fatalf("descriptor byte %d differs", i)
			}
		}
	})
}
