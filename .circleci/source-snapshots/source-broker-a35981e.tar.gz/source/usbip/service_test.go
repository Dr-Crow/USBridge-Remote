// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"errors"
	"net"
	"sync/atomic"
	"testing"
	"time"
)

type fakeRegistry struct {
	list func(context.Context, string) ([]DeviceDescription, error)
	open func(context.Context, string, string) (DeviceDescription, DeviceBackend, error)
}

func (r fakeRegistry) List(c context.Context, p string) ([]DeviceDescription, error) {
	return r.list(c, p)
}
func (r fakeRegistry) Open(c context.Context, p, b string) (DeviceDescription, DeviceBackend, error) {
	return r.open(c, p, b)
}
func serviceFixture(t *testing.T, r Registry, a AuthorizeDeviceSession) (net.Conn, <-chan error) {
	t.Helper()
	s, c := net.Pipe()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	done := make(chan error, 1)
	go func() { done <- ServeDeviceSession(ctx, s, "paired-test-owner", r, a, 2) }()
	_ = c.SetDeadline(time.Now().Add(2 * time.Second))
	t.Cleanup(func() { cancel(); _ = c.Close() })
	return c, done
}
func allowTestOwner(_ context.Context, p string) error {
	if p != "paired-test-owner" {
		return errors.New("wrong owner")
	}
	return nil
}
func sendNegotiation(t *testing.T, c net.Conn, q NegotiationRequest) {
	t.Helper()
	b, err := EncodeNegotiationRequest(q)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = c.Write(b); err != nil {
		t.Fatal(err)
	}
}
func TestServiceDeviceList(t *testing.T) {
	c, done := serviceFixture(t, fakeRegistry{list: func(_ context.Context, p string) ([]DeviceDescription, error) {
		if p != "paired-test-owner" {
			t.Error(p)
		}
		return []DeviceDescription{sampleDevice()}, nil
	}}, allowTestOwner)
	sendNegotiation(t, c, NegotiationRequest{Code: RequestDeviceList})
	ds, err := ReadDeviceListReply(c)
	if err != nil || len(ds) != 1 || ds[0].BusID != "1-2" {
		t.Fatal(ds, err)
	}
	if err := awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
}
func TestServiceImportThenTransfer(t *testing.T) {
	var closed atomic.Int32
	r := fakeRegistry{open: func(_ context.Context, p, b string) (DeviceDescription, DeviceBackend, error) {
		if p != "paired-test-owner" || b != "1-2" {
			t.Error(p, b)
		}
		return sampleDevice(), &fakeDevice{transfer: func(context.Context, Request) (TransferResult, error) {
			return TransferResult{ActualLength: 1, Data: []byte{9}}, nil
		}, close: func() error { closed.Add(1); return nil }}, nil
	}}
	c, done := serviceFixture(t, r, allowTestOwner)
	sendNegotiation(t, c, NegotiationRequest{Code: RequestImport, BusID: "1-2"})
	d, status, err := ReadImportReply(c)
	if err != nil || status != 0 || d.BusID != "1-2" {
		t.Fatal(d, status, err)
	}
	req := request(1)
	req.Device = 1<<16 | 2
	sendRequest(t, c, req)
	reply, err := ReadReply(c, func(uint32) (Request, bool) { return req, true })
	if err != nil || reply.ActualLength != 1 || reply.Data[0] != 9 {
		t.Fatal(reply, err)
	}
	_ = c.Close()
	if err = awaitSession(t, done); err != nil {
		t.Fatal(err)
	}
	if closed.Load() != 1 {
		t.Fatal("backend close count", closed.Load())
	}
}
func TestServiceDeniedDoesNotAccessRegistry(t *testing.T) {
	denied := errors.New("denied")
	r := fakeRegistry{list: func(context.Context, string) ([]DeviceDescription, error) {
		t.Error("unauthorized list")
		return nil, nil
	}}
	c, done := serviceFixture(t, r, func(context.Context, string) error { return denied })
	if err := awaitSession(t, done); !errors.Is(err, denied) {
		t.Fatal(err)
	}
	var b [1]byte
	if n, _ := c.Read(b[:]); n != 0 {
		t.Fatal("unauthorized response")
	}
}
func TestServiceOpenFailureClosesPartialBackend(t *testing.T) {
	var closed atomic.Int32
	failed := errors.New("claim failed")
	c, done := serviceFixture(t, fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return DeviceDescription{}, &fakeDevice{close: func() error { closed.Add(1); return nil }}, failed
	}}, allowTestOwner)
	sendNegotiation(t, c, NegotiationRequest{Code: RequestImport, BusID: "1-2"})
	d, status, err := ReadImportReply(c)
	if err != nil || status != 1 || d != nil {
		t.Fatal(d, status, err)
	}
	if err := awaitSession(t, done); !errors.Is(err, failed) || closed.Load() != 1 {
		t.Fatal(err, closed.Load())
	}
}
func TestServiceRechecksAccessAfterClaim(t *testing.T) {
	var calls, closed atomic.Int32
	denied := errors.New("revoked")
	c, done := serviceFixture(t, fakeRegistry{open: func(context.Context, string, string) (DeviceDescription, DeviceBackend, error) {
		return sampleDevice(), &fakeDevice{close: func() error { closed.Add(1); return nil }}, nil
	}}, func(context.Context, string) error {
		if calls.Add(1) == 3 {
			return denied
		}
		return nil
	})
	sendNegotiation(t, c, NegotiationRequest{Code: RequestImport, BusID: "1-2"})
	if err := awaitSession(t, done); !errors.Is(err, denied) || closed.Load() != 1 {
		t.Fatal(err, closed.Load())
	}
	var b [1]byte
	if n, _ := c.Read(b[:]); n != 0 {
		t.Fatal("revoked claim advertised")
	}
}
