// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
)

type Reply struct {
	Command, Sequence                                         uint32
	Status, ActualLength, StartFrame, PacketCount, ErrorCount int32
	Data                                                      []byte
}

// Lookup returns a snapshot of an already-pending request. It must be safe for
// the caller's concurrency model; ReadReply does not mutate or retire requests.
// A dispatcher must atomically resolve completion versus cancellation separately.
type Lookup func(sequence uint32) (Request, bool)

// ReadReply resolves direction and bounds from the matching pending request,
// not the response's zeroed direction field. Replies may arrive out of order.
// No allocation occurs until the response is matched and its length validated.
// An invalid/unknown response is fatal to the stream, not a resync opportunity.
func ReadReply(reader io.Reader, lookup Lookup) (Reply, error) {
	if reader == nil || lookup == nil {
		return Reply{}, errors.New("reader and pending lookup required")
	}
	var h [HeaderSize]byte
	if _, err := io.ReadFull(reader, h[:]); err != nil {
		return Reply{}, err
	}
	u := func(at int) uint32 { return binary.BigEndian.Uint32(h[at : at+4]) }
	response := Reply{Command: u(0), Sequence: u(4), Status: int32(u(20))}
	if response.Command != RetSubmit && response.Command != RetUnlink {
		return Reply{}, errors.New("unsupported reply")
	}
	if !bytes.Equal(h[8:20], make([]byte, 12)) {
		return Reply{}, errors.New("nonzero reply device/direction/endpoint")
	}
	request, ok := lookup(response.Sequence)
	if !ok || request.Sequence != response.Sequence {
		return Reply{}, errors.New("unknown reply sequence")
	}
	if err := validate(request); err != nil {
		return Reply{}, err
	}
	if response.Command == RetUnlink {
		if request.Command != CmdUnlink || !bytes.Equal(h[24:], make([]byte, 24)) {
			return Reply{}, errors.New("invalid unlink reply")
		}
		return response, nil
	}
	if request.Command != CmdSubmit {
		return Reply{}, errors.New("reply kind does not match pending request")
	}
	response.ActualLength = int32(u(24))
	response.StartFrame = int32(u(28))
	response.PacketCount = int32(u(32))
	response.ErrorCount = int32(u(36))
	if response.ActualLength < 0 || response.ActualLength > request.TransferLength {
		return Reply{}, errors.New("reply length exceeds pending request")
	}
	if response.PacketCount != 0 && response.PacketCount != -1 {
		return Reply{}, ErrUnsupportedISO
	}
	if !bytes.Equal(h[40:], make([]byte, 8)) {
		return Reply{}, errors.New("nonzero submit reply padding")
	}
	if request.Direction == 1 && response.ActualLength > 0 {
		response.Data = make([]byte, int(response.ActualLength))
		if _, err := io.ReadFull(reader, response.Data); err != nil {
			if err == io.EOF {
				err = io.ErrUnexpectedEOF
			}
			return Reply{}, err
		}
	}
	return response, nil
}
