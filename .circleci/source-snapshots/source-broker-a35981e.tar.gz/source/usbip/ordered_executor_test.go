// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"encoding/binary"
	"sync"
	"testing"
	"time"
)

type orderedFake struct{ *fakeDevice }

func (*orderedFake) SerializeEndpoints() bool { return true }
func TestOrderedEndpointSubmissionFIFO(t *testing.T) {
	const count = 32
	var mu sync.Mutex
	var seen []uint32
	e := newEngine(t, &orderedFake{&fakeDevice{transfer: func(_ context.Context, r Request) (TransferResult, error) {
		mu.Lock()
		seen = append(seen, r.Sequence)
		mu.Unlock()
		return TransferResult{}, nil
	}}}, count)
	for i := 1; i <= count; i++ {
		r := request(uint32(i))
		r.Endpoint = 3
		if err := e.Submit(r); err != nil {
			t.Fatal(err)
		}
	}
	for i := 1; i <= count; i++ {
		next(t, e)
	}
	mu.Lock()
	defer mu.Unlock()
	if len(seen) != count {
		t.Fatal(seen)
	}
	for i, seq := range seen {
		if seq != uint32(i+1) {
			t.Fatal("native calls reordered", seen)
		}
	}
}
func TestOrderedLaneCancellationDoesNotOvertake(t *testing.T) {
	entered := make(chan uint32, 4)
	release := make(chan struct{})
	e := newEngine(t, &orderedFake{&fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
		entered <- r.Sequence
		if r.Sequence == 1 {
			select {
			case <-release:
			case <-ctx.Done():
				return TransferResult{}, ctx.Err()
			}
		}
		return TransferResult{}, nil
	}}}, 4)
	for _, seq := range []uint32{1, 2, 3} {
		r := request(seq)
		r.Endpoint = 2
		if err := e.Submit(r); err != nil {
			t.Fatal(err)
		}
	}
	if seq := <-entered; seq != 1 {
		t.Fatal(seq)
	}
	// A different endpoint must execute while endpoint two remains blocked.
	r := request(4)
	r.Endpoint = 3
	if err := e.Submit(r); err != nil {
		t.Fatal(err)
	}
	if seq := <-entered; seq != 4 {
		t.Fatal("endpoint head of line blocked unrelated endpoint", seq)
	}
	if c := next(t, e); c.Sequence != 4 {
		t.Fatal(c.Sequence)
	}
	ack := make(chan []byte, 1)
	go func() {
		wire, err := e.Unlink(Request{Command: CmdUnlink, Device: 7, Sequence: 5, UnlinkSequence: 2})
		if err != nil {
			t.Error(err)
		}
		ack <- wire
	}()
	select {
	case wire := <-ack:
		if len(wire) != HeaderSize || int32(binary.BigEndian.Uint32(wire[20:24])) != -104 {
			t.Fatal(wire)
		}
	case <-time.After(time.Second):
		t.Fatal("queued cancellation waited for active endpoint")
	}
	select {
	case seq := <-entered:
		t.Fatal("queued request overtook active operation", seq)
	default:
	}
	close(release)
	if seq := <-entered; seq != 3 {
		t.Fatal("canceled request entered backend", seq)
	}
	for i := 0; i < 2; i++ {
		next(t, e)
	}
	// Next may race with releaseLane's final bookkeeping; Close joins it.
	if err := e.Close(); err != nil {
		t.Fatal(err)
	}
	e.mu.Lock()
	remaining := len(e.lanes)
	e.mu.Unlock()
	if remaining != 0 {
		t.Fatal("lane entries leaked", remaining)
	}
}
func TestOrderedControlLaneSharesDirections(t *testing.T) {
	entered := make(chan uint32, 3)
	release := make(chan struct{})
	e := newEngine(t, &orderedFake{&fakeDevice{transfer: func(ctx context.Context, r Request) (TransferResult, error) {
		entered <- r.Sequence
		if r.Sequence == 1 {
			select {
			case <-release:
			case <-ctx.Done():
				return TransferResult{}, ctx.Err()
			}
		}
		return TransferResult{}, nil
	}}}, 3)
	first := request(1)
	first.Direction = 0
	first.TransferLength = 0
	second := request(2)
	second.TransferLength = 0
	if err := e.Submit(first); err != nil {
		t.Fatal(err)
	}
	if err := e.Submit(second); err != nil {
		t.Fatal(err)
	}
	if seq := <-entered; seq != 1 {
		t.Fatal(seq)
	}
	third := request(3)
	third.Endpoint = 1
	if err := e.Submit(third); err != nil {
		t.Fatal(err)
	}
	if seq := <-entered; seq != 3 {
		t.Fatal("control directions not serialized", seq)
	}
	close(release)
	if seq := <-entered; seq != 2 {
		t.Fatal(seq)
	}
	for i := 0; i < 3; i++ {
		next(t, e)
	}
}
