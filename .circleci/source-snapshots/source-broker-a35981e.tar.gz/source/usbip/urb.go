// SPDX-License-Identifier: GPL-3.0-only
// Analyst-authored bounded non-isochronous USB/IP codec, not a device backend.
package usbip

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
)

const HeaderSize = 48
const MaxTransfer = 1 << 20
const (
	CmdSubmit uint32 = 1
	CmdUnlink uint32 = 2
	RetSubmit uint32 = 3
	RetUnlink uint32 = 4
)

var ErrUnsupportedISO = errors.New("isochronous USB/IP is not implemented")

// Request owns its OUT Data. Flags, setup bytes and timing fields are decoded,
// not authorization to operate a USB device. The backend must validate them.
type Request struct {
	Command, Sequence, Device, Direction, Endpoint    uint32
	Flags                                             uint32
	TransferLength, StartFrame, PacketCount, Interval int32
	Setup                                             [8]byte
	Data                                              []byte
	UnlinkSequence                                    uint32
}

func validate(r Request) error {
	if r.Direction > 1 || r.Endpoint > 15 {
		return errors.New("invalid direction or endpoint")
	}
	switch r.Command {
	case CmdUnlink:
		if r.Endpoint != 0 {
			return errors.New("unlink endpoint must be zero")
		}
	case CmdSubmit:
		if r.TransferLength < 0 || r.TransferLength > MaxTransfer {
			return errors.New("transfer exceeds bounded profile")
		}
		if r.PacketCount != 0 && r.PacketCount != -1 {
			return ErrUnsupportedISO
		}
	default:
		return errors.New("unsupported USB/IP command")
	}
	return nil
}

// ReadRequest reads one request after import, preserving following bytes. A
// malformed/unsupported header is fatal to the stream; callers must not attempt
// resynchronization. Allocation is bounded before reading an OUT payload.
func ReadRequest(reader io.Reader) (Request, error) {
	if reader == nil {
		return Request{}, errors.New("reader required")
	}
	var h [HeaderSize]byte
	if _, err := io.ReadFull(reader, h[:]); err != nil {
		return Request{}, err
	}
	u := func(at int) uint32 { return binary.BigEndian.Uint32(h[at : at+4]) }
	r := Request{Command: u(0), Sequence: u(4), Device: u(8), Direction: u(12), Endpoint: u(16)}
	switch r.Command {
	case CmdSubmit:
		r.Flags = u(20)
		r.TransferLength = int32(u(24))
		r.StartFrame = int32(u(28))
		r.PacketCount = int32(u(32))
		r.Interval = int32(u(36))
		copy(r.Setup[:], h[40:])
	case CmdUnlink:
		r.UnlinkSequence = u(20)
		if !bytes.Equal(h[24:], make([]byte, 24)) {
			return Request{}, errors.New("nonzero unlink padding")
		}
	}
	if err := validate(r); err != nil {
		return Request{}, err
	}
	if r.Command == CmdSubmit && r.Direction == 0 && r.TransferLength > 0 {
		r.Data = make([]byte, int(r.TransferLength))
		if _, err := io.ReadFull(reader, r.Data); err != nil {
			if err == io.EOF {
				err = io.ErrUnexpectedEOF
			}
			return Request{}, err
		}
	}
	return r, nil
}
func EncodeRequest(r Request) ([]byte, error) {
	if err := validate(r); err != nil {
		return nil, err
	}
	expected := 0
	if r.Command == CmdSubmit && r.Direction == 0 {
		expected = int(r.TransferLength)
	}
	if len(r.Data) != expected {
		return nil, errors.New("request payload length mismatch")
	}
	h := make([]byte, HeaderSize+expected)
	put := func(at int, v uint32) { binary.BigEndian.PutUint32(h[at:at+4], v) }
	put(0, r.Command)
	put(4, r.Sequence)
	put(8, r.Device)
	put(12, r.Direction)
	put(16, r.Endpoint)
	if r.Command == CmdUnlink {
		put(20, r.UnlinkSequence)
	} else {
		put(20, r.Flags)
		put(24, uint32(r.TransferLength))
		put(28, uint32(r.StartFrame))
		put(32, uint32(r.PacketCount))
		put(36, uint32(r.Interval))
		copy(h[40:48], r.Setup[:])
		copy(h[48:], r.Data)
	}
	return h, nil
}

// EncodeSubmitReply serializes the caller's real backend result; it never
// fabricates success. IN carries exactly actualLength bytes, OUT carries none.
func EncodeSubmitReply(request Request, status, actualLength int32, data []byte) ([]byte, error) {
	if request.Command != CmdSubmit {
		return nil, errors.New("submit request required")
	}
	if err := validate(request); err != nil {
		return nil, err
	}
	if actualLength < 0 || actualLength > request.TransferLength {
		return nil, errors.New("actual length exceeds request")
	}
	if (request.Direction == 1 && len(data) != int(actualLength)) || (request.Direction == 0 && len(data) != 0) {
		return nil, errors.New("reply payload length mismatch")
	}
	h := make([]byte, HeaderSize+len(data))
	binary.BigEndian.PutUint32(h[0:4], RetSubmit)
	binary.BigEndian.PutUint32(h[4:8], request.Sequence)
	binary.BigEndian.PutUint32(h[20:24], uint32(status))
	binary.BigEndian.PutUint32(h[24:28], uint32(actualLength))
	binary.BigEndian.PutUint32(h[32:36], uint32(request.PacketCount))
	copy(h[48:], data)
	return h, nil
}
func EncodeUnlinkReply(sequence uint32, status int32) []byte {
	h := make([]byte, HeaderSize)
	binary.BigEndian.PutUint32(h[:4], RetUnlink)
	binary.BigEndian.PutUint32(h[4:8], sequence)
	binary.BigEndian.PutUint32(h[20:24], uint32(status))
	return h
}
