// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"bytes"
	"encoding/binary"
	"encoding/hex"
	"io"
	"reflect"
	"testing"
	"testing/iotest"
)

func sampleDevice() DeviceDescription {
	return DeviceDescription{Path: "/sys/devices/usb1/1-2", BusID: "1-2", Bus: 1, Number: 2, Speed: 3, Vendor: 0x1234, Product: 0xabcd, BCD: 0x100, Class: 3, Configuration: 1, Configurations: 1, InterfaceCount: 1, Interfaces: [][3]byte{{3, 1, 2}}}
}
func TestNegotiationRequests(t *testing.T) {
	for _, q := range []NegotiationRequest{{Code: RequestDeviceList}, {Code: RequestImport, BusID: "1-2"}} {
		b, err := EncodeNegotiationRequest(q)
		if err != nil {
			t.Fatal(err)
		}
		r := bytes.NewReader(append(b, 0xaa))
		got, err := ReadNegotiationRequest(iotest.OneByteReader(r))
		if err != nil || got != q || r.Len() != 1 {
			t.Fatalf("%+v %v remainder%d", got, err, r.Len())
		}
		for n := 0; n < len(b); n++ {
			if _, err := ReadNegotiationRequest(bytes.NewReader(b[:n])); err == nil {
				t.Fatalf("accepted truncated %d", n)
			}
		}
	}
	b, _ := EncodeNegotiationRequest(NegotiationRequest{Code: RequestDeviceList})
	if hex.EncodeToString(b) != "0111800500000000" {
		t.Fatal("wire header")
	}
	for _, b := range [][]byte{{1, 18, 128, 5, 0, 0, 0, 0}, {1, 17, 128, 5, 0, 0, 0, 1}, {1, 17, 128, 6, 0, 0, 0, 0}} {
		if _, err := ReadNegotiationRequest(bytes.NewReader(b)); err == nil {
			t.Fatal("bad header accepted")
		}
	}
	b, _ = EncodeNegotiationRequest(NegotiationRequest{Code: RequestImport, BusID: "1-2"})
	b[12] = 1
	if _, err := ReadNegotiationRequest(bytes.NewReader(b)); err == nil {
		t.Fatal("padding accepted")
	}
}
func TestDeviceNegotiationRoundtrip(t *testing.T) {
	d := sampleDevice()
	b, err := EncodeDeviceListReply([]DeviceDescription{d, d})
	if err != nil {
		t.Fatal(err)
	}
	if len(b) != 12+2*316 || binary.BigEndian.Uint16(b[12+300:]) != d.Vendor {
		t.Fatal("wire offsets")
	}
	r := bytes.NewReader(append(b, 1, 2, 3, 4))
	ds, err := ReadDeviceListReply(iotest.OneByteReader(r))
	if err != nil || !reflect.DeepEqual(ds, []DeviceDescription{d, d}) || r.Len() != 4 {
		t.Fatalf("roundtrip %v", err)
	}
	for n := 0; n < len(b); n++ {
		if _, err := ReadDeviceListReply(bytes.NewReader(b[:n])); err == nil {
			t.Fatalf("truncated list %d", n)
		}
	}
	x, err := EncodeImportReply(0, &d)
	if err != nil || len(x) != 320 {
		t.Fatal(err, len(x))
	}
	r = bytes.NewReader(append(x, 0xbb))
	got, status, err := ReadImportReply(r)
	d.Interfaces = nil
	if err != nil || status != 0 || !reflect.DeepEqual(got, &d) || r.Len() != 1 {
		t.Fatal("import roundtrip", err)
	}
	for n := 0; n < len(x); n++ {
		if _, _, err := ReadImportReply(bytes.NewReader(x[:n])); err == nil {
			t.Fatalf("truncated import %d", n)
		}
	}
	x, _ = EncodeImportReply(1, nil)
	got, status, err = ReadImportReply(bytes.NewReader(x))
	if err != nil || status != 1 || got != nil || len(x) != 8 {
		t.Fatal("failure reply")
	}
}
func TestNegotiationBounds(t *testing.T) {
	b := append(common(ReplyDeviceList, 0), 0, 0, 1, 1)
	if _, err := ReadDeviceListReply(bytes.NewReader(b)); err == nil {
		t.Fatal("count")
	}
	d := sampleDevice()
	d.InterfaceCount = 2
	if _, err := EncodeDeviceListReply([]DeviceDescription{d}); err == nil {
		t.Fatal("interfaces")
	}
	d = sampleDevice()
	b, _ = EncodeDeviceListReply([]DeviceDescription{d})
	b[len(b)-1] = 1
	if _, err := ReadDeviceListReply(bytes.NewReader(b)); err == nil {
		t.Fatal("padding")
	}
	for _, q := range []NegotiationRequest{{Code: RequestImport}, {Code: RequestImport, BusID: string(make([]byte, 32))}, {Code: RequestDeviceList, BusID: "1"}, {Code: 99}} {
		if _, err := EncodeNegotiationRequest(q); err == nil {
			t.Fatal("invalid request")
		}
	}
	if _, err := EncodeImportReply(0, nil); err == nil {
		t.Fatal("missing success body")
	}
	if _, err := EncodeImportReply(1, &d); err == nil {
		t.Fatal("unexpected failure body")
	}
	if _, err := ReadNegotiationRequest(nil); err == nil {
		t.Fatal("nil reader")
	}
	if _, err := ReadNegotiationRequest(bytes.NewReader([]byte{1, 17, 128, 3, 0, 0, 0, 0})); err != io.ErrUnexpectedEOF {
		t.Fatal(err)
	}
}
func FuzzNegotiation(f *testing.F) {
	d := sampleDevice()
	b, _ := EncodeDeviceListReply([]DeviceDescription{d})
	f.Add(byte(0), b)
	b, _ = EncodeImportReply(0, &d)
	f.Add(byte(1), b)
	b, _ = EncodeNegotiationRequest(NegotiationRequest{Code: RequestImport, BusID: "1-2"})
	f.Add(byte(2), b)
	f.Fuzz(func(t *testing.T, kind byte, b []byte) {
		r := bytes.NewReader(b)
		switch kind % 3 {
		case 0:
			ds, err := ReadDeviceListReply(r)
			if err == nil {
				x, err := EncodeDeviceListReply(ds)
				if err != nil || !bytes.Equal(x, b[:len(b)-r.Len()]) {
					t.Fatal("list roundtrip")
				}
			}
		case 1:
			d, s, err := ReadImportReply(r)
			if err == nil {
				x, err := EncodeImportReply(s, d)
				if err != nil || !bytes.Equal(x, b[:len(b)-r.Len()]) {
					t.Fatal("import roundtrip")
				}
			}
		case 2:
			q, err := ReadNegotiationRequest(r)
			if err == nil {
				x, err := EncodeNegotiationRequest(q)
				if err != nil || !bytes.Equal(x, b[:len(b)-r.Len()]) {
					t.Fatal("request roundtrip")
				}
			}
		}
	})
}
