// SPDX-License-Identifier: GPL-3.0-only
package brokersession

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

func goodConfig() Config {
	return Config{Version: 1, Address: "127.0.0.1:1234", CertificateFile: filepath.Join(os.TempDir(), "client.pem"), KeyFile: filepath.Join(os.TempDir(), "client.key"), CAFile: filepath.Join(os.TempDir(), "ca.pem"), ServerName: "localhost", ServerPin: strings.Repeat("01", 32), BusID: "1-2", Consent: true, Capacity: 2}
}

type fakeSessionDevice struct {
	transfer func(context.Context, usbip.Request) (usbip.Reply, error)
	closed   atomic.Bool
}

func (d *fakeSessionDevice) Description() usbip.DeviceDescription {
	return usbip.DeviceDescription{BusID: "1-2", Bus: 1, Number: 2}
}
func (d *fakeSessionDevice) Transfer(ctx context.Context, r usbip.Request) (usbip.Reply, error) {
	return d.transfer(ctx, r)
}
func (d *fakeSessionDevice) Close() error { d.closed.Store(true); return nil }

func TestRejectConfigBeforeOpening(t *testing.T) {
	for _, change := range []func(*Config){func(c *Config) { c.Consent = false }, func(c *Config) { c.Version = 2 }, func(c *Config) { c.Capacity = 17 }, func(c *Config) { c.Address = "example.com:1234" }, func(c *Config) { c.Address = "8.8.8.8:1234" }, func(c *Config) { c.ServerPin = strings.Repeat("0", 64) }, func(c *Config) { c.KeyFile = "relative.key" }} {
		c := goodConfig()
		change(&c)
		b, _ := json.Marshal(c)
		var out bytes.Buffer
		err := run(context.Background(), io.NopCloser(bytes.NewReader(b)), &out, func(context.Context, Config) (sessionDevice, error) {
			t.Fatal("invalid configuration opened device")
			return nil, nil
		})
		if err == nil || !strings.Contains(out.String(), "invalid_config") {
			t.Fatal(err, out.String())
		}
	}
}
func TestStrictJSON(t *testing.T) {
	for _, s := range []string{`{"op":"close","op":"transfer"}`, `{"Op":"close"}`, `{"op":"close","unknown":0}`, `{"op":"close"} {}`, `[]`, `null`, strings.Repeat(" ", MaxLine+1)} {
		var c command
		if err := decodeObject([]byte(s), &c); err == nil {
			t.Fatal("accepted", s[:min(len(s), 100)])
		}
	}
	var c command
	if err := decodeObject([]byte(`{"op":"close"}`), &c); err != nil {
		t.Fatal(err)
	}
}
func TestTransferValidation(t *testing.T) {
	for _, s := range []string{`{"op":"transfer","id":"a","direction":1,"endpoint":1,"length":16385}`, `{"op":"transfer","id":"a","direction":1,"endpoint":1,"length":-1}`, `{"op":"transfer","id":"a","direction":0,"endpoint":1,"length":1}`, `{"op":"transfer","id":"a","direction":1,"endpoint":1,"length":1,"data":"YQ=="}`, `{"op":"transfer","id":"a","direction":1,"endpoint":1}`, `{"op":"transfer","id":"a","direction":1,"endpoint":16,"length":0}`, `{"op":"transfer","id":"a","direction":1,"endpoint":0,"length":0,"setup":[0,0,0,0,0,0,0,0,0]}`, `{"op":"transfer","id":"a","direction":1,"endpoint":0,"length":0,"setup":[256,0,0,0,0,0,0,0]}`} {
		var c command
		if err := decodeObject([]byte(s), &c); err != nil {
			t.Fatal(err)
		}
		if _, err := c.request(); err == nil {
			t.Fatal("accepted", s)
		}
	}
}
func TestLifecycleCancelCapacityAndEOF(t *testing.T) {
	input, commands := io.Pipe()
	output, events := io.Pipe()
	defer output.Close()
	defer commands.Close()
	started := make(chan uint32, 3)
	var active atomic.Int32
	d := &fakeSessionDevice{transfer: func(ctx context.Context, r usbip.Request) (usbip.Reply, error) {
		active.Add(1)
		defer active.Add(-1)
		started <- r.Endpoint
		if r.Endpoint == 1 {
			<-ctx.Done()
			return usbip.Reply{}, ctx.Err()
		}
		return usbip.Reply{Status: 0, ActualLength: 1, Data: []byte{9}}, nil
	}}
	runCtx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() {
		done <- run(runCtx, input, events, func(context.Context, Config) (sessionDevice, error) { return d, nil })
		events.Close()
	}()
	encoder := json.NewEncoder(commands)
	reader := bufio.NewReader(output)
	receive := func() map[string]any {
		t.Helper()
		line, err := reader.ReadBytes('\n')
		if err != nil {
			t.Fatal(err)
		}
		var value map[string]any
		if json.Unmarshal(line, &value) != nil {
			t.Fatal(string(line))
		}
		return value
	}
	if err := encoder.Encode(goodConfig()); err != nil {
		t.Fatal(err)
	}
	if e := receive(); e["event"] != "ready" || e["os_attached"] != false || e["role"] != "usbip-importer-client" {
		t.Fatal(e)
	}
	commands.Write([]byte("{\"op\":\"transfer\",\"id\":\"one\",\"direction\":1,\"endpoint\":1,\"length\":1}\n"))
	<-started
	commands.Write([]byte("{\"op\":\"transfer\",\"id\":\"one\",\"direction\":1,\"endpoint\":1,\"length\":1}\n"))
	if e := receive(); e["error"] != "duplicate_transfer" {
		t.Fatal(e)
	}
	commands.Write([]byte("{\"op\":\"transfer\",\"id\":\"two\",\"direction\":1,\"endpoint\":2,\"length\":1}\n"))
	<-started
	if e := receive(); e["event"] != "complete" || e["id"] != "two" || e["data"] != "CQ==" {
		t.Fatal(e)
	}
	commands.Write([]byte("{\"op\":\"cancel\",\"id\":\"one\"}\n"))
	if e := receive(); e["event"] != "cancel_requested" {
		t.Fatal(e)
	}
	if e := receive(); e["event"] != "complete" || e["error"] != "canceled" {
		t.Fatal(e)
	}
	commands.Close()
	if e := receive(); e["event"] != "stopped" || !d.closed.Load() || active.Load() != 0 {
		t.Fatal(e, d.closed.Load(), active.Load())
	}
	if err := <-done; err != nil {
		t.Fatal(err)
	}
}
func TestOutputFailureJoins(t *testing.T) {
	config, _ := json.Marshal(goodConfig())
	d := &fakeSessionDevice{}
	err := run(context.Background(), io.NopCloser(bytes.NewReader(config)), failWriter{}, func(context.Context, Config) (sessionDevice, error) { return d, nil })
	if err == nil || !d.closed.Load() {
		t.Fatal(err, d.closed.Load())
	}
}

type failWriter struct{}

func (failWriter) Write([]byte) (int, error) { return 0, errors.New("closed output") }
func FuzzSessionCommand(f *testing.F) {
	f.Add([]byte(`{"op":"transfer","id":"a","direction":1,"endpoint":1,"length":1}`))
	f.Add([]byte(`{"op":"cancel","id":"a"}`))
	f.Fuzz(func(t *testing.T, b []byte) {
		if len(b) > MaxLine {
			return
		}
		var c command
		if decodeObject(b, &c) != nil {
			return
		}
		if c.Op == "transfer" {
			r, err := c.request()
			if err == nil {
				if r.TransferLength > MaxPayload {
					t.Fatal("unbounded request")
				}
				if _, err := usbip.EncodeRequest(r); err != nil {
					t.Fatal(err)
				}
			}
		}
	})
}

func TestProcessIODoesNotJoinBlockedInheritedStdin(t *testing.T) {
	input, commands := io.Pipe()
	defer input.Close()
	defer commands.Close()
	var output bytes.Buffer
	device := &fakeSessionDevice{}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() {
		done <- runIO(ctx, io.NopCloser(input), &output, func(context.Context, Config) (sessionDevice, error) { return device, nil }, false)
	}()
	config, _ := json.Marshal(goodConfig())
	data := append(config, []byte("\n{\"op\":\"close\"}\n")...)
	if _, err := commands.Write(data); err != nil {
		t.Fatal(err)
	}
	select {
	case err := <-done:
		if err != nil || !device.closed.Load() || !strings.Contains(output.String(), "stopped") {
			t.Fatal(err, output.String())
		}
	case <-time.After(time.Second):
		t.Fatal("process runner waited for next stdin read")
	}
}
