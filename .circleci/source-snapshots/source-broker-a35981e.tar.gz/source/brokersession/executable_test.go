// SPDX-License-Identifier: GPL-3.0-only
package brokersession_test

import (
	"bufio"
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"math/big"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sync/atomic"
	"testing"
	"time"

	"github.com/Dr-Crow/usbridge-usb-broker-research/source/brokersession"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/localtls"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

func sessionIdentities(t *testing.T) (tls.Certificate, tls.Certificate, []byte, *x509.CertPool) {
	t.Helper()
	pub, key, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	root := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "ephemeral session CA"}, NotBefore: time.Now().Add(-time.Minute), NotAfter: time.Now().Add(time.Hour), IsCA: true, BasicConstraintsValid: true, KeyUsage: x509.KeyUsageCertSign | x509.KeyUsageDigitalSignature}
	der, err := x509.CreateCertificate(rand.Reader, root, root, pub, key)
	if err != nil {
		t.Fatal(err)
	}
	ca, err := x509.ParseCertificate(der)
	if err != nil {
		t.Fatal(err)
	}
	pool := x509.NewCertPool()
	pool.AddCert(ca)
	leaf := func(serial int64, usage x509.ExtKeyUsage) tls.Certificate {
		p, k, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			t.Fatal(err)
		}
		tpl := &x509.Certificate{SerialNumber: big.NewInt(serial), Subject: pkix.Name{CommonName: "ephemeral session leaf"}, DNSNames: []string{"localhost"}, NotBefore: root.NotBefore, NotAfter: root.NotAfter, KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{usage}}
		d, err := x509.CreateCertificate(rand.Reader, tpl, ca, p, key)
		if err != nil {
			t.Fatal(err)
		}
		return tls.Certificate{Certificate: [][]byte{d}, PrivateKey: k}
	}
	return leaf(2, x509.ExtKeyUsageServerAuth), leaf(3, x509.ExtKeyUsageClientAuth), der, pool
}

type syntheticRegistry struct {
	entered chan struct{}
	closed  atomic.Int32
}

func (r *syntheticRegistry) List(context.Context, string) ([]usbip.DeviceDescription, error) {
	return nil, nil
}
func (r *syntheticRegistry) Open(_ context.Context, _ string, id string) (usbip.DeviceDescription, usbip.DeviceBackend, error) {
	if id != "1-2" {
		return usbip.DeviceDescription{}, nil, errors.New("not authorized")
	}
	return usbip.DeviceDescription{BusID: "1-2", Bus: 1, Number: 2, InterfaceCount: 1}, r, nil
}
func (r *syntheticRegistry) Transfer(ctx context.Context, q usbip.Request) (usbip.TransferResult, error) {
	if q.Endpoint == 1 {
		close(r.entered)
		<-ctx.Done()
		return usbip.TransferResult{}, ctx.Err()
	}
	return usbip.TransferResult{ActualLength: 1, Data: []byte{8}}, nil
}
func (r *syntheticRegistry) Close() error { r.closed.Add(1); return nil }

// Runs on native Windows, macOS or Linux with the executable built by that host.
// The service and backend are pure Go; no libusb, driver or physical USB is used.
func TestPortableSessionExecutableMutualTLS(t *testing.T) { testPortableSession(t, "") }

func TestPortableAgentBrokerSessionMutualTLS(t *testing.T) {
	agent := os.Getenv("AGENT_SOURCE_BINARY")
	if agent == "" {
		t.Skip("AGENT_SOURCE_BINARY enables verified real agent supervision")
	}
	testPortableSession(t, agent)
}

func testPortableSession(t *testing.T, agent string) {
	binary := os.Getenv("BROKER_SESSION_BINARY")
	if binary == "" {
		t.Skip("build script supplies exact BROKER_SESSION_BINARY")
	}
	server, client, ca, pool := sessionIdentities(t)
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	registry := &syntheticRegistry{entered: make(chan struct{})}
	serverDone := make(chan error, 1)
	go func() {
		serverDone <- localtls.ServeTLS(ctx, listener, server, pool, sha256.Sum256(client.Certificate[0]), registry)
	}()
	dir := t.TempDir()
	write := func(name string, b []byte) string {
		p := filepath.Join(dir, name)
		if err := os.WriteFile(p, b, 0600); err != nil {
			t.Fatal(err)
		}
		return p
	}
	key, err := x509.MarshalPKCS8PrivateKey(client.PrivateKey)
	if err != nil {
		t.Fatal(err)
	}
	pin := sha256.Sum256(server.Certificate[0])
	config := brokersession.Config{Version: 1, Address: listener.Addr().String(), CertificateFile: write("client.pem", pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: client.Certificate[0]})), KeyFile: write("key.pem", pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: key})), CAFile: write("ca.pem", pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: ca})), ServerName: "localhost", ServerPin: hex.EncodeToString(pin[:]), BusID: "1-2", Consent: true, Capacity: 2}
	cmd := exec.CommandContext(ctx, binary, "--session-stdin")
	if agent != "" {
		data, err := os.ReadFile(binary)
		if err != nil {
			t.Fatal(err)
		}
		root := filepath.Join(dir, "package")
		if err := os.Mkdir(root, 0700); err != nil {
			t.Fatal(err)
		}
		entry := "broker-session"
		if runtime.GOOS == "windows" {
			entry += ".exe"
		}
		if err := os.WriteFile(filepath.Join(root, entry), data, 0700); err != nil {
			t.Fatal(err)
		}
		sum := sha256.Sum256(data)
		manifest, err := json.Marshal(map[string]any{"schema": 1, "components": []any{map[string]any{"name": "source-broker", "platform": runtime.GOOS + "/" + runtime.GOARCH, "version": "local-acceptance", "profile": "source-broker-v1", "entry": entry, "files": []any{map[string]any{"path": entry, "sha256": hex.EncodeToString(sum[:]), "size": len(data), "executable": true}}}}})
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(root, "manifest.json"), manifest, 0600); err != nil {
			t.Fatal(err)
		}
		manifestSum := sha256.Sum256(manifest)
		cmd = exec.CommandContext(ctx, agent, "--source-broker-mode", "--source-component-directory", root, "--source-manifest-sha256", hex.EncodeToString(manifestSum[:]), "--source-state-dir", filepath.Join(dir, "state"))
	}
	cmd.WaitDelay = time.Second
	stdin, err := cmd.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() {
		stdin.Close()
		if cmd.ProcessState == nil {
			cmd.Process.Kill()
			cmd.Wait()
		}
	}()
	encoder := json.NewEncoder(stdin)
	reader := bufio.NewReader(stdout)
	receive := func() map[string]any {
		t.Helper()
		b, err := reader.ReadBytes('\n')
		if err != nil {
			t.Fatal("event read", err)
		}
		var e map[string]any
		if err := json.Unmarshal(b, &e); err != nil {
			t.Fatal(err)
		}
		return e
	}
	if err := encoder.Encode(config); err != nil {
		t.Fatal(err)
	}
	if e := receive(); e["event"] != "ready" || e["os_attached"] != false || e["role"] != "usbip-importer-client" {
		t.Fatal(e)
	}
	send := func(id string, endpoint int) {
		t.Helper()
		if err := encoder.Encode(map[string]any{"op": "transfer", "id": id, "direction": 1, "endpoint": endpoint, "length": 3}); err != nil {
			t.Fatal(err)
		}
	}
	send("cancel", 1)
	select {
	case <-registry.entered:
	case <-ctx.Done():
		t.Fatal("no backend transfer")
	}
	send("keep", 2)
	if e := receive(); e["event"] != "complete" || e["id"] != "keep" || e["data"] != "CA==" {
		t.Fatal(e)
	}
	if err := encoder.Encode(map[string]any{"op": "cancel", "id": "cancel"}); err != nil {
		t.Fatal(err)
	}
	if e := receive(); e["event"] != "cancel_requested" {
		t.Fatal(e)
	}
	if e := receive(); e["event"] != "complete" || e["error"] != "canceled" {
		t.Fatal(e)
	}
	send("after", 2)
	if e := receive(); e["event"] != "complete" || e["id"] != "after" || e["data"] != "CA==" {
		t.Fatal(e)
	}
	// EOF shutdown is independent of an explicit close command and must join.
	stdin.Close()
	if e := receive(); e["event"] != "stopped" {
		t.Fatal(e)
	}
	if err := cmd.Wait(); err != nil {
		t.Fatal(err, stderr.String())
	}
	cancel()
	select {
	case <-serverDone:
	case <-time.After(time.Second):
		t.Fatal("server did not join")
	}
	if registry.closed.Load() != 1 {
		t.Fatal("backend release count", registry.closed.Load())
	}
}
