module github.com/Dr-Crow/usbridge-usb-broker-research/source

go 1.26.6
