// SPDX-License-Identifier: GPL-3.0-only
package localtls

import (
	"context"
	"errors"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
)

// OpenDevice authenticates an explicitly chosen local server, then imports the
// selected bus ID under server-enforced consent. It does not install a driver,
// attach a device to the OS or discover/select a device automatically.
func OpenDevice(ctx context.Context, address string, identity ClientIdentity, busID string) (*usbip.ImportedDevice, error) {
	if _, err := usbip.EncodeNegotiationRequest(usbip.NegotiationRequest{Code: usbip.RequestImport, BusID: busID}); err != nil {
		return nil, err
	}
	conn, err := Dial(ctx, address, identity)
	if err != nil {
		return nil, err
	}
	d, err := usbip.ImportDevice(ctx, conn, busID)
	if err != nil {
		_ = conn.Close()
	}
	return d, err
}

// OpenConcurrentDevice preserves the same trust and consent checks as
// OpenDevice, with a caller-bounded pipelined transfer dispatcher.
func OpenConcurrentDevice(ctx context.Context, address string, identity ClientIdentity, busID string, capacity int) (*usbip.ConcurrentDevice, error) {
	if capacity < 1 || capacity > 64 {
		return nil, errors.New("capacity 1..64 required")
	}
	if _, err := usbip.EncodeNegotiationRequest(usbip.NegotiationRequest{Code: usbip.RequestImport, BusID: busID}); err != nil {
		return nil, err
	}
	conn, err := Dial(ctx, address, identity)
	if err != nil {
		return nil, err
	}
	d, err := usbip.ImportConcurrentDevice(ctx, conn, busID, capacity)
	if err != nil {
		_ = conn.Close()
	}
	return d, err
}
