// SPDX-License-Identifier: GPL-3.0-only
// Package localtls connects an explicitly selected local broker using mutual TLS.
package localtls

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"net"
	"strconv"
	"time"
)

// ClientIdentity contains operator-provisioned trust. A pin supplements normal
// CA and hostname verification; it never replaces either. No keys are generated.
type ClientIdentity struct {
	Certificate tls.Certificate
	Roots       *x509.CertPool
	ServerName  string
	ServerPin   [32]byte
}

// ValidateAddress permits literal loopback/private IPs only, with an explicit
// nonzero port. It performs no DNS lookup and creates no network connection.
func ValidateAddress(address string) error {
	host, port, err := net.SplitHostPort(address)
	if err != nil {
		return errors.New("literal local IP and port required")
	}
	ip := net.ParseIP(host)
	n, err := strconv.Atoi(port)
	if err != nil || n < 1 || n > 65535 || ip == nil || (!ip.IsLoopback() && !ip.IsPrivate()) {
		return errors.New("literal private/loopback IP and port 1..65535 required")
	}
	return nil
}

// Dial verifies server trust before returning a connection. Authentication must
// also succeed on the server before USB/IP negotiation is allowed. The caller
// owns the returned connection and must set operation deadlines and close it.
func Dial(ctx context.Context, address string, identity ClientIdentity) (*tls.Conn, error) {
	if ctx == nil {
		return nil, errors.New("context required")
	}
	if err := ValidateAddress(address); err != nil {
		return nil, err
	}
	if len(identity.Certificate.Certificate) == 0 || identity.Certificate.PrivateKey == nil || identity.Roots == nil || len(identity.Roots.Subjects()) == 0 || identity.ServerName == "" || identity.ServerPin == [32]byte{} {
		return nil, errors.New("client identity, server CA/name and exact server pin required")
	}
	config := &tls.Config{MinVersion: tls.VersionTLS13, RootCAs: identity.Roots.Clone(), ServerName: identity.ServerName, Certificates: []tls.Certificate{identity.Certificate}}
	config.VerifyConnection = func(state tls.ConnectionState) error {
		if len(state.VerifiedChains) == 0 || len(state.PeerCertificates) == 0 {
			return errors.New("verified server chain required")
		}
		got := sha256.Sum256(state.PeerCertificates[0].Raw)
		if subtle.ConstantTimeCompare(got[:], identity.ServerPin[:]) != 1 {
			return errors.New("server certificate pin mismatch")
		}
		return nil
	}
	bounded, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	raw, err := (&net.Dialer{}).DialContext(bounded, "tcp", address)
	if err != nil {
		return nil, err
	}
	conn := tls.Client(raw, config)
	if err := conn.HandshakeContext(bounded); err != nil {
		_ = conn.Close()
		return nil, err
	}
	return conn, nil
}
