// SPDX-License-Identifier: GPL-3.0-only
package localtls

import (
	"context"
	"testing"
)

func TestLocalAddressPolicy(t *testing.T) {
	for _, address := range []string{"127.0.0.1:3241", "192.168.1.2:3241", "10.1.2.3:3241", "172.16.1.2:3241", "[::1]:3241", "[fd12::1]:3241"} {
		if err := ValidateAddress(address); err != nil {
			t.Fatal(address, err)
		}
	}
	for _, address := range []string{"localhost:3241", "example.com:3241", "0.0.0.0:3241", "8.8.8.8:3241", "100.64.1.2:3241", "169.254.1.2:3241", "224.1.2.3:3241", "[::]:3241", "127.0.0.1:0", "127.0.0.1:65536", "127.0.0.1:-1", "127.0.0.1"} {
		if err := ValidateAddress(address); err == nil {
			t.Fatal(address)
		}
	}
}
func TestIdentityRequiredBeforeDial(t *testing.T) {
	if c, err := Dial(context.Background(), "127.0.0.1:3241", ClientIdentity{}); err == nil || c != nil {
		t.Fatal("missing trust accepted")
	}
}
