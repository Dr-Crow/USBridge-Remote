// SPDX-License-Identifier: GPL-3.0-only
package localtls

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"github.com/Dr-Crow/usbridge-usb-broker-research/source/usbip"
	"log"
	"net"
	"sync"
	"time"
)

// ServeTLS accepts at most eight simultaneous connections. Certificates and the
// exact client certificate fingerprint come from operator provisioning. No keys
// are generated or downloaded. This is an independent TLS transport, not the
// stock USBP encrypted tunnel. The stock agent USBP transport is not used by this API.
func ServeTLS(ctx context.Context, listener net.Listener, certificate tls.Certificate, clientCA *x509.CertPool, clientPin [32]byte, registry usbip.Registry) error {
	if ctx == nil || listener == nil || len(certificate.Certificate) == 0 || clientCA == nil || len(clientCA.Subjects()) == 0 || clientPin == [32]byte{} || registry == nil {
		return errors.New("TLS server identity, client trust and exact client pin required")
	}
	run, cancel := context.WithCancel(ctx)
	var wg sync.WaitGroup
	stop := context.AfterFunc(run, func() { _ = listener.Close() })
	defer func() { cancel(); _ = listener.Close(); stop(); wg.Wait() }()
	config := &tls.Config{MinVersion: tls.VersionTLS13, Certificates: []tls.Certificate{certificate}, ClientAuth: tls.RequireAndVerifyClientCert, ClientCAs: clientCA.Clone()}
	slots := make(chan struct{}, 8)
	for {
		raw, err := listener.Accept()
		if err != nil {
			if run.Err() != nil {
				return run.Err()
			}
			return err
		}
		select {
		case slots <- struct{}{}:
		default:
			_ = raw.Close()
			continue
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			defer func() { <-slots }()
			defer raw.Close()
			c := tls.Server(raw, config)
			handshake, cancelHandshake := context.WithTimeout(run, 5*time.Second)
			err := c.HandshakeContext(handshake)
			cancelHandshake()
			if err != nil {
				log.Print("usb-broker event=tls_handshake_rejected")
				return
			}
			state := c.ConnectionState()
			if len(state.VerifiedChains) == 0 || len(state.PeerCertificates) == 0 {
				return
			}
			got := sha256.Sum256(state.PeerCertificates[0].Raw)
			if subtle.ConstantTimeCompare(got[:], clientPin[:]) != 1 {
				log.Print("usb-broker event=client_pin_rejected")
				return
			}
			principal := string(got[:]) // internal opaque verified identity, never logged
			authorize := func(c context.Context, p string) error {
				if c.Err() != nil {
					return c.Err()
				}
				if p != principal {
					return errors.New("principal mismatch")
				}
				return nil
			}
			if err := usbip.ServeDeviceSession(run, c, principal, registry, authorize, 16); err != nil {
				log.Printf("usb-broker event=session_failed error=%v", err)
			}
		}()
	}
}
