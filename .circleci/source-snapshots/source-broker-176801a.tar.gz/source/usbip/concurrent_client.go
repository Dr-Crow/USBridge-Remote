// SPDX-License-Identifier: GPL-3.0-only
package usbip

import (
	"context"
	"errors"
	"net"
	"sync"
	"time"
)

type pendingTransfer struct {
	request Request
	result  chan Reply
}

// ConcurrentDevice pipelines bounded non-ISO transfers over one imported,
// authenticated connection. Cancellation after a complete SUBMIT sends UNLINK
// and drains its outcome without interrupting unrelated transfers. An incomplete
// write, invalid response or failed cancellation cleanup terminates the session.
type ConcurrentDevice struct {
	conn          net.Conn
	description   DeviceDescription
	mu            sync.Mutex
	next          uint64
	pending       map[uint32]*pendingTransfer
	terminal      error
	done, stopped chan struct{}
	slots, writer chan struct{}
	once          sync.Once
}

// ImportConcurrentDevice preserves ImportDevice's authentication/consent
// preconditions. Capacity must be 1..64 and no larger than the server capacity.
// ctx bounds import only. There is one reader and no per-URB background goroutine.
func ImportConcurrentDevice(ctx context.Context, conn net.Conn, busID string, capacity int) (*ConcurrentDevice, error) {
	if capacity < 1 || capacity > 64 {
		return nil, errors.New("capacity 1..64 required")
	}
	d, err := ImportDevice(ctx, conn, busID)
	if err != nil {
		return nil, err
	}
	c := &ConcurrentDevice{conn: d.conn, description: d.Description(), next: 1, pending: make(map[uint32]*pendingTransfer), done: make(chan struct{}), stopped: make(chan struct{}), slots: make(chan struct{}, capacity), writer: make(chan struct{}, 1)}
	d.closed.Store(true) // ownership moved; no synchronous transfer was started
	go c.readReplies()
	return c, nil
}

// Done closes when this imported connection ends, including idle peer loss.
// Err returns its terminal cause after Done closes and nil while it is live.
func (c *ConcurrentDevice) Done() <-chan struct{} { return c.done }
func (c *ConcurrentDevice) Err() error            { return c.terminalError() }

func (c *ConcurrentDevice) Description() DeviceDescription {
	d := c.description
	d.Interfaces = append([][3]byte(nil), d.Interfaces...)
	return d
}

func (c *ConcurrentDevice) fail(err error) {
	c.once.Do(func() {
		if err == nil {
			err = net.ErrClosed
		}
		c.mu.Lock()
		c.terminal = err
		clear(c.pending)
		c.mu.Unlock()
		close(c.done)
		_ = c.conn.Close()
	})
}
func (c *ConcurrentDevice) terminalError() error { c.mu.Lock(); defer c.mu.Unlock(); return c.terminal }
func (c *ConcurrentDevice) Close() error {
	if c == nil {
		return nil
	}
	c.fail(net.ErrClosed)
	<-c.stopped
	return nil
}
func (c *ConcurrentDevice) readReplies() {
	defer close(c.stopped)
	for {
		reply, err := ReadReply(c.conn, func(seq uint32) (Request, bool) {
			c.mu.Lock()
			defer c.mu.Unlock()
			p, ok := c.pending[seq]
			if !ok {
				return Request{}, false
			}
			return p.request, true
		})
		if err != nil {
			c.fail(err)
			return
		}
		c.mu.Lock()
		p, ok := c.pending[reply.Sequence]
		delete(c.pending, reply.Sequence)
		c.mu.Unlock()
		if !ok {
			c.fail(errors.New("unexpected transfer completion"))
			return
		}
		p.result <- reply // one completion, buffered; consumer may have canceled
	}
}

// register assigns a sequence while the caller holds the writer token, making
// SUBMIT and UNLINK share the same increasing wire order.
func (c *ConcurrentDevice) register(req Request) (*pendingTransfer, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.terminal != nil {
		return nil, c.terminal
	}
	if c.next > 0xffffffff {
		return nil, errors.New("transfer sequence exhausted")
	}
	req.Sequence = uint32(c.next)
	c.next++
	req.Device = c.description.Bus<<16 | c.description.Number
	p := &pendingTransfer{request: req, result: make(chan Reply, 1)}
	c.pending[req.Sequence] = p
	return p, nil
}

// writePending is called with the writer token. A cancellation during the write
// may have left a partial frame, so it must close rather than attempt UNLINK.
func (c *ConcurrentDevice) writePending(ctx context.Context, p *pendingTransfer) error {
	wire, err := EncodeRequest(p.request)
	if err != nil {
		c.fail(err)
		return err
	}
	callbackDone := make(chan struct{})
	stop := context.AfterFunc(ctx, func() { c.fail(ctx.Err()); close(callbackDone) })
	deadline, _ := ctx.Deadline()
	err = c.conn.SetWriteDeadline(deadline)
	if err == nil {
		err = writeAll(c.conn, wire)
	}
	if !stop() {
		<-callbackDone
		return ctx.Err()
	}
	if err != nil {
		c.fail(err)
	}
	return err
}

// retireCanceled retains the original transfer slot until both cancellation
// and any winning completion are resolved. ctx is a fresh, bounded cleanup
// context, independent of the canceled caller. At most one UNLINK per SUBMIT is
// pending, so total pending entries remain at most twice the transfer capacity.
func (c *ConcurrentDevice) retireCanceled(ctx context.Context, original *pendingTransfer) (result error) {
	defer func() {
		if result != nil {
			c.fail(result)
		}
	}()
	select {
	case c.writer <- struct{}{}:
	case <-ctx.Done():
		return ctx.Err()
	case <-c.done:
		return c.terminalError()
	}
	c.mu.Lock()
	stillPending := c.pending[original.request.Sequence] == original
	c.mu.Unlock()
	if !stillPending {
		<-c.writer
		// The reply reader already retired this SUBMIT (or the session failed).
		return nil
	}
	unlink, err := c.register(Request{Command: CmdUnlink, UnlinkSequence: original.request.Sequence})
	if err == nil {
		err = c.writePending(ctx, unlink)
	}
	<-c.writer
	if err != nil {
		return err
	}
	var ack Reply
	select {
	case ack = <-unlink.result:
	case <-ctx.Done():
		return ctx.Err()
	case <-c.done:
		return c.terminalError()
	}
	switch ack.Status {
	case -104: // -ECONNRESET: cancellation won; RET_SUBMIT must be suppressed.
		c.mu.Lock()
		stillPending = c.pending[original.request.Sequence] == original
		delete(c.pending, original.request.Sequence)
		c.mu.Unlock()
		if !stillPending {
			return errors.New("canceled transfer also completed")
		}
		return nil
	case 0: // Completion won. It may precede or follow the UNLINK reply.
		select {
		case <-original.result:
			return nil
		case <-ctx.Done():
			return ctx.Err()
		case <-c.done:
			return c.terminalError()
		}
	default:
		return errors.New("unexpected unlink status")
	}
}

// Transfer assigns ordered connection-wide sequences while allowing replies
// to finish in any order. Caller buffers are copied before transmission. The
// operation lasts at most ten seconds, followed by up to five seconds to settle
// cancellation. Failure to settle cancellation closes all outstanding work.
func (c *ConcurrentDevice) Transfer(ctx context.Context, req Request) (Reply, error) {
	if c == nil || ctx == nil {
		return Reply{}, errors.New("device and context required")
	}
	if req.Command != CmdSubmit || req.Sequence != 0 || req.Device != 0 {
		return Reply{}, errors.New("submit with unassigned sequence/device required")
	}
	if _, err := EncodeRequest(req); err != nil {
		return Reply{}, err
	}
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	select {
	case c.slots <- struct{}{}:
	case <-ctx.Done():
		return Reply{}, ctx.Err()
	case <-c.done:
		return Reply{}, c.terminalError()
	}
	defer func() { <-c.slots }()
	select {
	case c.writer <- struct{}{}:
	case <-ctx.Done():
		return Reply{}, ctx.Err()
	case <-c.done:
		return Reply{}, c.terminalError()
	}
	if err := ctx.Err(); err != nil {
		<-c.writer
		return Reply{}, err
	}
	req.Data = append([]byte(nil), req.Data...)
	p, err := c.register(req)
	if err == nil {
		err = c.writePending(ctx, p)
	}
	<-c.writer
	if err != nil {
		return Reply{}, err
	}
	select {
	case reply := <-p.result:
		return reply, nil
	case <-ctx.Done():
		cleanup, stop := context.WithTimeout(context.Background(), 5*time.Second)
		defer stop()
		err := c.retireCanceled(cleanup, p)
		return Reply{}, errors.Join(ctx.Err(), err)
	case <-c.done:
		return Reply{}, c.terminalError()
	}
}
